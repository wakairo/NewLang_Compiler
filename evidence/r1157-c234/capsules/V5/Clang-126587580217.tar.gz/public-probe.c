#include "newlang/parser.h"
#include "newlang/if_field.h"
#include <stdio.h>
#include <string.h>

static void places(const char *path, const char *phase, const NLSemanticContext *w,
                   const NLIfFieldView *v)
{
    const size_t ids[3] = {v->root, v->child, v->sibling};
    for (size_t k = 0; k < 3; ++k) {
        NLSemanticPlaceView p;
        if (!nl_semantic_place_view(w, ids[k], &p)) continue;
        printf("{\"kind\":\"place\",\"path\":\"%s\",\"phase\":\"%s\",\"role\":%zu,\"place\":%zu,\"inc\":%zu,\"fact\":%zu,\"value\":%zu,\"parent\":%zu,\"index\":%zu,\"live\":%d}\n",
               path, phase, k, ids[k], p.incarnation, p.current_fact,
               p.current_value, p.parent_aggregate, p.parent_field_index, p.live);
    }
}
static int walk(const NLCheckedFragment *f, const char *path, unsigned depth)
{
    if (depth > 8) return 1;
    for (size_t i = 1; i <= nl_checked_node_count(f); ++i) {
        const NLCheckedNodeView *n = nl_checked_node_view(f, i);
        if (!n) continue;
        NLSourceView name = {0};
        const NLSource *source = nl_checked_source(f);
        if (!nl_source_view(source, n->name, &name)) name.length = 0;
        if (name.length > 60) name.length = 0;
        printf("{\"kind\":\"node\",\"path\":\"%s\",\"id\":%zu,\"nodekind\":%d,\"name\":\"%.*s\",\"symbol\":%zu,\"type\":%zu,\"initializer\":%zu,\"copied\":%d,\"field\":%d,\"root\":%zu,\"child\":%zu,\"index\":%zu,\"old\":%zu,\"new\":%zu,\"inductive\":%d,\"backedges\":%zu,\"breaks\":%zu}\n",
               path, i, (int)n->kind, (int)name.length, name.bytes ? (const char *)name.bytes : "",
               n->symbol, n->type, n->initializer, n->value_use == NL_VALUE_COPIED,
               n->field.present, n->field.parent, n->field.child, n->field.index,
               n->field.old_value, n->field.new_value, n->header_inductive,
               n->continue_edges, n->break_edges);
        if (n->kind == NL_CHECKED_IF) {
            NLIfFieldView v;
            if (nl_checked_if_field_view(f, i, &v)) {
                NLCheckStatus valid = nl_checked_if_field_validate(f, i, &v);
                printf("{\"kind\":\"ifview\",\"path\":\"%s\",\"id\":%zu,\"validation\":%d,\"root\":%zu,\"child\":%zu,\"sibling\":%zu,\"index\":%zu,\"inc\":%zu,\"child_inc\":%zu,\"base\":%zu,\"changes0\":%zu,\"changes1\":%zu}\n",
                       path, i, (int)valid, v.root, v.child, v.sibling, v.index,
                       v.incarnation, v.child_incarnation, v.base,
                       v.arms[0].change_count, v.arms[1].change_count);
                if (valid != NL_CHECK_OK) return 2;
                places(path, "entry", v.entry, &v);
                places(path, "post", v.post, &v);
                for (size_t a = 0; a < 2; ++a) {
                    for (size_t e = 0; e < v.arms[a].event_count; ++e) {
                        NLIfFieldEvent event;
                        if (!nl_checked_if_field_event(f, i, a, e, &event)) return 3;
                        NLCheckStatus ok = nl_checked_if_field_event_validate(f, i, a, e, &event);
                        printf("{\"kind\":\"ifevent\",\"arm\":%zu,\"event\":%zu,\"change\":%d,\"validation\":%d,\"root\":%zu,\"child\":%zu,\"index\":%zu,\"old\":%zu,\"incoming\":%zu}\n",
                               a, e, event.change, (int)ok, event.field.parent,
                               event.field.child, event.field.index, event.field.old_value, event.incoming);
                        if (ok != NL_CHECK_OK) return 4;
                    }
                }
            }
            for (size_t a = 0; a < 2; ++a) {
                const NLCheckedFragment *arm = nl_checked_if_arm(f, i, a);
                if (arm) { char next[160]; snprintf(next, sizeof next, "%s/i%zu.%zu", path, i, a);
                    int status = walk(arm, next, depth + 1); if (status) return status; }
            }
        }
        if (n->kind == NL_CHECKED_LOOP) {
            const NLCheckedFragment *body = nl_checked_loop_body(f, i);
            if (body) { char next[160]; snprintf(next, sizeof next, "%s/l%zu", path, i);
                int status = walk(body, next, depth + 1); if (status) return status; }
        }
        if (n->kind == NL_CHECKED_REGISTERED_CALL && n->body_backed) {
            const NLCheckedFragment *body = nl_checked_call_body(f, i);
            if (body) { char next[160]; snprintf(next, sizeof next, "%s/c%zu", path, i);
                int status = walk(body, next, depth + 1); if (status) return status; }
        }
    }
    return 0;
}
int main(int argc, char **argv)
{
    NLSource *source = NULL, *call_source = NULL;
    NLParser *parser = NULL, *call_parser = NULL;
    NLSyntaxTree *tree = NULL, *call_tree = NULL;
    NLSemanticContext *context = NULL;
    NLCheckedFragment *checked = NULL;
    NLParseDiagnostic parse = {0}; NLFunctionUnitDiagnostic unit = {0};
    NLCheckDiagnostic diagnostic = {0};
    int result = 10;
    if (argc != 3 || nl_source_load(argv[1], &source) != NL_SOURCE_OK) goto cleanup;
    if (nl_parser_create(source, &parser) != NL_PARSE_OK) goto cleanup;
    NLParseStatus ps = nl_parser_parse_function_unit(parser, &tree, &parse);
    printf("{\"kind\":\"stage\",\"stage\":\"parse\",\"status\":%d}\n", (int)ps);
    if (ps != NL_PARSE_OK) { nl_parse_diagnostic_render(stderr, source, &parse); goto cleanup; }
    if (nl_semantic_create(&context) != NL_CHECK_OK) goto cleanup;
    const NLSyntaxTree *inputs[] = {tree};
    NLCheckStatus cs = nl_semantic_register_function_unit(context, inputs, 1, &unit);
    printf("{\"kind\":\"stage\",\"stage\":\"register\",\"status\":%d}\n", (int)cs);
    if (cs != NL_CHECK_OK) { nl_check_diagnostic_render(stderr, source, &unit.diagnostic); goto cleanup; }
    const char *call = argv[2];
    if (nl_source_create(call, strlen(call), "<R1157-own-call>", &call_source) != NL_SOURCE_OK) goto cleanup;
    if (nl_parser_create(call_source, &call_parser) != NL_PARSE_OK) goto cleanup;
    if (nl_parser_parse_source_fragment(call_parser, &call_tree, &parse) != NL_PARSE_OK) goto cleanup;
    cs = nl_semantic_check_source_fragment(context, call_tree, &checked, &diagnostic);
    printf("{\"kind\":\"stage\",\"stage\":\"actual_call\",\"status\":%d}\n", (int)cs);
    if (cs != NL_CHECK_OK) { nl_check_diagnostic_render(stderr, call_source, &diagnostic); goto cleanup; }
    result = walk(checked, "actual", 0);
cleanup:
    nl_checked_destroy(checked); nl_semantic_destroy(context);
    nl_syntax_tree_destroy(call_tree); nl_syntax_tree_destroy(tree);
    nl_parser_destroy(call_parser); nl_parser_destroy(parser);
    nl_source_destroy(call_source); nl_source_destroy(source);
    return result;
}
