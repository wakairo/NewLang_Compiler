#include <stdio.h>
#include <limits.h>
/* North Star V0/V1/AVS Checked-C reference output. */
#include <stdint.h>

#include <limits.h>
_Static_assert(CHAR_BIT == 8, "NewLang C17 requires 8-bit bytes");
_Static_assert(UINT8_MAX == 255 && sizeof(uint8_t) == 1 && ((uint8_t)-1) == 255, "NewLang C17 requires exact 8-bit uint8_t");
#include <stddef.h>
_Static_assert(SIZE_MAX == UINTMAX_C(18446744073709551615), "NewLang usize target mismatch");

static void nl_fn_10(void);
static uint8_t nl_fn_13(size_t nl_local_1);
static uint8_t nl_fn_14(size_t nl_local_4);
static uint8_t nl_fn_11(size_t nl_local_6);
static uint8_t nl_fn_12(size_t nl_local_9);

static void nl_fn_10(void)
{
    const uint8_t nl_call_2 = nl_fn_13(((size_t)UINTMAX_C(18446744073709551615)));
    printf("R1120_C219_RESULT nl_fn_13 nl_call_2 %u\n", (unsigned)nl_call_2);
    (void)nl_call_2;
    const uint8_t nl_local_3 = nl_call_2;
    (void)nl_local_3;
    const uint8_t nl_call_6 = nl_fn_14(((size_t)UINTMAX_C(18446744073709551615)));
    printf("R1120_C219_RESULT nl_fn_14 nl_call_6 %u\n", (unsigned)nl_call_6);
    (void)nl_call_6;
    const uint8_t nl_local_5 = nl_call_6;
    (void)nl_local_5;
    const uint8_t nl_call_10 = nl_fn_11(((size_t)UINTMAX_C(18446744073709551615)));
    printf("R1120_C219_RESULT nl_fn_11 nl_call_10 %u\n", (unsigned)nl_call_10);
    (void)nl_call_10;
    const uint8_t nl_local_8 = nl_call_10;
    (void)nl_local_8;
    const uint8_t nl_call_14 = nl_fn_12(((size_t)UINTMAX_C(18446744073709551615)));
    printf("R1120_C219_RESULT nl_fn_12 nl_call_14 %u\n", (unsigned)nl_call_14);
    (void)nl_call_14;
    const uint8_t nl_local_13 = nl_call_14;
    (void)nl_local_13;
    (void)0;
}

static uint8_t nl_fn_13(size_t nl_local_1)
{
    printf("R1120_C219_ARG nl_fn_13 %zu\n", nl_local_1);
    (void)nl_local_1;
    const _Bool nl_local_2 = (nl_local_1 == ((size_t)UINTMAX_C(913)));
    printf("R1120_C219_BOOL nl_local_2 %u\n", (unsigned)nl_local_2);
    (void)nl_local_2;
    return (nl_local_2 ? (printf("R1120_C219_ARM nl_fn_13 0\n"), (47)) : (printf("R1120_C219_ARM nl_fn_13 1\n"), (219)) );
}

static uint8_t nl_fn_14(size_t nl_local_4)
{
    printf("R1120_C219_ARG nl_fn_14 %zu\n", nl_local_4);
    (void)nl_local_4;
    const size_t nl_less_left_2 = nl_local_4;
    const size_t nl_less_right_2 = ((size_t)UINTMAX_C(613));
    return ((nl_less_left_2 < nl_less_right_2) ? (printf("R1120_C219_ARM nl_fn_14 0\n"), (152)) : (printf("R1120_C219_ARM nl_fn_14 1\n"), (219)) );
}

static uint8_t nl_fn_11(size_t nl_local_6)
{
    printf("R1120_C219_ARG nl_fn_11 %zu\n", nl_local_6);
    (void)nl_local_6;
    const _Bool nl_local_7 = (((size_t)UINTMAX_C(1253)) == nl_local_6);
    printf("R1120_C219_BOOL nl_local_7 %u\n", (unsigned)nl_local_7);
    (void)nl_local_7;
    return (nl_local_7 ? (printf("R1120_C219_ARM nl_fn_11 0\n"), (47)) : (printf("R1120_C219_ARM nl_fn_11 1\n"), (219)) );
}

static uint8_t nl_fn_12(size_t nl_local_9)
{
    printf("R1120_C219_ARG nl_fn_12 %zu\n", nl_local_9);
    (void)nl_local_9;
    const size_t nl_local_10 = nl_local_9;
    (void)nl_local_10;
    const size_t nl_local_11 = ((size_t)UINTMAX_C(1253));
    (void)nl_local_11;
    const size_t nl_less_left_8 = nl_local_10;
    const size_t nl_less_right_8 = nl_local_11;
    const _Bool nl_local_12 = (nl_less_left_8 < nl_less_right_8);
    printf("R1120_C219_BOOL nl_local_12 %u\n", (unsigned)nl_local_12);
    (void)nl_local_12;
    return (nl_local_12 ? (printf("R1120_C219_ARM nl_fn_12 0\n"), (152)) : (printf("R1120_C219_ARM nl_fn_12 1\n"), (219)) );
}

int main(void)
{
    printf("R1120_C219_WIDTH %zu %zu\n", sizeof(size_t) * CHAR_BIT, (size_t)SIZE_MAX);
    nl_fn_10();
    return 0;
}
