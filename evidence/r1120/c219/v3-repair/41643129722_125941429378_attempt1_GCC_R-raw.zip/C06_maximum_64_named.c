/* North Star V0/V1/AVS Checked-C reference output. */
#include <stdint.h>

#include <limits.h>
_Static_assert(CHAR_BIT == 8, "NewLang C17 requires 8-bit bytes");
_Static_assert(UINT8_MAX == 255 && sizeof(uint8_t) == 1 && ((uint8_t)-1) == 255, "NewLang C17 requires exact 8-bit uint8_t");
#include <stddef.h>
_Static_assert(SIZE_MAX == UINTMAX_C(18446744073709551615), "NewLang usize target mismatch");

static void nl_fn_10(void);
static uint8_t nl_fn_13(size_t nl_local_1);
static uint8_t nl_fn_14(size_t nl_local_4);
static uint8_t nl_fn_11(size_t nl_local_6);
static uint8_t nl_fn_12(size_t nl_local_9);

static void nl_fn_10(void)
{
    const uint8_t nl_call_2 = nl_fn_13(((size_t)UINTMAX_C(18446744073709551615)));
    (void)nl_call_2;
    const uint8_t nl_local_3 = nl_call_2;
    (void)nl_local_3;
    const uint8_t nl_call_6 = nl_fn_14(((size_t)UINTMAX_C(18446744073709551615)));
    (void)nl_call_6;
    const uint8_t nl_local_5 = nl_call_6;
    (void)nl_local_5;
    const uint8_t nl_call_10 = nl_fn_11(((size_t)UINTMAX_C(18446744073709551615)));
    (void)nl_call_10;
    const uint8_t nl_local_8 = nl_call_10;
    (void)nl_local_8;
    const uint8_t nl_call_14 = nl_fn_12(((size_t)UINTMAX_C(18446744073709551615)));
    (void)nl_call_14;
    const uint8_t nl_local_13 = nl_call_14;
    (void)nl_local_13;
    (void)0;
}

static uint8_t nl_fn_13(size_t nl_local_1)
{
    (void)nl_local_1;
    const _Bool nl_local_2 = (nl_local_1 == ((size_t)UINTMAX_C(913)));
    (void)nl_local_2;
    return (nl_local_2 ? 47 : 219);
}

static uint8_t nl_fn_14(size_t nl_local_4)
{
    (void)nl_local_4;
    const size_t nl_less_left_2 = nl_local_4;
    const size_t nl_less_right_2 = ((size_t)UINTMAX_C(613));
    return ((nl_less_left_2 < nl_less_right_2) ? 152 : 219);
}

static uint8_t nl_fn_11(size_t nl_local_6)
{
    (void)nl_local_6;
    const _Bool nl_local_7 = (((size_t)UINTMAX_C(1253)) == nl_local_6);
    (void)nl_local_7;
    return (nl_local_7 ? 47 : 219);
}

static uint8_t nl_fn_12(size_t nl_local_9)
{
    (void)nl_local_9;
    const size_t nl_local_10 = nl_local_9;
    (void)nl_local_10;
    const size_t nl_local_11 = ((size_t)UINTMAX_C(1253));
    (void)nl_local_11;
    const size_t nl_less_left_8 = nl_local_10;
    const size_t nl_less_right_8 = nl_local_11;
    const _Bool nl_local_12 = (nl_less_left_8 < nl_less_right_8);
    (void)nl_local_12;
    return (nl_local_12 ? 152 : 219);
}

int main(void)
{
    nl_fn_10();
    return 0;
}
