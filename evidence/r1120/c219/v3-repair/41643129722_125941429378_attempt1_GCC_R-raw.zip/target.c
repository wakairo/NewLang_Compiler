#include <stdint.h>
#include <stddef.h>
#include <limits.h>
#include <stdio.h>
int main(void) {
    printf("%zu %zu\n", sizeof(size_t) * CHAR_BIT, (size_t)SIZE_MAX);
    return 0;
}
