#include <stdio.h>
#include <limits.h>
/* North Star V0/V1/AVS Checked-C reference output. */
#include <stdint.h>

#include <limits.h>
_Static_assert(CHAR_BIT == 8, "NewLang C17 requires 8-bit bytes");
_Static_assert(UINT8_MAX == 255 && sizeof(uint8_t) == 1 && ((uint8_t)-1) == 255, "NewLang C17 requires exact 8-bit uint8_t");
#include <stddef.h>
_Static_assert(SIZE_MAX == UINTMAX_C(18446744073709551615), "NewLang usize target mismatch");

static void nl_fn_10(void);
static uint8_t nl_fn_11(size_t nl_local_1);

static void nl_fn_10(void)
{
    const uint8_t nl_call_2 = nl_fn_11(((size_t)UINTMAX_C(0)));
    printf("R1120_C219_RESULT nl_fn_11 nl_call_2 %u\n", (unsigned)nl_call_2);
    (void)nl_call_2;
    const uint8_t nl_local_2 = nl_call_2;
    (void)nl_local_2;
    const uint8_t nl_call_6 = nl_fn_11(((size_t)UINTMAX_C(612)));
    printf("R1120_C219_RESULT nl_fn_11 nl_call_6 %u\n", (unsigned)nl_call_6);
    (void)nl_call_6;
    const uint8_t nl_local_4 = nl_call_6;
    (void)nl_local_4;
    const uint8_t nl_call_10 = nl_fn_11(((size_t)UINTMAX_C(613)));
    printf("R1120_C219_RESULT nl_fn_11 nl_call_10 %u\n", (unsigned)nl_call_10);
    (void)nl_call_10;
    const uint8_t nl_local_6 = nl_call_10;
    (void)nl_local_6;
    const uint8_t nl_call_14 = nl_fn_11(((size_t)UINTMAX_C(657)));
    printf("R1120_C219_RESULT nl_fn_11 nl_call_14 %u\n", (unsigned)nl_call_14);
    (void)nl_call_14;
    const uint8_t nl_local_8 = nl_call_14;
    (void)nl_local_8;
    const uint8_t nl_call_18 = nl_fn_11(((size_t)UINTMAX_C(768)));
    printf("R1120_C219_RESULT nl_fn_11 nl_call_18 %u\n", (unsigned)nl_call_18);
    (void)nl_call_18;
    const uint8_t nl_local_10 = nl_call_18;
    (void)nl_local_10;
    const uint8_t nl_call_22 = nl_fn_11(((size_t)UINTMAX_C(912)));
    printf("R1120_C219_RESULT nl_fn_11 nl_call_22 %u\n", (unsigned)nl_call_22);
    (void)nl_call_22;
    const uint8_t nl_local_12 = nl_call_22;
    (void)nl_local_12;
    const uint8_t nl_call_26 = nl_fn_11(((size_t)UINTMAX_C(913)));
    printf("R1120_C219_RESULT nl_fn_11 nl_call_26 %u\n", (unsigned)nl_call_26);
    (void)nl_call_26;
    const uint8_t nl_local_14 = nl_call_26;
    (void)nl_local_14;
    const uint8_t nl_call_30 = nl_fn_11(((size_t)UINTMAX_C(914)));
    printf("R1120_C219_RESULT nl_fn_11 nl_call_30 %u\n", (unsigned)nl_call_30);
    (void)nl_call_30;
    const uint8_t nl_local_16 = nl_call_30;
    (void)nl_local_16;
    (void)0;
}

static uint8_t nl_fn_11(size_t nl_local_1)
{
    printf("R1120_C219_ARG nl_fn_11 %zu\n", nl_local_1);
    (void)nl_local_1;
    const size_t nl_less_left_2 = nl_local_1;
    const size_t nl_less_right_2 = ((size_t)UINTMAX_C(613));
    return ((nl_less_left_2 < nl_less_right_2) ? (printf("R1120_C219_ARM nl_fn_11 0\n"), (152)) : (printf("R1120_C219_ARM nl_fn_11 1\n"), (219)) );
}

int main(void)
{
    printf("R1120_C219_WIDTH %zu %zu\n", sizeof(size_t) * CHAR_BIT, (size_t)SIZE_MAX);
    nl_fn_10();
    return 0;
}
