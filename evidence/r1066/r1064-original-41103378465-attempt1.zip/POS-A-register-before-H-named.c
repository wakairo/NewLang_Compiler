/* Bounded Checked-C representation, not a NewLang ABI. */
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <limits.h>
_Static_assert(CHAR_BIT == 8, "NewLang C17 requires 8-bit bytes");
_Static_assert(UINT8_MAX == 255 && sizeof(uint8_t) == 1 && ((uint8_t)-1) == 255, "NewLang C17 requires exact 8-bit uint8_t");
typedef struct nl_node nl_node;
typedef struct { unsigned tag; const nl_node *ptr; } nl_node_option;
struct nl_node { nl_node_option f0; uint8_t f1; };
#ifdef NEWLANG_NODE_OBSERVER
#include NEWLANG_NODE_OBSERVER
#else
#define NL_NODE_BIND(...) ((void)0)
#define NL_NODE_REPLACE(...) ((void)0)
#define NL_NODE_ARM(...) ((void)0)
#define NL_NODE_RELOAN(...) ((void)0)
#define NL_NODE_FINISH() ((void)0)
#endif
_Static_assert(sizeof(nl_node)==24 && _Alignof(nl_node)==8, "checked H target layout");
_Static_assert(sizeof(void*)==8 && offsetof(nl_node,f0)==0 && offsetof(nl_node,f1)==16, "private member plan");
_Static_assert(sizeof(nl_node_option)==16 && _Alignof(nl_node_option)==8 && _Generic(((nl_node *)0)->f0,nl_node_option:1,default:0) && _Generic(((nl_node *)0)->f1,uint8_t:1,default:0) && _Generic(((nl_node_option *)0)->ptr,const nl_node *:1,default:0), "private member types");
typedef struct {void *handle;} nl_allocation;
typedef struct {unsigned char *bytes;size_t length;} nl_storage;
typedef struct {unsigned char *bytes;size_t length;} nl_slot;
typedef struct {size_t token;} nl_domain;
typedef struct {const nl_node *ptr;nl_allocation allocation;nl_domain domain;} nl_live_tail;
typedef struct {unsigned tag;nl_live_tail packet;} nl_custody;
typedef struct {nl_allocation allocation;nl_storage raw;} nl_backing;
#ifdef NEWLANG_HEAP_OBSERVER
#include NEWLANG_HEAP_OBSERVER
#else
#define NL_HEAP_TRIAL(...) ((void)0)
#define NL_HEAP_ARM(...) ((void)0)
#define NL_HEAP_DOMAIN(...) ((void)0)
#define NL_HEAP_SLOT(...) ((void)0)
#define NL_HEAP_INITIALIZE(...) ((void)0)
#define NL_HEAP_RELOAN(...) ((void)0)
#define NL_HEAP_ROOT(...) ((void)0)
#define NL_HEAP_FIELD(...) ((void)0)
#define NL_HEAP_COPY(...) ((void)0)
#define NL_HEAP_CHANGE(...) ((void)0)
#define NL_HEAP_SCOPE_END(...) ((void)0)
#define NL_HEAP_END(...) ((void)0)
#define NL_HEAP_RAW(...) ((void)0)
#define NL_HEAP_FINALIZE(...) ((void)0)
#define NL_HEAP_RELEASE(...) ((void)0)
#define NL_HEAP_FINISH() ((void)0)
#define NL_HEAP_HANDOFF(...) ((void)0)
#define NL_HEAP_RECEIVER_ENTER(...) ((void)0)
#define NL_HEAP_RECEIVER_EXIT() ((void)0)
#define NL_HEAP_RETURNED(...) ((void)0)
#define NL_LIVE_SEND(...) ((void)0)
#define NL_LIVE_ENTER(...) ((void)0)
#define NL_LIVE_RETURN(...) ((void)0)
#define NL_LIVE_RECEIVE(...) ((void)0)
#endif
#ifndef NL_CUSTODY_ENTER
#define NL_CUSTODY_ENTER(...) ((void)0)
#define NL_CUSTODY_STORED(...) ((void)0)
#define NL_CUSTODY_RETURNED(...) ((void)0)
#define NL_CUSTODY_EXTRACT(...) ((void)0)
#define NL_CUSTODY_NONE(...) ((void)0)
#define NL_CUSTODY_POLICY(...) ((void)0)
#define NL_CUSTODY_LOAN(...) ((void)0)
#endif
typedef struct {uint8_t f0,f1;} nl_copy_record;
#ifndef NL_MIXED_OWNER_LOCAL
#define NL_MIXED_OWNER_LOCAL(...) ((void)0)
#endif
#ifndef NL_MIXED_COPY_BIND
#define NL_MIXED_COPY_BIND(...) ((void)0)
#endif
#ifndef NL_MIXED_COPY_STORE
#define NL_MIXED_COPY_STORE(...) ((void)0)
#endif
#ifndef NL_MIXED_COPY_CALL
#define NL_MIXED_COPY_CALL(...) ((void)0)
#endif
static uint8_t nl_copy_state_10(uint8_t *target,uint8_t next){uint8_t old=*target;*target=next;NL_MIXED_COPY_CALL(target,old,next);return old;}
static uint8_t nl_copy_state_13(uint8_t *target,uint8_t next){uint8_t old=*target;*target=next;NL_MIXED_COPY_CALL(target,old,next);return old;}
static void nl_owner_14(const nl_node *nl_b_16_52,nl_allocation nl_b_16_53,nl_domain nl_b_16_54) {
NL_HEAP_RECEIVER_ENTER(nl_b_16_52,nl_b_16_53.handle,nl_b_16_54.token,16,52,53,54,&nl_b_16_53,&nl_b_16_54);
{ const nl_domain *nl_b_17_55 = &nl_b_16_54;
(void)nl_b_17_55;
const nl_node * nl_v_94 = nl_b_16_52;
const nl_domain * nl_v_95 = nl_b_17_55;
const nl_node * nl_v_96 = nl_v_94;
NL_HEAP_ROOT(nl_v_96,nl_v_95->token,0,37,40,10);
(void)nl_v_95;
const nl_node * nl_b_17_56 = nl_v_96;
(void)nl_b_17_56;
NL_NODE_BIND(17, 56, 4, &nl_b_17_56);
NL_HEAP_SCOPE_END(10);
}
nl_slot nl_v_97;
{ const nl_domain *nl_b_18_57 = &nl_b_16_54;
(void)nl_b_18_57;
const nl_node * nl_v_98 = nl_b_16_52;
NL_HEAP_END(nl_v_98,nl_b_18_57->token);
nl_slot nl_v_99 = {(unsigned char *)nl_v_98,24};
nl_v_97 = nl_v_99;
}
nl_slot nl_b_16_58 = nl_v_97;
(void)nl_b_16_58;
NL_NODE_BIND(16, 58, 4, &nl_b_16_58);
nl_slot nl_v_100 = nl_b_16_58;
nl_b_16_58 = (nl_slot){0};
nl_storage nl_v_101 = {nl_v_100.bytes,nl_v_100.length};
NL_HEAP_RAW(nl_v_101.bytes,nl_v_101.length);
nl_storage nl_b_16_59 = nl_v_101;
(void)nl_b_16_59;
NL_NODE_BIND(16, 59, 4, &nl_b_16_59);
nl_domain nl_v_102 = nl_b_16_54;
nl_b_16_54 = (nl_domain){0};
NL_HEAP_FINALIZE(nl_v_102.token);
(void)nl_v_102;
nl_allocation nl_v_103 = nl_b_16_53;
nl_b_16_53 = (nl_allocation){0};
nl_storage nl_v_104 = nl_b_16_59;
nl_b_16_59 = (nl_storage){0};
NL_HEAP_RELEASE(nl_v_103.handle,nl_v_104.bytes,nl_v_104.length);
free(nl_v_103.handle);
nl_v_103.handle=NULL;
nl_v_104.bytes=NULL;
(void)nl_v_104;
NL_HEAP_RECEIVER_EXIT();
}
static nl_live_tail nl_producer_11(nl_node_option * nl_b_14_42,const nl_node * nl_b_14_43,nl_allocation nl_b_14_44,nl_domain nl_b_14_45) {
NL_LIVE_ENTER(nl_b_14_42,nl_b_14_43,nl_b_14_44.handle,nl_b_14_45.token);
nl_node_option * nl_v_80 = nl_b_14_42;
nl_node_option nl_v_81 = { 0, NULL };
nl_node_option nl_v_82 = *nl_v_80;
*nl_v_80 = nl_v_81;
NL_HEAP_CHANGE(nl_v_80,&nl_v_82,2);
(void)nl_v_82;
const nl_node * nl_v_83 = nl_b_14_43;
nl_allocation nl_v_84 = nl_b_14_44;
nl_b_14_44 = (nl_allocation){0};
nl_domain nl_v_85 = nl_b_14_45;
nl_b_14_45 = (nl_domain){0};
nl_live_tail nl_v_86 = {nl_v_83,nl_v_84,nl_v_85};
NL_LIVE_RETURN(nl_v_86);
return nl_v_86;
}
int main(void) {
uint8_t nl_v_1 = 42;
uint8_t nl_v_2 = 13;
nl_copy_record nl_v_3 = {nl_v_2,nl_v_1};
nl_copy_record nl_b_0_1 = nl_v_3;
NL_MIXED_COPY_BIND(0,1,&nl_b_0_1.f0,&nl_b_0_1.f1);
uint8_t nl_v_4 = 204;
uint8_t nl_v_5 = 91;
nl_copy_record nl_v_6 = {nl_v_4,nl_v_5};
nl_copy_record nl_b_0_2 = nl_v_6;
NL_MIXED_COPY_BIND(0,2,&nl_b_0_2.f0,&nl_b_0_2.f1);
uint8_t nl_v_7 = 137;
uint8_t nl_v_8 = nl_copy_state_10(&nl_b_0_1.f1,nl_v_7);
uint8_t nl_b_0_7 = nl_v_8;
(void)nl_b_0_7;
NL_NODE_BIND(0, 7, 4, &nl_b_0_7);
uint8_t nl_v_9 = nl_b_0_7;
uint8_t nl_v_10 = nl_copy_state_13(&nl_b_0_2.f0,nl_v_9);
uint8_t nl_b_0_11 = nl_v_10;
(void)nl_b_0_11;
NL_NODE_BIND(0, 11, 4, &nl_b_0_11);
uint8_t nl_v_11 = nl_b_0_11;
uint8_t nl_v_12 = nl_b_0_1.f0;
nl_b_0_1.f0=nl_v_11;
NL_MIXED_COPY_STORE(&nl_b_0_1.f0,nl_v_12,nl_v_11);
uint8_t nl_b_0_13 = nl_v_12;
(void)nl_b_0_13;
NL_NODE_BIND(0, 13, 4, &nl_b_0_13);
uint8_t nl_v_13=nl_b_0_1.f0;
uint8_t nl_b_0_14 = nl_v_13;
(void)nl_b_0_14;
NL_NODE_BIND(0, 14, 4, &nl_b_0_14);
uint8_t nl_v_14=nl_b_0_1.f1;
uint8_t nl_b_0_15 = nl_v_14;
(void)nl_b_0_15;
NL_NODE_BIND(0, 15, 4, &nl_b_0_15);
uint8_t nl_v_15=nl_b_0_2.f0;
uint8_t nl_b_0_16 = nl_v_15;
(void)nl_b_0_16;
NL_NODE_BIND(0, 16, 4, &nl_b_0_16);
uint8_t nl_v_16=nl_b_0_2.f1;
uint8_t nl_b_0_17 = nl_v_16;
(void)nl_b_0_17;
NL_NODE_BIND(0, 17, 4, &nl_b_0_17);
void *nl_heap_17 = malloc(24);
NL_HEAP_TRIAL(nl_heap_17,24,8);
if (nl_heap_17 == NULL) {
NL_HEAP_ARM(1);
}
if (nl_heap_17 != NULL) {
NL_HEAP_ARM(2);
nl_backing nl_b_2_18 = { {nl_heap_17}, {(unsigned char *)nl_heap_17,24} };
nl_backing nl_v_18 = nl_b_2_18;
nl_b_2_18 = (nl_backing){0};
nl_allocation nl_b_2_19 = nl_v_18.allocation;
(void)nl_b_2_19;
nl_storage nl_b_2_20 = nl_v_18.raw;
(void)nl_b_2_20;
nl_v_18 = (nl_backing){0};
nl_allocation nl_v_19 = nl_b_2_19;
nl_b_2_19 = (nl_allocation){0};
nl_allocation nl_b_2_21 = nl_v_19;
(void)nl_b_2_21;
NL_NODE_BIND(2, 21, 4, &nl_b_2_21);
nl_storage nl_v_20 = nl_b_2_20;
nl_b_2_20 = (nl_storage){0};
nl_slot nl_v_21 = {nl_v_20.bytes,nl_v_20.length};
NL_HEAP_SLOT(nl_v_21.bytes,nl_v_21.length);
nl_slot nl_b_2_22 = nl_v_21;
(void)nl_b_2_22;
NL_NODE_BIND(2, 22, 4, &nl_b_2_22);
nl_domain nl_v_22 = {1};
NL_HEAP_DOMAIN(nl_v_22.token);
nl_domain nl_b_2_23 = nl_v_22;
(void)nl_b_2_23;
NL_NODE_BIND(2, 23, 4, &nl_b_2_23);
const nl_node * nl_v_23;
{ const nl_domain *nl_b_3_24 = &nl_b_2_23;
(void)nl_b_3_24;
nl_slot nl_v_24 = nl_b_2_22;
nl_b_2_22 = (nl_slot){0};
nl_node_option nl_v_25 = { 0, NULL };
uint8_t nl_v_26 = 63;
nl_node nl_v_27 = { nl_v_25, nl_v_26 };
const nl_domain * nl_v_28 = nl_b_3_24;
*(nl_node *)nl_v_24.bytes = nl_v_27;
const nl_node *nl_v_29 = (nl_node *)nl_v_24.bytes;
NL_HEAP_INITIALIZE(nl_v_29,nl_v_28->token);
(void)nl_v_28;
nl_v_23 = nl_v_29;
}
const nl_node * const nl_b_2_25 = nl_v_23;
(void)nl_b_2_25;
NL_NODE_BIND(2, 25, 2, &nl_b_2_25);
void *nl_heap_30 = malloc(24);
NL_HEAP_TRIAL(nl_heap_30,24,8);
if (nl_heap_30 == NULL) {
NL_HEAP_ARM(1);
nl_slot nl_v_31;
{ const nl_domain *nl_b_5_26 = &nl_b_2_23;
(void)nl_b_5_26;
const nl_node * nl_v_32 = nl_b_2_25;
NL_HEAP_END(nl_v_32,nl_b_5_26->token);
nl_slot nl_v_33 = {(unsigned char *)nl_v_32,24};
nl_v_31 = nl_v_33;
}
nl_slot nl_b_4_27 = nl_v_31;
(void)nl_b_4_27;
NL_NODE_BIND(4, 27, 4, &nl_b_4_27);
nl_slot nl_v_34 = nl_b_4_27;
nl_b_4_27 = (nl_slot){0};
nl_storage nl_v_35 = {nl_v_34.bytes,nl_v_34.length};
NL_HEAP_RAW(nl_v_35.bytes,nl_v_35.length);
nl_storage nl_b_4_28 = nl_v_35;
(void)nl_b_4_28;
NL_NODE_BIND(4, 28, 4, &nl_b_4_28);
nl_domain nl_v_36 = nl_b_2_23;
nl_b_2_23 = (nl_domain){0};
NL_HEAP_FINALIZE(nl_v_36.token);
(void)nl_v_36;
nl_allocation nl_v_37 = nl_b_2_21;
nl_b_2_21 = (nl_allocation){0};
nl_storage nl_v_38 = nl_b_4_28;
nl_b_4_28 = (nl_storage){0};
NL_HEAP_RELEASE(nl_v_37.handle,nl_v_38.bytes,nl_v_38.length);
free(nl_v_37.handle);
nl_v_37.handle=NULL;
nl_v_38.bytes=NULL;
(void)nl_v_38;
}
if (nl_heap_30 != NULL) {
NL_HEAP_ARM(2);
nl_backing nl_b_6_26 = { {nl_heap_30}, {(unsigned char *)nl_heap_30,24} };
nl_backing nl_v_39 = nl_b_6_26;
nl_b_6_26 = (nl_backing){0};
nl_allocation nl_b_6_27 = nl_v_39.allocation;
(void)nl_b_6_27;
nl_storage nl_b_6_28 = nl_v_39.raw;
(void)nl_b_6_28;
nl_v_39 = (nl_backing){0};
nl_allocation nl_v_40 = nl_b_6_27;
nl_b_6_27 = (nl_allocation){0};
nl_allocation nl_b_6_29 = nl_v_40;
(void)nl_b_6_29;
NL_NODE_BIND(6, 29, 4, &nl_b_6_29);
nl_storage nl_v_41 = nl_b_6_28;
nl_b_6_28 = (nl_storage){0};
nl_slot nl_v_42 = {nl_v_41.bytes,nl_v_41.length};
NL_HEAP_SLOT(nl_v_42.bytes,nl_v_42.length);
nl_slot nl_b_6_30 = nl_v_42;
(void)nl_b_6_30;
NL_NODE_BIND(6, 30, 4, &nl_b_6_30);
nl_domain nl_v_43 = {2};
NL_HEAP_DOMAIN(nl_v_43.token);
nl_domain nl_b_6_31 = nl_v_43;
(void)nl_b_6_31;
NL_NODE_BIND(6, 31, 4, &nl_b_6_31);
const nl_node * nl_v_44;
{ const nl_domain *nl_b_7_32 = &nl_b_6_31;
(void)nl_b_7_32;
nl_slot nl_v_45 = nl_b_6_30;
nl_b_6_30 = (nl_slot){0};
nl_node_option nl_v_46 = { 0, NULL };
uint8_t nl_v_47 = 171;
nl_node nl_v_48 = { nl_v_46, nl_v_47 };
const nl_domain * nl_v_49 = nl_b_7_32;
*(nl_node *)nl_v_45.bytes = nl_v_48;
const nl_node *nl_v_50 = (nl_node *)nl_v_45.bytes;
NL_HEAP_INITIALIZE(nl_v_50,nl_v_49->token);
(void)nl_v_49;
nl_v_44 = nl_v_50;
}
const nl_node * const nl_b_6_33 = nl_v_44;
(void)nl_b_6_33;
NL_NODE_BIND(6, 33, 2, &nl_b_6_33);
nl_node_option nl_v_51;
{ const nl_domain *nl_b_8_34 = &nl_b_2_23;
(void)nl_b_8_34;
const nl_node * nl_v_52 = nl_b_2_25;
const nl_domain * nl_v_53 = nl_b_8_34;
nl_node * nl_v_54 = (nl_node *)nl_v_52;
NL_HEAP_ROOT(nl_v_54,nl_v_53->token,1,26,29,6);
(void)nl_v_53;
nl_node * nl_b_8_35 = nl_v_54;
(void)nl_b_8_35;
NL_NODE_BIND(8, 35, 4, &nl_b_8_35);
nl_node * nl_v_55 = nl_b_8_35;
nl_node_option * nl_v_56 = &nl_v_55->f0;
NL_HEAP_FIELD(nl_v_55,nl_v_56,1,11,0,30,30,6);
const nl_node * nl_v_57 = nl_b_6_33;
nl_node_option nl_v_58 = { 1, nl_v_57 };
nl_node_option nl_v_59 = *nl_v_56;
*nl_v_56 = nl_v_58;
NL_HEAP_CHANGE(nl_v_56,&nl_v_59,1);
nl_v_51 = nl_v_59;
NL_HEAP_SCOPE_END(6);
}
nl_node_option nl_b_6_36 = nl_v_51;
(void)nl_b_6_36;
NL_NODE_BIND(6, 36, 3, &nl_b_6_36);
nl_node_option nl_v_60;
{ const nl_domain *nl_b_9_37 = &nl_b_2_23;
(void)nl_b_9_37;
const nl_node * nl_v_61 = nl_b_2_25;
const nl_domain * nl_v_62 = nl_b_9_37;
const nl_node * nl_v_63 = nl_v_61;
NL_HEAP_ROOT(nl_v_63,nl_v_62->token,0,26,29,7);
(void)nl_v_62;
const nl_node * nl_b_9_38 = nl_v_63;
(void)nl_b_9_38;
NL_NODE_BIND(9, 38, 4, &nl_b_9_38);
const nl_node * nl_v_64 = nl_b_9_38;
const nl_node_option * nl_v_65 = &nl_v_64->f0;
NL_HEAP_FIELD(nl_v_64,nl_v_65,0,11,0,30,30,7);
nl_node_option nl_v_66 = *nl_v_65;
NL_HEAP_COPY(nl_v_65,&nl_v_66);
nl_v_60 = nl_v_66;
NL_HEAP_SCOPE_END(7);
}
nl_node_option nl_b_6_39 = nl_v_60;
(void)nl_b_6_39;
NL_NODE_BIND(6, 39, 3, &nl_b_6_39);
nl_node_option nl_v_67 = nl_b_6_39;
switch (nl_v_67.tag) {
case 0: {
NL_NODE_ARM(1, nl_v_67.ptr);
break; }
case 1: {
const nl_node *const nl_b_11_40 = nl_v_67.ptr;
NL_NODE_ARM(2, nl_b_11_40);
(void)nl_b_11_40;
{ const nl_domain *nl_b_12_41 = &nl_b_6_31;
(void)nl_b_12_41;
const nl_node * nl_v_68 = nl_b_11_40;
const nl_domain * nl_v_69 = nl_b_12_41;
const nl_node * nl_v_70 = nl_v_68;
NL_HEAP_ROOT(nl_v_70,nl_v_69->token,0,37,40,8);
(void)nl_v_69;
const nl_node * nl_b_12_42 = nl_v_70;
(void)nl_b_12_42;
NL_NODE_BIND(12, 42, 4, &nl_b_12_42);
NL_HEAP_SCOPE_END(8);
}
break; }
}
nl_live_tail nl_v_71;
{ const nl_domain *nl_b_13_40 = &nl_b_2_23;
(void)nl_b_13_40;
const nl_node * nl_v_72 = nl_b_2_25;
const nl_domain * nl_v_73 = nl_b_13_40;
nl_node * nl_v_74 = (nl_node *)nl_v_72;
NL_HEAP_ROOT(nl_v_74,nl_v_73->token,1,26,29,8);
(void)nl_v_73;
nl_node * nl_b_13_41 = nl_v_74;
(void)nl_b_13_41;
NL_NODE_BIND(13, 41, 4, &nl_b_13_41);
nl_node * nl_v_75 = nl_b_13_41;
nl_node_option * nl_v_76 = &nl_v_75->f0;
NL_HEAP_FIELD(nl_v_75,nl_v_76,1,11,0,30,30,8);
const nl_node * nl_v_77 = nl_b_6_33;
nl_allocation nl_v_78 = nl_b_6_29;
nl_b_6_29 = (nl_allocation){0};
nl_domain nl_v_79 = nl_b_6_31;
nl_b_6_31 = (nl_domain){0};
NL_LIVE_SEND(nl_v_77,nl_v_78.handle,nl_v_79.token,&nl_b_6_29,&nl_b_6_31);
nl_live_tail nl_v_87 = nl_producer_11(nl_v_76,nl_v_77,nl_v_78,nl_v_79);
NL_LIVE_RECEIVE(nl_v_87,&nl_b_6_29,&nl_b_6_31);
nl_v_71 = nl_v_87;
NL_HEAP_SCOPE_END(8);
}
const nl_node * nl_b_6_47 = nl_v_71.ptr;
(void)nl_b_6_47;
nl_allocation nl_b_6_48 = nl_v_71.allocation;
(void)nl_b_6_48;
nl_domain nl_b_6_49 = nl_v_71.domain;
(void)nl_b_6_49;
nl_v_71 = (nl_live_tail){0};
{ const nl_domain *nl_b_15_50 = &nl_b_6_49;
(void)nl_b_15_50;
const nl_node * nl_v_88 = nl_b_6_47;
const nl_domain * nl_v_89 = nl_b_15_50;
const nl_node * nl_v_90 = nl_v_88;
NL_HEAP_ROOT(nl_v_90,nl_v_89->token,0,37,40,9);
(void)nl_v_89;
const nl_node * nl_b_15_51 = nl_v_90;
(void)nl_b_15_51;
NL_NODE_BIND(15, 51, 4, &nl_b_15_51);
NL_HEAP_SCOPE_END(9);
}
const nl_node * nl_v_91 = nl_b_6_47;
nl_allocation nl_v_92 = nl_b_6_48;
nl_b_6_48 = (nl_allocation){0};
nl_domain nl_v_93 = nl_b_6_49;
nl_b_6_49 = (nl_domain){0};
NL_HEAP_HANDOFF(nl_v_91,nl_v_92.handle,nl_v_93.token,&nl_b_6_48,&nl_b_6_49);
nl_owner_14(nl_v_91,nl_v_92,nl_v_93);
NL_HEAP_RETURNED(&nl_b_6_48,&nl_b_6_49);
nl_slot nl_v_105;
{ const nl_domain *nl_b_19_60 = &nl_b_2_23;
(void)nl_b_19_60;
const nl_node * nl_v_106 = nl_b_2_25;
NL_HEAP_END(nl_v_106,nl_b_19_60->token);
nl_slot nl_v_107 = {(unsigned char *)nl_v_106,24};
nl_v_105 = nl_v_107;
}
nl_slot nl_b_6_61 = nl_v_105;
(void)nl_b_6_61;
NL_NODE_BIND(6, 61, 4, &nl_b_6_61);
nl_slot nl_v_108 = nl_b_6_61;
nl_b_6_61 = (nl_slot){0};
nl_storage nl_v_109 = {nl_v_108.bytes,nl_v_108.length};
NL_HEAP_RAW(nl_v_109.bytes,nl_v_109.length);
nl_storage nl_b_6_62 = nl_v_109;
(void)nl_b_6_62;
NL_NODE_BIND(6, 62, 4, &nl_b_6_62);
nl_domain nl_v_110 = nl_b_2_23;
nl_b_2_23 = (nl_domain){0};
NL_HEAP_FINALIZE(nl_v_110.token);
(void)nl_v_110;
nl_allocation nl_v_111 = nl_b_2_21;
nl_b_2_21 = (nl_allocation){0};
nl_storage nl_v_112 = nl_b_6_62;
nl_b_6_62 = (nl_storage){0};
NL_HEAP_RELEASE(nl_v_111.handle,nl_v_112.bytes,nl_v_112.length);
free(nl_v_111.handle);
nl_v_111.handle=NULL;
nl_v_112.bytes=NULL;
(void)nl_v_112;
}
}
NL_HEAP_FINISH();
return 0;
}
