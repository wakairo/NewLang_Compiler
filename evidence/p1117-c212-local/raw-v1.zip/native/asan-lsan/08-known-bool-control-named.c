/* North Star V0/V1/AVS Checked-C reference output. */
#include <stdint.h>

#include <limits.h>
_Static_assert(CHAR_BIT == 8, "NewLang C17 requires 8-bit bytes");
_Static_assert(UINT8_MAX == 255 && sizeof(uint8_t) == 1 && ((uint8_t)-1) == 255, "NewLang C17 requires exact 8-bit uint8_t");
#include <stddef.h>
_Static_assert(SIZE_MAX == UINTMAX_C(18446744073709551615), "NewLang usize target mismatch");

static void nl_fn_10(void);

static void nl_fn_10(void)
{
    const size_t nl_local_1 = ((size_t)UINTMAX_C(43));
    (void)nl_local_1;
    const _Bool nl_local_2 = (nl_local_1 == ((size_t)UINTMAX_C(43)));
    (void)nl_local_2;
    const _Bool nl_local_3 = nl_local_2;
    (void)nl_local_3;
    (void)0;
    return;
}

int main(void)
{
    nl_fn_10();
    return 0;
}
