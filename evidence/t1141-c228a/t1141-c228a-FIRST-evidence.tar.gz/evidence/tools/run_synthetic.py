#!/usr/bin/env python3
"""One old counterexample + three patched cases; no compiler execution."""
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

ROOT = Path(__file__).resolve().parent
E = ROOT / "evidence"
FIXTURE = ROOT / "synthetic"
IGNORED = "kept first.h"
LIVE = "sub/live name [x].c"
SENTINEL = b"T1141_SYNTHETIC_FIRST_SENTINEL_20261104"
LIVE_BAD = b"int live_example(void){\nreturn 7;\n}\n"
LIVE_GOOD = b"int live_example(void) {\n    return 7;\n}\n"
BEGIN = b"----- BEGIN EXACT clang-format SUGGESTIONS -----"


def run(args, cwd=FIXTURE, env=None):
    return subprocess.run(args, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


def git(*args):
    p = run(["git", *args])
    assert p.returncode == 0, p.stderr.decode(errors="replace")
    return p.stdout


def snapshot(destination):
    hashes = {}
    for name in TRACKED:
        data = (FIXTURE / name).read_bytes()
        out = destination / name
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(data)
        hashes[name] = hashlib.sha256(data).hexdigest()
    (destination / "SHA256.json").write_text(json.dumps(hashes, indent=2) + "\n")
    return hashes


def execute(name, expected):
    case = E / "cases" / name
    first = case / "FIRST"
    first.mkdir(parents=True)
    before = snapshot(case / "before")
    patch = first / "suggestions.patch"
    env = os.environ.copy()
    env["CLANG_FORMAT"] = FORMATTER
    env["FORMAT_SUGGESTIONS_PATCH"] = str(patch)
    p = run(["bash", "scripts/check-format.sh"], env=env)
    (first / "stdout").write_bytes(p.stdout)
    (first / "stderr").write_bytes(p.stderr)
    (first / "status").write_text(str(p.returncode) + "\n")
    after = snapshot(case / "after")
    result = {"case": name, "script_status": p.returncode, "source_unchanged": before == after,
              "patch_exists": patch.exists(), "expected": expected}
    (case / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    assert before == after, "Script changed source/config/script bytes"
    patch_bytes = patch.read_bytes() if patch.exists() else b""
    if expected in ("old_bug", "fixed_red"):
        strict = re.search(rb"clang-format failed \(exit ([0-9]+)\)", p.stderr)
        assert strict and int(strict.group(1)) != 0
        assert p.returncode == int(strict.group(1))
        assert patch_bytes and BEGIN in p.stderr and not p.stdout
        applicable = run(["git", "apply", "--check", str(patch)])
        (first / "apply-check.stdout").write_bytes(applicable.stdout)
        (first / "apply-check.stderr").write_bytes(applicable.stderr)
        (first / "apply-check.status").write_text(str(applicable.returncode) + "\n")
        assert applicable.returncode == 0
        headers = [line for line in patch_bytes.splitlines() if line.startswith(b"--- ")]
        assert b"--- a/" + LIVE.encode() in headers
        assert all(b"empty.c" not in h for h in headers)
        if expected == "old_bug":
            assert b"--- a/" + IGNORED.encode() in headers
            assert SENTINEL in patch_bytes and SENTINEL in p.stderr
        else:
            assert headers == [b"--- a/" + LIVE.encode()]
            assert SENTINEL not in patch_bytes + p.stdout + p.stderr
            assert IGNORED.encode() not in patch_bytes
    elif expected == "green":
        assert p.returncode == 0 and not p.stdout and not p.stderr and not patch.exists()
        assert (FIXTURE / LIVE).read_bytes() == LIVE_GOOD
    else:
        assert p.returncode != 0 and not patch.exists() and BEGIN not in p.stdout + p.stderr
        assert b"unknown key 'T1141InvalidStyleKey'" in p.stderr
        assert b"Formatter could not produce canonical bytes for " + LIVE.encode() in p.stderr
        assert SENTINEL not in p.stdout + p.stderr
    result["oracle_passed"] = True
    (case / "result.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result), flush=True)
    return patch


if __name__ == "__main__":
    assert not (E / "suite-started.json").exists(), "Keep FIRST: no automatic reruns"
    assert not FIXTURE.exists()
    FORMATTER = json.loads((E / "readiness.json").read_text())["formatter"]
    binary_sha = hashlib.sha256(Path(FORMATTER).read_bytes()).hexdigest()
    assert binary_sha == "16691dbe5bd3462af8acf565b20172db2a9ec683b9db9c86b740e9681947cfa3"
    (E / "suite-started.json").write_text(json.dumps({"utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "script_executions_budget": 4, "harness_repairs": 0}) + "\n")
    scripts = E / "scripts"
    scripts.mkdir()
    old = subprocess.check_output(["git", "-C", str(ROOT / "checkout"), "show", "HEAD:scripts/check-format.sh"])
    patched = (ROOT / "checkout/scripts/check-format.sh").read_bytes()
    (scripts / "old-check-format.sh").write_bytes(old)
    (scripts / "patched-check-format.sh").write_bytes(patched)
    fixture_files = {".clang-format": b"BasedOnStyle: LLVM\nIndentWidth: 2\n",
                     ".clang-format-ignore": (IGNORED + "\n").encode(),
                     "sub/.clang-format": b"BasedOnStyle: LLVM\nIndentWidth: 4\nAllowShortFunctionsOnASingleLine: None\n",
                     IGNORED: b"/* " + SENTINEL + b" */\nint    retained_first ( void ) {return 314;}\n",
                     LIVE: LIVE_BAD, "empty.c": b"", "scripts/check-format.sh": old}
    TRACKED = sorted(fixture_files)
    for name, data in fixture_files.items():
        path = FIXTURE / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    git("init", "--initial-branch=t1141-synthetic")
    git("add", "--all")
    git("-c", "user.name=NewLang Track T synthetic harness", "-c", "user.email=t1141@local.invalid", "-c", "commit.gpgsign=false", "commit", "-m", "Synthetic inputs only for T1141")
    (E / "oracle.json").write_text(json.dumps({"live_expected_canonical_utf8": LIVE_GOOD.decode(),
                                               "sentinel": SENTINEL.decode(), "fixture_head": git("rev-parse", "HEAD").decode().strip(),
                                               "cases": ["old_bug", "fixed_red", "green", "actual_invalid_style_failure"]}, indent=2) + "\n")
    execute("01-old-counterexample", "old_bug")
    (FIXTURE / "scripts/check-format.sh").write_bytes(patched)
    patch = execute("02-patched-red", "fixed_red")
    git("apply", str(patch))
    assert (FIXTURE / LIVE).read_bytes() == LIVE_GOOD, "Formatter canonical bytes differ from frozen oracle"
    execute("03-patched-green", "green")
    (FIXTURE / "sub/.clang-format").write_bytes(b"BasedOnStyle: LLVM\nT1141InvalidStyleKey: true\n")
    execute("04-patched-formatter-failure", "formatter_failure")
    (E / "suite-completed.json").write_text(json.dumps({"old_script_executions": 1, "patched_script_executions": 3,
                                                       "harness_repairs": 0, "all_oracles_passed": True}, indent=2) + "\n")
