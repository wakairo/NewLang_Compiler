#!/usr/bin/env python3
"""T1141-only staging: reuse unchanged archive helpers, no full bootstrap."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
REPO = ROOT / "checkout"
EVIDENCE = ROOT / "evidence"
EXPECTED_MAIN = "c120dd1accfefd3e8d3d7ae7a2f7f17b54e3f89a"
EXPECTED_SHA = "5369d292ef513d32758634f98ec7cf62c52f82a0a333eb330ecf9a325648b133"


def checked(args):
    p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    return p


def main():
    assert platform.freedesktop_os_release()["ID"] == "debian"
    assert platform.freedesktop_os_release()["VERSION_ID"] == "13"
    assert platform.machine() == "x86_64"
    assert subprocess.check_output(["git", "-C", str(REPO), "rev-parse", "HEAD"], text=True).strip() == EXPECTED_MAIN
    assert subprocess.check_output(["git", "-C", str(REPO), "rev-parse", "HEAD:scripts/toolchain-lock.json"], text=True).strip() == "457b445cd558293ebb061d7fd07844fea8526b37"
    lock = json.loads((REPO / "scripts/toolchain-lock.json").read_text())
    # This key selects exact artifact bytes; the actual host stays Debian13.
    artifact = lock["platforms"]["ubuntu-24.04-x86_64"]["sdk_archive"]
    assert artifact["size"] == 126520077
    assert artifact["tar_size"] == 448040960
    assert artifact["sha256"] == EXPECTED_SHA
    assert artifact["version"] == "23.1.3"
    spec = importlib.util.spec_from_file_location("t1141_bootstrap", REPO / "scripts/bootstrap.py")
    bootstrap = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(bootstrap)
    downloads = ROOT / "downloads"
    downloads.mkdir(exist_ok=True)
    archive = downloads / artifact["filename"]
    attempt = EVIDENCE / "sdk-download-attempt.json"
    if not archive.exists():
        assert not attempt.exists(), "SDK acquisition budget already consumed"
        attempt.write_text(json.dumps({"attempt": 1, "url": artifact["url"], "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}, indent=2) + "\n")
        print("SDK acquisition attempt 1/1 from exact locked HTTPS URL", flush=True)
        bootstrap._sdk_download(artifact, archive)
    bootstrap._sdk_valid_archive(artifact, archive)
    print(f"SDK archive actual size={archive.stat().st_size} sha256={bootstrap.sha256(archive)}", flush=True)
    prefix = ROOT / "sdk-23.1.3"
    assert not prefix.exists(), "Do not overwrite an existing SDK prefix"
    prefix.mkdir()
    bootstrap._sdk_decode_and_extract(artifact, archive, prefix)
    sdk = bootstrap._sdk_root(prefix)
    assert (sdk / "PROVENANCE.md").is_file()
    assert (sdk / "licenses").is_dir()
    executable = sdk / "bin/clang-format"
    actual = executable.resolve(strict=True)
    assert actual.is_relative_to(prefix.resolve())
    assert actual.is_file() and os.access(actual, os.X_OK)
    binary_hash = bootstrap.sha256(actual)
    ldd = checked(["ldd", str(actual)])
    (EVIDENCE / "formatter-ldd.stdout").write_bytes(ldd.stdout)
    (EVIDENCE / "formatter-ldd.stderr").write_bytes(ldd.stderr)
    (EVIDENCE / "formatter-ldd.status").write_text(str(ldd.returncode) + "\n")
    assert ldd.returncode == 0 and b"not found" not in ldd.stdout + ldd.stderr
    version = checked([str(actual), "--version"])
    (EVIDENCE / "formatter-version.stdout").write_bytes(version.stdout)
    (EVIDENCE / "formatter-version.stderr").write_bytes(version.stderr)
    (EVIDENCE / "formatter-version.status").write_text(str(version.returncode) + "\n")
    assert version.returncode == 0 and b"clang-format version 23.1.3" in version.stdout
    result = {"host": "debian-13-x86_64", "main": EXPECTED_MAIN,
              "archive": str(archive), "archive_size": archive.stat().st_size,
              "archive_sha256": bootstrap.sha256(archive), "tar_size": artifact["tar_size"],
              "sdk_root": str(sdk), "formatter": str(actual), "formatter_sha256": binary_hash,
              "version": version.stdout.decode().strip(), "ldd_status": ldd.returncode,
              "version_status": version.returncode, "download_attempts": 1,
              "bootstrap_sha256": hashlib.sha256((REPO / "scripts/bootstrap.py").read_bytes()).hexdigest()}
    (EVIDENCE / "readiness.json").write_text(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
