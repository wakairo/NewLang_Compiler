int live_example(void){
return 7;
}
