/* T1141_SYNTHETIC_FIRST_SENTINEL_20261104 */
int    retained_first ( void ) {return 314;}
