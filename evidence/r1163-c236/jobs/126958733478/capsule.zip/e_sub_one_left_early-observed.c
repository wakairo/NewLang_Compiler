#include <stdio.h>
#include <stddef.h>
static unsigned r1163_condition_count, r1163_branch_count[2];
static unsigned r1163_continue_count, r1163_break_count, r1163_store_count;
static unsigned r1163_postread_count, r1163_return_count;
static unsigned r1163_loan_enter_count, r1163_loan_exit_count;
static int r1163_bool_record(unsigned kind, unsigned tag,
                            unsigned long long lhs, unsigned long long rhs,
                            int actual) {
  if (kind) {
    ++r1163_condition_count;
    printf("R1163 COMPARE tag=%u lhs=%llu rhs=%llu bool=%d\n", tag, lhs, rhs, actual);
  } else {
    printf("R1163 GUARD tag=%u phase=%llu bound=%llu bool=%d\n", tag, lhs, rhs, actual);
  }
  return actual;
}
/* North Star V0/V1/AVS Checked-C reference output. */
#include <stdint.h>

#include <limits.h>
_Static_assert(CHAR_BIT == 8, "NewLang C17 requires 8-bit bytes");
_Static_assert(UINT8_MAX == 255 && sizeof(uint8_t) == 1 && ((uint8_t)-1) == 255, "NewLang C17 requires exact 8-bit uint8_t");
#include <stddef.h>
_Static_assert(SIZE_MAX == UINTMAX_C(18446744073709551615), "NewLang usize target mismatch");

typedef struct { uint8_t f0; uint8_t f1; } nl_type_10;

#ifdef NEWLANG_LOOP_OBSERVER
#include NEWLANG_LOOP_OBSERVER
#endif
#ifndef NL_LOOP_BIND
#define NL_LOOP_BIND(...) ((void)0)
#endif
#ifndef NL_LOOP_READ
#define NL_LOOP_READ(...) ((void)0)
#endif
#ifndef NL_LOOP_BEFORE
#define NL_LOOP_BEFORE(...) ((void)0)
#endif
#ifndef NL_LOOP_AFTER
#define NL_LOOP_AFTER(...) ((void)0)
#endif

#ifdef NEWLANG_SCALAR_LOOP_OBSERVER
#include NEWLANG_SCALAR_LOOP_OBSERVER
#endif
#ifndef NL_SCALAR_PHASE
#define NL_SCALAR_PHASE(...) ((void)0)
#endif
#ifndef NL_SCALAR_RESULT
#define NL_SCALAR_RESULT(...) ((void)0)
#endif

static void nl_fn_10(void);

static void nl_fn_10(void)
{
    nl_type_10 nl_local_1 = { .f1 = 149, .f0 = 83, };
    
printf("R1163 ROOT tag=3 root=%p f0=%p f1=%p v0=%llu v1=%llu\n", (void *)(&nl_local_1), (void *)(&nl_local_1.f0), (void *)(&nl_local_1.f1), (unsigned long long)(nl_local_1.f0), (unsigned long long)(nl_local_1.f1));
(void)nl_local_1;
    NL_LOOP_BIND(&nl_local_1.f0, &nl_local_1.f1);
    size_t nl_local_2;
    size_t nl_loop_carry_10 = (size_t)UINTMAX_C(19);
    
printf("R1163 SCALAR tag=6 value=%llu\n", (unsigned long long)(nl_loop_carry_10));
for (;;) {
        const size_t nl_loop_phase_10 = nl_loop_carry_10;
        
printf("R1163 SCALAR tag=7 value=%llu\n", (unsigned long long)(nl_loop_phase_10));
NL_SCALAR_PHASE(nl_loop_phase_10);
        if (!(r1163_bool_record(0, 1, (unsigned long long)(nl_loop_phase_10), (unsigned long long)((size_t)UINTMAX_C(19)), (nl_loop_phase_10 < (size_t)UINTMAX_C(19))))) {
            nl_loop_carry_10 = nl_loop_phase_10 - (size_t)UINTMAX_C(1);
printf("R1163 ASSIGN tag=8 value=%llu\n", (unsigned long long)(nl_loop_carry_10));

printf("R1163 ARITH tag=2 lhs=%llu rhs=%llu result=%llu\n", (unsigned long long)(nl_loop_phase_10), (unsigned long long)((size_t)UINTMAX_C(1)), (unsigned long long)(nl_loop_carry_10));

            
++r1163_continue_count;
continue;
        }
        nl_local_2 = nl_loop_phase_10;
printf("R1163 ASSIGN tag=9 value=%llu\n", (unsigned long long)(nl_local_2));

        NL_SCALAR_RESULT(nl_local_2);
        
++r1163_break_count;
break;
    }
    (void)nl_local_2;
    const size_t nl_local_3 = nl_local_2;
    
printf("R1163 SCALAR tag=10 value=%llu\n", (unsigned long long)(nl_local_3));
(void)nl_local_3;
    uint8_t nl_if_result_19;
    if ((r1163_bool_record(1, 0, (unsigned long long)(nl_local_3), (unsigned long long)(((size_t)UINTMAX_C(18))), (nl_local_3 == ((size_t)UINTMAX_C(18)))))) {
++r1163_branch_count[0];
printf("R1163 BRANCH arm=0 c_arm=0\n");

        (void)0;
        
++r1163_return_count;
return;
    } else {
++r1163_branch_count[1];
printf("R1163 BRANCH arm=1 c_arm=1\n");

        uint8_t nl_loan_result_1;
        {
++r1163_loan_enter_count;

            uint8_t *const nl_local_4 = &nl_local_1.f0;
            (void)nl_local_4;
            const uint8_t nl_replace_old_4 = *nl_local_4;
            
printf("R1163 SCALAR tag=11 value=%llu\n", (unsigned long long)(nl_replace_old_4));

printf("R1163 STORE_BEFORE tag=4 address=%p old=%llu\n", (void *)(&(*nl_local_4)), (unsigned long long)(*nl_local_4));
*nl_local_4 = 227;
++r1163_store_count;

printf("R1163 STORE_AFTER tag=5 address=%p current=%llu\n", (void *)(&(*nl_local_4)), (unsigned long long)(*nl_local_4));

            nl_loan_result_1 = nl_replace_old_4;
printf("R1163 ASSIGN tag=12 value=%llu\n", (unsigned long long)(nl_loan_result_1));

        
++r1163_loan_exit_count;
}
        (void)nl_loan_result_1;
        nl_if_result_19 = nl_loan_result_1;
printf("R1163 ASSIGN tag=13 value=%llu\n", (unsigned long long)(nl_if_result_19));

    }
    const uint8_t nl_local_5 = nl_if_result_19;
    
printf("R1163 SCALAR tag=14 value=%llu\n", (unsigned long long)(nl_local_5));
(void)nl_local_5;
    const uint8_t nl_local_6 = nl_local_5;
    
printf("R1163 SCALAR tag=15 value=%llu\n", (unsigned long long)(nl_local_6));
(void)nl_local_6;
    const uint8_t nl_local_7 = nl_local_1.f0;
    
++r1163_postread_count;

printf("R1163 POSTREAD tag=17 address=%p value=%llu index=%llu\n", (void *)(&(nl_local_1.f0)), (unsigned long long)(nl_local_7), (unsigned long long)(0));

printf("R1163 SCALAR tag=16 value=%llu\n", (unsigned long long)(nl_local_7));
(void)nl_local_7;
    NL_LOOP_READ(&nl_local_1.f0, nl_local_7);
    const uint8_t nl_local_8 = nl_local_1.f1;
    
++r1163_postread_count;

printf("R1163 POSTREAD tag=19 address=%p value=%llu index=%llu\n", (void *)(&(nl_local_1.f1)), (unsigned long long)(nl_local_8), (unsigned long long)(1));

printf("R1163 SCALAR tag=18 value=%llu\n", (unsigned long long)(nl_local_8));
(void)nl_local_8;
    NL_LOOP_READ(&nl_local_1.f1, nl_local_8);
    (void)nl_local_6;
    (void)nl_local_7;
    (void)nl_local_8;
    (void)0;
}

int r1163_guest_main(void)
{
    nl_fn_10();
    return 0;
}

int main(void) {
  int result = r1163_guest_main();
  printf("R1163 COUNTERS condition=%u then=%u else=%u continue=%u break=%u store=%u postread=%u returns=%u loan_enter=%u loan_exit=%u\n", r1163_condition_count, r1163_branch_count[0], r1163_branch_count[1], r1163_continue_count, r1163_break_count, r1163_store_count, r1163_postread_count, r1163_return_count, r1163_loan_enter_count, r1163_loan_exit_count);
  return result;
}
