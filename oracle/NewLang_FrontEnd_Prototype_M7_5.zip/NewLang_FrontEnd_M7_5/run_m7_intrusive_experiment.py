from __future__ import annotations

import json
from pathlib import Path

from newlang_frontend.intrusive_pressure import run_intrusive_pressure

result = run_intrusive_pressure(seed=20261004, cases=20_000)
out = Path('m7_intrusive_owner_recovery_results.json')
out.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2, sort_keys=True))
