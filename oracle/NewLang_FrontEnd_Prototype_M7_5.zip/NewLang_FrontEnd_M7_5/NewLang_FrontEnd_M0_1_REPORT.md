# NewLang Front-End Prototype M0.1 — Semantic-call Bridge Correction Report

> Status: **completed experimental M0.1 correction**
>
> Semantic baseline: `NewLang_v0_spec_Draft17_2.md`
>
> Starting point: Front-End Prototype M0
>
> Purpose: correct the M0 function-boundary semantic bridge before adding M1 lifetime/pointer mechanisms. M0.1 is not a normative language revision.

## 1. Why M0.1 existed

M0 successfully parsed and type-checked real `.nl` source and lowered `store(self@field, value)` to the existing Draft-17.2 source effect/dependency runner.

The remaining hole was function-boundary substitution:

```text
callee body:
    Change(self.value)

caller:
    loan write b as w {
        w.set_value(...)
    }
```

The old bridge called `Box::set_value` only by function name. It did not carry the fact that:

```text
callee self
    aliases caller place b
```

because `w` is a lexical loan alias of `b`.

That was sufficient for the M0 smoke corpus, which created no hidden current-value dependencies, but it was not sufficient for dependency-heavy source validation.

M0.1 makes this substitution explicit in the shared semantic IR rather than adding a parallel front-end effect checker.

---

## 2. Shared semantic-call IR change

The vendored source semantic IR now records formal parameters:

```text
FunctionDef {
    name
    body
    params
}
```

and call-site semantic actual places:

```text
CallStmt {
    function
    actual_places
    origin
}
```

`actual_places[i]` is:

```text
caller place string
    if formal parameter i semantically aliases a caller place

None
    for an ordinary by-value parameter with a fresh callee place
```

The important distinction is therefore:

```text
fn mutate(self: ref<write,T>)
    caller place aliases callee formal

fn consume_or_copy(self: T)
    callee formal is a fresh place
```

M0.1 does **not** substitute a by-value formal with the caller binding merely because the argument expression has a name.

---

## 3. Loan alias preservation

Lowering now carries a small lexical place-alias environment.

Example:

```text
let b = ...

loan write b as w {
    w.set_value(...)
}
```

is lowered with:

```text
w -> b
```

for the loan body.

The receiver call therefore carries:

```text
CallStmt(
    function = Box::set_value,
    actual_places = (b, None)
)
```

where the second `None` is the ordinary by-value numeric argument.

Inside `Box::set_value`:

```text
Change(self.value)
```

is instantiated as:

```text
Change(b.value)
```

at the call boundary.

---

## 4. Nested wrapper substitution

Substitution is applied recursively at every known call boundary.

Source:

```text
fn set_value(self: ref<write,Self>, value: u32) -> unit {
    store(self@value, value)
}

fn update(self: ref<write,Self>, value: u32) -> unit {
    self.set_value(value)
}

...

loan write b as w {
    w.update(u32(2))
}
```

The semantic path becomes conceptually:

```text
main w -> b

update self -> b

set_value self -> update self -> b

Change(self.value)
    -> Change(b.value)
```

An injected live dependency:

```text
b.value
```

therefore conflicts in the innermost callee exactly as it would after normative body substitution.

This source test now rejects as intended.

---

## 5. Aliased actual parameters

M0.1 explicitly tests:

```text
w.set_other(w, value)
```

where both ref formals receive the same caller place.

The lowered call carries:

```text
actual_places = (b, b, None)
```

so aliasing is not lost merely because the callee uses different formal names:

```text
self
other
```

An effect on:

```text
other.value
```

is instantiated to:

```text
b.value
```

and conflicts with a live `b.value` dependency.

Result: **PASS**.

---

## 6. By-value place isolation

The opposite break-test is equally important.

```text
fn touch_copy(self: Self) -> unit {
    loan write self as w {
        store(w@value, ...)
    }
}

...

b.touch_copy()
```

must **not** turn an effect on the callee parameter into:

```text
Change(b.value)
```

when the formal is by value.

M0.1 assigns a fresh call-frame place such as:

```text
@frame1:Box::touch_copy:self
```

and the effect becomes:

```text
Change(@frame1:Box::touch_copy:self.value)
```

A live caller dependency `b.value` therefore remains unaffected.

This directly prevents a common but incorrect “source name means same place” lowering rule.

Result: **PASS**.

---

## 7. Dependency and effect substitution use one mechanism

The shared exact runner substitutes the same formal-root mapping into:

```text
EffectStmt
AddDepStmt
KillDepStmt
```

A direct semantic-IR regression constructs:

```text
mutate(self):
    AddDep(self.value)
    Change(self.value)

main:
    mutate(box)
```

and observes:

```text
AddDep(box.value)
Change(box.value)
-> semantic conflict at box.value
```

The substitution rule therefore applies to both sides of the dependency/effect relation.

---

## 8. Receiver syntax remains semantic sugar

M0.1 compares:

```text
w.set_value(u32(2))
```

with:

```text
set_value(w, u32(2))
```

under the same injected caller dependency.

Both produce:

```text
semantic conflict at b.value
```

This is additional evidence that receiver syntax is not becoming a second call semantic system.

Result: **PASS**.

---

## 9. Source-origin semantic diagnostics

`EffectStmt` and `CallStmt` now carry optional origin metadata.

When a substituted callee effect conflicts, the exact runner records the origin of the rejecting effect.

The front end therefore reports the callee operation:

```text
store(self@value, value)
```

as the primary semantic diagnostic span instead of falling back to the first declaration in the file.

For M0.1 test-only dependency injection:

```text
E_SEMANTIC_CONFLICT:
semantic conflict at b.value
```

points at the actual `store` source line in `Box::set_value`, including through an intermediate wrapper.

This remains a first-error diagnostic; related call-site notes are future diagnostic polish.

---

## 10. Developer-only dependency injection hook

M0.1 adds:

```text
check_source(..., semantic_initial_deps=(...))
```

for falsification tests.

This is **not NewLang source syntax**.

M0 still has no source construct that naturally creates `Value` / `Occurrence` hidden dependencies, so the hook lets the real-source lowering be tested against a caller-visible semantic pre-state before M1/M2 expose such mechanisms naturally.

No user-facing `depend(...)` pseudo-feature was added.

---

## 11. Source corpus added in M0.1

Four additional real `.nl` files exercise the corrected bridge:

| File | Injected dependency | Expected | Result |
|---|---|---|---|
| `11_semantic_direct_ref_conflict.nl` | `b.value` | semantic reject | PASS |
| `12_semantic_nested_wrapper_conflict.nl` | `b.value` | semantic reject | PASS |
| `13_semantic_aliased_actuals_conflict.nl` | `b.value` | semantic reject | PASS |
| `14_semantic_by_value_isolation.nl` | `b.value` | accept | PASS |

The original ten M0 `.nl` programs remain unchanged and still pass.

---

## 12. Regression tests

M0.1 test suite:

```text
29 passed
```

Coverage includes the original M0 tests plus:

```text
formal -> actual dependency substitution
formal -> actual effect substitution
loan binding -> source place alias
nested wrapper substitution
same-place aliased actuals
by-value fresh call-frame isolation
receiver/ordinary semantic equivalence
semantic rejection source origin
legacy SourceProgram negative cases
```

Bytecode validation:

```text
python -m compileall -q newlang_frontend vendor tests
PASS
```

The unchanged full upstream Draft-17.2 closure checker was rerun independently:

```text
110 passed
compileall PASS
```

No upstream regression was observed.

---

## 13. What M0.1 deliberately did not do

M0.1 does not add:

```text
ptr / LifetimeDomain
initialize / take / destroy
exclusive refs
sum / match
Array / span
callbacks
loops / recursion in the front end
generics
Storage / slot / Allocation
new source-visible dependency syntax
post-state/result dependency transformer syntax
code generation
```

It also does not turn the small string-form place paths into a final compiler representation.

Current bridge paths are sufficient for M0.1:

```text
root
root.field
root.field.subfield
```

Before arrays/index projections and richer pointer-derived place identities become substantial, a structured compiler-internal Place/Projection representation should be considered. That is an implementation representation issue, not a source semantic change.

---

## 14. Remaining semantic-bridge boundary

M0.1 fixes **callee formal -> caller place substitution for effects and dependency facts already represented by the shared source IR**.

It does not yet solve every future post-state problem. In particular, source constructs that return values carrying hidden dependencies will eventually need an explicit result/post-state dependency transformer rather than relying on undifferentiated surviving `AddDepStmt` state.

That work should be introduced when M1/M2 first lowers a source operation that actually creates/returns such a dependency.

The important architectural result is that the substitution point now exists in the shared semantic-call layer; the front end does not need its own parallel lifetime/effect logic.

---

## 15. M0.1 judgment

The M0 architectural decision survives the correction.

Keep:

```text
Python handwritten front end
ReceiverCall / QualifiedCall / FieldProjection AST separation
Self + explicit self
module-private representation experiment
selection before compatibility/weakening
Draft-17.2 checker as semantic authority
```

Corrected:

```text
function call now carries semantic actual places
loan aliases are preserved
ref formals substitute caller places
by-value formals get fresh callee places
nested wrappers preserve substitution
semantic conflicts keep source origin
```

**M0.1 judgment: PASS.**

The specific M0 blocker identified before M1 is closed.

Proceeding to M1 is now reasonable, with one implementation discipline carried forward:

> when a new M1 source construct creates hidden post-state/dependency information, extend the shared semantic transformer at the same time rather than encoding that meaning independently in the front-end type checker.
