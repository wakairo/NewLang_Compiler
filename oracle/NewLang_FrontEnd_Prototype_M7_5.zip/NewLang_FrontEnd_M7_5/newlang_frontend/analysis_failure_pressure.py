from __future__ import annotations

import random
from dataclasses import dataclass

import sys
from pathlib import Path

_VENDOR = Path(__file__).resolve().parent.parent / "vendor"
if str(_VENDOR) not in sys.path:
    sys.path.insert(0, str(_VENDOR))

from newlang_checker.analysis import BoundedAnalyzer  # type: ignore[import-not-found]
from newlang_checker.ir import Effect  # type: ignore[import-not-found]
from newlang_checker.source_ir import (  # type: ignore[import-not-found]
    AddDepStmt,
    CallStmt,
    ExactSourceRunner,
    FunctionDef,
    GenericCallStmt,
    SourceProgram,
)

from .authority_region_pressure import DenseVecModel, ResponsibilityOracle
from .recursive_summary import infer_semantic_effect_summaries


@dataclass(frozen=True, slots=True)
class AnalysisPressureResult:
    cases: int
    exact_accepts: int
    exact_rejections: int
    bounded_accepts: int
    bounded_rejections: int
    precision_rejections: int
    false_accepts: int
    false_rejects: int
    unknown_summary_cases: int
    diagnostic_provenance_cases: int


def _overlap(a: str, b: str) -> bool:
    if a == "*" or b == "*":
        return True
    aa = a.split(".")
    bb = b.split(".")
    for left, right in zip(aa, bb):
        if left == right:
            continue
        if left == "$index:*" and right.startswith("$index:"):
            continue
        if right == "$index:*" and left.startswith("$index:"):
            continue
        return False
    return True


def _conflicts(effect: Effect, deps: set[str]) -> bool:
    return effect.kind in {"Change", "Reset", "EndRoot", "Unknown"} and any(
        _overlap(effect.place, dep) for dep in deps
    )


def run_analysis_pressure(*, seed: int = 20261004, cases: int = 20_000) -> AnalysisPressureResult:
    """Pressure finite widening and Unknown conservatism.

    This is deliberately independent of the exact frontend parser.  It attacks the
    small may-effect abstraction directly and checks the critical M6.6 property:
    precision loss may reject an otherwise safe case, but must never accept an
    exact conflict.
    """

    rng = random.Random(seed)
    exact_accepts_count = 0
    exact_rejections = 0
    bounded_accepts = 0
    bounded_rejections = 0
    precision_rejections = 0
    false_accepts = 0
    false_rejects = 0

    places = ["x.a", "x.b", "x.c", "y.a", "y.b", "z.$index:0", "z.$index:1"]
    kinds = ["Change", "Reset", "EndRoot"]

    for _ in range(cases):
        alt_count = rng.randint(1, 16)
        alternatives: list[tuple[set[str], list[Effect]]] = []
        exact_accepts = True
        for _alt in range(alt_count):
            dep_count = rng.randint(0, 3)
            eff_count = rng.randint(0, 3)
            deps = set(rng.sample(places, dep_count))
            effects = [Effect(rng.choice(kinds), rng.choice(places)) for _ in range(eff_count)]
            # Rare explicit Unknown models an opaque/failed interprocedural fact.
            if rng.randrange(80) == 0:
                effects.append(Effect("Unknown", "*"))
            alternatives.append((deps, effects))
            if any(_conflicts(e, deps) for e in effects):
                exact_accepts = False

        analyzer = BoundedAnalyzer(alternative_budget=8)
        result = analyzer.analyze_correlated_alternatives(alternatives)
        if exact_accepts:
            exact_accepts_count += 1
            if not result.accepted:
                false_rejects += 1
        else:
            exact_rejections += 1
            if result.accepted:
                false_accepts += 1
        if result.accepted:
            bounded_accepts += 1
        else:
            bounded_rejections += 1
            if result.precision_loss:
                precision_rejections += 1

    # Exercise recursive summary reasons and diagnostic provenance separately.
    unknown_summary_cases = 0
    diagnostic_provenance_cases = 0

    growing = {
        "grow": FunctionDef(
            "grow",
            (
                # Each recursive substitution grows the projection until the finite
                # effect budget widens rather than diverging.
                CallStmt("grow", ("x.next",), origin="recursive-call-site"),
            ),
            ("x",),
        )
    }
    # Seed the body with an effect without importing another statement class above.
    from newlang_checker.source_ir import EffectStmt  # type: ignore[import-not-found]
    growing["grow"] = FunctionDef(
        "grow",
        (
            EffectStmt(Effect("Change", "x.value"), origin="grow-effect"),
            CallStmt("grow", ("x.next",), origin="recursive-call-site"),
        ),
        ("x",),
    )
    summaries, stats = infer_semantic_effect_summaries(growing, max_effects_per_function=4, max_scc_iterations=32)
    if not summaries["grow"].unknown or stats.widened_sccs != 1:
        raise AssertionError("projection-growing SCC did not widen deterministically")
    unknown_summary_cases += 1
    if not any(reason.startswith("recursive-scc:") for reason in summaries["grow"].unknown_reasons):
        raise AssertionError("recursive SCC context was lost from Unknown provenance")

    dep = {
        "dep": FunctionDef(
            "dep",
            (
                AddDepStmt("x.value", origin="dependency-site"),
                CallStmt("dep", ("x",), origin="dependency-recursive-call"),
            ),
            ("x",),
        )
    }
    dep_summaries, _ = infer_semantic_effect_summaries(dep)
    if not dep_summaries["dep"].unknown or "dependency-post-state" not in dep_summaries["dep"].unknown_reasons:
        raise AssertionError("recursive dependency post-state was not preserved as Unknown")
    unknown_summary_cases += 1
    dep_program = SourceProgram(dep, function_summaries=dep_summaries)
    dep_run = ExactSourceRunner(dep_program).run("dep")
    rejected = next((p for p in dep_run.paths if p.rejected), None)
    if rejected is None or "dependency-post-state" not in rejected.reason:
        raise AssertionError("Unknown diagnostic lost the precision-loss cause")
    if rejected.rejection_origin != "dependency-recursive-call":
        raise AssertionError("Unknown diagnostic did not point at the recursive call")
    diagnostic_provenance_cases += 1

    unresolved = SourceProgram(
        {"main": FunctionDef("main", (GenericCallStmt("missing"),))},
        generic_resolution={},
    )
    unresolved_run = ExactSourceRunner(unresolved).run("main")
    rejected = next((p for p in unresolved_run.paths if p.rejected), None)
    if rejected is None or "unresolved generic call missing" not in rejected.reason:
        raise AssertionError("unresolved generic call did not retain a useful Unknown reason")
    diagnostic_provenance_cases += 1

    if false_accepts:
        raise AssertionError(f"bounded analysis produced {false_accepts} false accepts")

    return AnalysisPressureResult(
        cases,
        exact_accepts_count,
        exact_rejections,
        bounded_accepts,
        bounded_rejections,
        precision_rejections,
        false_accepts,
        false_rejects,
        unknown_summary_cases,
        diagnostic_provenance_cases,
    )


def run_failure_pressure(*, seed: int = 20261004, traces: int = 300, steps: int = 64) -> dict[str, int]:
    """Inject ordinary recoverable failures at every DenseVec transition phase."""

    rng = random.Random(seed)
    operations = 0
    push_failures = 0
    pop_failures = 0
    growth_failures = 0
    successful_pushes = 0
    successful_pops = 0

    push_failure_points = ("after_claim", "after_initialize", "after_publish")
    pop_failure_points = ("after_claim", "after_take", "after_publish", "after_return")

    for trace in range(traces):
        oracle = ResponsibilityOracle()
        vec = DenseVecModel(rng.randint(2, 8), oracle=oracle, name=f"m66-failure-{trace}")
        model: list[str] = []
        serial = 0

        for _ in range(steps):
            operations += 1
            action = rng.randrange(100)

            if action < 44 and len(model) < vec.region.capacity:
                serial += 1
                token = f"f{trace}:{serial}"
                oracle.create_external(token)
                before = tuple(model)
                if rng.randrange(3) == 0:
                    point = rng.choice(push_failure_points)
                    if vec.push(token, fail_at=point):
                        raise AssertionError(f"push failure injection {point} unexpectedly committed")
                    push_failures += 1
                    if tuple(model) != before or vec.logical_contents() != before:
                        raise AssertionError("failed push changed logical contents")
                    if oracle.owner(token) != "external":
                        raise AssertionError("failed push lost caller responsibility")
                else:
                    if not vec.push(token):
                        raise AssertionError("ordinary push unexpectedly failed")
                    model.append(token)
                    successful_pushes += 1

            elif action < 78 and model:
                before = tuple(model)
                expected = model[-1]
                if rng.randrange(3) == 0:
                    point = rng.choice(pop_failure_points)
                    ok, value = vec.try_pop(fail_at=point)
                    if ok or value is not None:
                        raise AssertionError(f"pop failure injection {point} unexpectedly committed")
                    pop_failures += 1
                    if tuple(model) != before or vec.logical_contents() != before:
                        raise AssertionError("failed pop changed logical contents")
                    if oracle.owner(expected) != vec.region.region_id:
                        raise AssertionError("failed pop did not restore hidden responsibility")
                else:
                    got = vec.pop()
                    if got != expected:
                        raise AssertionError("successful pop returned the wrong token")
                    model.pop()
                    if oracle.owner(got) != "external":
                        raise AssertionError("successful pop did not transfer responsibility to caller")
                    successful_pops += 1

            elif action < 88:
                before = tuple(model)
                if vec.grow(vec.region.capacity + rng.randint(1, 4), allocation_fails=True):
                    raise AssertionError("injected allocation failure committed growth")
                growth_failures += 1
                if vec.logical_contents() != before:
                    raise AssertionError("allocation failure changed contents")

            # M6.6 normal-error closure invariant: no transition/claim may leak to
            # the next public operation regardless of the injected failure point.
            if vec.region.transition_active:
                raise AssertionError("normal error path leaked transition authority")
            if vec.region.open_claims:
                raise AssertionError("normal error path leaked scoped claim authority")
            if vec.logical_contents() != tuple(model):
                raise AssertionError("public metadata and hidden responsibility diverged")
            oracle.assert_conserved()

        while model:
            expected = model.pop()
            if vec.pop() != expected:
                raise AssertionError("failure pressure drain mismatch")
        vec.teardown()
        oracle.assert_conserved()

    return {
        "traces": traces,
        "operations": operations,
        "push_failures": push_failures,
        "pop_failures": pop_failures,
        "growth_failures": growth_failures,
        "successful_pushes": successful_pushes,
        "successful_pops": successful_pops,
        "mismatches": 0,
    }
