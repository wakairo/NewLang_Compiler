from __future__ import annotations

from . import ast
from .diagnostics import Diagnostic, FrontendError
from .source import Span
from .tokens import Token, TokenKind


class Parser:
    def __init__(self, tokens: tuple[Token, ...]):
        self.tokens = tokens
        self.i = 0
        self.loop_depth = 0

    @property
    def cur(self) -> Token:
        return self.tokens[self.i]

    def at(self, kind: TokenKind) -> bool:
        return self.cur.kind is kind

    def bump(self) -> Token:
        tok = self.cur
        self.i += 1
        return tok

    def expect(self, kind: TokenKind, code: str = "E_PARSE") -> Token:
        if not self.at(kind):
            raise FrontendError(Diagnostic(code, f"expected {kind.name}, found {self.cur.kind.name}", self.cur.span))
        return self.bump()

    def skip_newlines(self) -> None:
        while self.at(TokenKind.NEWLINE):
            self.bump()

    def program(self) -> ast.Program:
        decls: list[ast.TopDecl] = []
        self.skip_newlines()
        while not self.at(TokenKind.EOF):
            if self.at(TokenKind.MODULE):
                decls.append(self.module_decl())
            elif self.at(TokenKind.SUM):
                decls.append(self.sum_decl())
            elif self.at(TokenKind.FN):
                decls.append(self.function_decl())
            else:
                raise FrontendError(Diagnostic("E_PARSE_DECL", "expected module, sum, or fn declaration", self.cur.span))
            self.skip_newlines()
        return ast.Program(tuple(decls))


    def decl_type_params(self) -> tuple[str, ...]:
        params: list[str] = []
        if not self.at(TokenKind.LT):
            return ()
        self.bump()
        while True:
            tp = self.expect(TokenKind.IDENT, "E_PARSE_GENERIC")
            if tp.text in params:
                raise FrontendError(Diagnostic("E_DUP_TYPE_PARAM", f"duplicate type parameter {tp.text}", tp.span))
            params.append(tp.text)
            if not self.at(TokenKind.COMMA):
                break
            self.bump()
        self.expect(TokenKind.GT, "E_PARSE_GENERIC")
        return tuple(params)

    def module_decl(self) -> ast.ModuleDecl:
        start = self.expect(TokenKind.MODULE).span
        name = self.expect(TokenKind.IDENT)
        type_params = self.decl_type_params()
        self.skip_newlines()
        struct = self.struct_decl()
        functions: list[ast.FunctionDecl] = []
        self.skip_newlines()
        while self.at(TokenKind.FN):
            functions.append(self.function_decl())
            self.skip_newlines()
        end = self.expect(TokenKind.END)
        return ast.ModuleDecl(name.text, type_params, struct, tuple(functions), Span.merge(start, end.span))

    def struct_decl(self) -> ast.StructDecl:
        start = self.expect(TokenKind.STRUCT).span
        self.expect(TokenKind.LBRACE)
        fields: list[ast.FieldDecl] = []
        self.skip_newlines()
        while not self.at(TokenKind.RBRACE):
            name = self.expect(TokenKind.IDENT)
            self.expect(TokenKind.COLON)
            ty = self.type_syntax()
            fields.append(ast.FieldDecl(name.text, ty, Span.merge(name.span, ty.span)))
            if self.at(TokenKind.COMMA):
                self.bump()
            self.skip_newlines()
        end = self.expect(TokenKind.RBRACE)
        return ast.StructDecl(tuple(fields), Span.merge(start, end.span))

    def sum_decl(self) -> ast.SumDecl:
        start = self.expect(TokenKind.SUM).span
        name = self.expect(TokenKind.IDENT)
        type_params = self.decl_type_params()
        self.expect(TokenKind.LBRACE)
        variants: list[ast.SumVariantDecl] = []
        self.skip_newlines()
        while not self.at(TokenKind.RBRACE):
            v = self.expect(TokenKind.IDENT)
            payload = None
            end_span = v.span
            if self.at(TokenKind.LPAREN):
                self.bump()
                payload = self.type_syntax()
                end_span = self.expect(TokenKind.RPAREN).span
            variants.append(ast.SumVariantDecl(v.text, payload, Span.merge(v.span, end_span)))
            if self.at(TokenKind.COMMA):
                self.bump()
            self.skip_newlines()
        end = self.expect(TokenKind.RBRACE)
        if not variants:
            raise FrontendError(Diagnostic("E_EMPTY_SUM", "sum must declare at least one variant", Span.merge(start, end.span)))
        return ast.SumDecl(name.text, type_params, tuple(variants), Span.merge(start, end.span))

    def function_decl(self) -> ast.FunctionDecl:
        start = self.expect(TokenKind.FN).span
        name = self.expect(TokenKind.IDENT)
        type_params: list[str] = []
        if self.at(TokenKind.LT):
            self.bump()
            while True:
                tp = self.expect(TokenKind.IDENT, "E_PARSE_GENERIC")
                if tp.text in type_params:
                    raise FrontendError(Diagnostic("E_DUP_TYPE_PARAM", f"duplicate type parameter {tp.text}", tp.span))
                type_params.append(tp.text)
                if not self.at(TokenKind.COMMA):
                    break
                self.bump()
            self.expect(TokenKind.GT, "E_PARSE_GENERIC")
        self.expect(TokenKind.LPAREN)
        params: list[ast.ParamDecl] = []
        self.skip_newlines()
        if not self.at(TokenKind.RPAREN):
            while True:
                p_name = self.bump()
                if p_name.kind not in {TokenKind.IDENT, TokenKind.SELF_VALUE}:
                    raise FrontendError(Diagnostic("E_PARSE_PARAM", "expected parameter name", p_name.span))
                self.expect(TokenKind.COLON)
                p_type = self.type_syntax()
                params.append(ast.ParamDecl(p_name.text, p_type, Span.merge(p_name.span, p_type.span)))
                if not self.at(TokenKind.COMMA):
                    break
                self.bump()
                self.skip_newlines()
        self.skip_newlines()
        self.expect(TokenKind.RPAREN)
        self.expect(TokenKind.ARROW)
        ret = self.type_syntax()
        body = self.block()
        return ast.FunctionDecl(name.text, tuple(type_params), tuple(params), ret, body, Span.merge(start, body.span))

    def type_syntax(self) -> ast.TypeSyntax:
        if self.at(TokenKind.EXCLUSIVE):
            start = self.bump().span
            ref_tok = self.expect(TokenKind.IDENT, "E_PARSE_TYPE")
            if ref_tok.text != "ref":
                raise FrontendError(Diagnostic("E_PARSE_TYPE", "exclusive must qualify ref<...>", ref_tok.span))
            self.expect(TokenKind.LT)
            mode_tok = self.bump()
            if mode_tok.kind not in {TokenKind.READ, TokenKind.WRITE}:
                raise FrontendError(Diagnostic("E_PARSE_TYPE", "expected read or write ref mode", mode_tok.span))
            self.expect(TokenKind.COMMA)
            inner = self.type_syntax()
            end = self.expect(TokenKind.GT)
            return ast.ExclusiveRefTypeSyntax(mode_tok.text, inner, Span.merge(start, end.span))

        if self.at(TokenKind.LPAREN):
            start = self.bump().span
            items: list[ast.TypeSyntax] = [self.type_syntax()]
            while self.at(TokenKind.COMMA):
                self.bump()
                items.append(self.type_syntax())
            end = self.expect(TokenKind.RPAREN)
            if len(items) < 2:
                raise FrontendError(Diagnostic("E_PARSE_TYPE", "tuple type requires at least two elements", Span.merge(start, end.span)))
            return ast.TupleTypeSyntax(tuple(items), Span.merge(start, end.span))

        if self.at(TokenKind.BLOCK):
            start = self.bump().span
            self.expect(TokenKind.LPAREN)
            params: list[ast.TypeSyntax] = []
            self.skip_newlines()
            if not self.at(TokenKind.RPAREN):
                while True:
                    params.append(self.type_syntax())
                    if not self.at(TokenKind.COMMA):
                        break
                    self.bump()
            self.expect(TokenKind.RPAREN)
            self.expect(TokenKind.ARROW)
            result = self.type_syntax()
            return ast.BlockTypeSyntax(tuple(params), result, Span.merge(start, result.span))

        tok = self.bump()
        if tok.kind not in {TokenKind.IDENT, TokenKind.SELF_TYPE, TokenKind.UNIT}:
            raise FrontendError(Diagnostic("E_PARSE_TYPE", "expected type name", tok.span))

        if tok.kind is TokenKind.IDENT and tok.text == "ref" and self.at(TokenKind.LT):
            start = tok.span
            self.bump()
            mode_tok = self.bump()
            if mode_tok.kind not in {TokenKind.READ, TokenKind.WRITE}:
                raise FrontendError(Diagnostic("E_PARSE_TYPE", "expected read or write ref mode", mode_tok.span))
            self.expect(TokenKind.COMMA)
            inner = self.type_syntax()
            end = self.expect(TokenKind.GT)
            return ast.RefTypeSyntax(mode_tok.text, inner, Span.merge(start, end.span))

        if tok.kind is TokenKind.IDENT and tok.text == "Array" and self.at(TokenKind.LT):
            self.bump()
            inner = self.type_syntax()
            self.expect(TokenKind.COMMA)
            length = self.expect(TokenKind.INT)
            end = self.expect(TokenKind.GT)
            return ast.ArrayTypeSyntax(inner, int(length.text), Span.merge(tok.span, end.span))

        if tok.kind is TokenKind.IDENT and tok.text == "span" and self.at(TokenKind.LT):
            self.bump()
            mode = self.bump()
            if mode.kind not in {TokenKind.READ, TokenKind.WRITE}:
                raise FrontendError(Diagnostic("E_PARSE_TYPE", "span mode must be read or write", mode.span))
            self.expect(TokenKind.COMMA)
            inner = self.type_syntax()
            end = self.expect(TokenKind.GT)
            return ast.SpanTypeSyntax(mode.text, inner, Span.merge(tok.span, end.span))

        if tok.kind is TokenKind.IDENT and self.at(TokenKind.LT):
            start = tok.span
            self.bump()
            args: list[ast.TypeSyntax] = [self.type_syntax()]
            while self.at(TokenKind.COMMA):
                self.bump()
                args.append(self.type_syntax())
            end = self.expect(TokenKind.GT)
            return ast.GenericTypeSyntax(tok.text, tuple(args), Span.merge(start, end.span))

        return ast.NamedTypeSyntax(tok.text, tok.span)

    def block(self) -> ast.Block:
        start = self.expect(TokenKind.LBRACE).span
        self.skip_newlines()
        items: list[ast.Stmt] = []
        while not self.at(TokenKind.RBRACE):
            if self.at(TokenKind.LET):
                items.append(self.let_stmt())
            else:
                expr = self.expr()
                items.append(ast.ExprStmt(expr, expr.span))
            if self.at(TokenKind.COMMA):
                self.bump()
            self.skip_newlines()
        end = self.expect(TokenKind.RBRACE)
        tail: ast.Expr | None = None
        if items and isinstance(items[-1], ast.ExprStmt):
            tail = items.pop().expr
        return ast.Block(tuple(items), tail, Span.merge(start, end.span))

    def let_stmt(self) -> ast.LetStmt:
        start = self.expect(TokenKind.LET).span
        pat = self.pattern()
        annotation = None
        if self.at(TokenKind.COLON):
            self.bump()
            annotation = self.type_syntax()
        self.expect(TokenKind.EQ)
        value = self.expr()
        return ast.LetStmt(pat, annotation, value, Span.merge(start, value.span))

    def pattern(self) -> ast.Pattern:
        if self.at(TokenKind.LPAREN):
            start = self.bump().span
            items: list[ast.Pattern] = [self.pattern()]
            while self.at(TokenKind.COMMA):
                self.bump()
                items.append(self.pattern())
            end = self.expect(TokenKind.RPAREN)
            if len(items) < 2:
                raise FrontendError(Diagnostic("E_PARSE_PATTERN", "tuple pattern requires at least two elements", Span.merge(start, end.span)))
            return ast.TuplePattern(tuple(items), Span.merge(start, end.span))

        tok = self.bump()
        if tok.kind not in {TokenKind.IDENT, TokenKind.SELF_TYPE}:
            raise FrontendError(Diagnostic("E_PARSE_PATTERN", "expected binding or struct pattern", tok.span))
        if self.at(TokenKind.LBRACE):
            self.bump()
            fields: list[str] = []
            self.skip_newlines()
            while not self.at(TokenKind.RBRACE):
                f = self.expect(TokenKind.IDENT)
                fields.append(f.text)
                if self.at(TokenKind.COMMA):
                    self.bump()
                self.skip_newlines()
            end = self.expect(TokenKind.RBRACE)
            return ast.StructPattern(tok.text, tuple(fields), Span.merge(tok.span, end.span))
        return ast.NamePattern(tok.text, tok.span)

    def expr(self) -> ast.Expr:
        expr = self.primary()
        while True:
            save = self.i
            self.skip_newlines()
            if self.at(TokenKind.DOT):
                dot = self.bump()
                name = self.expect(TokenKind.IDENT)
                if not self.at(TokenKind.LPAREN):
                    raise FrontendError(Diagnostic(
                        "E_BOUND_METHOD_UNSUPPORTED",
                        "receiver member syntax requires an immediate call; bound methods are not in M3",
                        Span.merge(dot.span, name.span),
                    ))
                args, end = self.arg_list()
                expr = ast.ReceiverCallExpr(expr, name.text, args, Span.merge(expr.span, end))
                continue
            if self.at(TokenKind.AT):
                self.bump()
                name = self.expect(TokenKind.IDENT)
                expr = ast.FieldProjectionExpr(expr, name.text, name.span, Span.merge(expr.span, name.span))
                continue
            if self.at(TokenKind.LBRACKET):
                self.bump()
                idx = self.expr()
                end = self.expect(TokenKind.RBRACKET).span
                expr = ast.IndexExpr(expr, idx, Span.merge(expr.span, end))
                continue
            if self.at(TokenKind.DCOLON):
                if not isinstance(expr, ast.NameExpr):
                    raise FrontendError(Diagnostic("E_QUALIFIER", "qualified call requires a name qualifier", expr.span))
                self.bump()
                name = self.expect(TokenKind.IDENT)
                args, end = self.arg_list()
                expr = ast.QualifiedCallExpr(expr.name, name.text, args, Span.merge(expr.span, end))
                continue
            if self.at(TokenKind.LPAREN):
                if not isinstance(expr, ast.NameExpr):
                    raise FrontendError(Diagnostic("E_CALL", "M3 ordinary calls require a named callee", expr.span))
                if expr.name == "ref_from_ptr":
                    args, end = self.ref_from_ptr_arg_list()
                else:
                    args, end = self.arg_list()
                expr = ast.OrdinaryCallExpr(expr, args, Span.merge(expr.span, end))
                continue
            self.i = save
            break
        return expr

    def primary(self) -> ast.Expr:
        if self.at(TokenKind.LOAN):
            return self.loan_expr()
        if self.at(TokenKind.MATCH):
            return self.match_expr()
        if self._looks_like_loop_expr():
            return self.loop_expr()
        if self.loop_depth and self.at(TokenKind.IDENT) and self.cur.text == "continue":
            return self.continue_expr()
        if self.loop_depth and self.at(TokenKind.IDENT) and self.cur.text == "break":
            return self.break_expr()
        if self.at(TokenKind.LBRACE):
            return self.block_literal()
        if self.at(TokenKind.INT):
            tok = self.bump()
            return ast.IntExpr(int(tok.text), tok.span)
        if self.at(TokenKind.UNIT):
            return ast.UnitExpr(self.bump().span)
        tok = self.bump()
        if tok.kind not in {TokenKind.IDENT, TokenKind.SELF_TYPE, TokenKind.SELF_VALUE}:
            raise FrontendError(Diagnostic("E_PARSE_EXPR", "expected expression", tok.span))
        name = ast.NameExpr(tok.text, tok.span)
        if self.at(TokenKind.LBRACE):
            start = tok.span
            self.bump()
            fields: list[ast.StructFieldInit] = []
            self.skip_newlines()
            while not self.at(TokenKind.RBRACE):
                f = self.expect(TokenKind.IDENT)
                self.expect(TokenKind.COLON)
                value = self.expr()
                fields.append(ast.StructFieldInit(f.text, value, Span.merge(f.span, value.span)))
                if self.at(TokenKind.COMMA):
                    self.bump()
                self.skip_newlines()
            end = self.expect(TokenKind.RBRACE)
            return ast.StructLiteralExpr(tok.text, tuple(fields), Span.merge(start, end.span))
        return name

    def loan_expr(self) -> ast.LoanExpr:
        start = self.expect(TokenKind.LOAN).span
        exclusive = False
        if self.at(TokenKind.EXCLUSIVE):
            self.bump()
            exclusive = True
        mode = self.bump()
        if mode.kind not in {TokenKind.READ, TokenKind.WRITE}:
            raise FrontendError(Diagnostic("E_LOAN_MODE", "expected read or write", mode.span))
        source = self.expr()
        self.expect(TokenKind.AS)
        binding = self.expect(TokenKind.IDENT)
        body = self.block()
        return ast.LoanExpr(mode.text, exclusive, source, binding.text, body, Span.merge(start, body.span))

    def block_literal(self) -> ast.BlockLiteralExpr:
        start = self.expect(TokenKind.LBRACE).span
        self.skip_newlines()
        self.expect(TokenKind.PIPE, "E_BLOCK_LITERAL")
        params: list[ast.BlockParam] = []
        if not self.at(TokenKind.PIPE):
            while True:
                name = self.expect(TokenKind.IDENT, "E_BLOCK_LITERAL")
                self.expect(TokenKind.COLON)
                ty = self.type_syntax()
                params.append(ast.BlockParam(name.text, ty, Span.merge(name.span, ty.span)))
                if not self.at(TokenKind.COMMA):
                    break
                self.bump()
        self.expect(TokenKind.PIPE, "E_BLOCK_LITERAL")
        self.skip_newlines()
        items: list[ast.Stmt] = []
        while not self.at(TokenKind.RBRACE):
            if self.at(TokenKind.LET):
                items.append(self.let_stmt())
            else:
                value = self.expr()
                items.append(ast.ExprStmt(value, value.span))
            if self.at(TokenKind.COMMA):
                self.bump()
            self.skip_newlines()
        end = self.expect(TokenKind.RBRACE)
        tail = None
        if items and isinstance(items[-1], ast.ExprStmt):
            tail = items.pop().expr
        body = ast.Block(tuple(items), tail, Span.merge(start, end.span))
        return ast.BlockLiteralExpr(tuple(params), body, Span.merge(start, end.span))

    def match_expr(self) -> ast.MatchExpr:
        start = self.expect(TokenKind.MATCH).span
        # `match value {` must not reinterpret `value {` as a struct literal.
        # A bare name before the match-arm brace is therefore parsed directly;
        # calls/projections still use the ordinary expression parser.
        if self.cur.kind in {TokenKind.IDENT, TokenKind.SELF_VALUE} and self.tokens[self.i + 1].kind is TokenKind.LBRACE:
            tok = self.bump()
            value = ast.NameExpr(tok.text, tok.span)
        else:
            value = self.expr()
        self.expect(TokenKind.LBRACE)
        self.skip_newlines()
        arms: list[ast.MatchArm] = []
        while not self.at(TokenKind.RBRACE):
            v = self.expect(TokenKind.IDENT, "E_MATCH_PATTERN")
            binding: str | None = None
            discard = False
            end_pat = v.span
            if self.at(TokenKind.LPAREN):
                self.bump()
                b = self.expect(TokenKind.IDENT, "E_MATCH_PATTERN")
                discard = b.text == "_"
                binding = None if discard else b.text
                end_pat = self.expect(TokenKind.RPAREN).span
            pat = ast.MatchPattern(v.text, binding, discard, Span.merge(v.span, end_pat))
            self.expect(TokenKind.FATARROW)
            body = self.block()
            arms.append(ast.MatchArm(pat, body, Span.merge(pat.span, body.span)))
            if self.at(TokenKind.COMMA):
                self.bump()
            self.skip_newlines()
        end = self.expect(TokenKind.RBRACE)
        return ast.MatchExpr(value, tuple(arms), Span.merge(start, end.span))


    def _looks_like_loop_expr(self) -> bool:
        if not self.at(TokenKind.IDENT) or self.cur.text != "loop":
            return False
        if self.i + 1 >= len(self.tokens) or self.tokens[self.i + 1].kind is not TokenKind.LPAREN:
            return False
        depth = 0
        j = self.i + 1
        while j < len(self.tokens):
            kind = self.tokens[j].kind
            if kind is TokenKind.LPAREN:
                depth += 1
            elif kind is TokenKind.RPAREN:
                depth -= 1
                if depth == 0:
                    j += 1
                    while j < len(self.tokens) and self.tokens[j].kind is TokenKind.NEWLINE:
                        j += 1
                    return j < len(self.tokens) and self.tokens[j].kind is TokenKind.ARROW
            j += 1
        return False

    def loop_expr(self) -> ast.LoopExpr:
        tok = self.expect(TokenKind.IDENT)
        if tok.text != "loop":
            raise FrontendError(Diagnostic("E_PARSE_LOOP", "expected loop", tok.span))
        start = tok.span
        self.expect(TokenKind.LPAREN)
        self.skip_newlines()
        params: list[ast.LoopParam] = []
        seen: set[str] = set()
        if not self.at(TokenKind.RPAREN):
            while True:
                name = self.expect(TokenKind.IDENT)
                if name.text in seen:
                    raise FrontendError(Diagnostic("E_LOOP_DUP_PARAM", f"duplicate loop parameter {name.text}", name.span))
                seen.add(name.text)
                self.expect(TokenKind.COLON)
                ty = self.type_syntax()
                self.expect(TokenKind.EQ)
                initial = self.expr()
                params.append(ast.LoopParam(name.text, ty, initial, Span.merge(name.span, initial.span)))
                self.skip_newlines()
                if not self.at(TokenKind.COMMA):
                    break
                self.bump()
                self.skip_newlines()
        self.expect(TokenKind.RPAREN)
        self.expect(TokenKind.ARROW)
        result_type = self.type_syntax()
        self.loop_depth += 1
        try:
            body = self.block()
        finally:
            self.loop_depth -= 1
        return ast.LoopExpr(tuple(params), result_type, body, Span.merge(start, body.span))

    def continue_expr(self) -> ast.ContinueExpr:
        tok = self.expect(TokenKind.IDENT)
        if tok.text != "continue":
            raise FrontendError(Diagnostic("E_PARSE_CONTINUE", "expected continue", tok.span))
        start = tok.span
        args, end = self.arg_list()
        return ast.ContinueExpr(args, Span.merge(start, end))

    def break_expr(self) -> ast.BreakExpr:
        tok = self.expect(TokenKind.IDENT)
        if tok.text != "break":
            raise FrontendError(Diagnostic("E_PARSE_BREAK", "expected break", tok.span))
        start = tok.span
        args, end = self.arg_list()
        if len(args) > 1:
            raise FrontendError(Diagnostic("E_BREAK_ARITY", "break expects zero or one value", Span.merge(start, end)))
        return ast.BreakExpr(args[0] if args else None, Span.merge(start, end))

    def ref_from_ptr_arg_list(self) -> tuple[tuple[ast.Expr, ...], Span]:
        self.expect(TokenKind.LPAREN)
        self.skip_newlines()
        mode = self.bump()
        if mode.kind not in {TokenKind.READ, TokenKind.WRITE}:
            raise FrontendError(Diagnostic("E_REF_FROM_PTR_MODE", "ref_from_ptr first argument must be read or write", mode.span))
        args: list[ast.Expr] = [ast.AccessModeExpr(mode.text, mode.span)]
        self.skip_newlines()
        self.expect(TokenKind.COMMA)
        self.skip_newlines()
        args.append(self.expr())
        self.skip_newlines()
        self.expect(TokenKind.COMMA)
        self.skip_newlines()
        args.append(self.expr())
        self.skip_newlines()
        end = self.expect(TokenKind.RPAREN).span
        return tuple(args), end

    def arg_list(self) -> tuple[tuple[ast.Expr, ...], Span]:
        self.expect(TokenKind.LPAREN)
        args: list[ast.Expr] = []
        self.skip_newlines()
        if not self.at(TokenKind.RPAREN):
            while True:
                args.append(self.expr())
                self.skip_newlines()
                if not self.at(TokenKind.COMMA):
                    break
                self.bump()
                self.skip_newlines()
        end = self.expect(TokenKind.RPAREN).span
        return tuple(args), end


def parse(tokens: tuple[Token, ...]) -> ast.Program:
    return Parser(tokens).program()
