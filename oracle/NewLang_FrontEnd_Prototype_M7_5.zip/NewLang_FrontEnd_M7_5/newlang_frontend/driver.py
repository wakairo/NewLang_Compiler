from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

from .ast import Program
from .diagnostics import Diagnostic, FrontendError
from .lexer import lex
from .lifecycle import run_lifecycle_detailed
from .lower import run_semantic_detailed
from .parser import parse
from .source import SourceFile
from .symbols import SymbolBuilder, SymbolTable
from .typecheck import TypeChecker
from .typed_ir import TProgram


@dataclass(frozen=True, slots=True)
class CheckResult:
    accepted: bool
    diagnostic: Diagnostic | None = None
    ast: Program | None = None
    symbols: SymbolTable | None = None
    typed: TProgram | None = None
    semantic_reason: str = ""


def check_source(
    text: str,
    name: str = "<memory>",
    *,
    semantic_initial_deps: Iterable[str] = (),
) -> CheckResult:
    """Check one M7.2 source unit.

    ``semantic_initial_deps`` is a developer/test hook, not NewLang syntax. It
    lets the front-end bridge be falsified against caller-visible dependency
    facts before M1 adds source constructs that naturally create those facts.
    """

    source = SourceFile(name, text)
    try:
        tree = parse(lex(source))
        symbols = SymbolBuilder(tree).build()
        typed = TypeChecker(symbols).check_program()
        semantic = run_semantic_detailed(typed, initial_deps=semantic_initial_deps)
        if not semantic.accepted:
            code = "E_SEMANTIC_CONFLICT" if semantic.reason.startswith("semantic conflict at ") else "E_SEMANTIC"
            span = semantic.origin if semantic.origin is not None else source_span(tree, source)
            return CheckResult(
                False,
                Diagnostic(code, semantic.reason, span),
                tree,
                symbols,
                typed,
                semantic.reason,
            )
        lifecycle = run_lifecycle_detailed(typed)
        if not lifecycle.accepted:
            span = lifecycle.origin if lifecycle.origin is not None else source_span(tree, source)
            return CheckResult(
                False,
                Diagnostic(lifecycle.code or "E_LIFETIME", lifecycle.reason, span),
                tree,
                symbols,
                typed,
                lifecycle.reason,
            )
        return CheckResult(True, None, tree, symbols, typed, f"{semantic.reason}; {lifecycle.reason}")
    except FrontendError as exc:
        return CheckResult(False, exc.diagnostic)


def source_span(tree: Program, source: SourceFile):
    if tree.declarations:
        return tree.declarations[0].span
    from .source import Span

    return Span(source, 0, 0)
