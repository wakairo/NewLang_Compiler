from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Literal


BoundaryKind = Literal[
    "scalar",
    "c_pointer",
    "explicit_c_record",
    "explicit_c_union",
    "native_aggregate",
    "native_sum",
    "semantic_resource",
]
Direction = Literal["parameter", "return"]
LoweringOwner = Literal["direct-c-abi", "target-abi-classifier", "generated-c-shim", "forbidden"]


@dataclass(frozen=True, slots=True)
class CAbiBoundaryPlan:
    """Conservative v0 plan for one C ABI boundary value.

    The key separation is that NewLang native aggregate layout is never made C
    ABI-visible merely because a value crosses an `extern C` boundary.  A C
    aggregate is a distinct compatibility representation.  Target calling
    convention classification (`sret`, `byval`, register coercions, etc.) is a
    backend result, not a semantic property of the NewLang source type.
    """

    kind: BoundaryKind
    direction: Direction
    by_value: bool
    direct_c_abi_eligible: bool
    requires_explicit_c_representation: bool
    requires_field_marshalling: bool
    lowering_owner: LoweringOwner
    native_layout_exposed: bool = False
    source_owns_sret_byval: bool = False
    padding_is_semantic: bool = False
    reason: str = ""

    def as_dict(self) -> dict[str, object]:
        return asdict(self)


def plan_c_abi_boundary(
    kind: BoundaryKind,
    *,
    direction: Direction,
    by_value: bool = True,
    target_abi_profile_known: bool = False,
    generated_c_shim_available: bool = True,
    variadic_position: bool = False,
) -> CAbiBoundaryPlan:
    if direction not in ("parameter", "return"):
        raise ValueError(direction)

    if kind in ("scalar", "c_pointer"):
        return CAbiBoundaryPlan(
            kind=kind,
            direction=direction,
            by_value=by_value,
            direct_c_abi_eligible=True,
            requires_explicit_c_representation=False,
            requires_field_marshalling=False,
            lowering_owner="direct-c-abi",
            reason="scalar/C-pointer boundary values have an explicit C ABI representation",
        )

    if kind in ("explicit_c_record", "explicit_c_union"):
        if variadic_position and by_value:
            owner: LoweringOwner = "generated-c-shim" if generated_c_shim_available else "forbidden"
            return CAbiBoundaryPlan(
                kind=kind,
                direction=direction,
                by_value=by_value,
                direct_c_abi_eligible=False,
                requires_explicit_c_representation=True,
                requires_field_marshalling=False,
                lowering_owner=owner,
                reason=(
                    "v0 keeps by-value aggregate varargs behind a C shim; default promotions and target ABI "
                    "classification are not part of native NewLang semantics"
                ),
            )
        owner = "target-abi-classifier" if target_abi_profile_known else (
            "generated-c-shim" if generated_c_shim_available else "forbidden"
        )
        return CAbiBoundaryPlan(
            kind=kind,
            direction=direction,
            by_value=by_value,
            direct_c_abi_eligible=target_abi_profile_known,
            requires_explicit_c_representation=True,
            requires_field_marshalling=False,
            lowering_owner=owner,
            reason=(
                "explicit C representation may cross by value, but register/stack/sret/byval classification "
                "belongs to the target ABI backend or generated C shim"
            ),
        )

    if kind in ("native_aggregate", "native_sum"):
        return CAbiBoundaryPlan(
            kind=kind,
            direction=direction,
            by_value=by_value,
            direct_c_abi_eligible=False,
            requires_explicit_c_representation=True,
            requires_field_marshalling=True,
            lowering_owner="generated-c-shim" if generated_c_shim_available else "forbidden",
            reason=(
                "native aggregate/sum layout is opaque; crossing C ABI requires an explicit C representation "
                "and semantic field/variant marshalling rather than bitcopy"
            ),
        )

    if kind == "semantic_resource":
        return CAbiBoundaryPlan(
            kind=kind,
            direction=direction,
            by_value=by_value,
            direct_c_abi_eligible=False,
            requires_explicit_c_representation=True,
            requires_field_marshalling=True,
            lowering_owner="forbidden",
            reason=(
                "NewLang authority/dependency/resource state is not encoded by foreign aggregate bytes; "
                "a dedicated privileged FFI contract is required"
            ),
        )

    raise ValueError(kind)


def llvm_c_abi_attribute_contract() -> dict[str, object]:
    return {
        "sret": "target ABI lowering result; never inferred from NewLang native aggregate spelling",
        "byval": "target ABI lowering result for an explicit C representation; not a NewLang ownership fact",
        "inreg": "target-specific ABI lowering result",
        "preallocated_or_inalloca": "target/backend implementation detail; never native semantic state",
        "calling_convention": "must match the declared foreign ABI exactly at declaration and call site",
        "padding": "C compatibility representation detail; never part of native semantic value",
        "native_bitcopy_to_c_record": False,
    }


def baseline_c_abi_matrix() -> dict[str, object]:
    return {
        "scalar_parameter": plan_c_abi_boundary("scalar", direction="parameter").as_dict(),
        "c_pointer_parameter": plan_c_abi_boundary("c_pointer", direction="parameter").as_dict(),
        "c_record_parameter_without_classifier": plan_c_abi_boundary(
            "explicit_c_record", direction="parameter", target_abi_profile_known=False
        ).as_dict(),
        "c_record_parameter_with_classifier": plan_c_abi_boundary(
            "explicit_c_record", direction="parameter", target_abi_profile_known=True
        ).as_dict(),
        "native_aggregate_parameter": plan_c_abi_boundary("native_aggregate", direction="parameter").as_dict(),
        "native_aggregate_return": plan_c_abi_boundary("native_aggregate", direction="return").as_dict(),
        "native_sum_parameter": plan_c_abi_boundary("native_sum", direction="parameter").as_dict(),
        "semantic_resource_parameter": plan_c_abi_boundary("semantic_resource", direction="parameter").as_dict(),
        "c_record_vararg": plan_c_abi_boundary(
            "explicit_c_record", direction="parameter", variadic_position=True
        ).as_dict(),
        "llvm_attributes": llvm_c_abi_attribute_contract(),
    }
