from __future__ import annotations

from dataclasses import dataclass
from typing import TypeAlias

from .source import Span


@dataclass(frozen=True, slots=True)
class NamedTypeSyntax:
    name: str
    span: Span


@dataclass(frozen=True, slots=True)
class RefTypeSyntax:
    mode: str
    inner: "TypeSyntax"
    span: Span


@dataclass(frozen=True, slots=True)
class ExclusiveRefTypeSyntax:
    mode: str
    inner: "TypeSyntax"
    span: Span


@dataclass(frozen=True, slots=True)
class GenericTypeSyntax:
    name: str
    args: tuple["TypeSyntax", ...]
    span: Span


@dataclass(frozen=True, slots=True)
class ArrayTypeSyntax:
    inner: "TypeSyntax"
    length: int
    span: Span


@dataclass(frozen=True, slots=True)
class SpanTypeSyntax:
    mode: str
    inner: "TypeSyntax"
    span: Span


@dataclass(frozen=True, slots=True)
class BlockTypeSyntax:
    params: tuple["TypeSyntax", ...]
    result: "TypeSyntax"
    span: Span


@dataclass(frozen=True, slots=True)
class TupleTypeSyntax:
    items: tuple["TypeSyntax", ...]
    span: Span


TypeSyntax: TypeAlias = (
    NamedTypeSyntax | RefTypeSyntax | ExclusiveRefTypeSyntax | GenericTypeSyntax |
    ArrayTypeSyntax | SpanTypeSyntax | BlockTypeSyntax | TupleTypeSyntax
)


@dataclass(frozen=True, slots=True)
class FieldDecl:
    name: str
    type: TypeSyntax
    span: Span


@dataclass(frozen=True, slots=True)
class StructDecl:
    fields: tuple[FieldDecl, ...]
    span: Span


@dataclass(frozen=True, slots=True)
class SumVariantDecl:
    name: str
    payload: TypeSyntax | None
    span: Span


@dataclass(frozen=True, slots=True)
class SumDecl:
    name: str
    type_params: tuple[str, ...]
    variants: tuple[SumVariantDecl, ...]
    span: Span


@dataclass(frozen=True, slots=True)
class ParamDecl:
    name: str
    type: TypeSyntax
    span: Span


@dataclass(frozen=True, slots=True)
class NameExpr:
    name: str
    span: Span


@dataclass(frozen=True, slots=True)
class IntExpr:
    value: int
    span: Span


@dataclass(frozen=True, slots=True)
class UnitExpr:
    span: Span


@dataclass(frozen=True, slots=True)
class AccessModeExpr:
    mode: str
    span: Span


@dataclass(frozen=True, slots=True)
class OrdinaryCallExpr:
    callee: NameExpr
    args: tuple["Expr", ...]
    span: Span


@dataclass(frozen=True, slots=True)
class QualifiedCallExpr:
    qualifier: str
    name: str
    args: tuple["Expr", ...]
    span: Span


@dataclass(frozen=True, slots=True)
class ReceiverCallExpr:
    receiver: "Expr"
    name: str
    args: tuple["Expr", ...]
    span: Span


@dataclass(frozen=True, slots=True)
class FieldProjectionExpr:
    base: "Expr"
    field: str
    field_span: Span
    span: Span


@dataclass(frozen=True, slots=True)
class IndexExpr:
    base: "Expr"
    index: "Expr"
    span: Span


@dataclass(frozen=True, slots=True)
class StructFieldInit:
    name: str
    expr: "Expr"
    span: Span


@dataclass(frozen=True, slots=True)
class StructLiteralExpr:
    type_name: str
    fields: tuple[StructFieldInit, ...]
    span: Span


@dataclass(frozen=True, slots=True)
class LoanExpr:
    mode: str
    exclusive: bool
    source: "Expr"
    binding: str
    body: "Block"
    span: Span


@dataclass(frozen=True, slots=True)
class BlockParam:
    name: str
    type: TypeSyntax
    span: Span


@dataclass(frozen=True, slots=True)
class BlockLiteralExpr:
    params: tuple[BlockParam, ...]
    body: "Block"
    span: Span


@dataclass(frozen=True, slots=True)
class LoopParam:
    name: str
    type: TypeSyntax
    initial: "Expr"
    span: Span


@dataclass(frozen=True, slots=True)
class LoopExpr:
    params: tuple[LoopParam, ...]
    result_type: TypeSyntax
    body: "Block"
    span: Span


@dataclass(frozen=True, slots=True)
class ContinueExpr:
    args: tuple["Expr", ...]
    span: Span


@dataclass(frozen=True, slots=True)
class BreakExpr:
    value: "Expr | None"
    span: Span


@dataclass(frozen=True, slots=True)
class MatchPattern:
    variant: str
    binding: str | None
    discard: bool
    span: Span


@dataclass(frozen=True, slots=True)
class MatchArm:
    pattern: MatchPattern
    body: "Block"
    span: Span


@dataclass(frozen=True, slots=True)
class MatchExpr:
    value: "Expr"
    arms: tuple[MatchArm, ...]
    span: Span


Expr: TypeAlias = (
    NameExpr | IntExpr | UnitExpr | AccessModeExpr | OrdinaryCallExpr |
    QualifiedCallExpr | ReceiverCallExpr | FieldProjectionExpr | IndexExpr |
    StructLiteralExpr | LoanExpr | BlockLiteralExpr | MatchExpr | LoopExpr | ContinueExpr | BreakExpr
)


@dataclass(frozen=True, slots=True)
class NamePattern:
    name: str
    span: Span


@dataclass(frozen=True, slots=True)
class StructPattern:
    type_name: str
    fields: tuple[str, ...]
    span: Span


@dataclass(frozen=True, slots=True)
class TuplePattern:
    items: tuple["Pattern", ...]
    span: Span


Pattern: TypeAlias = NamePattern | StructPattern | TuplePattern


@dataclass(frozen=True, slots=True)
class LetStmt:
    pattern: Pattern
    annotation: TypeSyntax | None
    value: Expr
    span: Span


@dataclass(frozen=True, slots=True)
class ExprStmt:
    expr: Expr
    span: Span


Stmt: TypeAlias = LetStmt | ExprStmt


@dataclass(frozen=True, slots=True)
class Block:
    statements: tuple[Stmt, ...]
    tail: Expr | None
    span: Span


@dataclass(frozen=True, slots=True)
class FunctionDecl:
    name: str
    type_params: tuple[str, ...]
    params: tuple[ParamDecl, ...]
    return_type: TypeSyntax
    body: Block
    span: Span


@dataclass(frozen=True, slots=True)
class ModuleDecl:
    name: str
    type_params: tuple[str, ...]
    struct: StructDecl
    functions: tuple[FunctionDecl, ...]
    span: Span


TopDecl: TypeAlias = ModuleDecl | SumDecl | FunctionDecl


@dataclass(frozen=True, slots=True)
class Program:
    declarations: tuple[TopDecl, ...]
