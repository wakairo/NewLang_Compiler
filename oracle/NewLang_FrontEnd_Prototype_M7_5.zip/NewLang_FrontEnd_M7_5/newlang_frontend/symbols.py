from __future__ import annotations

from dataclasses import dataclass, field

from . import ast
from .diagnostics import Diagnostic, FrontendError
from .typesys import (
    BOOL,
    LIFETIME_DOMAIN,
    ALLOCATION,
    STORAGE,
    U32,
    UNIT,
    USIZE,
    ArrayType,
    BlockType,
    BuiltinType,
    ExclusiveRefType,
    NominalType,
    LayoutType,
    PtrType,
    RefType,
    SlotType,
    SpanType,
    SumType,
    TupleType,
    Type,
    TypeParamType,
)


@dataclass(frozen=True, slots=True)
class FieldSymbol:
    field_id: int
    name: str
    owner_module_id: int
    type: Type
    decl: ast.FieldDecl


@dataclass(frozen=True, slots=True)
class FunctionSymbol:
    function_id: int
    name: str
    qualified_name: str
    owner_module_id: int | None
    type_params: tuple[TypeParamType, ...]
    params: tuple[tuple[str, Type], ...]
    return_type: Type
    decl: ast.FunctionDecl
    template_function_id: int | None = None

    @property
    def receiver_capable(self) -> bool:
        return bool(self.params) and self.params[0][0] == "self"


@dataclass(frozen=True, slots=True)
class SumVariantSymbol:
    name: str
    payload: Type | None
    decl: ast.SumVariantDecl


@dataclass(slots=True)
class SumSymbol:
    sum_id: int
    name: str
    type: SumType
    type_params: tuple[TypeParamType, ...]
    decl: ast.SumDecl
    variants: dict[str, SumVariantSymbol] = field(default_factory=dict)


@dataclass(slots=True)
class ModuleSymbol:
    module_id: int
    name: str
    nominal: NominalType
    type_params: tuple[TypeParamType, ...]
    decl: ast.ModuleDecl
    fields: dict[str, FieldSymbol] = field(default_factory=dict)
    functions: dict[str, FunctionSymbol] = field(default_factory=dict)


@dataclass(slots=True)
class SymbolTable:
    modules: dict[str, ModuleSymbol]
    sums: dict[str, SumSymbol]
    top_functions: dict[str, FunctionSymbol]
    type_modules: dict[int, ModuleSymbol]
    type_sums: dict[int, SumSymbol]

    def module_for_type(self, t: NominalType) -> ModuleSymbol:
        return self.type_modules[t.type_id]

    def sum_for_type(self, t: SumType) -> SumSymbol:
        return self.type_sums[t.type_id]


class SymbolBuilder:
    def __init__(self, program: ast.Program):
        self.program = program
        self.next_module = 1
        self.next_type = 1
        self.next_field = 1
        self.next_function = 1
        self.next_sum = 1
        self.modules: dict[str, ModuleSymbol] = {}
        self.sums: dict[str, SumSymbol] = {}
        self.top_functions: dict[str, FunctionSymbol] = {}
        self.type_modules: dict[int, ModuleSymbol] = {}
        self.type_sums: dict[int, SumSymbol] = {}

    def build(self) -> SymbolTable:
        # Pass 1: establish nominal identities before resolving payload/field types.
        for decl in self.program.declarations:
            if isinstance(decl, ast.ModuleDecl):
                if decl.name in self.modules or decl.name in self.sums:
                    raise FrontendError(Diagnostic("E_DUP_TYPE", f"duplicate type/module {decl.name}", decl.span))
                type_id = self.next_type
                type_params = tuple(TypeParamType(-type_id, i, name) for i, name in enumerate(decl.type_params))
                nominal = NominalType(type_id, decl.name, type_params)
                self.next_type += 1
                module = ModuleSymbol(self.next_module, decl.name, nominal, type_params, decl)
                self.next_module += 1
                self.modules[decl.name] = module
                self.type_modules[nominal.type_id] = module
            elif isinstance(decl, ast.SumDecl):
                if decl.name in self.modules or decl.name in self.sums:
                    raise FrontendError(Diagnostic("E_DUP_TYPE", f"duplicate type {decl.name}", decl.span))
                type_id = self.next_type
                type_params = tuple(TypeParamType(-type_id, i, name) for i, name in enumerate(decl.type_params))
                ty = SumType(type_id, decl.name, type_params)
                self.next_type += 1
                sym = SumSymbol(self.next_sum, decl.name, ty, type_params, decl)
                self.next_sum += 1
                self.sums[decl.name] = sym
                self.type_sums[ty.type_id] = sym

        # Pass 2: fields, sum payloads, functions.
        for decl in self.program.declarations:
            if isinstance(decl, ast.ModuleDecl):
                module = self.modules[decl.name]
                module_type_param_map = {t.name: t for t in module.type_params}
                for fdecl in decl.struct.fields:
                    if fdecl.name in module.fields:
                        raise FrontendError(Diagnostic("E_DUP_FIELD", f"duplicate field {fdecl.name}", fdecl.span))
                    ty = self.resolve_type(fdecl.type, module, module_type_param_map)
                    if self.contains_block_type(ty):
                        raise FrontendError(Diagnostic("E_BLOCK_ESCAPE_TYPE", "nonescaping block values cannot be stored in struct fields in M3", fdecl.span))
                    module.fields[fdecl.name] = FieldSymbol(
                        self.next_field, fdecl.name, module.module_id, ty, fdecl
                    )
                    self.next_field += 1
                for fn in decl.functions:
                    self._add_function(fn, module)
            elif isinstance(decl, ast.SumDecl):
                s = self.sums[decl.name]
                sum_type_param_map = {t.name: t for t in s.type_params}
                for vdecl in decl.variants:
                    if vdecl.name in s.variants:
                        raise FrontendError(Diagnostic("E_DUP_VARIANT", f"duplicate variant {vdecl.name}", vdecl.span))
                    payload = None if vdecl.payload is None else self.resolve_type(vdecl.payload, None, sum_type_param_map)
                    if payload is not None and self.contains_block_type(payload):
                        raise FrontendError(Diagnostic("E_BLOCK_ESCAPE_TYPE", "nonescaping block values cannot be stored in sum payloads in M3", vdecl.span))
                    s.variants[vdecl.name] = SumVariantSymbol(vdecl.name, payload, vdecl)
            else:
                self._add_function(decl, None)
        self._validate_sized_nominals()
        return SymbolTable(self.modules, self.sums, self.top_functions, self.type_modules, self.type_sums)

    def _validate_sized_nominals(self) -> None:
        def visit_type(ty: Type, active: frozenset[int], span) -> None:
            if isinstance(ty, (RefType, ExclusiveRefType, PtrType, SlotType, LayoutType, SpanType, BlockType)):
                return
            if isinstance(ty, ArrayType):
                visit_type(ty.inner, active, span)
                return
            if isinstance(ty, TupleType):
                for item in ty.items:
                    visit_type(item, active, span)
                return
            if isinstance(ty, NominalType):
                if ty.type_id in active:
                    raise FrontendError(Diagnostic("E_RECURSIVE_VALUE_TYPE", f"recursive by-value nominal type {ty.name} is not Sized; use ptr/ref indirection", span))
                module = self.type_modules[ty.type_id]
                subst = dict(zip(module.type_params, ty.args, strict=True))
                from .typesys import substitute_type
                for field in module.fields.values():
                    visit_type(substitute_type(field.type, subst), active | {ty.type_id}, field.decl.span)
                return
            if isinstance(ty, SumType):
                if ty.type_id in active:
                    raise FrontendError(Diagnostic("E_RECURSIVE_VALUE_TYPE", f"recursive by-value sum type {ty.name} is not Sized; use ptr/ref indirection", span))
                sum_sym = self.type_sums[ty.type_id]
                subst = dict(zip(sum_sym.type_params, ty.args, strict=True))
                from .typesys import substitute_type
                for variant in sum_sym.variants.values():
                    if variant.payload is not None:
                        visit_type(substitute_type(variant.payload, subst), active | {ty.type_id}, variant.decl.span)

        for module in self.modules.values():
            subst = {tp: tp for tp in module.type_params}
            from .typesys import substitute_type
            for field in module.fields.values():
                visit_type(substitute_type(field.type, subst), frozenset({module.nominal.type_id}), field.decl.span)
        for sum_sym in self.sums.values():
            subst = {tp: tp for tp in sum_sym.type_params}
            from .typesys import substitute_type
            for variant in sum_sym.variants.values():
                if variant.payload is not None:
                    visit_type(substitute_type(variant.payload, subst), frozenset({sum_sym.type.type_id}), variant.decl.span)

    def _add_function(self, decl: ast.FunctionDecl, module: ModuleSymbol | None) -> None:
        target = self.top_functions if module is None else module.functions
        if decl.name in target:
            raise FrontendError(Diagnostic("E_DUP_FUNCTION", f"duplicate function {decl.name}", decl.span))
        fid = self.next_function
        self.next_function += 1
        module_type_params = () if module is None else module.type_params
        module_names = {t.name for t in module_type_params}
        overlap = module_names.intersection(decl.type_params)
        if overlap:
            name = sorted(overlap)[0]
            raise FrontendError(Diagnostic("E_DUP_TYPE_PARAM", f"function type parameter {name} shadows nominal type parameter", decl.span))
        function_type_params = tuple(TypeParamType(fid, i, name) for i, name in enumerate(decl.type_params))
        type_params = module_type_params + function_type_params
        type_param_map = {t.name: t for t in type_params}
        params = tuple((p.name, self.resolve_type(p.type, module, type_param_map)) for p in decl.params)
        ret = self.resolve_type(decl.return_type, module, type_param_map)
        qname = decl.name if module is None else f"{module.name}::{decl.name}"
        sym = FunctionSymbol(fid, decl.name, qname, None if module is None else module.module_id, type_params, params, ret, decl)
        target[decl.name] = sym

    def contains_block_type(self, ty: Type) -> bool:
        if isinstance(ty, BlockType):
            return True
        if isinstance(ty, (RefType, ExclusiveRefType, PtrType, SlotType, ArrayType, SpanType)):
            return self.contains_block_type(ty.inner)
        if isinstance(ty, TupleType):
            return any(self.contains_block_type(i) for i in ty.items)
        return False

    def resolve_type(self, syntax: ast.TypeSyntax, current_module: ModuleSymbol | None, type_params: dict[str, TypeParamType] | None = None) -> Type:
        type_params = {} if type_params is None else type_params
        if isinstance(syntax, ast.RefTypeSyntax):
            return RefType(syntax.mode, self.resolve_type(syntax.inner, current_module, type_params))
        if isinstance(syntax, ast.ExclusiveRefTypeSyntax):
            return ExclusiveRefType(syntax.mode, self.resolve_type(syntax.inner, current_module, type_params))
        if isinstance(syntax, ast.TupleTypeSyntax):
            return TupleType(tuple(self.resolve_type(item, current_module, type_params) for item in syntax.items))
        if isinstance(syntax, ast.ArrayTypeSyntax):
            return ArrayType(self.resolve_type(syntax.inner, current_module, type_params), syntax.length)
        if isinstance(syntax, ast.SpanTypeSyntax):
            return SpanType(syntax.mode, self.resolve_type(syntax.inner, current_module, type_params))
        if isinstance(syntax, ast.BlockTypeSyntax):
            return BlockType(
                tuple(self.resolve_type(p, current_module, type_params) for p in syntax.params),
                self.resolve_type(syntax.result, current_module, type_params),
            )
        if isinstance(syntax, ast.GenericTypeSyntax):
            if len(syntax.args) == 1 and syntax.name in {"ptr", "slot", "Layout"}:
                inner = self.resolve_type(syntax.args[0], current_module, type_params)
                if syntax.name == "ptr":
                    return PtrType(inner)
                if syntax.name == "slot":
                    return SlotType(inner)
                return LayoutType(inner)
            args = tuple(self.resolve_type(arg, current_module, type_params) for arg in syntax.args)
            module = self.modules.get(syntax.name)
            if module is not None:
                if len(args) != len(module.type_params):
                    raise FrontendError(Diagnostic("E_GENERIC_TYPE_ARITY", f"{syntax.name} expects {len(module.type_params)} type argument(s), got {len(args)}", syntax.span))
                return NominalType(module.nominal.type_id, module.name, args)
            sum_sym = self.sums.get(syntax.name)
            if sum_sym is not None:
                if len(args) != len(sum_sym.type_params):
                    raise FrontendError(Diagnostic("E_GENERIC_TYPE_ARITY", f"{syntax.name} expects {len(sum_sym.type_params)} type argument(s), got {len(args)}", syntax.span))
                return SumType(sum_sym.type.type_id, sum_sym.name, args)
            raise FrontendError(Diagnostic("E_UNKNOWN_TYPE", f"unsupported generic type {syntax.name}", syntax.span))
        name = syntax.name
        if name in type_params:
            return type_params[name]
        builtins: dict[str, BuiltinType] = {
            "unit": UNIT, "u32": U32, "usize": USIZE, "bool": BOOL, "LifetimeDomain": LIFETIME_DOMAIN,
            "Allocation": ALLOCATION, "Storage": STORAGE
        }
        if name in builtins:
            return builtins[name]
        if name == "Self":
            if current_module is None:
                raise FrontendError(Diagnostic("E_SELF_OUTSIDE_MODULE", "Self is only valid in a module", syntax.span))
            return current_module.nominal
        module = self.modules.get(name)
        if module is not None:
            if module.type_params:
                raise FrontendError(Diagnostic("E_GENERIC_TYPE_ARGUMENTS_REQUIRED", f"generic type {name} requires type arguments", syntax.span))
            return module.nominal
        sum_sym = self.sums.get(name)
        if sum_sym is not None:
            if sum_sym.type_params:
                raise FrontendError(Diagnostic("E_GENERIC_TYPE_ARGUMENTS_REQUIRED", f"generic type {name} requires type arguments", syntax.span))
            return sum_sym.type
        raise FrontendError(Diagnostic("E_UNKNOWN_TYPE", f"unknown type {name}", syntax.span))
