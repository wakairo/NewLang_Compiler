from __future__ import annotations

from dataclasses import dataclass
import random


class IntrusiveReject(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


@dataclass(frozen=True, slots=True)
class FieldLayout:
    name: str
    type_name: str
    offset: int
    size: int
    align: int


@dataclass(frozen=True, slots=True)
class NominalLayout:
    name: str
    size: int
    align: int
    fields: tuple[FieldLayout, ...]

    def field(self, name: str) -> FieldLayout:
        for field in self.fields:
            if field.name == name:
                return field
        raise KeyError(name)

    def public_facts(self) -> tuple[int, int]:
        """The source-visible/native generic surface may know extent/alignment only."""
        return self.size, self.align


@dataclass(frozen=True, slots=True)
class ProjectionStep:
    owner_type: str
    field_name: str
    field_type: str
    offset: int  # compiler-private backend fact, never a source semantic value


@dataclass(frozen=True, slots=True)
class PtrToken:
    root_id: str
    root_type: str
    current_type: str
    root_address: int
    address: int
    projection_path: tuple[ProjectionStep, ...] = ()
    stale: bool = False

    @property
    def root_capable(self) -> bool:
        return not self.projection_path


class CompilerProjectionModel:
    def __init__(self, layouts: dict[str, NominalLayout]):
        self.layouts = layouts

    def root_ptr(self, root_id: str, type_name: str, address: int) -> PtrToken:
        return PtrToken(root_id, type_name, type_name, address, address)

    def project_field(self, ptr: PtrToken, field_name: str) -> PtrToken:
        layout = self.layouts.get(ptr.current_type)
        if layout is None:
            raise IntrusiveReject("E_NO_FIELDS", f"{ptr.current_type} has no compiler-known nominal layout")
        try:
            field = layout.field(field_name)
        except KeyError as exc:
            raise IntrusiveReject("E_UNKNOWN_FIELD", f"{layout.name} has no field {field_name}") from exc
        step = ProjectionStep(layout.name, field.name, field.type_name, field.offset)
        return PtrToken(
            ptr.root_id,
            ptr.root_type,
            field.type_name,
            ptr.root_address,
            ptr.address + field.offset,
            ptr.projection_path + (step,),
            ptr.stale,
        )

    def recover_owner(self, ptr: PtrToken, owner_type: str) -> PtrToken:
        """Invert only a compiler-proven typed projection relation.

        No address/offset supplied by the program is accepted.  The private offset
        is backend information attached to the proven projection path.
        """
        idx = None
        for i in range(len(ptr.projection_path) - 1, -1, -1):
            if ptr.projection_path[i].owner_type == owner_type:
                idx = i
                break
        if idx is None:
            raise IntrusiveReject(
                "E_OWNER_PROJECTION",
                f"{ptr.current_type} ptr has no proven enclosing {owner_type} projection",
            )
        suffix = ptr.projection_path[idx:]
        recovered_address = ptr.address - sum(step.offset for step in suffix)
        prefix = ptr.projection_path[:idx]
        expected = ptr.root_address + sum(step.offset for step in prefix)
        if recovered_address != expected:
            raise AssertionError("compiler-private projection address accounting diverged")
        return PtrToken(
            ptr.root_id,
            ptr.root_type,
            owner_type,
            ptr.root_address,
            recovered_address,
            prefix,
            ptr.stale,
        )

    @staticmethod
    def require_live_access(ptr: PtrToken) -> None:
        if ptr.stale:
            raise IntrusiveReject("E_STALE_PTR", "owner recovery does not revive an ended incarnation")

    def lower_owner_recovery(self, ptr: PtrToken, owner_type: str) -> dict[str, object]:
        recovered = self.recover_owner(ptr, owner_type)
        idx = len(recovered.projection_path)
        suffix = ptr.projection_path[idx:]
        delta = -sum(step.offset for step in suffix)
        # Conceptual LLVM-shaped lowering: keep pointer provenance, do not expose
        # offsetof to source, and do not round-trip through an integer address.
        return {
            "operation": "gep-byte-offset",
            "delta": delta,
            "inbounds_candidate": True,
            "source_provenance_required": True,
            "integer_roundtrip": False,
            "result_address": recovered.address,
        }


def _round_up(value: int, align: int) -> int:
    return (value + align - 1) // align * align


def make_layout(name: str, specs: list[tuple[str, str, int, int]], order: list[int]) -> NominalLayout:
    offset = 0
    max_align = 1
    fields: list[FieldLayout] = []
    for index in order:
        field_name, type_name, size, align = specs[index]
        offset = _round_up(offset, align)
        fields.append(FieldLayout(field_name, type_name, offset, size, align))
        offset += size
        max_align = max(max_align, align)
    # Canonical field lookup is by identity/name, not by physical order.
    fields.sort(key=lambda f: f.name)
    return NominalLayout(name, _round_up(offset, max_align), max_align, tuple(fields))


def layout_variants() -> tuple[dict[str, NominalLayout], ...]:
    link = make_layout("Link", [("tag", "u32", 4, 4)], [0])
    inner_a = make_layout("Inner", [("prefix", "u32", 4, 4), ("link", "Link", link.size, link.align)], [0, 1])
    inner_b = make_layout("Inner", [("prefix", "u32", 4, 4), ("link", "Link", link.size, link.align)], [1, 0])
    node_specs = [
        ("small", "u8", 1, 1),
        ("first", "Link", link.size, link.align),
        ("word", "usize", 8, 8),
        ("second", "Link", link.size, link.align),
    ]
    node_a = make_layout("Node", node_specs, [0, 1, 2, 3])
    node_b = make_layout("Node", node_specs, [2, 3, 0, 1])
    outer_specs = [("inner", "Inner", inner_a.size, inner_a.align), ("tail", "usize", 8, 8)]
    outer_a = make_layout("Outer", outer_specs, [0, 1])
    outer_b_specs = [("inner", "Inner", inner_b.size, inner_b.align), ("tail", "usize", 8, 8)]
    outer_b = make_layout("Outer", outer_b_specs, [1, 0])
    return (
        {"Link": link, "Inner": inner_a, "Node": node_a, "Outer": outer_a},
        {"Link": link, "Inner": inner_b, "Node": node_b, "Outer": outer_b},
    )


def run_intrusive_pressure(*, seed: int = 20261004, cases: int = 20_000) -> dict[str, object]:
    rng = random.Random(seed)
    variants = layout_variants()
    recovered = 0
    same_type_fields = 0
    nested = 0
    fake_rejected = 0
    stale_recovered = 0
    stale_access_rejected = 0
    layout_reorders = 0
    lowering_mismatch = 0
    ring_steps = 0

    # Deterministic intrusive-ring workload for each physical layout.
    for layout_set in variants:
        model = CompilerProjectionModel(layout_set)
        roots = [model.root_ptr(f"node{i}", "Node", 0x1000 + i * 0x100) for i in range(3)]
        links = [model.project_field(root, "first") for root in roots]
        next_link = {links[i].root_id: links[(i + 1) % 3] for i in range(3)}
        cur = links[0]
        seen = []
        for _ in range(6):
            owner = model.recover_owner(cur, "Node")
            seen.append(owner.root_id)
            cur = next_link[owner.root_id]
            ring_steps += 1
        assert seen == ["node0", "node1", "node2", "node0", "node1", "node2"]

    for i in range(cases):
        layout_set = variants[i % len(variants)]
        if i % len(variants):
            layout_reorders += 1
        model = CompilerProjectionModel(layout_set)
        base = 0x100000 + i * 0x80
        root = model.root_ptr(f"R{i}", "Node", base)
        field_name = "first" if rng.randrange(2) == 0 else "second"
        field = model.project_field(root, field_name)
        owner = model.recover_owner(field, "Node")
        if owner.address != base or not owner.root_capable or owner.root_id != root.root_id:
            raise AssertionError("owner recovery mismatch")
        recovered += 1
        same_type_fields += 1
        lowered = model.lower_owner_recovery(field, "Node")
        if lowered["result_address"] != base or lowered["integer_roundtrip"]:
            lowering_mismatch += 1

        # Numeric equality alone must not mint the missing projection relation.
        forged = PtrToken(f"fake{i}", "Link", "Link", field.address, field.address)
        try:
            model.recover_owner(forged, "Node")
        except IntrusiveReject as exc:
            assert exc.code == "E_OWNER_PROJECTION"
            fake_rejected += 1
        else:
            raise AssertionError("forged address unexpectedly recovered an owner")

        # Recovery is a locator transform and remains legal after lifetime end,
        # but it cannot revive safe access.
        stale = PtrToken(
            field.root_id, field.root_type, field.current_type, field.root_address,
            field.address, field.projection_path, True,
        )
        stale_owner = model.recover_owner(stale, "Node")
        stale_recovered += 1
        try:
            model.require_live_access(stale_owner)
        except IntrusiveReject as exc:
            assert exc.code == "E_STALE_PTR"
            stale_access_rejected += 1
        else:
            raise AssertionError("stale owner recovery revived access")

        # Nested inverse projection: Outer.inner -> Inner.link -> ptr<Link>, then
        # recover all the way to Outer without exposing either physical offset.
        outer = model.root_ptr(f"O{i}", "Outer", base + 0x40)
        inner = model.project_field(outer, "inner")
        link = model.project_field(inner, "link")
        outer2 = model.recover_owner(link, "Outer")
        if outer2.address != outer.address or outer2.root_id != outer.root_id:
            raise AssertionError("nested owner recovery mismatch")
        nested += 1

    return {
        "seed": seed,
        "cases": cases,
        "recovered": recovered,
        "same_type_field_recoveries": same_type_fields,
        "nested_recoveries": nested,
        "forged_address_rejections": fake_rejected,
        "stale_locator_recoveries": stale_recovered,
        "stale_access_rejections": stale_access_rejected,
        "layout_reordered_cases": layout_reorders,
        "backend_lowering_mismatches": lowering_mismatch,
        "intrusive_ring_steps": ring_steps,
        "field_offsets_exposed_to_source": False,
        "integer_pointer_roundtrip_required": False,
    }
