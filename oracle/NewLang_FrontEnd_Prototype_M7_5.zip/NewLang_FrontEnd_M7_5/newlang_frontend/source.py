from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class SourceFile:
    name: str
    text: str

    def line_col(self, offset: int) -> tuple[int, int]:
        line = self.text.count("\n", 0, offset) + 1
        last = self.text.rfind("\n", 0, offset)
        col = offset + 1 if last < 0 else offset - last
        return line, col


@dataclass(frozen=True, slots=True)
class Span:
    source: SourceFile
    start: int
    end: int

    @property
    def start_line_col(self) -> tuple[int, int]:
        return self.source.line_col(self.start)

    @property
    def end_line_col(self) -> tuple[int, int]:
        return self.source.line_col(self.end)

    @staticmethod
    def merge(a: "Span", b: "Span") -> "Span":
        assert a.source is b.source
        return Span(a.source, min(a.start, b.start), max(a.end, b.end))
