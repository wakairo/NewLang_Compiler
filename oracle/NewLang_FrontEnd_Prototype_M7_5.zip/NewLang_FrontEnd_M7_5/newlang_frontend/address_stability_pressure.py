from __future__ import annotations

from dataclasses import dataclass, replace
import random

from .intrusive_pressure import CompilerProjectionModel, PtrToken, layout_variants


class AddressStabilityReject(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


@dataclass(slots=True)
class PlaceObject:
    """Logical object hosted at one typed-lifetime root/place."""
    semantic_id: str
    ptr: PtrToken
    payload: int = 0
    alive: bool = True


@dataclass(slots=True)
class AddressInvariant:
    """Library-owned invariant, not a proposed core type property.

    `self_ptr` means the semantic object expects its embedded locator to denote
    its current host place. `external_observers` models intrusive/backlink users
    that expect the semantic object to remain at this address.
    """
    self_ptr: PtrToken | None = None
    external_observers: int = 0

    @property
    def active(self) -> bool:
        return self.self_ptr is not None or self.external_observers != 0


@dataclass(slots=True)
class StablePlaceOwner:
    """Library-level stable backing owner.

    Moving this *handle* does not move its pointee.  While an address-sensitive
    invariant is active the wrapper does not expose whole-place replace/swap/take.
    Fine-grained payload updates at the same place remain legal.
    """
    obj: PlaceObject
    invariant: AddressInvariant
    handle_generation: int = 0

    def move_handle(self) -> "StablePlaceOwner":
        return StablePlaceOwner(self.obj, self.invariant, self.handle_generation + 1)

    def install_self_reference(self) -> None:
        if self.invariant.self_ptr is not None:
            raise AddressStabilityReject("E_ALREADY_ANCHORED", "self-reference already installed")
        self.invariant.self_ptr = self.obj.ptr

    def clear_self_reference(self) -> None:
        self.invariant.self_ptr = None

    def add_external_observer(self) -> PtrToken:
        self.invariant.external_observers += 1
        return self.obj.ptr

    def remove_external_observer(self) -> None:
        if self.invariant.external_observers <= 0:
            raise AddressStabilityReject("E_OBSERVER_BALANCE", "no external observer to remove")
        self.invariant.external_observers -= 1

    def mutate_payload(self, value: int) -> None:
        self.obj.payload = value
        self._assert_invariant()

    def whole_replace(self, semantic_id: str) -> str:
        if self.invariant.active:
            raise AddressStabilityReject("E_ADDRESS_STABILITY", "whole replace is hidden while address invariant is active")
        old = self.obj.semantic_id
        self.obj.semantic_id = semantic_id
        return old

    def swap_with(self, other: "StablePlaceOwner") -> None:
        if self.invariant.active or other.invariant.active:
            raise AddressStabilityReject("E_ADDRESS_STABILITY", "whole swap is hidden while address invariant is active")
        self.obj.semantic_id, other.obj.semantic_id = other.obj.semantic_id, self.obj.semantic_id
        self.obj.payload, other.obj.payload = other.obj.payload, self.obj.payload

    def take_for_relocation(self) -> str:
        if self.invariant.active:
            raise AddressStabilityReject("E_ADDRESS_STABILITY", "take/relocation requires address invariant to be discharged")
        self.obj.alive = False
        return self.obj.semantic_id

    def _assert_invariant(self) -> None:
        if self.invariant.self_ptr is not None:
            p = self.invariant.self_ptr
            if p.root_id != self.obj.ptr.root_id or p.address != self.obj.ptr.address:
                raise AssertionError("self-reference no longer denotes the hosted object")


def ordinary_relocate(obj: PlaceObject, *, new_root_id: str, new_address: int) -> tuple[PlaceObject, PtrToken]:
    """Ordinary consume-transfer: old locators remain as stale tokens.

    This operation intentionally performs no self-pointer/backlink fixup.
    """
    if not obj.alive:
        raise AddressStabilityReject("E_DEAD_OBJECT", "cannot relocate dead object")
    old_ptr = obj.ptr
    stale_old = replace(old_ptr, stale=True)
    obj.alive = False
    new_ptr = PtrToken(new_root_id, old_ptr.root_type, old_ptr.current_type, new_address, new_address)
    return PlaceObject(obj.semantic_id, new_ptr, obj.payload, True), stale_old


def ordinary_swap(left: PlaceObject, right: PlaceObject) -> None:
    """Swap semantic values while retaining place/root identities."""
    left.semantic_id, right.semantic_id = right.semantic_id, left.semantic_id
    left.payload, right.payload = right.payload, left.payload


def privileged_self_fixup_relocate(owner: StablePlaceOwner, *, new_root_id: str, new_address: int) -> StablePlaceOwner:
    """Localized structure-specific relocation for the self-only case.

    This is deliberately *not* a general safe primitive. External observers make
    the proof non-local, so this prototype rejects them instead of pretending a
    self-pointer fixup repairs arbitrary intrusive structure invariants.
    """
    if owner.invariant.external_observers:
        raise AddressStabilityReject(
            "E_NONLOCAL_RELOCATION_FIXUP",
            "self fixup cannot repair external intrusive observers",
        )
    had_self = owner.invariant.self_ptr is not None
    # privileged boundary temporarily discharges its own private invariant
    owner.invariant.self_ptr = None
    semantic_id = owner.take_for_relocation()
    new_ptr = PtrToken(new_root_id, owner.obj.ptr.root_type, owner.obj.ptr.current_type, new_address, new_address)
    out = StablePlaceOwner(PlaceObject(semantic_id, new_ptr, owner.obj.payload), AddressInvariant())
    if had_self:
        out.install_self_reference()
    out._assert_invariant()
    return out


def run_address_stability_pressure(*, seed: int = 20261004, cases: int = 20_000) -> dict[str, object]:
    rng = random.Random(seed)
    layouts = layout_variants()[0]
    model = CompilerProjectionModel(layouts)

    stale_after_move = 0
    swap_identity_mismatches = 0
    wrapper_moves_ok = 0
    anchored_replace_rejects = 0
    anchored_swap_rejects = 0
    anchored_take_rejects = 0
    payload_updates_ok = 0
    unanchor_then_move_ok = 0
    self_fixup_ok = 0
    nonlocal_fixup_rejects = 0

    for i in range(cases):
        a_ptr = model.root_ptr(f"A{i}", "Node", 0x100000 + i * 0x100)
        b_ptr = model.root_ptr(f"B{i}", "Node", 0x200000 + i * 0x100)

        # Ordinary relocation preserves memory safety by invalidating the old
        # incarnation; it does not preserve address-sensitive logical identity.
        a = PlaceObject(f"value-A{i}", a_ptr, rng.randrange(1 << 16))
        moved, stale = ordinary_relocate(a, new_root_id=f"A2-{i}", new_address=0x300000 + i * 0x100)
        if stale.stale and moved.ptr.address != stale.address:
            stale_after_move += 1

        # Ordinary same-type swap retains both places.  A location observer still
        # denotes the same place but now observes the other semantic value.
        left = PlaceObject(f"L{i}", a_ptr)
        right = PlaceObject(f"R{i}", b_ptr)
        observed_left_semantic = left.semantic_id
        ordinary_swap(left, right)
        if left.semantic_id != observed_left_semantic and left.ptr.root_id == a_ptr.root_id:
            swap_identity_mismatches += 1

        # Stable owner: self/intrusive invariants are library state, not a nominal
        # forever-nonrelocatable property. Moving the owner handle is harmless.
        owner = StablePlaceOwner(PlaceObject(f"S{i}", a_ptr, 1), AddressInvariant())
        owner.install_self_reference()
        moved_handle = owner.move_handle()
        moved_handle._assert_invariant()
        if moved_handle.obj.ptr.address == a_ptr.address:
            wrapper_moves_ok += 1

        try:
            moved_handle.whole_replace(f"new{i}")
        except AddressStabilityReject as exc:
            assert exc.code == "E_ADDRESS_STABILITY"
            anchored_replace_rejects += 1
        else:
            raise AssertionError("anchored whole replace unexpectedly allowed")

        peer = StablePlaceOwner(PlaceObject(f"P{i}", b_ptr), AddressInvariant())
        try:
            moved_handle.swap_with(peer)
        except AddressStabilityReject as exc:
            assert exc.code == "E_ADDRESS_STABILITY"
            anchored_swap_rejects += 1
        else:
            raise AssertionError("anchored swap unexpectedly allowed")

        try:
            moved_handle.take_for_relocation()
        except AddressStabilityReject as exc:
            assert exc.code == "E_ADDRESS_STABILITY"
            anchored_take_rejects += 1
        else:
            raise AssertionError("anchored take unexpectedly allowed")

        moved_handle.mutate_payload(rng.randrange(1 << 16))
        moved_handle._assert_invariant()
        payload_updates_ok += 1

        moved_handle.clear_self_reference()
        sid = moved_handle.take_for_relocation()
        if sid == f"S{i}":
            unanchor_then_move_ok += 1

        fix = StablePlaceOwner(PlaceObject(f"F{i}", a_ptr), AddressInvariant())
        fix.install_self_reference()
        fixed = privileged_self_fixup_relocate(fix, new_root_id=f"F2-{i}", new_address=0x400000 + i * 0x100)
        if fixed.invariant.self_ptr is not None and fixed.invariant.self_ptr.address == fixed.obj.ptr.address:
            self_fixup_ok += 1

        nonlocal_owner = StablePlaceOwner(PlaceObject(f"N{i}", b_ptr), AddressInvariant())
        nonlocal_owner.install_self_reference()
        nonlocal_owner.add_external_observer()
        try:
            privileged_self_fixup_relocate(nonlocal_owner, new_root_id=f"N2-{i}", new_address=0x500000 + i * 0x100)
        except AddressStabilityReject as exc:
            assert exc.code == "E_NONLOCAL_RELOCATION_FIXUP"
            nonlocal_fixup_rejects += 1
        else:
            raise AssertionError("non-local relocation fixup unexpectedly accepted")

    return {
        "seed": seed,
        "cases": cases,
        "ordinary_relocation_stale_old_locator": stale_after_move,
        "ordinary_swap_location_identity_mismatch": swap_identity_mismatches,
        "stable_owner_handle_moves": wrapper_moves_ok,
        "anchored_replace_rejections": anchored_replace_rejects,
        "anchored_swap_rejections": anchored_swap_rejects,
        "anchored_take_rejections": anchored_take_rejects,
        "same_place_payload_updates": payload_updates_ok,
        "unanchor_then_move": unanchor_then_move_ok,
        "privileged_self_fixup_relocations": self_fixup_ok,
        "nonlocal_fixup_rejections": nonlocal_fixup_rejects,
        "runtime_pin_flag_required": False,
        "core_pin_type_required_by_experiment": False,
        "nominal_forever_nonrelocatable_required": False,
        "general_relocation_fixup_safe": False,
    }
