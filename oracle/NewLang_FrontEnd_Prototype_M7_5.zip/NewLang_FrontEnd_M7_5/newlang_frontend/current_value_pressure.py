from __future__ import annotations

import random
import sys
from pathlib import Path
from typing import Any

_VENDOR = Path(__file__).resolve().parent.parent / "vendor"
if str(_VENDOR) not in sys.path:
    sys.path.insert(0, str(_VENDOR))

from newlang_checker.language_ir import ReplaceRoot, StoreRoot, SwapRoots, UFunction, UProgram
from newlang_checker.model import SemanticError
from newlang_checker.production_analysis import ProductionChecker
from newlang_checker.semantics import apply_step, load_initial


def _initial(*, cap_dep: str | None = None, incoming_dep: str | None = None) -> dict[str, Any]:
    values: dict[str, Any] = {
        "new_left": {"local": "C"},
        "new_right": {"local": "D"},
    }
    if cap_dep is not None:
        values["cap"] = {"local": "cap", "dependencies": [{"kind": "Value", "target": cap_dep}]}
    if incoming_dep is not None:
        values["new_left"] = {"local": "C", "dependencies": [{"kind": "Value", "target": incoming_dep}]}
    return {
        "backings": {"R": {"abstract_bytes": "R", "live": True}},
        "roots": {
            "left": {
                "type": "Pair",
                "incarnation": "OL",
                "placement": {"backing_region": "R", "range": [0, 16]},
                "value_package": {"local": "A"},
                "root_value_fact": "LV",
                "fixed_subobjects": {
                    "a": {"incarnation": "LA", "value_fact": "LVA"},
                    "b": {"incarnation": "LB", "value_fact": "LVB"},
                },
            },
            "right": {
                "type": "Pair",
                "incarnation": "OR",
                "placement": {"backing_region": "R", "range": [16, 32]},
                "value_package": {"local": "B"},
                "root_value_fact": "RV",
                "fixed_subobjects": {
                    "a": {"incarnation": "RA", "value_fact": "RVA"},
                    "b": {"incarnation": "RB", "value_fact": "RVB"},
                },
            },
        },
        "values": values,
    }


def _case(family: int) -> tuple[dict[str, Any], list[dict[str, Any]], tuple[object, ...]]:
    if family == 0:
        init = _initial()
        exact = [{"op": "replace_root_package", "root": "left", "new_value": "new_left", "result_old": "old"}]
        prod = (ReplaceRoot("left", "new_left", "old"),)
    elif family == 1:
        init = _initial(cap_dep="LV")
        exact = [{"op": "replace_root_package", "root": "left", "new_value": "new_left", "result_old": "old"}]
        prod = (ReplaceRoot("left", "new_left", "old"),)
    elif family == 2:
        init = _initial(cap_dep="LVA")
        exact = [{"op": "replace_root_package", "root": "left", "new_value": "new_left", "result_old": "old"}]
        prod = (ReplaceRoot("left", "new_left", "old"),)
    elif family == 3:
        init = _initial(cap_dep="LVB")
        exact = [{"op": "store_root_package", "root": "left", "new_value": "new_left"}]
        prod = (StoreRoot("left", "new_left"),)
    elif family == 4:
        init = _initial(cap_dep="RVA")
        exact = [{"op": "replace_root_package", "root": "left", "new_value": "new_left", "result_old": "old"}]
        prod = (ReplaceRoot("left", "new_left", "old"),)
    elif family == 5:
        init = _initial(cap_dep="LVA")
        exact = [{"op": "swap_roots", "roots": ["left", "right"]}]
        prod = (SwapRoots("left", "right"),)
    elif family == 6:
        init = _initial(cap_dep="LVA")
        exact = [{"op": "swap_roots", "roots": ["left", "left"]}]
        prod = (SwapRoots("left", "left"),)
    elif family == 7:
        init = _initial()
        exact = [
            {"op": "replace_root_package", "root": "left", "new_value": "new_left", "result_old": "old_a"},
            {"op": "replace_root_package", "root": "left", "new_value": "old_a", "result_old": "old_c"},
        ]
        prod = (
            ReplaceRoot("left", "new_left", "old_a"),
            ReplaceRoot("left", "old_a", "old_c"),
        )
    elif family == 8:
        init = _initial(cap_dep="LV")
        exact = [{"op": "store_root_package", "root": "left", "new_value": "new_left"}]
        prod = (StoreRoot("left", "new_left"),)
    elif family == 9:
        init = _initial(incoming_dep="LVA")
        exact = [{"op": "replace_root_package", "root": "left", "new_value": "new_left", "result_old": "old"}]
        prod = (ReplaceRoot("left", "new_left", "old"),)
    elif family == 10:
        init = _initial(incoming_dep="LV")
        exact = [{"op": "store_root_package", "root": "left", "new_value": "new_left"}]
        prod = (StoreRoot("left", "new_left"),)
    elif family == 11:
        init = _initial(cap_dep="RV")
        exact = [{"op": "swap_roots", "roots": ["left", "right"]}]
        prod = (SwapRoots("left", "right"),)
    else:
        raise AssertionError(family)
    return init, exact, prod


def exact_accepts(family: int) -> bool:
    init, steps, _ = _case(family)
    st = load_initial(init)
    try:
        for step in steps:
            apply_step(st, step)
        return True
    except (SemanticError, KeyError):
        return False


def production_accepts(family: int) -> bool:
    init, _, body = _case(family)
    program = UProgram({"main": UFunction("main", tuple(body))})
    return ProductionChecker(program, path_budget=8, value_budget=8).analyze("main", init).accepted


def run_current_value_pressure(*, seed: int = 20261004, cases: int = 20_000) -> dict[str, int]:
    rng = random.Random(seed)
    mismatches = 0
    accepted = 0
    rejected = 0
    family_counts = {i: 0 for i in range(12)}
    for _ in range(cases):
        family = rng.randrange(12)
        family_counts[family] += 1
        exact = exact_accepts(family)
        production = production_accepts(family)
        if exact != production:
            mismatches += 1
        if exact:
            accepted += 1
        else:
            rejected += 1
    result: dict[str, int] = {
        "cases": cases,
        "accepted": accepted,
        "rejected": rejected,
        "mismatches": mismatches,
    }
    result.update({f"family_{k}": v for k, v in family_counts.items()})
    return result
