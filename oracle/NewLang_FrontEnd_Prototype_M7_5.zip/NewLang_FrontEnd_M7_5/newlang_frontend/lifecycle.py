from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path
from typing import TypeAlias

_VENDOR = Path(__file__).resolve().parent.parent / "vendor"
if str(_VENDOR) not in sys.path:
    sys.path.insert(0, str(_VENDOR))

from newlang_checker.model import (  # type: ignore[import-not-found]
    BackingRegion,
    ByteRange,
    SemanticError,
    SemanticState,
    SlotClaim,
    StorageClaim,
    ValuePackage,
)
from newlang_checker.semantics import (  # type: ignore[import-not-found]
    apply_step,
    create_lifetime_domain,
    derive_ptr_token,
    finalize_lifetime_domain,
    require_ending_domain,
    require_stability_domain,
    resolve_live_ptr_root,
    validate_state,
)

from .source import Span
from .recursive_summary import infer_lifecycle_recursion_info, typed_block_lifecycle_sensitive
from .typed_ir import (
    TAccessMode,
    TBuiltinCall,
    TBlockInvoke,
    TBlockLiteral,
    TCall,
    TExpr,
    TExprStmt,
    TField,
    TFunction,
    TIndex,
    TInt,
    TLet,
    TLoan,
    TLoop,
    TContinue,
    TBreak,
    TMatch,
    TName,
    TProgram,
    TLayoutInfo,
    TStructLiteral,
    TSumConstruct,
    TUnit,
)
from .typesys import (
    LIFETIME_DOMAIN,
    ALLOCATION,
    STORAGE,
    UNIT,
    USIZE,
    ArrayType,
    BlockType,
    BuiltinType,
    ExclusiveRefType,
    NominalType,
    LayoutType,
    PtrType,
    RefType,
    SlotType,
    SpanType,
    SumType,
    TupleType,
    Type,
    display_type,
)


@dataclass(frozen=True, slots=True)
class ValueHandle:
    name: str
    type: Type


@dataclass(frozen=True, slots=True)
class SlotHandle:
    name: str
    type: SlotType


@dataclass(frozen=True, slots=True)
class AllocationHandle:
    identity: str


@dataclass(frozen=True, slots=True)
class StorageHandle:
    name: str


@dataclass(frozen=True, slots=True)
class LayoutHandle:
    info: TLayoutInfo
    type: LayoutType


@dataclass(frozen=True, slots=True)
class ProjectionFrame:
    owner_type: Type
    field_name: str


@dataclass(frozen=True, slots=True)
class PtrHandle:
    name: str
    type: PtrType
    root_capable: bool = True
    projection_path: tuple[ProjectionFrame, ...] = ()


@dataclass(frozen=True, slots=True)
class DomainHandle:
    identity: str


@dataclass(frozen=True, slots=True)
class RefHandle:
    mode: str
    exclusive: bool
    target: "Handle"
    type: Type
    stability_anchor: "RefHandle | None" = None
    scope_anchor: object | None = None
    origin_ptr: "PtrHandle | None" = None
    # M5.2 compiler-internal writable-location metadata for projected refs.
    parent: "Handle | None" = None
    selector: str | int | None = None


@dataclass(frozen=True, slots=True)
class AccessModeHandle:
    mode: str


@dataclass(frozen=True, slots=True)
class TupleHandle:
    items: tuple["Handle", ...]
    type: TupleType


@dataclass(frozen=True, slots=True)
class SumHandle:
    variant: str
    payload: "Handle | None"
    type: SumType


@dataclass(frozen=True, slots=True)
class StructHandle:
    fields: tuple[tuple[str, "Handle"], ...]
    type: NominalType


@dataclass(frozen=True, slots=True)
class ArrayHandle:
    items: tuple["Handle", ...]
    type: ArrayType


@dataclass(frozen=True, slots=True)
class SpanHandle:
    array: ArrayHandle
    start: int
    count: int
    type: SpanType
    stability_anchor: RefHandle | None = None
    access_anchor: RefHandle | None = None


@dataclass(frozen=True, slots=True)
class BlockHandle:
    params: tuple[str, ...]
    body: object
    captures: dict[str, "Handle"]
    type: BlockType


@dataclass(frozen=True, slots=True)
class UsizeHandle:
    values: frozenset[int] | None
    type: Type = USIZE


@dataclass(frozen=True, slots=True)
class ChoiceHandle:
    options: tuple["Handle", ...]
    type: Type


@dataclass(frozen=True, slots=True)
class UnitHandle:
    pass


Handle: TypeAlias = (
    ValueHandle | SlotHandle | AllocationHandle | StorageHandle | LayoutHandle | PtrHandle | DomainHandle | RefHandle | AccessModeHandle |
    TupleHandle | SumHandle | StructHandle | ArrayHandle | SpanHandle | BlockHandle | UsizeHandle | ChoiceHandle | UnitHandle
)


@dataclass(frozen=True, slots=True)
class LifecycleOutcome:
    accepted: bool
    reason: str
    code: str = ""
    origin: Span | None = None


class LifecycleReject(Exception):
    def __init__(self, code: str, message: str, span: Span | None = None):
        super().__init__(message)
        self.code = code
        self.message = message
        self.span = span


class LoopContinueSignal(Exception):
    def __init__(self, values: tuple[Handle, ...]):
        super().__init__("loop continue")
        self.values = values


class LoopBreakSignal(Exception):
    def __init__(self, value: Handle):
        super().__init__("loop break")
        self.value = value


class LoopDivergesSignal(Exception):
    pass



class LifecycleRunner:
    """M1 exact source bridge for explicit lifetime-root transitions.

    The bridge does not reimplement initialize/take/destroy occupancy transitions.
    It maps typed source values to bindings in the shared Draft-17 checker state
    and delegates those transitions to ``newlang_checker.semantics.apply_step``.

    M1 deliberately uses synthetic incoming slot backing for entry parameters of
    type ``slot<T>``. This is a prototype harness convention, not NewLang syntax.
    Storage -> slot construction belongs to a later front-end milestone.
    """

    def __init__(self, program: TProgram):
        self.program = program
        self.functions = {fn.symbol.function_id: fn for fn in program.functions}
        self.by_name = {fn.symbol.qualified_name: fn for fn in program.functions}
        self.state = SemanticState()
        self.serial = 0
        self.call_depth = 0
        self.active_functions: list[int] = []
        self.recursion_info = infer_lifecycle_recursion_info(program)
        # M2.1: ordinary lexical locals participate in the same lifetime-root
        # model through compiler-internal implicit roots. The source binding's
        # value model remains separate; this shadow exists only to model local
        # place/incarnation lifetime and persistent ptr tokens.
        self.handle_owners: dict[int, object] = {}
        self.local_origin_ptrs: dict[int, PtrHandle] = {}
        self.owner_local_ptrs: dict[object, list[PtrHandle]] = {}
        self.allocations: dict[str, tuple[str, int, int, bool]] = {}  # id -> (backing, size, align, dematerialized)
        self.layouts: dict[Type, TLayoutInfo] = {info.type: info for info in program.layouts}

    def fresh(self, prefix: str) -> str:
        self.serial += 1
        return f"{prefix}#{self.serial}"

    def run(self, entry: str = "main") -> LifecycleOutcome:
        fn = self.by_name.get(entry)
        if fn is None:
            return LifecycleOutcome(False, f"missing lifecycle entry {entry}", "E_LIFETIME_ENTRY")
        env: dict[str, Handle] = {}
        try:
            for index, (name, ty) in enumerate(fn.symbol.params):
                env[name] = self.seed_entry_param(name, ty, index)
            try:
                result = self.exec_function(fn, env)
            except LoopDivergesSignal:
                validate_state(self.state)
                return LifecycleOutcome(True, "Draft 17.2 lifecycle bridge accepted diverging loop")
            self.check_exit_resources(result, fn.body.span)
            validate_state(self.state)
            return LifecycleOutcome(True, "Draft 17.2 lifecycle bridge accepted")
        except LifecycleReject as exc:
            return LifecycleOutcome(False, exc.message, exc.code, exc.span)
        except SemanticError as exc:
            return LifecycleOutcome(False, f"{exc.kind}: {exc.message}", self.code_for_semantic_error(exc.kind))
        except KeyError as exc:
            return LifecycleOutcome(False, f"missing semantic resource {exc.args[0]}", "E_LIFETIME_RESOURCE")

    def seed_entry_param(self, name: str, ty: Type, index: int) -> Handle:
        if isinstance(ty, SlotType):
            backing = f"@entry-backing:{index}:{name}"
            self.state.backings[backing] = BackingRegion(backing, backing)
            size = 1
            self.state.slots[name] = SlotClaim(self.type_name(ty.inner), backing, ByteRange(0, size))
            return SlotHandle(name, ty)
        if ty == LIFETIME_DOMAIN:
            identity = f"@entry-domain:{index}:{name}"
            create_lifetime_domain(self.state, identity)
            return DomainHandle(identity)
        if ty == USIZE:
            # Dynamic usize entry values are modeled as an unknown finite-domain
            # quantity. Array/span preconditions later restrict the alternatives.
            return UsizeHandle(None)
        if isinstance(ty, ArrayType):
            items = tuple(self.seed_array_item(f"{name}[{i}]", ty.inner, index, i) for i in range(ty.length))
            return ArrayHandle(items, ty)
        if isinstance(ty, LayoutType):
            info = self.layouts.get(ty.inner)
            if info is None:
                raise LifecycleReject("E_LAYOUT_WITNESS", f"missing compiler Layout<{display_type(ty.inner)}> witness")
            return LayoutHandle(info, ty)
        if isinstance(ty, (RefType, ExclusiveRefType, PtrType, SpanType, BlockType, SumType)):
            raise LifecycleReject(
                "E_M1_ENTRY_PARAM",
                f"M1 cannot synthesize external entry parameter {name}: {display_type(ty)}",
                None,
            )
        value = self.fresh(f"param:{name}")
        self.state.values[value] = ValuePackage(local=name)
        return ValueHandle(value, ty)

    def seed_array_item(self, name: str, ty: Type, param_index: int, item_index: int) -> Handle:
        if ty == LIFETIME_DOMAIN:
            identity = f"@entry-array-domain:{param_index}:{item_index}:{name}"
            create_lifetime_domain(self.state, identity)
            return DomainHandle(identity)
        if ty == USIZE:
            return UsizeHandle(None)
        if isinstance(ty, SlotType):
            slot_name = f"@entry-array-slot:{param_index}:{item_index}:{name}"
            backing = f"@entry-array-backing:{param_index}:{item_index}:{name}"
            self.state.backings[backing] = BackingRegion(backing, backing)
            self.state.slots[slot_name] = SlotClaim(self.type_name(ty.inner), backing, ByteRange(0, 1))
            return SlotHandle(slot_name, ty)
        value = self.fresh(f"array-item:{name}")
        self.state.values[value] = ValuePackage(local=name)
        return ValueHandle(value, ty)

    def exec_function(self, fn: TFunction, env: dict[str, Handle]) -> Handle:
        function_id = fn.symbol.function_id
        if function_id in self.active_functions:
            if not self.recursion_info.neutral.get(function_id, False):
                raise LifecycleReject(
                    "E_LIFETIME_RECURSIVE_SUMMARY",
                    "recursive lifecycle SCC requires a resource/post-state transformer",
                    fn.body.span,
                )
            return self.recursive_summary_result(fn.symbol.return_type, fn.body.span)
        self.call_depth += 1
        if self.call_depth > 32:
            self.call_depth -= 1
            raise LifecycleReject("E_LIFETIME_RECURSION", "M1 lifecycle bridge call-depth limit exceeded", fn.body.span)
        self.active_functions.append(function_id)
        try:
            return self.exec_block(fn.body, env)
        finally:
            self.active_functions.pop()
            self.call_depth -= 1

    def recursive_summary_result(self, ty: Type, span: Span) -> Handle:
        if ty == UNIT:
            return UnitHandle()
        if ty == USIZE:
            return UsizeHandle(None)
        if isinstance(ty, BuiltinType) and ty != LIFETIME_DOMAIN:
            name = self.fresh("recursive-summary")
            self.state.values[name] = ValuePackage(local="recursive-summary")
            return ValueHandle(name, ty)
        raise LifecycleReject(
            "E_LIFETIME_RECURSIVE_RESULT",
            f"recursive lifecycle summary cannot synthesize result {display_type(ty)}",
            span,
        )

    def exec_block(self, block, env: dict[str, Handle]) -> Handle:
        local = dict(env)
        owner = object()
        for handle in local.values():
            self.handle_owners.setdefault(id(handle), owner)
        try:
            for stmt in block.statements:
                if isinstance(stmt, TLet):
                    value = self.eval_expr(stmt.value, local)
                    if len(stmt.bindings) == 1 and self.handle_type(value) == stmt.bindings[0][1]:
                        flat = [value]
                    else:
                        flat = self.flatten_handle(value)
                    if len(flat) != len(stmt.bindings):
                        raise LifecycleReject("E_LIFETIME_BIND", "typed binding shape mismatch", stmt.span)
                    for (name, _), handle in zip(stmt.bindings, flat, strict=True):
                        local[name] = handle
                        self.handle_owners.setdefault(id(handle), owner)
                elif isinstance(stmt, TExprStmt):
                    self.eval_expr(stmt.expr, local)
                else:
                    raise AssertionError(stmt)
            result = UnitHandle() if block.tail is None else self.eval_expr(block.tail, local)
            return result
        finally:
            self.end_owned_local_roots(owner, block.span)

    def eval_expr(self, expr: TExpr, env: dict[str, Handle]) -> Handle:
        if isinstance(expr, TName):
            handle = env.get(expr.name)
            if handle is None:
                raise LifecycleReject("E_LIFETIME_NAME", f"no lifecycle binding for {expr.name}", expr.span)
            return handle
        if isinstance(expr, TInt):
            name = self.fresh("int")
            self.state.values[name] = ValuePackage(local=str(expr.value))
            return ValueHandle(name, expr.type)
        if isinstance(expr, TUnit):
            return UnitHandle()
        if isinstance(expr, TAccessMode):
            return AccessModeHandle(expr.mode)
        if isinstance(expr, TStructLiteral):
            fields = tuple((field.name, self.eval_expr(value, env)) for field, value in expr.fields)
            assert isinstance(expr.type, NominalType)
            if all(isinstance(child, (ValueHandle, UsizeHandle, UnitHandle)) for _, child in fields):
                name = self.fresh("value")
                self.state.values[name] = ValuePackage(local=f"struct:{self.type_name(expr.type)}")
                return ValueHandle(name, expr.type)
            return StructHandle(fields, expr.type)
        if isinstance(expr, TField):
            base = self.eval_expr(expr.base, env)
            return self.project_field(base, expr.type, expr.field.name, expr.span)
        if isinstance(expr, TIndex):
            base = self.eval_expr(expr.base, env)
            domain = self.eval_index_domain(expr.index, env, expr.span)
            return self.project_index(base, domain, expr.type, expr.span)
        if isinstance(expr, TSumConstruct):
            payload = None if expr.payload is None else self.eval_expr(expr.payload, env)
            assert isinstance(expr.type, SumType)
            return SumHandle(expr.variant.name, payload, expr.type)
        if isinstance(expr, TBlockLiteral):
            assert isinstance(expr.type, BlockType)
            return BlockHandle(tuple(name for name, _ in expr.params), expr.body, dict(env), expr.type)
        if isinstance(expr, TBlockInvoke):
            block = self.eval_expr(expr.callee, env)
            if not isinstance(block, BlockHandle):
                raise LifecycleReject("E_BLOCK_CALL", "callee is not a block value", expr.span)
            args = [self.eval_expr(a, env) for a in expr.args]
            return self.invoke_block(block, args, expr.span)
        if isinstance(expr, TLoop):
            carried = tuple(self.eval_expr(param.initial, env) for param in expr.params)
            for _ in range(64):
                child = dict(env)
                for param, handle in zip(expr.params, carried, strict=True):
                    child[param.name] = handle
                try:
                    self.exec_block(expr.body, child)
                except LoopContinueSignal as signal:
                    carried = signal.values
                    if not self._loop_body_contains_break(expr.body) and not typed_block_lifecycle_sensitive(expr.body):
                        raise LoopDivergesSignal()
                    continue
                except LoopBreakSignal as signal:
                    return signal.value
                raise LifecycleReject("E_LOOP_FALLTHROUGH", "typed loop body fell through in lifecycle bridge", expr.span)
            raise LifecycleReject(
                "E_LOOP_LIFECYCLE_BUDGET",
                "loop lifecycle execution exceeded finite prototype budget; richer loop post-state summary required",
                expr.span,
            )
        if isinstance(expr, TContinue):
            raise LoopContinueSignal(tuple(self.eval_expr(arg, env) for arg in expr.args))
        if isinstance(expr, TBreak):
            value = UnitHandle() if expr.value is None else self.eval_expr(expr.value, env)
            raise LoopBreakSignal(value)
        if isinstance(expr, TMatch):
            return self.eval_match(expr, env)
        if isinstance(expr, TLoan):
            source = self.eval_expr(expr.source, env)
            ref_type: Type = (
                ExclusiveRefType(expr.mode, self.handle_type(source))
                if expr.exclusive
                else RefType(expr.mode, self.handle_type(source))
            )
            origin_ptr = None
            if not expr.exclusive and isinstance(source, (ValueHandle, SumHandle, ArrayHandle)):
                origin_ptr = self.ensure_local_origin_ptr(source, expr.span)
            ref = RefHandle(expr.mode, expr.exclusive, source, ref_type, origin_ptr=origin_ptr)
            child = dict(env)
            child[expr.binding] = ref
            try:
                result = self.exec_block(expr.body, child)
            except (LoopContinueSignal, LoopBreakSignal):
                self._write_back_loan(expr, ref, env)
                raise
            self._write_back_loan(expr, ref, env)
            if self.handle_depends_on(result, ref):
                raise LifecycleReject("E_SCOPE_ESCAPE", "value derived from a loan escapes its lexical block", expr.span)
            return result
        if isinstance(expr, TCall):
            actuals = [self.eval_expr(arg, env) for arg in expr.args]
            callee = self.functions[expr.function.function_id]
            call_env = {name: value for (name, _), value in zip(callee.symbol.params, actuals, strict=True)}
            return self.exec_function(callee, call_env)
        if isinstance(expr, TBuiltinCall):
            return self.eval_builtin(expr, env)
        raise AssertionError(expr)

    def _loop_body_contains_break(self, block) -> bool:
        def expr_has_break(item: TExpr) -> bool:
            if isinstance(item, TBreak):
                return True
            if isinstance(item, TLoop):
                # Nested loop breaks target the nested loop, not this one. Its
                # initializers execute outside the nested target, but M4 does
                # not rely on non-local control in initializers.
                return False
            if isinstance(item, TMatch):
                return any(self._loop_body_contains_break(arm.body) for arm in item.arms)
            if isinstance(item, TLoan):
                return self._loop_body_contains_break(item.body)
            return False
        for stmt in block.statements:
            item = stmt.value if isinstance(stmt, TLet) else stmt.expr
            if expr_has_break(item):
                return True
        return block.tail is not None and expr_has_break(block.tail)

    def eval_builtin(self, expr: TBuiltinCall, env: dict[str, Handle]) -> Handle:
        name = expr.name
        args = [self.eval_expr(arg, env) for arg in expr.args]
        if name == "u32":
            value = self.fresh(name)
            self.state.values[value] = ValuePackage(local=name)
            return ValueHandle(value, expr.type)
        if name == "usize":
            source = expr.args[0] if expr.args else None
            if isinstance(source, TInt):
                return UsizeHandle(frozenset({source.value}))
            if args and isinstance(args[0], UsizeHandle):
                return args[0]
            return UsizeHandle(None)
        if name == "layout":
            if not isinstance(expr.type, LayoutType):
                raise LifecycleReject("E_LAYOUT_WITNESS", "layout() lost its Layout<T> result type", expr.span)
            info = self.layouts.get(expr.type.inner)
            if info is None:
                raise LifecycleReject("E_LAYOUT_WITNESS", f"missing compiler Layout<{display_type(expr.type.inner)}> witness", expr.span)
            return LayoutHandle(info, expr.type)
        if name in {"layout_size", "layout_align", "layout_stride"}:
            layout = self.require_layout(args[0], expr.span)
            value = {
                "layout_size": layout.info.size,
                "layout_align": layout.info.align,
                "layout_stride": layout.info.stride,
            }[name]
            return UsizeHandle(frozenset({value}))
        if name == "allocate_layout":
            layout = self.require_layout(args[0], expr.span)
            count = self.require_known_usize(args[1], expr.span, "layout allocation element count")
            if count <= 0:
                raise LifecycleReject("E_ALLOCATION_LAYOUT", "layout allocation count must be positive", expr.span)
            if layout.info.size == 0:
                raise LifecycleReject(
                    "E_ZST_DYNAMIC_STORAGE",
                    "v0 raw Storage allocation does not represent logical multiplicity for zero-sized object lifetimes",
                    expr.span,
                )
            size = layout.info.stride * count
            align = layout.info.align
            aid = self.fresh("alloc")
            backing = f"@backing:{aid}"
            storage = self.fresh("storage")
            self.state.backings[backing] = BackingRegion(backing, backing)
            self.state.storages[storage] = StorageClaim(backing, ByteRange(0, size))
            self.allocations[aid] = (backing, size, align, False)
            validate_state(self.state)
            return TupleHandle((AllocationHandle(aid), StorageHandle(storage)), expr.type)
        if name == "storage_into_slot_layout":
            storage = self.require_storage(args[0], expr.span)
            layout = self.require_layout(args[1], expr.span)
            claim = self.state.storages.get(storage.name)
            if claim is None:
                raise LifecycleReject("E_STORAGE_CONSUMED", f"Storage {storage.name} was already consumed", expr.span)
            if layout.info.size == 0:
                raise LifecycleReject(
                    "E_ZST_DYNAMIC_STORAGE",
                    "v0 raw Storage/slot bridge does not materialize zero-sized object lifetimes",
                    expr.span,
                )
            if claim.byte_range.length != layout.info.size:
                raise LifecycleReject(
                    "E_SLOT_SIZE",
                    f"Storage is {claim.byte_range.length} bytes but compiler Layout<{display_type(layout.info.type)}>.size is {layout.info.size}",
                    expr.span,
                )
            backing_align = self.backing_alignment(claim.backing_region)
            if backing_align < layout.info.align or claim.byte_range.start % layout.info.align != 0:
                raise LifecycleReject("E_SLOT_ALIGNMENT", f"Storage is not aligned for {display_type(layout.info.type)}", expr.span)
            type_name = self.type_name(layout.info.type)
            self.state.sizeof[type_name] = layout.info.size
            self.state.storages[storage.name] = StorageClaim(
                claim.backing_region,
                claim.byte_range,
                claim.raw,
                frozenset({type_name}),
            )
            slot = self.fresh("slot")
            try:
                apply_step(self.state, {"op": "into_slot", "storage": storage.name, "type": type_name, "result": slot})
                validate_state(self.state)
            except SemanticError as exc:
                raise LifecycleReject(self.code_for_semantic_error(exc.kind), f"{exc.kind}: {exc.message}", expr.span) from exc
            assert isinstance(expr.type, SlotType)
            return SlotHandle(slot, expr.type)
        if name == "store":
            return UnitHandle()
        if name == "replace":
            dst = args[0]
            if isinstance(dst, ChoiceHandle):
                raise LifecycleReject(
                    "E_REPLACE_DYNAMIC_PRECISION",
                    "exact lifecycle bridge cannot update an unresolved dynamic destination; finite branch state is required",
                    expr.span,
                )
            if not isinstance(dst, RefHandle) or dst.exclusive or dst.mode != "write":
                raise LifecycleReject("E_REPLACE_DEST", "replace requires ordinary ref<write,T>", expr.span)
            return self.replace_ref_target(dst, args[1], expr.span)
        if name == "swap":
            left, right = args
            if isinstance(left, ChoiceHandle) or isinstance(right, ChoiceHandle):
                raise LifecycleReject(
                    "E_SWAP_DYNAMIC_PRECISION",
                    "swap cannot act on an unresolved dynamic destination without finite correlated location state",
                    expr.span,
                )
            if not isinstance(left, RefHandle) or left.exclusive or left.mode != "write":
                raise LifecycleReject("E_SWAP_DEST", "swap requires ordinary ref<write,T> destinations", expr.span)
            if not isinstance(right, RefHandle) or right.exclusive or right.mode != "write":
                raise LifecycleReject("E_SWAP_DEST", "swap requires ordinary ref<write,T> destinations", expr.span)
            self.swap_ref_targets(left, right, expr.span)
            return UnitHandle()
        if name == "allocate_storage":
            size = self.require_known_usize(args[0], expr.span, "allocation byte count")
            align = self.require_known_usize(args[1], expr.span, "allocation alignment")
            if size <= 0 or align <= 0 or align & (align - 1):
                raise LifecycleReject("E_ALLOCATION_LAYOUT", "allocation size must be positive and alignment must be a positive power of two", expr.span)
            aid = self.fresh("alloc")
            backing = f"@backing:{aid}"
            storage = self.fresh("storage")
            self.state.backings[backing] = BackingRegion(backing, backing)
            self.state.storages[storage] = StorageClaim(backing, ByteRange(0, size))
            self.allocations[aid] = (backing, size, align, False)
            return TupleHandle((AllocationHandle(aid), StorageHandle(storage)), expr.type)
        if name == "split_storage":
            storage = self.require_storage(args[0], expr.span)
            off = self.require_known_usize(args[1], expr.span, "split offset")
            left, right = self.fresh("storage"), self.fresh("storage")
            try:
                apply_step(self.state, {"op": "split", "storage": storage.name, "offset": off, "results": [left, right]})
                validate_state(self.state)
            except SemanticError as exc:
                raise LifecycleReject(self.code_for_semantic_error(exc.kind), f"{exc.kind}: {exc.message}", expr.span) from exc
            assert isinstance(expr.type, TupleType)
            return TupleHandle((StorageHandle(left), StorageHandle(right)), expr.type)
        if name == "merge_storage":
            a = self.require_storage(args[0], expr.span); b = self.require_storage(args[1], expr.span)
            out = self.fresh("storage")
            try:
                apply_step(self.state, {"op": "merge", "storages": [a.name, b.name], "result": out}); validate_state(self.state)
            except SemanticError as exc:
                raise LifecycleReject(self.code_for_semantic_error(exc.kind), f"{exc.kind}: {exc.message}", expr.span) from exc
            return StorageHandle(out)
        if name == "storage_into_slot":
            storage = self.require_storage(args[0], expr.span)
            assert isinstance(expr.type, SlotType)
            type_name = self.type_name(expr.type.inner)
            size = self.sizeof_type(expr.type.inner, expr.span)
            align = self.alignof_type(expr.type.inner, expr.span)
            claim = self.state.storages[storage.name]
            backing_align = self.backing_alignment(claim.backing_region)
            if claim.byte_range.length != size:
                raise LifecycleReject("E_SLOT_SIZE", f"Storage is {claim.byte_range.length} bytes but sizeof({type_name}) is {size}", expr.span)
            if backing_align < align or claim.byte_range.start % align != 0:
                raise LifecycleReject("E_SLOT_ALIGNMENT", f"Storage is not aligned for {type_name}", expr.span)
            self.state.sizeof[type_name] = size
            self.state.storages[storage.name] = StorageClaim(claim.backing_region, claim.byte_range, claim.raw, frozenset({type_name}))
            slot = self.fresh("slot")
            try:
                apply_step(self.state, {"op": "into_slot", "storage": storage.name, "type": type_name, "result": slot}); validate_state(self.state)
            except SemanticError as exc:
                raise LifecycleReject(self.code_for_semantic_error(exc.kind), f"{exc.kind}: {exc.message}", expr.span) from exc
            return SlotHandle(slot, expr.type)
        if name == "erase_slot":
            slot = self.require_slot(args[0], expr.span); storage = self.fresh("storage")
            try:
                apply_step(self.state, {"op": "erase_slot", "slot": slot.name, "result": storage}); validate_state(self.state)
            except SemanticError as exc:
                raise LifecycleReject(self.code_for_semantic_error(exc.kind), f"{exc.kind}: {exc.message}", expr.span) from exc
            return StorageHandle(storage)
        if name == "deallocate_storage":
            alloc = self.require_allocation(args[0], expr.span); storage = self.require_storage(args[1], expr.span)
            backing, size, _align, demat = self.allocations[alloc.identity]
            if demat:
                raise LifecycleReject("E_DEALLOCATE_CLAIM", "cannot deallocate while storage responsibility is held by metadata", expr.span)
            claim = self.state.storages.get(storage.name)
            if claim is None or claim.backing_region != backing or claim.byte_range != ByteRange(0, size):
                raise LifecycleReject("E_DEALLOCATE_CLAIM", "deallocation requires whole Allocation Storage", expr.span)
            self.state.storages.pop(storage.name)
            self.state.backings[backing] = BackingRegion(backing, backing, False)
            del self.allocations[alloc.identity]
            validate_state(self.state)
            return UnitHandle()
        if name in {"unchecked_dematerialize_storage", "unchecked_materialize_slot", "unchecked_recover_whole_storage"}:
            raise LifecycleReject(
                "E_M62_LEGACY_DYNAMIC_BRIDGE",
                "M6.1 metadata-driven authority reconstruction was retired in M6.2; use the authority-preserving region prototype",
                expr.span,
            )
        if name == "array_span":
            ref = args[0]
            if isinstance(ref, ChoiceHandle):
                return self.make_choice(tuple(self.array_span_from_ref(x, expr.type, expr.span) for x in ref.options), expr.type)
            return self.array_span_from_ref(ref, expr.type, expr.span)
        if name == "len":
            span = args[0]
            counts = {x.count for x in self.span_options(span, expr.span)}
            return UsizeHandle(frozenset(counts))
        if name == "subspan":
            spans = self.span_options(args[0], expr.span)
            start_domain = self.index_domain_from_handle(expr.args[1], args[1])
            count_domain = self.index_domain_from_handle(expr.args[2], args[2])
            out: list[Handle] = []
            for span in spans:
                starts = range(span.count + 1) if start_domain is None else sorted(start_domain)
                counts = range(span.count + 1) if count_domain is None else sorted(count_domain)
                for start in starts:
                    for count in counts:
                        if 0 <= start <= span.count and 0 <= count <= span.count - start:
                            assert isinstance(expr.type, SpanType)
                            out.append(SpanHandle(span.array, span.start + start, count, expr.type, span.stability_anchor, span.access_anchor))
            if not out:
                raise LifecycleReject("E_BOUNDS", "subspan range violates its precondition", expr.span)
            return self.make_choice(tuple(out), expr.type)
        if name == "consume_array":
            array, block = args
            if not isinstance(array, ArrayHandle) or not isinstance(block, BlockHandle):
                raise LifecycleReject("E_CONSUME_ARRAY", "consume_array requires Array and block", expr.span)
            for item in array.items:
                result = self.invoke_block(block, [item], expr.span)
                if not isinstance(result, UnitHandle):
                    raise LifecycleReject("E_CONSUME_ARRAY", "consumer must return unit", expr.span)
            return UnitHandle()
        if name == "lifetime_domain":
            identity = self.fresh("D")
            create_lifetime_domain(self.state, identity)
            return DomainHandle(identity)
        if name == "finalize_domain":
            domain = self.require_domain(args[0], expr.span)
            try:
                finalize_lifetime_domain(self.state, domain.identity)
            except SemanticError as exc:
                raise LifecycleReject(self.code_for_semantic_error(exc.kind), f"{exc.kind}: {exc.message}", expr.span) from exc
            return UnitHandle()
        if name == "initialize":
            slot = self.require_slot(args[0], expr.span)
            value = self.require_value(args[1], expr.span)
            stable = self.require_domain_ref(args[2], exclusive=False, span=expr.span)
            root = self.fresh("root")
            ptr = self.fresh("ptr")
            try:
                apply_step(self.state, {
                    "op": "initialize",
                    "slot": slot.name,
                    "value": value.name,
                    "domain": stable.target.identity,
                    "result_root": root,
                    "result_location_token": ptr,
                })
                validate_state(self.state)
            except SemanticError as exc:
                raise LifecycleReject(self.code_for_semantic_error(exc.kind), f"{exc.kind}: {exc.message}", expr.span) from exc
            assert isinstance(expr.type, PtrType)
            return PtrHandle(ptr, expr.type)
        if name == "ref_from_ptr":
            mode = args[0]
            if not isinstance(mode, AccessModeHandle):
                raise LifecycleReject("E_REF_FROM_PTR_MODE", "expected read/write access mode", expr.span)
            stable = self.require_domain_ref(args[2], exclusive=False, span=expr.span)
            ptr_arg = args[1]
            if isinstance(ptr_arg, ChoiceHandle):
                options = tuple(self.ref_from_ptr_handle(mode.mode, x, stable, expr.type, expr.span) for x in ptr_arg.options)
                return self.make_choice(options, expr.type)
            return self.ref_from_ptr_handle(mode.mode, ptr_arg, stable, expr.type, expr.span)
        if name == "ptr_from_ref":
            ref = args[0]
            if isinstance(ref, ChoiceHandle):
                options = tuple(self.ptr_from_ref_handle(x, expr.type, expr.span) for x in ref.options)
                return self.make_choice(options, expr.type)
            return self.ptr_from_ref_handle(ref, expr.type, expr.span)
        if name == "owner_ptr":
            source = args[0]
            if isinstance(source, ChoiceHandle):
                options = tuple(self.owner_ptr_handle(x, expr.type, expr.span) for x in source.options)
                return self.make_choice(options, expr.type)
            return self.owner_ptr_handle(source, expr.type, expr.span)
        if name in {"take", "destroy"}:
            if not isinstance(args[0], PtrHandle):
                raise LifecycleReject("E_LIFETIME_PTR", "expected ptr<T>", expr.span)
            ptr = args[0]
            if not ptr.root_capable:
                raise LifecycleReject("E_NOT_LIFETIME_ROOT", "projected ptr does not carry independent lifetime-root authority", expr.span)
            ptr = self.require_ptr(ptr, expr.span)
            ending = self.require_domain_ref(args[1], exclusive=True, span=expr.span)
            try:
                root = require_ending_domain(self.state, ptr.name, ending.target.identity)
            except SemanticError as exc:
                raise LifecycleReject(self.code_for_semantic_error(exc.kind), f"{exc.kind}: {exc.message}", expr.span) from exc
            if name == "destroy":
                slot_name = self.fresh("slot")
                try:
                    apply_step(self.state, {
                        "op": "destroy",
                        "root": root.root_id,
                        "ending_domain": ending.target.identity,
                        "result_slot": slot_name,
                    })
                    validate_state(self.state)
                except SemanticError as exc:
                    raise LifecycleReject(self.code_for_semantic_error(exc.kind), f"{exc.kind}: {exc.message}", expr.span) from exc
                assert isinstance(expr.type, SlotType)
                return SlotHandle(slot_name, expr.type)
            value_name = self.fresh("taken-value")
            slot_name = self.fresh("slot")
            try:
                apply_step(self.state, {
                    "op": "take",
                    "root": root.root_id,
                    "ending_domain": ending.target.identity,
                    "result_value": value_name,
                    "result_slot": slot_name,
                })
                validate_state(self.state)
            except SemanticError as exc:
                raise LifecycleReject(self.code_for_semantic_error(exc.kind), f"{exc.kind}: {exc.message}", expr.span) from exc
            assert isinstance(expr.type, TupleType)
            return TupleHandle((
                ValueHandle(value_name, expr.type.items[0]),
                SlotHandle(slot_name, expr.type.items[1]),  # type: ignore[arg-type]
            ), expr.type)
        # Other M0 builtins are lifecycle-neutral.
        name_id = self.fresh(f"builtin:{name}")
        self.state.values[name_id] = ValuePackage(local=name)
        return ValueHandle(name_id, expr.type)

    def _write_back_loan(self, expr: TLoan, ref: RefHandle, env: dict[str, Handle]) -> None:
        if expr.mode == "write" and isinstance(expr.source, TName):
            env[expr.source.name] = self.current_ref_target(ref)

    def current_ref_target(self, ref: RefHandle) -> Handle:
        parent = ref.parent
        selector = ref.selector
        if isinstance(parent, StructHandle) and isinstance(selector, str):
            for name, child in parent.fields:
                if name == selector:
                    object.__setattr__(ref, "target", child)
                    return child
        elif isinstance(parent, ArrayHandle) and isinstance(selector, int):
            if 0 <= selector < len(parent.items):
                child = parent.items[selector]
                object.__setattr__(ref, "target", child)
                return child
        return ref.target

    def same_ref_location(self, left: RefHandle, right: RefHandle) -> bool:
        if left.parent is None and right.parent is None:
            return left.target is right.target
        return left.parent is right.parent and left.selector == right.selector

    def set_ref_target(self, ref: RefHandle, new_value: Handle, span: Span) -> None:
        parent = ref.parent
        selector = ref.selector
        if parent is None:
            object.__setattr__(ref, "target", new_value)
            return
        if isinstance(parent, StructHandle) and isinstance(selector, str):
            fields = list(parent.fields)
            for i, (name, _) in enumerate(fields):
                if name == selector:
                    fields[i] = (name, new_value)
                    object.__setattr__(parent, "fields", tuple(fields))
                    object.__setattr__(ref, "target", new_value)
                    return
            raise LifecycleReject("E_SWAP_DEST", f"struct location has no field {selector}", span)
        if isinstance(parent, ArrayHandle) and isinstance(selector, int):
            if not (0 <= selector < len(parent.items)):
                raise LifecycleReject("E_BOUNDS", "swap array destination is out of bounds", span)
            items = list(parent.items)
            items[selector] = new_value
            object.__setattr__(parent, "items", tuple(items))
            object.__setattr__(ref, "target", new_value)
            return
        raise LifecycleReject(
            "E_SWAP_LOCATION_PRECISION",
            "swap destination lacks a writable structural location in the lifecycle bridge",
            span,
        )

    def swap_ref_targets(self, left: RefHandle, right: RefHandle, span: Span) -> None:
        if self.same_ref_location(left, right):
            return
        old_left = self.current_ref_target(left)
        old_right = self.current_ref_target(right)
        # Read both old values first, then perform the two writes as one abstract
        # transition; no observable empty state is introduced.
        self.set_ref_target(left, old_right, span)
        self.set_ref_target(right, old_left, span)

    def replace_ref_target(self, ref: RefHandle, new_value: Handle, span: Span) -> Handle:
        old = self.current_ref_target(ref)
        parent = ref.parent
        selector = ref.selector
        if parent is None:
            object.__setattr__(ref, "target", new_value)
            return old
        if isinstance(parent, StructHandle) and isinstance(selector, str):
            fields = list(parent.fields)
            for i, (name, _) in enumerate(fields):
                if name == selector:
                    fields[i] = (name, new_value)
                    object.__setattr__(parent, "fields", tuple(fields))
                    object.__setattr__(ref, "target", new_value)
                    return old
            raise LifecycleReject("E_REPLACE_DEST", f"struct location has no field {selector}", span)
        if isinstance(parent, ArrayHandle) and isinstance(selector, int):
            if not (0 <= selector < len(parent.items)):
                raise LifecycleReject("E_BOUNDS", "replace array destination is out of bounds", span)
            items = list(parent.items)
            items[selector] = new_value
            object.__setattr__(parent, "items", tuple(items))
            object.__setattr__(ref, "target", new_value)
            return old
        raise LifecycleReject(
            "E_REPLACE_LOCATION_PRECISION",
            "replace destination lacks a writable structural location in the lifecycle bridge",
            span,
        )

    def make_choice(self, options: tuple[Handle, ...], ty: Type) -> Handle:
        flat: list[Handle] = []
        seen: set[str] = set()
        for option in options:
            children = option.options if isinstance(option, ChoiceHandle) else (option,)
            for child in children:
                key = repr(child)
                if key not in seen:
                    seen.add(key)
                    flat.append(child)
        if not flat:
            raise LifecycleReject("E_ANALYSIS_PRECISION", "no feasible handle alternatives remain")
        if len(flat) == 1:
            return flat[0]
        return ChoiceHandle(tuple(flat), ty)

    def index_domain_from_handle(self, expr: TExpr, handle: Handle) -> frozenset[int] | None:
        if isinstance(expr, TBuiltinCall) and expr.name == "usize" and expr.args and isinstance(expr.args[0], TInt):
            return frozenset({expr.args[0].value})
        if isinstance(expr, TInt):
            return frozenset({expr.value})
        if isinstance(handle, UsizeHandle):
            return handle.values
        if isinstance(handle, ChoiceHandle):
            vals: set[int] = set()
            for option in handle.options:
                domain = self.index_domain_from_handle(expr, option)
                if domain is None:
                    return None
                vals.update(domain)
            return frozenset(vals)
        if isinstance(handle, ValueHandle):
            try:
                return frozenset({int(self.state.values[handle.name].local or "")})
            except (ValueError, KeyError):
                return None
        return None

    def eval_index_domain(self, expr: TExpr, env: dict[str, Handle], span: Span) -> frozenset[int] | None:
        handle = self.eval_expr(expr, env)
        return self.index_domain_from_handle(expr, handle)

    def project_origin_ptr(
        self,
        origin: PtrHandle | None,
        inner: Type,
        span: Span,
        prefix: str,
        *,
        owner_type: Type | None = None,
        field_name: str | None = None,
    ) -> PtrHandle | None:
        if origin is None:
            return None
        projected = self.fresh(prefix)
        try:
            derive_ptr_token(self.state, origin.name, projected)
        except SemanticError as exc:
            raise LifecycleReject(self.code_for_semantic_error(exc.kind), f"{exc.kind}: {exc.message}", span) from exc
        path = origin.projection_path
        if owner_type is not None and field_name is not None:
            path = path + (ProjectionFrame(owner_type, field_name),)
        return PtrHandle(projected, PtrType(inner), False, path)

    def project_field(self, base: Handle, result_type: Type, field_name: str, span: Span) -> Handle:
        if isinstance(base, ChoiceHandle):
            return self.make_choice(tuple(self.project_field(x, result_type, field_name, span) for x in base.options), result_type)
        if isinstance(base, StructHandle):
            for name, child in base.fields:
                if name == field_name:
                    return child
            raise LifecycleReject("E_UNKNOWN_FIELD", f"struct handle has no field {field_name}", span)
        if isinstance(base, PtrHandle):
            projected = self.fresh("projected-ptr")
            try:
                derive_ptr_token(self.state, base.name, projected)
            except SemanticError as exc:
                raise LifecycleReject(self.code_for_semantic_error(exc.kind), f"{exc.kind}: {exc.message}", span) from exc
            owner_type = base.type.inner
            path = base.projection_path + (ProjectionFrame(owner_type, field_name),)
            return PtrHandle(projected, result_type, False, path)  # type: ignore[arg-type]
        if isinstance(base, RefHandle):
            inner = result_type.inner if isinstance(result_type, (RefType, ExclusiveRefType)) else result_type
            owner_type = base.type.inner if isinstance(base.type, (RefType, ExclusiveRefType)) else None
            origin = self.project_origin_ptr(
                base.origin_ptr, inner, span, "projected-ref-ptr", owner_type=owner_type, field_name=field_name
            )
            target = self.current_ref_target(base)
            parent: Handle | None = None
            selector: str | int | None = None
            if isinstance(target, StructHandle):
                matches = [child for name, child in target.fields if name == field_name]
                if not matches:
                    raise LifecycleReject("E_UNKNOWN_FIELD", f"struct handle has no field {field_name}", span)
                parent = target
                selector = field_name
                target = matches[0]
            return RefHandle(
                base.mode, base.exclusive, target, result_type,
                base.stability_anchor, base.scope_anchor, origin, parent, selector,
            )
        name = self.fresh("field-value")
        self.state.values[name] = ValuePackage(local=field_name)
        return ValueHandle(name, result_type)

    def project_index(self, base: Handle, domain: frozenset[int] | None, result_type: Type, span: Span) -> Handle:
        if isinstance(base, ChoiceHandle):
            out: list[Handle] = []
            for option in base.options:
                projected = self.project_index(option, domain, result_type, span)
                out.extend(projected.options if isinstance(projected, ChoiceHandle) else (projected,))
            return self.make_choice(tuple(out), result_type)
        if isinstance(base, SpanHandle):
            indices = range(base.count) if domain is None else sorted(domain)
            out = []
            for index in indices:
                if 0 <= index < base.count:
                    target = base.array.items[base.start + index]
                    out.append(RefHandle(
                        base.type.mode, False, target, result_type,
                        base.stability_anchor, base.access_anchor, None, base.array, base.start + index,
                    ))
            if not out:
                raise LifecycleReject("E_BOUNDS", "span index violates its precondition", span)
            return self.make_choice(tuple(out), result_type)
        if isinstance(base, RefHandle) and isinstance(self.current_ref_target(base), ArrayHandle):
            array = self.current_ref_target(base)
            assert isinstance(array, ArrayHandle)
            length = len(array.items)
            indices = range(length) if domain is None else sorted(domain)
            out = []
            for index in indices:
                if 0 <= index < length:
                    target = array.items[index]
                    inner = result_type.inner if isinstance(result_type, (RefType, ExclusiveRefType)) else result_type
                    origin = self.project_origin_ptr(base.origin_ptr, inner, span, "array-ref-element-ptr")
                    out.append(RefHandle(
                        base.mode, base.exclusive, target, result_type,
                        base.stability_anchor, base.scope_anchor, origin, array, index,
                    ))
            if not out:
                raise LifecycleReject("E_BOUNDS", "Array index violates its precondition", span)
            return self.make_choice(tuple(out), result_type)
        if isinstance(base, PtrHandle):
            assert isinstance(base.type.inner, ArrayType)
            length = base.type.inner.length
            indices = range(length) if domain is None else sorted(domain)
            out = []
            for index in indices:
                if 0 <= index < length:
                    projected = self.fresh(f"array-element-ptr:{index}")
                    try:
                        derive_ptr_token(self.state, base.name, projected)
                    except SemanticError as exc:
                        raise LifecycleReject(self.code_for_semantic_error(exc.kind), f"{exc.kind}: {exc.message}", span) from exc
                    out.append(PtrHandle(projected, result_type, False))  # type: ignore[arg-type]
            if not out:
                raise LifecycleReject("E_BOUNDS", "Array ptr index violates its precondition", span)
            return self.make_choice(tuple(out), result_type)
        raise LifecycleReject("E_INDEX_BASE", "index base unavailable in lifecycle bridge", span)

    def array_span_from_ref(self, handle: Handle, result_type: Type, span: Span) -> SpanHandle:
        if not isinstance(handle, RefHandle):
            raise LifecycleReject("E_ARRAY_SPAN", "array_span requires a ref to Array", span)
        target = self.current_ref_target(handle)
        if not isinstance(target, ArrayHandle):
            raise LifecycleReject("E_ARRAY_SPAN", "array_span requires a ref to Array", span)
        assert isinstance(result_type, SpanType)
        return SpanHandle(
            target, 0, len(target.items), result_type,
            handle.stability_anchor, handle,
        )

    def span_options(self, handle: Handle, span: Span) -> tuple[SpanHandle, ...]:
        if isinstance(handle, SpanHandle):
            return (handle,)
        if isinstance(handle, ChoiceHandle):
            spans = tuple(x for x in handle.options if isinstance(x, SpanHandle))
            if len(spans) != len(handle.options):
                raise LifecycleReject("E_SUBSPAN", "span alternative set contains non-span value", span)
            return spans
        raise LifecycleReject("E_SUBSPAN", "expected span", span)

    def owner_ptr_handle(self, handle: Handle, result_type: Type, span: Span) -> PtrHandle:
        if not isinstance(handle, PtrHandle) or not isinstance(result_type, PtrType):
            raise LifecycleReject("E_OWNER_PTR", "owner_ptr requires ptr input and ptr result", span)
        target = result_type.inner
        match_index: int | None = None
        for i in range(len(handle.projection_path) - 1, -1, -1):
            if handle.projection_path[i].owner_type == target:
                match_index = i
                break
        if match_index is None:
            raise LifecycleReject(
                "E_OWNER_PROJECTION",
                f"ptr<{display_type(handle.type.inner)}> does not carry a projection provenance from {display_type(target)}",
                span,
            )
        result = self.fresh("owner-ptr")
        try:
            derive_ptr_token(self.state, handle.name, result)
        except SemanticError as exc:
            raise LifecycleReject(self.code_for_semantic_error(exc.kind), f"{exc.kind}: {exc.message}", span) from exc
        remaining = handle.projection_path[:match_index]
        return PtrHandle(result, result_type, not remaining, remaining)

    def ref_from_ptr_handle(self, mode: str, handle: Handle, stable: RefHandle, result_type: Type, span: Span) -> RefHandle:
        ptr = self.require_ptr(handle, span)
        try:
            require_stability_domain(self.state, ptr.name, stable.target.identity)
        except SemanticError as exc:
            raise LifecycleReject(self.code_for_semantic_error(exc.kind), f"{exc.kind}: {exc.message}", span) from exc
        return RefHandle(mode, False, ptr, result_type, stable, origin_ptr=ptr)

    def ptr_from_ref_handle(self, handle: Handle, result_type: Type, span: Span) -> PtrHandle:
        if not isinstance(handle, RefHandle) or handle.exclusive:
            raise LifecycleReject("E_PTR_FROM_REF", "ptr_from_ref requires an ordinary ref", span)
        source = handle.origin_ptr if handle.origin_ptr is not None else (handle.target if isinstance(handle.target, PtrHandle) else None)
        if source is None:
            source = self.ensure_local_origin_ptr(handle.target, span)
        result = self.fresh("ptr-from-ref")
        try:
            derive_ptr_token(self.state, source.name, result)
        except SemanticError as exc:
            raise LifecycleReject(self.code_for_semantic_error(exc.kind), f"{exc.kind}: {exc.message}", span) from exc
        assert isinstance(result_type, PtrType)
        return PtrHandle(result, result_type, source.root_capable, source.projection_path)

    def ensure_local_origin_ptr(self, handle: Handle, span: Span) -> PtrHandle:
        key = id(handle)
        existing = self.local_origin_ptrs.get(key)
        if existing is not None:
            return existing
        ty = self.handle_type(handle)
        backing = self.fresh("@local-backing")
        slot = self.fresh("@local-slot")
        value = self.fresh("@local-shadow-value")
        domain = self.fresh("@local-domain")
        root = self.fresh("@local-root")
        ptr = self.fresh("@local-ptr")
        self.state.backings[backing] = BackingRegion(backing, backing)
        self.state.slots[slot] = SlotClaim(self.type_name(ty), backing, ByteRange(0, 1))
        self.state.values[value] = ValuePackage(local=f"implicit-local:{display_type(ty)}")
        create_lifetime_domain(self.state, domain)
        try:
            apply_step(self.state, {
                "op": "initialize", "slot": slot, "value": value, "domain": domain,
                "result_root": root, "result_location_token": ptr,
            })
        except SemanticError as exc:
            raise LifecycleReject(self.code_for_semantic_error(exc.kind), f"{exc.kind}: {exc.message}", span) from exc
        ph = PtrHandle(ptr, PtrType(ty), True)
        self.local_origin_ptrs[key] = ph
        owner = self.handle_owners.get(key)
        if owner is not None:
            self.owner_local_ptrs.setdefault(owner, []).append(ph)
        return ph

    def end_owned_local_roots(self, owner: object, span: Span) -> None:
        for ptr in self.owner_local_ptrs.pop(owner, []):
            token = self.state.ptrs.get(ptr.name)
            if token is None or token.stale:
                continue
            root = self.state.roots.get(token.root_id)
            if root is None:
                continue
            domain = root.governing_domain
            if domain is None:
                continue
            result_slot = self.fresh("@local-ended-slot")
            try:
                apply_step(self.state, {
                    "op": "destroy", "root": root.root_id,
                    "ending_domain": domain, "result_slot": result_slot,
                })
                slot = self.state.slots.pop(result_slot, None)
                finalize_lifetime_domain(self.state, domain)
                if slot is not None:
                    self.state.backings.pop(slot.backing_region, None)
            except SemanticError as exc:
                raise LifecycleReject(self.code_for_semantic_error(exc.kind), f"{exc.kind}: {exc.message}", span) from exc
        # id(handle) is only a scope-local implementation key. Retaining it after
        # the owner ends permits Python object-id reuse to alias a later handle.
        stale = [key for key, bound_owner in self.handle_owners.items() if bound_owner is owner]
        for key in stale:
            self.handle_owners.pop(key, None)
            self.local_origin_ptrs.pop(key, None)

    def invoke_block(self, block: BlockHandle, args: list[Handle], span: Span) -> Handle:
        if len(args) != len(block.params):
            raise LifecycleReject("E_BLOCK_CALL", "block argument count mismatch", span)
        child = dict(block.captures)
        child.update(zip(block.params, args, strict=True))
        return self.exec_block(block.body, child)

    def eval_match(self, expr: TMatch, env: dict[str, Handle]) -> Handle:
        source = self.eval_expr(expr.value, env)
        parent_ref: RefHandle | None = source if isinstance(source, RefHandle) else None
        target = self.current_ref_target(source) if parent_ref is not None else source
        if not isinstance(target, SumHandle):
            raise LifecycleReject("E_MATCH_TYPE", "match target is not a concrete sum value in M3 lifecycle bridge", expr.span)
        arm = next((a for a in expr.arms if a.variant.name == target.variant), None)
        if arm is None:
            raise LifecycleReject("E_NONEXHAUSTIVE_MATCH", f"no arm for runtime variant {target.variant}", expr.span)
        child = dict(env)
        anchor = object()
        if arm.binding is not None:
            name, ty = arm.binding
            if target.payload is None:
                raise LifecycleReject("E_MATCH_PATTERN", "payload binding for payloadless variant", arm.span)
            if parent_ref is None:
                child[name] = target.payload
            else:
                child[name] = RefHandle(parent_ref.mode, False, target.payload, ty, parent_ref.stability_anchor, anchor)
        result = self.exec_block(arm.body, child)
        if self.handle_depends_on_scope(result, anchor):
            raise LifecycleReject("E_OCCURRENCE_ESCAPE", "payload ref escapes its match-arm occurrence scope", arm.span)
        return result

    def require_domain(self, handle: Handle, span: Span) -> DomainHandle:
        if not isinstance(handle, DomainHandle):
            raise LifecycleReject("E_LIFETIME_DOMAIN", "expected LifetimeDomain value", span)
        return handle

    def require_domain_ref(self, handle: Handle, *, exclusive: bool, span: Span) -> RefHandle:
        if not isinstance(handle, RefHandle) or handle.exclusive != exclusive or handle.mode != "read":
            kind = "exclusive ref<read,LifetimeDomain>" if exclusive else "ref<read,LifetimeDomain>"
            raise LifecycleReject("E_LIFETIME_AUTHORITY", f"expected {kind}", span)
        if not isinstance(handle.target, DomainHandle):
            raise LifecycleReject("E_LIFETIME_AUTHORITY", "domain authority does not refer to a LifetimeDomain", span)
        return handle

    def require_slot(self, handle: Handle, span: Span) -> SlotHandle:
        if not isinstance(handle, SlotHandle):
            raise LifecycleReject("E_LIFETIME_SLOT", "expected slot<T>", span)
        return handle

    def require_ptr(self, handle: Handle, span: Span) -> PtrHandle:
        if not isinstance(handle, PtrHandle):
            raise LifecycleReject("E_LIFETIME_PTR", "expected ptr<T>", span)
        try:
            resolve_live_ptr_root(self.state, handle.name)
        except SemanticError as exc:
            raise LifecycleReject(self.code_for_semantic_error(exc.kind), f"{exc.kind}: {exc.message}", span) from exc
        return handle

    def require_allocation(self, handle: Handle, span: Span) -> AllocationHandle:
        if not isinstance(handle, AllocationHandle) or handle.identity not in self.allocations:
            raise LifecycleReject("E_ALLOCATION_CONSUMED", "expected live Allocation authority", span)
        return handle

    def require_storage(self, handle: Handle, span: Span) -> StorageHandle:
        if not isinstance(handle, StorageHandle) or handle.name not in self.state.storages:
            raise LifecycleReject("E_STORAGE_CONSUMED", "expected live Storage claim", span)
        return handle

    def require_known_usize(self, handle: Handle, span: Span, what: str) -> int:
        if not isinstance(handle, UsizeHandle) or handle.values is None or len(handle.values) != 1:
            raise LifecycleReject("E_LAYOUT_CONST", f"{what} must be a compile-time-known usize in M6.1 prototype", span)
        return next(iter(handle.values))

    def require_layout(self, handle: Handle, span: Span) -> LayoutHandle:
        if not isinstance(handle, LayoutHandle):
            raise LifecycleReject("E_LAYOUT_ARGUMENT", "expected compiler Layout<T> witness", span)
        return handle

    def backing_alignment(self, backing: str) -> int:
        for _aid, (b, _size, align, _demat) in self.allocations.items():
            if b == backing:
                return align
        return 1

    def sizeof_type(self, ty: Type, span: Span) -> int:
        from .typesys import U32, USIZE, BOOL
        if ty == U32: return 4
        if ty == USIZE: return 8
        if ty == BOOL: return 1
        if isinstance(ty, ArrayType): return self.sizeof_type(ty.inner, span) * ty.length
        raise LifecycleReject("E_OPAQUE_LAYOUT", f"M6.1 raw slot conversion has no fixed layout for {display_type(ty)}", span)

    def alignof_type(self, ty: Type, span: Span) -> int:
        from .typesys import U32, USIZE, BOOL
        if ty == U32: return 4
        if ty == USIZE: return 8
        if ty == BOOL: return 1
        if isinstance(ty, ArrayType): return self.alignof_type(ty.inner, span)
        raise LifecycleReject("E_OPAQUE_LAYOUT", f"M6.1 raw slot conversion has no fixed alignment for {display_type(ty)}", span)

    def require_value(self, handle: Handle, span: Span) -> ValueHandle:
        if not isinstance(handle, ValueHandle):
            raise LifecycleReject("E_LIFETIME_VALUE", "expected ordinary semantic value", span)
        if handle.name not in self.state.values:
            raise LifecycleReject("E_VALUE_CONSUMED", f"value {handle.name} was already consumed", span)
        return handle

    def check_exit_resources(self, result: Handle, span: Span) -> None:
        returned_slots = {h.name for h in self.walk_handles(result) if isinstance(h, SlotHandle)}
        returned_domains = {h.identity for h in self.walk_handles(result) if isinstance(h, DomainHandle)}
        leaked_slots = set(self.state.slots) - returned_slots
        if leaked_slots:
            raise LifecycleReject(
                "E_SLOT_NOT_CONSUMED",
                f"non-Discardable slot value(s) not returned/consumed: {', '.join(sorted(leaked_slots))}",
                span,
            )
        returned_allocs = {h.identity for h in self.walk_handles(result) if isinstance(h, AllocationHandle)}
        returned_storages = {h.name for h in self.walk_handles(result) if isinstance(h, StorageHandle)}
        leaked_allocs = set(self.allocations) - returned_allocs
        if leaked_allocs:
            raise LifecycleReject("E_ALLOCATION_NOT_CONSUMED", "Allocation authority not deallocated/returned: " + ", ".join(sorted(leaked_allocs)), span)
        leaked_storages = set(self.state.storages) - returned_storages
        if leaked_storages:
            raise LifecycleReject("E_STORAGE_NOT_CONSUMED", "Storage claim not consumed/returned: " + ", ".join(sorted(leaked_storages)), span)
        leaked_domains = self.state.live_domains - returned_domains
        if leaked_domains:
            raise LifecycleReject(
                "E_DOMAIN_NOT_FINALIZED",
                f"LifetimeDomain value(s) remain live: {', '.join(sorted(leaked_domains))}",
                span,
            )

    def flatten_handle(self, handle: Handle) -> list[Handle]:
        if isinstance(handle, TupleHandle):
            out: list[Handle] = []
            for child in handle.items:
                out.extend(self.flatten_handle(child))
            return out
        if isinstance(handle, StructHandle):
            return [child for _, child in handle.fields]
        return [handle]

    def walk_handles(self, handle: Handle):
        yield handle
        if isinstance(handle, TupleHandle):
            for item in handle.items:
                yield from self.walk_handles(item)
        elif isinstance(handle, SumHandle) and handle.payload is not None:
            yield from self.walk_handles(handle.payload)
        elif isinstance(handle, StructHandle):
            for _, item in handle.fields:
                yield from self.walk_handles(item)
        elif isinstance(handle, ArrayHandle):
            for item in handle.items:
                yield from self.walk_handles(item)
        elif isinstance(handle, ChoiceHandle):
            for item in handle.options:
                yield from self.walk_handles(item)

    def handle_depends_on(self, tree: Handle, anchor: RefHandle) -> bool:
        for item in self.walk_handles(tree):
            if item is anchor:
                return True
            if isinstance(item, RefHandle) and (item.stability_anchor is anchor or item.scope_anchor is anchor):
                return True
            if isinstance(item, SpanHandle) and item.access_anchor is anchor:
                return True
        return False

    def handle_depends_on_scope(self, tree: Handle, anchor: object) -> bool:
        return any(isinstance(item, RefHandle) and item.scope_anchor is anchor for item in self.walk_handles(tree))

    def contains_handle(self, tree: Handle, needle: Handle) -> bool:
        return any(item is needle for item in self.walk_handles(tree))

    def handle_type(self, handle: Handle) -> Type:
        if isinstance(handle, (ValueHandle, SlotHandle, LayoutHandle, PtrHandle, TupleHandle, SumHandle, StructHandle, ArrayHandle, SpanHandle, BlockHandle, UsizeHandle, ChoiceHandle)):
            return handle.type
        if isinstance(handle, DomainHandle):
            return LIFETIME_DOMAIN
        if isinstance(handle, AllocationHandle):
            return ALLOCATION
        if isinstance(handle, StorageHandle):
            return STORAGE
        if isinstance(handle, RefHandle):
            return handle.type
        if isinstance(handle, AccessModeHandle):
            from .typesys import AccessModeType
            return AccessModeType(handle.mode)
        if isinstance(handle, UnitHandle):
            from .typesys import UNIT
            return UNIT
        raise AssertionError(handle)

    def type_name(self, ty: Type) -> str:
        return display_type(ty)

    @staticmethod
    def code_for_semantic_error(kind: str) -> str:
        mapping = {
            "lifetime_domain_mismatch": "E_LIFETIME_DOMAIN_MISMATCH",
            "domain_still_governs_live_root": "E_DOMAIN_STILL_GOVERNS_ROOT",
            "domain_not_live": "E_DOMAIN_NOT_LIVE",
            "stale_ptr": "E_STALE_PTR",
            "missing_slot": "E_SLOT_CONSUMED",
            "missing_root": "E_STALE_PTR",
        }
        return mapping.get(kind, "E_LIFETIME_SEMANTIC")


def run_lifecycle_detailed(program: TProgram, entry: str = "main") -> LifecycleOutcome:
    return LifecycleRunner(program).run(entry)
