from __future__ import annotations

from dataclasses import dataclass, field
import random


class StorageLayoutReject(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message)
        self.code = code
        self.message = message


def _is_pow2(value: int) -> bool:
    return value > 0 and value & (value - 1) == 0


@dataclass(frozen=True, slots=True)
class LayoutFacts:
    size: int
    align: int
    stride: int

    @classmethod
    def make(cls, size: int, align: int) -> "LayoutFacts":
        if size < 0 or not _is_pow2(align):
            raise ValueError("invalid layout")
        stride = 0 if size == 0 else ((size + align - 1) // align) * align
        return cls(size, align, stride)


@dataclass(frozen=True, slots=True)
class RawAllocation:
    size: int
    align: int

    def materialize(self, start: int, layout: LayoutFacts) -> tuple[int, int]:
        if layout.size == 0:
            raise StorageLayoutReject(
                "E_ZST_DYNAMIC_STORAGE",
                "byte-range Storage has no logical multiplicity for zero-sized object lifetimes",
            )
        end = start + layout.size
        if not (0 <= start <= end <= self.size):
            raise StorageLayoutReject("E_SLOT_SIZE", "typed slot extent is outside allocation")
        if self.align < layout.align or start % layout.align != 0:
            raise StorageLayoutReject("E_SLOT_ALIGNMENT", "typed slot start does not satisfy target alignment")
        return start, end


def naive_zero_extent_claims_do_not_conflict(count: int) -> bool:
    """Show why byte non-overlap alone cannot encode ZST multiplicity.

    Empty half-open ranges never overlap, so any number of logical claims at the
    same byte position are indistinguishable to a byte-range-only occupancy rule.
    This is evidence for either a separate logical-slot authority axis or a v0
    restriction, not a proposed implementation primitive.
    """
    ranges = [(0, 0) for _ in range(count)]
    for i, a in enumerate(ranges):
        for b in ranges[i + 1 :]:
            if a[0] < b[1] and b[0] < a[1]:
                return False
    return True


@dataclass(slots=True)
class LogicalZstArena:
    """Comparison model for the mechanism full ZST support would require."""
    capacity: int
    _free: set[int] = field(init=False, repr=False)
    _live: set[int] = field(init=False, repr=False)

    def __post_init__(self) -> None:
        if self.capacity < 0:
            raise ValueError("negative capacity")
        self._free = set(range(self.capacity))
        self._live = set()

    def initialize(self, index: int) -> None:
        if index not in self._free:
            raise StorageLayoutReject("E_ZST_LOGICAL_OCCUPANCY", "logical ZST slot is not vacant")
        self._free.remove(index)
        self._live.add(index)

    def destroy(self, index: int) -> None:
        if index not in self._live:
            raise StorageLayoutReject("E_ZST_LOGICAL_OCCUPANCY", "logical ZST slot is not live")
        self._live.remove(index)
        self._free.add(index)

    @property
    def conserved(self) -> bool:
        return len(self._free | self._live) == self.capacity and not (self._free & self._live)


def run_storage_layout_pressure(*, seed: int = 20261004, cases: int = 20_000) -> dict[str, object]:
    rng = random.Random(seed)
    aligned_ok = 0
    underaligned_reject = 0
    offset_reject = 0
    zst_reject = 0
    logical_zst_model_ok = 0

    alignments = (16, 32, 64, 128, 256, 512, 1024, 2048, 4096)
    for i in range(cases):
        align = rng.choice(alignments)
        units = rng.randint(1, 4)
        size = align * units
        layout = LayoutFacts.make(size, align)

        alloc = RawAllocation(size * 4, align)
        start = align * rng.randint(0, 3)
        alloc.materialize(start, layout)
        aligned_ok += 1

        try:
            RawAllocation(size * 2, max(1, align // 2)).materialize(0, layout)
        except StorageLayoutReject as exc:
            assert exc.code == "E_SLOT_ALIGNMENT"
            underaligned_reject += 1
        else:
            raise AssertionError("under-aligned backing unexpectedly accepted")

        bad_start = align // 2
        try:
            RawAllocation(size * 3, align).materialize(bad_start, layout)
        except StorageLayoutReject as exc:
            assert exc.code == "E_SLOT_ALIGNMENT"
            offset_reject += 1
        else:
            raise AssertionError("misaligned subrange unexpectedly accepted")

        try:
            RawAllocation(align, align).materialize(0, LayoutFacts.make(0, align))
        except StorageLayoutReject as exc:
            assert exc.code == "E_ZST_DYNAMIC_STORAGE"
            zst_reject += 1
        else:
            raise AssertionError("zero-sized dynamic slot unexpectedly accepted")

        arena = LogicalZstArena(rng.randint(1, 8))
        order = list(range(arena.capacity))
        rng.shuffle(order)
        for idx in order:
            arena.initialize(idx)
        rng.shuffle(order)
        for idx in order:
            arena.destroy(idx)
        if arena.conserved:
            logical_zst_model_ok += 1

    return {
        "seed": seed,
        "cases": cases,
        "overaligned_materializations": aligned_ok,
        "underaligned_backing_rejections": underaligned_reject,
        "misaligned_subrange_rejections": offset_reject,
        "zst_dynamic_storage_rejections": zst_reject,
        "logical_zst_comparison_model_conserved": logical_zst_model_ok,
        "naive_zero_extent_claims_nonconflicting": naive_zero_extent_claims_do_not_conflict(32),
        "max_alignment_tested": max(alignments),
        "runtime_alignment_tag_required": False,
        "zst_value_layout_query_allowed": True,
        "zst_raw_storage_bridge_allowed": False,
        "full_zst_support_would_need_logical_multiplicity_axis": True,
    }
