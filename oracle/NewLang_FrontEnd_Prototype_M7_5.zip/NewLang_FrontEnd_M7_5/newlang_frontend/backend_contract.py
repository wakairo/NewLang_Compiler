from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Literal


CaptureKind = Literal["unknown", "none", "address", "read_provenance", "provenance"]
StorageKind = Literal["stack_alloca", "heap_or_external", "subobject_or_slot"]


@dataclass(frozen=True, slots=True)
class PointerLoweringContract:
    """Conservative LLVM lowering facts for one NewLang pointer-like capability.

    The contract deliberately separates source capability spelling from LLVM
    alias promises.  In particular, `ref<write,T>` is *not* an exclusivity
    claim and `exclusive ref<...>` is not automatically an LLVM noalias claim.
    Backend-only noalias requires an explicit checker fact that all relevant
    accesses to the byte range for the IR dynamic extent are based on this
    pointer.
    """

    readonly: bool = False
    writeonly: bool = False
    noalias: bool = False
    captures: CaptureKind = "unknown"
    dereferenceable_bytes: int | None = None
    emit_nofree: bool = False
    emit_invariant_scope: bool = False
    reason: str = ""

    def as_dict(self) -> dict[str, object]:
        return asdict(self)


def ref_contract(
    mode: Literal["read", "write"],
    *,
    exclusive_spelling: bool = False,
    proven_access_exclusive: bool = False,
    capture: CaptureKind = "unknown",
    positive_extent: int | None = None,
    target_null_address_policy_known: bool = False,
) -> PointerLoweringContract:
    """Return the baseline v0 LLVM contract for a NewLang ref.

    `positive_extent` is intentionally not enough by itself to emit
    dereferenceable(N): in LLVM addrspace(0) that fact also interacts with the
    null-address policy.  M7.3 keeps it off until target lowering owns that
    policy explicitly.
    """

    if mode == "read":
        readonly = True
    elif mode == "write":
        readonly = False
    else:
        raise ValueError(mode)

    # ref<write> can be weakened/read, so writeonly would be too strong.
    writeonly = False

    # Source `exclusive` is an authority/resource property.  LLVM noalias is an
    # access-set promise.  Do not conflate them.  A later checked-MIR fact may
    # establish access exclusivity for the exact range/dynamic extent.
    noalias = bool(proven_access_exclusive)

    # Nonescaping ref syntax does not imply LLVM nocapture: NewLang can derive a
    # persistent ptr locator from a ref and return/store that locator.
    captures = capture

    deref = None
    if positive_extent is not None and positive_extent <= 0:
        raise ValueError("dereferenceable extent must be positive")
    if positive_extent is not None and target_null_address_policy_known:
        # This says only that a target-aware lowering phase may choose to emit
        # it.  The prototype leaves the actual ABI/null policy outside M7.3.
        deref = positive_extent

    return PointerLoweringContract(
        readonly=readonly,
        writeonly=writeonly,
        noalias=noalias,
        captures=captures,
        dereferenceable_bytes=deref,
        emit_nofree=False,
        emit_invariant_scope=False,
        reason=(
            "read ref may lower readonly; noalias is emitted only from an explicit "
            "backend access-exclusivity proof, never from write/exclusive spelling alone"
        ),
    )


def lifetime_intrinsic_contract(storage_kind: StorageKind, *, exact_storage_lifetime: bool) -> dict[str, object]:
    """Whether NewLang lifetime events may lower to llvm.lifetime.*.

    Current LLVM LangRef restricts llvm.lifetime.start/end operands to alloca or
    structured.alloca results.  NewLang typed-object lifetime transitions inside
    heap/external Storage therefore do not map to those intrinsics.
    """

    emit = storage_kind == "stack_alloca" and exact_storage_lifetime
    return {
        "storage_kind": storage_kind,
        "exact_storage_lifetime": exact_storage_lifetime,
        "emit_llvm_lifetime": emit,
        "semantic_object_lifetime_maps_directly": False,
        "reason": (
            "LLVM lifetime intrinsics describe compiler stack allocation lifetime; "
            "they are not the general representation of NewLang typed object incarnation"
        ),
    }


def alias_metadata_contract(*, proven_disjoint_access_sets: bool) -> dict[str, object]:
    return {
        "emit_alias_scope_or_noalias_metadata": bool(proven_disjoint_access_sets),
        "source_ref_kind_is_sufficient": False,
        "reason": (
            "LLVM alias.scope/noalias metadata is UB-producing if the access sets alias; "
            "only checked-MIR disjoint-access facts may justify it"
        ),
    }


def baseline_contract_matrix() -> dict[str, object]:
    return {
        "ref_read": ref_contract("read").as_dict(),
        "ref_write": ref_contract("write").as_dict(),
        "exclusive_ref_read_without_access_proof": ref_contract("read", exclusive_spelling=True).as_dict(),
        "exclusive_ref_write_without_access_proof": ref_contract("write", exclusive_spelling=True).as_dict(),
        "backend_proven_exclusive_write": ref_contract("write", proven_access_exclusive=True).as_dict(),
        "returned_locator_from_ref": ref_contract("read", capture="provenance").as_dict(),
        "stack_storage_lifetime": lifetime_intrinsic_contract("stack_alloca", exact_storage_lifetime=True),
        "heap_typed_lifetime": lifetime_intrinsic_contract("heap_or_external", exact_storage_lifetime=True),
        "slot_subobject_lifetime": lifetime_intrinsic_contract("subobject_or_slot", exact_storage_lifetime=True),
        "ordinary_ref_alias_metadata": alias_metadata_contract(proven_disjoint_access_sets=False),
        "checked_disjoint_access_metadata": alias_metadata_contract(proven_disjoint_access_sets=True),
    }
