"""NewLang Front-End Prototype M5.1."""

from .driver import CheckResult, check_source

__all__ = ["CheckResult", "check_source"]
