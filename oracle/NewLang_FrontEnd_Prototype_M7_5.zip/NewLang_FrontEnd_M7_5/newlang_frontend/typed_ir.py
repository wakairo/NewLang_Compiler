from __future__ import annotations

from dataclasses import dataclass
from typing import TypeAlias

from .source import Span
from .symbols import FieldSymbol, FunctionSymbol, SumVariantSymbol
from .typesys import Type


@dataclass(frozen=True, slots=True)
class TName:
    name: str
    type: Type
    span: Span


@dataclass(frozen=True, slots=True)
class TInt:
    value: int
    type: Type
    span: Span


@dataclass(frozen=True, slots=True)
class TAccessMode:
    mode: str
    type: Type
    span: Span


@dataclass(frozen=True, slots=True)
class TUnit:
    type: Type
    span: Span


@dataclass(frozen=True, slots=True)
class TCall:
    function: FunctionSymbol
    args: tuple["TExpr", ...]
    receiver_syntax: bool
    type: Type
    span: Span
    weakenings: tuple[int, ...] = ()




@dataclass(frozen=True, slots=True)
class DependentRequirement:
    name: str
    argument_types: tuple[Type, ...]
    result_type: Type
    receiver_syntax: bool
    span: Span


@dataclass(frozen=True, slots=True)
class TDependentCall:
    name: str
    args: tuple["TExpr", ...]
    receiver_syntax: bool
    type: Type
    span: Span

@dataclass(frozen=True, slots=True)
class TBlockInvoke:
    callee: "TExpr"
    args: tuple["TExpr", ...]
    type: Type
    span: Span


@dataclass(frozen=True, slots=True)
class TBuiltinCall:
    name: str
    args: tuple["TExpr", ...]
    type: Type
    span: Span


@dataclass(frozen=True, slots=True)
class TField:
    base: "TExpr"
    field: FieldSymbol
    type: Type
    span: Span


@dataclass(frozen=True, slots=True)
class TIndex:
    base: "TExpr"
    index: "TExpr"
    type: Type
    span: Span


@dataclass(frozen=True, slots=True)
class TStructLiteral:
    type: Type
    fields: tuple[tuple[FieldSymbol, "TExpr"], ...]
    span: Span


@dataclass(frozen=True, slots=True)
class TSumConstruct:
    sum_name: str
    variant: SumVariantSymbol
    payload: "TExpr | None"
    type: Type
    span: Span


@dataclass(frozen=True, slots=True)
class TLoan:
    mode: str
    exclusive: bool
    source: "TExpr"
    binding: str
    body: "TBlock"
    type: Type
    span: Span


@dataclass(frozen=True, slots=True)
class TBlockLiteral:
    params: tuple[tuple[str, Type], ...]
    body: "TBlock"
    type: Type
    span: Span


@dataclass(frozen=True, slots=True)
class TLoopParam:
    name: str
    type: Type
    initial: "TExpr"
    span: Span


@dataclass(frozen=True, slots=True)
class TLoop:
    params: tuple[TLoopParam, ...]
    result_type: Type
    body: "TBlock"
    type: Type
    span: Span


@dataclass(frozen=True, slots=True)
class TContinue:
    args: tuple["TExpr", ...]
    type: Type
    span: Span


@dataclass(frozen=True, slots=True)
class TBreak:
    value: "TExpr | None"
    type: Type
    span: Span


@dataclass(frozen=True, slots=True)
class TMatchArm:
    variant: SumVariantSymbol
    binding: tuple[str, Type] | None
    discard: bool
    body: "TBlock"
    span: Span


@dataclass(frozen=True, slots=True)
class TMatch:
    value: "TExpr"
    arms: tuple[TMatchArm, ...]
    type: Type
    span: Span


TExpr: TypeAlias = (
    TName | TInt | TAccessMode | TUnit | TCall | TDependentCall | TBlockInvoke | TBuiltinCall |
    TField | TIndex | TStructLiteral | TSumConstruct | TLoan | TBlockLiteral | TMatch | TLoop | TContinue | TBreak
)


@dataclass(frozen=True, slots=True)
class TLet:
    bindings: tuple[tuple[str, Type], ...]
    value: TExpr
    span: Span


@dataclass(frozen=True, slots=True)
class TExprStmt:
    expr: TExpr
    span: Span


TStmt: TypeAlias = TLet | TExprStmt


@dataclass(frozen=True, slots=True)
class TBlock:
    statements: tuple[TStmt, ...]
    tail: TExpr | None
    type: Type
    span: Span


@dataclass(frozen=True, slots=True)
class TFunction:
    symbol: FunctionSymbol
    body: TBlock
    requirements: tuple[DependentRequirement, ...] = ()


@dataclass(frozen=True, slots=True)
class TLayoutInfo:
    type: Type
    size: int
    align: int
    stride: int


@dataclass(frozen=True, slots=True)
class TProgram:
    functions: tuple[TFunction, ...]
    generic_requirements: tuple[tuple[str, tuple[DependentRequirement, ...]], ...] = ()
    layouts: tuple[TLayoutInfo, ...] = ()
