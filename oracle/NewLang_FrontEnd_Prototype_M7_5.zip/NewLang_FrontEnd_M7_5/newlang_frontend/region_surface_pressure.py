from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Literal

from .authority_region_pressure import ClaimReceipt, RegionReject, SealedRegion


class SurfaceReject(RegionReject):
    pass


@dataclass(slots=True)
class LinearClaimToken:
    """M6.3 source-surface stand-in for a non-Copy/non-Discardable claim token.

    The token does not create authority: it wraps one receipt already extracted
    from a rooted SealedRegion.  A successful state transition consumes this
    wrapper.  The underlying region still validates root, epoch, and claim id.
    """

    receipt: ClaimReceipt
    consumed: bool = False

    def require_live_token(self) -> ClaimReceipt:
        if self.consumed:
            raise SurfaceReject("E_M63_CLAIM_TOKEN_CONSUMED", "linear claim token was already consumed")
        return self.receipt

    def consume_after_success(self) -> None:
        if self.consumed:
            raise SurfaceReject("E_M63_CLAIM_TOKEN_CONSUMED", "linear claim token was already consumed")
        self.consumed = True


class ReceiptSurface:
    """Candidate A: explicit linear receipt/token API.

    This is the semantic baseline candidate.  All authority comes from the
    region ledger and is threaded through non-duplicating tokens.
    """

    def __init__(self, region: SealedRegion):
        self.region = region

    def vacant(self, index: int, type_name: str) -> LinearClaimToken:
        return LinearClaimToken(self.region.claim_vacant(index, type_name))

    def live(self, index: int, *, expected_type: str | None = None) -> LinearClaimToken:
        return LinearClaimToken(self.region.claim_live(index, expected_type=expected_type))

    def return_vacant(self, token: LinearClaimToken) -> None:
        receipt = token.require_live_token()
        self.region.return_vacant(receipt)
        token.consume_after_success()

    def return_live(self, token: LinearClaimToken) -> None:
        receipt = token.require_live_token()
        self.region.return_live(receipt)
        token.consume_after_success()

    def initialize(self, token: LinearClaimToken, value: str, *, type_name: str | None = None) -> str:
        receipt = token.require_live_token()
        root = self.region.initialize_vacant(receipt, value, type_name=type_name)
        token.consume_after_success()
        return root

    def take(self, token: LinearClaimToken) -> tuple[str, LinearClaimToken]:
        receipt = token.require_live_token()
        value, vacant = self.region.take_live(receipt)
        token.consume_after_success()
        return value, LinearClaimToken(vacant)


@dataclass(slots=True)
class ScopedVacantClaim:
    """Closure sugar over ReceiptSurface; it never owns independent authority."""

    surface: ReceiptSurface
    token: LinearClaimToken
    changed: bool = False

    def initialize(self, value: str, *, type_name: str | None = None) -> None:
        self.surface.initialize(self.token, value, type_name=type_name)
        self.changed = True

    def close(self) -> None:
        if not self.token.consumed:
            self.surface.return_vacant(self.token)


@dataclass(slots=True)
class ScopedLiveClaim:
    surface: ReceiptSurface
    token: LinearClaimToken
    taken_value: str | None = None
    vacant_after_take: LinearClaimToken | None = None

    def take(self) -> str:
        if self.taken_value is not None:
            raise SurfaceReject("E_M63_SCOPED_CLAIM_REUSE", "live scoped claim was already taken")
        value, vacant = self.surface.take(self.token)
        self.taken_value = value
        self.vacant_after_take = vacant
        return value

    def close(self) -> None:
        if self.vacant_after_take is not None:
            self.surface.return_vacant(self.vacant_after_take)
        elif not self.token.consumed:
            self.surface.return_live(self.token)


class ClosureSurface:
    """Candidate B: nonescaping callback as sugar over a linear receipt.

    The ordinary NewLang block remains 0..N in type semantics.  Soundness does
    not come from pretending the callback is exactly-once.  Instead the helper
    owns one linear token, invokes the callback according to its implementation,
    and must return/consume that token on every normal path.  This prototype
    invokes once; source-level tests separately show that 0-call paths can close
    the token and 2-call paths cannot reuse it.
    """

    def __init__(self, region: SealedRegion):
        self.receipts = ReceiptSurface(region)

    def with_vacant(
        self,
        index: int,
        type_name: str,
        callback: Callable[[ScopedVacantClaim], object],
    ) -> object:
        scope = ScopedVacantClaim(self.receipts, self.receipts.vacant(index, type_name))
        try:
            return callback(scope)
        finally:
            scope.close()

    def with_live(
        self,
        index: int,
        callback: Callable[[ScopedLiveClaim], object],
        *,
        expected_type: str | None = None,
    ) -> object:
        scope = ScopedLiveClaim(self.receipts, self.receipts.live(index, expected_type=expected_type))
        try:
            return callback(scope)
        finally:
            scope.close()


class PrivilegedHookSurface:
    """Candidate C: specialized trusted hook with no first-class claim token.

    This can implement safe high-level operations, but each operation is a new
    trusted boundary.  It is therefore useful as a library/backend hook, not as
    a replacement for the authority model itself.
    """

    def __init__(self, region: SealedRegion):
        self.receipts = ReceiptSurface(region)
        self.trusted_operations = 0

    def install(self, index: int, type_name: str, value: str) -> None:
        self.trusted_operations += 1
        token = self.receipts.vacant(index, type_name)
        self.receipts.initialize(token, value)

    def remove(self, index: int, *, expected_type: str | None = None) -> str:
        self.trusted_operations += 1
        token = self.receipts.live(index, expected_type=expected_type)
        value, vacant = self.receipts.take(token)
        self.receipts.return_vacant(vacant)
        return value


@dataclass(frozen=True, slots=True)
class SurfaceAssessment:
    candidate: Literal["receipt", "closure", "hook"]
    conserves_authority: bool
    first_class_claim: bool
    needs_new_callable_semantics: bool
    trusted_operation_growth: Literal["constant", "per-operation"]
    verdict: str


def assess_surfaces() -> tuple[SurfaceAssessment, ...]:
    return (
        SurfaceAssessment(
            "receipt",
            True,
            True,
            False,
            "constant",
            "best semantic base; spelling remains provisional",
        ),
        SurfaceAssessment(
            "closure",
            True,
            False,
            False,
            "constant",
            "viable sugar when implemented by linear token threading; 0..N block semantics need not change",
        ),
        SurfaceAssessment(
            "hook",
            True,
            False,
            False,
            "per-operation",
            "useful privileged implementation hook, but not a general authority mechanism",
        ),
    )


def run_surface_experiment() -> dict[str, object]:
    from .authority_region_pressure import ResponsibilityOracle

    result: dict[str, object] = {
        "assessments": [a.__dict__ if hasattr(a, "__dict__") else {
            "candidate": a.candidate,
            "conserves_authority": a.conserves_authority,
            "first_class_claim": a.first_class_claim,
            "needs_new_callable_semantics": a.needs_new_callable_semantics,
            "trusted_operation_growth": a.trusted_operation_growth,
            "verdict": a.verdict,
        } for a in assess_surfaces()],
    }

    # Receipt candidate: double use is rejected without minting replacement authority.
    oracle = ResponsibilityOracle()
    oracle.create_external("r")
    region = SealedRegion(1, elem_size=8, elem_align=8, oracle=oracle, name="surface-receipt")
    region.register_type("Token", size=8, align=8)
    api = ReceiptSurface(region)
    vacant = api.vacant(0, "Token")
    api.initialize(vacant, "r")
    double_use = False
    try:
        api.return_vacant(vacant)
    except RegionReject:
        double_use = True
    live = api.live(0, expected_type="Token")
    value, empty = api.take(live)
    api.return_vacant(empty)
    assert value == "r"
    assert oracle.owner("r") == "external"
    region.unseal()
    result["receipt"] = {"double_use_rejected": double_use, "authority_conserved": True}

    # Closure candidate: unused scoped claim is returned automatically; initialized
    # responsibility becomes hidden in the region, then can be taken in another scope.
    oracle = ResponsibilityOracle()
    oracle.create_external("c")
    region = SealedRegion(1, elem_size=8, elem_align=8, oracle=oracle, name="surface-closure")
    region.register_type("Token", size=8, align=8)
    closure = ClosureSurface(region)
    closure.with_vacant(0, "Token", lambda claim: None)
    no_call_like_path_closed = region.responsibility(0).kind == "vacant" and not region.open_claims
    closure.with_vacant(0, "Token", lambda claim: claim.initialize("c"))
    got = closure.with_live(0, lambda claim: claim.take(), expected_type="Token")
    assert got == "c"
    assert oracle.owner("c") == "external"
    region.unseal()
    result["closure"] = {
        "unused_scope_closed": no_call_like_path_closed,
        "lifecycle_transition_closed": True,
        "new_exactly_once_callable_kind_required": False,
    }

    # Hook candidate works, but the trusted surface grows with each distinct operation.
    oracle = ResponsibilityOracle()
    oracle.create_external("h")
    region = SealedRegion(1, elem_size=8, elem_align=8, oracle=oracle, name="surface-hook")
    region.register_type("Token", size=8, align=8)
    hook = PrivilegedHookSurface(region)
    hook.install(0, "Token", "h")
    got = hook.remove(0, expected_type="Token")
    assert got == "h"
    assert oracle.owner("h") == "external"
    region.unseal()
    result["hook"] = {
        "authority_conserved": True,
        "trusted_operations": hook.trusted_operations,
        "general_claim_protocol_exposed": False,
    }
    return result
