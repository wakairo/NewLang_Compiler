from __future__ import annotations

import random
import struct
from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ScalarSpec:
    fmt: str
    size: int
    align: int


SCALARS: dict[str, ScalarSpec] = {
    "i32": ScalarSpec("<i", 4, 4),
    "i64": ScalarSpec("<q", 8, 8),
    "f64": ScalarSpec("<d", 8, 8),
}


@dataclass(frozen=True, slots=True)
class Field:
    name: str
    kind: str


@dataclass(frozen=True, slots=True)
class Layout:
    offsets: dict[str, int]
    size: int
    align: int


def _align_up(value: int, align: int) -> int:
    return (value + align - 1) // align * align


def layout_for(fields: list[Field]) -> Layout:
    offset = 0
    max_align = 1
    offsets: dict[str, int] = {}
    for field in fields:
        spec = SCALARS[field.kind]
        offset = _align_up(offset, spec.align)
        offsets[field.name] = offset
        offset += spec.size
        max_align = max(max_align, spec.align)
    return Layout(offsets=offsets, size=_align_up(offset, max_align), align=max_align)


def encode(fields: list[Field], layout: Layout, values: dict[str, int | float], *, fill: int = 0xA5) -> bytes:
    blob = bytearray([fill] * layout.size)
    for field in fields:
        spec = SCALARS[field.kind]
        struct.pack_into(spec.fmt, blob, layout.offsets[field.name], values[field.name])
    return bytes(blob)


def decode(fields: list[Field], layout: Layout, blob: bytes) -> dict[str, int | float]:
    out: dict[str, int | float] = {}
    for field in fields:
        spec = SCALARS[field.kind]
        out[field.name] = struct.unpack_from(spec.fmt, blob, layout.offsets[field.name])[0]
    return out


def marshal(
    fields: list[Field], src_layout: Layout, src_blob: bytes, dst_layout: Layout, *, fill: int = 0x5A
) -> bytes:
    values = decode(fields, src_layout, src_blob)
    return encode(fields, dst_layout, values, fill=fill)


def run_pressure(seed: int = 20261004, cases: int = 20_000) -> dict[str, object]:
    rng = random.Random(seed)
    roundtrip_mismatch = 0
    direct_bitcopy_not_equivalent = 0
    reordered = 0
    padding_cases = 0

    for case in range(cases):
        count = rng.randint(2, 6)
        fields = [Field(f"f{i}", rng.choice(tuple(SCALARS))) for i in range(count)]
        native_fields = list(fields)
        rng.shuffle(native_fields)
        if [f.name for f in native_fields] != [f.name for f in fields]:
            reordered += 1

        c_layout = layout_for(fields)
        native_layout = layout_for(native_fields)
        if c_layout.size > sum(SCALARS[f.kind].size for f in fields) or native_layout.size > sum(
            SCALARS[f.kind].size for f in fields
        ):
            padding_cases += 1

        values: dict[str, int | float] = {}
        for field in fields:
            if field.kind == "i32":
                values[field.name] = rng.randint(-1_000_000, 1_000_000)
            elif field.kind == "i64":
                values[field.name] = rng.randint(-10**12, 10**12)
            else:
                values[field.name] = rng.randint(-1_000_000, 1_000_000) / 16.0

        native_blob = encode(fields, native_layout, values)
        c_blob = marshal(fields, native_layout, native_blob, c_layout)
        returned_native = marshal(fields, c_layout, c_blob, native_layout)
        if decode(fields, native_layout, returned_native) != decode(fields, native_layout, native_blob):
            roundtrip_mismatch += 1

        # A raw native->C bitcopy is considered invalid whenever layout/size differs
        # or decoding the copied bytes under C offsets changes any semantic field.
        direct_bad = native_layout.size != c_layout.size
        if not direct_bad:
            try:
                direct_bad = decode(fields, c_layout, native_blob) != values
            except (struct.error, ValueError):
                direct_bad = True
        if direct_bad:
            direct_bitcopy_not_equivalent += 1

    return {
        "seed": seed,
        "cases": cases,
        "roundtrip_mismatch": roundtrip_mismatch,
        "reordered_native_layout_cases": reordered,
        "padding_cases": padding_cases,
        "direct_native_bitcopy_not_equivalent": direct_bitcopy_not_equivalent,
        "explicit_field_marshalling_preserved_all_values": roundtrip_mismatch == 0,
    }
