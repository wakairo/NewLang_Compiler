from __future__ import annotations

from dataclasses import dataclass
from typing import TypeAlias


@dataclass(frozen=True, slots=True)
class FieldProjection:
    name: str


@dataclass(frozen=True, slots=True)
class IndexProjection:
    key: str


Projection: TypeAlias = FieldProjection | IndexProjection


@dataclass(frozen=True, slots=True)
class Place:
    root: str
    projections: tuple[Projection, ...] = ()

    def field(self, name: str) -> "Place":
        return Place(self.root, self.projections + (FieldProjection(name),))

    def index(self, key: str) -> "Place":
        return Place(self.root, self.projections + (IndexProjection(key),))

    def render(self) -> str:
        parts = [self.root]
        for projection in self.projections:
            if isinstance(projection, FieldProjection):
                parts.append(projection.name)
            else:
                parts.append(f"$index:{projection.key}")
        return ".".join(parts)
