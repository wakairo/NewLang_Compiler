from __future__ import annotations

from dataclasses import dataclass
from typing import TypeAlias


@dataclass(frozen=True, slots=True)
class BuiltinType:
    name: str


@dataclass(frozen=True, slots=True)
class IntLiteralType:
    pass


@dataclass(frozen=True, slots=True)
class NeverType:
    pass


@dataclass(frozen=True, slots=True)
class NominalType:
    type_id: int
    name: str
    args: tuple["Type", ...] = ()


@dataclass(frozen=True, slots=True)
class SumType:
    type_id: int
    name: str
    args: tuple["Type", ...] = ()


@dataclass(frozen=True, slots=True)
class TypeParamType:
    function_id: int
    index: int
    name: str


@dataclass(frozen=True, slots=True)
class RefType:
    mode: str
    inner: "Type"


@dataclass(frozen=True, slots=True)
class ExclusiveRefType:
    mode: str
    inner: "Type"


@dataclass(frozen=True, slots=True)
class PtrType:
    inner: "Type"


@dataclass(frozen=True, slots=True)
class SlotType:
    inner: "Type"


@dataclass(frozen=True, slots=True)
class LayoutType:
    """Compiler-provided opaque layout witness for ``inner``.

    The witness deliberately does not expose field offsets or C-compatible
    aggregate layout.  M6.3 uses it only to transport the target extent /
    alignment / stride selected by the compiler for generic storage work.
    """

    inner: "Type"


@dataclass(frozen=True, slots=True)
class ArrayType:
    inner: "Type"
    length: int


@dataclass(frozen=True, slots=True)
class SpanType:
    mode: str
    inner: "Type"


@dataclass(frozen=True, slots=True)
class BlockType:
    params: tuple["Type", ...]
    result: "Type"


@dataclass(frozen=True, slots=True)
class AccessModeType:
    mode: str


@dataclass(frozen=True, slots=True)
class TupleType:
    items: tuple["Type", ...]


Type: TypeAlias = (
    BuiltinType | IntLiteralType | NeverType | NominalType | SumType | TypeParamType | RefType | ExclusiveRefType |
    PtrType | SlotType | LayoutType | ArrayType | SpanType | BlockType | AccessModeType | TupleType
)

UNIT = BuiltinType("unit")
U32 = BuiltinType("u32")
USIZE = BuiltinType("usize")
BOOL = BuiltinType("bool")
LIFETIME_DOMAIN = BuiltinType("LifetimeDomain")
ALLOCATION = BuiltinType("Allocation")
STORAGE = BuiltinType("Storage")
INT_LITERAL = IntLiteralType()
NEVER = NeverType()


def display_type(t: Type) -> str:
    if isinstance(t, BuiltinType):
        return t.name
    if isinstance(t, IntLiteralType):
        return "integer literal"
    if isinstance(t, NeverType):
        return "never"
    if isinstance(t, (NominalType, SumType)):
        if not t.args:
            return t.name
        return f"{t.name}<" + ",".join(display_type(a) for a in t.args) + ">"
    if isinstance(t, TypeParamType):
        return t.name
    if isinstance(t, RefType):
        return f"ref<{t.mode},{display_type(t.inner)}>"
    if isinstance(t, ExclusiveRefType):
        return f"exclusive ref<{t.mode},{display_type(t.inner)}>"
    if isinstance(t, PtrType):
        return f"ptr<{display_type(t.inner)}>"
    if isinstance(t, SlotType):
        return f"slot<{display_type(t.inner)}>"
    if isinstance(t, LayoutType):
        return f"Layout<{display_type(t.inner)}>"
    if isinstance(t, ArrayType):
        return f"Array<{display_type(t.inner)},{t.length}>"
    if isinstance(t, SpanType):
        return f"span<{t.mode},{display_type(t.inner)}>"
    if isinstance(t, BlockType):
        return "block(" + ", ".join(display_type(p) for p in t.params) + ") -> " + display_type(t.result)
    if isinstance(t, AccessModeType):
        return t.mode
    if isinstance(t, TupleType):
        return "(" + ", ".join(display_type(i) for i in t.items) + ")"
    raise AssertionError(t)


def dispatch_nominal(t: Type) -> NominalType | None:
    while isinstance(t, (RefType, ExclusiveRefType, PtrType)):
        t = t.inner
    return t if isinstance(t, NominalType) else None


def is_resource_type(t: Type) -> bool:
    return isinstance(t, SlotType) or t in {LIFETIME_DOMAIN, ALLOCATION, STORAGE}

# M3 generic helpers

def contains_type_param(t: Type) -> bool:
    if isinstance(t, TypeParamType):
        return True
    if isinstance(t, (NominalType, SumType)):
        return any(contains_type_param(a) for a in t.args)
    if isinstance(t, (RefType, ExclusiveRefType, PtrType, SlotType, LayoutType, ArrayType, SpanType)):
        return contains_type_param(t.inner)
    if isinstance(t, BlockType):
        return any(contains_type_param(p) for p in t.params) or contains_type_param(t.result)
    if isinstance(t, TupleType):
        return any(contains_type_param(i) for i in t.items)
    return False


def substitute_type(t: Type, subst: dict[TypeParamType, Type]) -> Type:
    if isinstance(t, TypeParamType):
        return subst.get(t, t)
    if isinstance(t, NominalType):
        return NominalType(t.type_id, t.name, tuple(substitute_type(a, subst) for a in t.args))
    if isinstance(t, SumType):
        return SumType(t.type_id, t.name, tuple(substitute_type(a, subst) for a in t.args))
    if isinstance(t, RefType):
        return RefType(t.mode, substitute_type(t.inner, subst))
    if isinstance(t, ExclusiveRefType):
        return ExclusiveRefType(t.mode, substitute_type(t.inner, subst))
    if isinstance(t, PtrType):
        return PtrType(substitute_type(t.inner, subst))
    if isinstance(t, SlotType):
        return SlotType(substitute_type(t.inner, subst))
    if isinstance(t, LayoutType):
        return LayoutType(substitute_type(t.inner, subst))
    if isinstance(t, ArrayType):
        return ArrayType(substitute_type(t.inner, subst), t.length)
    if isinstance(t, SpanType):
        return SpanType(t.mode, substitute_type(t.inner, subst))
    if isinstance(t, BlockType):
        return BlockType(tuple(substitute_type(p, subst) for p in t.params), substitute_type(t.result, subst))
    if isinstance(t, TupleType):
        return TupleType(tuple(substitute_type(i, subst) for i in t.items))
    return t


def infer_type_substitution(pattern: Type, actual: Type, subst: dict[TypeParamType, Type]) -> bool:
    if isinstance(pattern, TypeParamType):
        prior = subst.get(pattern)
        if prior is None:
            subst[pattern] = actual
            return True
        return prior == actual
    if type(pattern) is not type(actual):
        return False
    if isinstance(pattern, (BuiltinType, IntLiteralType, NeverType, AccessModeType)):
        return pattern == actual
    if isinstance(pattern, NominalType):
        a = actual  # type: ignore[assignment]
        return pattern.type_id == a.type_id and len(pattern.args) == len(a.args) and all(
            infer_type_substitution(p, q, subst) for p, q in zip(pattern.args, a.args, strict=True)
        )
    if isinstance(pattern, SumType):
        a = actual  # type: ignore[assignment]
        return pattern.type_id == a.type_id and len(pattern.args) == len(a.args) and all(
            infer_type_substitution(p, q, subst) for p, q in zip(pattern.args, a.args, strict=True)
        )
    if isinstance(pattern, RefType):
        return pattern.mode == actual.mode and infer_type_substitution(pattern.inner, actual.inner, subst)  # type: ignore[attr-defined]
    if isinstance(pattern, ExclusiveRefType):
        return pattern.mode == actual.mode and infer_type_substitution(pattern.inner, actual.inner, subst)  # type: ignore[attr-defined]
    if isinstance(pattern, PtrType):
        return infer_type_substitution(pattern.inner, actual.inner, subst)  # type: ignore[attr-defined]
    if isinstance(pattern, SlotType):
        return infer_type_substitution(pattern.inner, actual.inner, subst)  # type: ignore[attr-defined]
    if isinstance(pattern, LayoutType):
        return infer_type_substitution(pattern.inner, actual.inner, subst)  # type: ignore[attr-defined]
    if isinstance(pattern, ArrayType):
        return pattern.length == actual.length and infer_type_substitution(pattern.inner, actual.inner, subst)  # type: ignore[attr-defined]
    if isinstance(pattern, SpanType):
        return pattern.mode == actual.mode and infer_type_substitution(pattern.inner, actual.inner, subst)  # type: ignore[attr-defined]
    if isinstance(pattern, BlockType):
        a = actual  # type: ignore[assignment]
        return len(pattern.params) == len(a.params) and all(infer_type_substitution(p, q, subst) for p, q in zip(pattern.params, a.params, strict=True)) and infer_type_substitution(pattern.result, a.result, subst)
    if isinstance(pattern, TupleType):
        a = actual  # type: ignore[assignment]
        return len(pattern.items) == len(a.items) and all(infer_type_substitution(p, q, subst) for p, q in zip(pattern.items, a.items, strict=True))
    return pattern == actual
