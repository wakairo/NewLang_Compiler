from __future__ import annotations

from .diagnostics import Diagnostic, FrontendError
from .source import SourceFile, Span
from .tokens import KEYWORDS, Token, TokenKind


_SINGLE = {
    "{": TokenKind.LBRACE,
    "}": TokenKind.RBRACE,
    "(": TokenKind.LPAREN,
    ")": TokenKind.RPAREN,
    "[": TokenKind.LBRACKET,
    "]": TokenKind.RBRACKET,
    "<": TokenKind.LT,
    ">": TokenKind.GT,
    ":": TokenKind.COLON,
    ",": TokenKind.COMMA,
    "=": TokenKind.EQ,
    ".": TokenKind.DOT,
    "@": TokenKind.AT,
    "|": TokenKind.PIPE,
}


def lex(source: SourceFile) -> tuple[Token, ...]:
    text = source.text
    out: list[Token] = []
    i = 0
    n = len(text)
    while i < n:
        ch = text[i]
        if ch in " \t\r":
            i += 1
            continue
        if ch == "\n":
            out.append(Token(TokenKind.NEWLINE, "\n", Span(source, i, i + 1)))
            i += 1
            continue
        if text.startswith("//", i):
            j = text.find("\n", i)
            i = n if j < 0 else j
            continue
        if text.startswith("::", i):
            out.append(Token(TokenKind.DCOLON, "::", Span(source, i, i + 2)))
            i += 2
            continue
        if text.startswith("->", i):
            out.append(Token(TokenKind.ARROW, "->", Span(source, i, i + 2)))
            i += 2
            continue
        if text.startswith("=>", i):
            out.append(Token(TokenKind.FATARROW, "=>", Span(source, i, i + 2)))
            i += 2
            continue
        if ch.isalpha() or ch == "_":
            j = i + 1
            while j < n and (text[j].isalnum() or text[j] == "_"):
                j += 1
            word = text[i:j]
            out.append(Token(KEYWORDS.get(word, TokenKind.IDENT), word, Span(source, i, j)))
            i = j
            continue
        if ch.isdigit():
            j = i + 1
            while j < n and text[j].isdigit():
                j += 1
            out.append(Token(TokenKind.INT, text[i:j], Span(source, i, j)))
            i = j
            continue
        kind = _SINGLE.get(ch)
        if kind is not None:
            out.append(Token(kind, ch, Span(source, i, i + 1)))
            i += 1
            continue
        raise FrontendError(Diagnostic("E_LEX", f"unexpected character {ch!r}", Span(source, i, i + 1)))
    out.append(Token(TokenKind.EOF, "", Span(source, n, n)))
    return tuple(out)
