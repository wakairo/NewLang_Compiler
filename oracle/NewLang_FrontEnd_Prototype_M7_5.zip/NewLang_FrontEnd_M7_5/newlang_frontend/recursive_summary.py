from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Mapping

_VENDOR = Path(__file__).resolve().parent.parent / "vendor"
if str(_VENDOR) not in sys.path:
    sys.path.insert(0, str(_VENDOR))

from newlang_checker.ir import Effect, Summary  # type: ignore[import-not-found]
from newlang_checker.source_ir import (  # type: ignore[import-not-found]
    AddDepStmt,
    CallbackStmt,
    CallStmt,
    EffectStmt,
    FunctionDef,
    GenericCallStmt,
    IfStmt,
    KillDepStmt,
    LoopStmt,
    Stmt,
)

from .typed_ir import (
    TBuiltinCall,
    TBlockInvoke,
    TBlockLiteral,
    TCall,
    TDependentCall,
    TExpr,
    TExprStmt,
    TField,
    TFunction,
    TIndex,
    TLet,
    TLoan,
    TLoop,
    TContinue,
    TBreak,
    TMatch,
    TName,
    TInt,
    TAccessMode,
    TProgram,
    TStructLiteral,
    TSumConstruct,
    TUnit,
)


@dataclass(frozen=True, slots=True)
class SemanticSummaryStats:
    scc_count: int
    recursive_scc_count: int
    iterations: int
    widened_sccs: int


@dataclass(frozen=True, slots=True)
class LifecycleRecursionInfo:
    neutral: Mapping[int, bool]
    recursive_function_ids: frozenset[int]
    scc_count: int
    recursive_scc_count: int


def _stmt_calls(stmt: Stmt) -> set[str]:
    if isinstance(stmt, CallStmt):
        return {stmt.function}
    if isinstance(stmt, IfStmt):
        out: set[str] = set()
        for branch in stmt.branches:
            out.update(_body_calls(branch))
        return out
    if isinstance(stmt, LoopStmt):
        return _body_calls(stmt.body)
    return set()


def _body_calls(body: Iterable[Stmt]) -> set[str]:
    out: set[str] = set()
    for stmt in body:
        out.update(_stmt_calls(stmt))
    return out


def _tarjan(nodes: Iterable[object], edges: Mapping[object, set[object]]) -> list[tuple[object, ...]]:
    index = 0
    indices: dict[object, int] = {}
    lowlinks: dict[object, int] = {}
    stack: list[object] = []
    on_stack: set[object] = set()
    out: list[tuple[object, ...]] = []

    def visit(node: object) -> None:
        nonlocal index
        indices[node] = index
        lowlinks[node] = index
        index += 1
        stack.append(node)
        on_stack.add(node)
        for target in edges.get(node, set()):
            if target not in indices:
                visit(target)
                lowlinks[node] = min(lowlinks[node], lowlinks[target])
            elif target in on_stack:
                lowlinks[node] = min(lowlinks[node], indices[target])
        if lowlinks[node] == indices[node]:
            component: list[object] = []
            while True:
                current = stack.pop()
                on_stack.remove(current)
                component.append(current)
                if current == node:
                    break
            out.append(tuple(component))

    for node in nodes:
        if node not in indices:
            visit(node)
    return out


def _effect_root(place: str) -> str:
    return place.partition(".")[0]


def _visible_effect(effect: Effect, params: tuple[str, ...]) -> Effect | None:
    if effect.kind == "Unknown" or effect.place == "*":
        return Effect("Unknown", "*")
    return effect if _effect_root(effect.place) in params else None


def _substitute_summary_effect(
    effect: Effect,
    callee: FunctionDef,
    call: CallStmt,
    caller: FunctionDef,
) -> Effect | None:
    if effect.kind == "Unknown" or effect.place == "*":
        return Effect("Unknown", "*")
    root, sep, rest = effect.place.partition(".")
    try:
        index = callee.params.index(root)
    except ValueError:
        return None
    actual = call.actual_places[index] if index < len(call.actual_places) else None
    if actual is None:
        return None
    place = actual + (sep + rest if sep else "")
    return _visible_effect(Effect(effect.kind, place), caller.params)


def _semantic_body_summary(
    function: FunctionDef,
    body: Iterable[Stmt],
    functions: Mapping[str, FunctionDef],
    summaries: Mapping[str, Summary],
) -> Summary:
    effects: set[Effect] = set()
    unknown = False
    unknown_reasons: set[str] = set()

    def mark_unknown(reason: str) -> None:
        nonlocal unknown
        unknown = True
        unknown_reasons.add(reason)

    def add_stmt(stmt: Stmt) -> None:
        nonlocal unknown
        if isinstance(stmt, EffectStmt):
            visible = _visible_effect(stmt.effect, function.params)
            if visible is not None:
                if visible.kind == "Unknown":
                    mark_unknown("explicit-unknown-effect")
                else:
                    effects.add(visible)
            return
        if isinstance(stmt, (AddDepStmt, KillDepStmt)):
            # This small summary algebra intentionally does not encode dependency
            # post-state transformers.
            mark_unknown("dependency-post-state")
            return
        if isinstance(stmt, GenericCallStmt):
            mark_unknown("generic-resolution-or-post-state")
            return
        if isinstance(stmt, CallbackStmt):
            mark_unknown("callback-post-state")
            return
        if isinstance(stmt, IfStmt):
            for branch in stmt.branches:
                for child in branch:
                    add_stmt(child)
            return
        if isinstance(stmt, LoopStmt):
            for child in stmt.body:
                add_stmt(child)
            return
        if isinstance(stmt, CallStmt):
            callee = functions.get(stmt.function)
            summary = summaries.get(stmt.function)
            if callee is None or summary is None:
                mark_unknown(f"missing-callee-summary:{stmt.function}")
                return
            if summary.unknown:
                # Do not recursively embed the callee's prose/reasons here; a
                # finite label keeps recursive diagnostics from growing without
                # bound across fixpoint iterations.
                mark_unknown(f"callee-summary-unknown:{stmt.function}")
                return
            for effect in summary.effects:
                substituted = _substitute_summary_effect(effect, callee, stmt, function)
                if substituted is not None:
                    if substituted.kind == "Unknown":
                        mark_unknown(f"callee-unknown-effect:{stmt.function}")
                    else:
                        effects.add(substituted)
            return
        raise TypeError(f"unsupported summary statement {stmt!r}")

    for item in body:
        add_stmt(item)
    return Summary(frozenset(effects), frozenset(), unknown, frozenset(unknown_reasons))


def infer_semantic_effect_summaries(
    functions: Mapping[str, FunctionDef],
    *,
    max_effects_per_function: int = 64,
    max_scc_iterations: int = 128,
) -> tuple[dict[str, Summary], SemanticSummaryStats]:
    """Infer finite caller-visible may-effect summaries with recursive SCC fixpoints.

    The abstraction intentionally stops at effects. Any dependency-state operation,
    unresolved generic call, or callback is widened to Unknown rather than treated as
    dependency-free. Projection-growing SCCs are also widened when the finite budget is
    exceeded.
    """

    names = tuple(functions)
    edges: dict[object, set[object]] = {
        name: {target for target in _body_calls(functions[name].body) if target in functions}
        for name in names
    }
    sccs = _tarjan(names, edges)
    owner: dict[str, int] = {}
    for i, component in enumerate(sccs):
        for name in component:
            assert isinstance(name, str)
            owner[name] = i
    deps: dict[int, set[int]] = {i: set() for i in range(len(sccs))}
    for name in names:
        src = owner[name]
        for target in edges[name]:
            assert isinstance(target, str)
            dst = owner[target]
            if src != dst:
                deps[src].add(dst)

    summaries = {name: Summary() for name in names}
    solved: set[int] = set()
    total_iterations = 0
    widened_sccs = 0

    def solve(index: int) -> None:
        nonlocal total_iterations, widened_sccs
        if index in solved:
            return
        for dep in deps[index]:
            solve(dep)
        members = tuple(str(x) for x in sccs[index])
        converged = False
        widened = False
        for _ in range(max_scc_iterations):
            total_iterations += 1
            changed = False
            next_values: dict[str, Summary] = {}
            for name in members:
                summary = _semantic_body_summary(functions[name], functions[name].body, functions, summaries)
                if len(summary.effects) > max_effects_per_function:
                    summary = Summary(
                        frozenset(),
                        frozenset(),
                        True,
                        frozenset({f"effect-budget-exceeded:{max_effects_per_function}"}),
                    )
                    widened = True
                previous = summaries[name]
                # Unknown is an absorbing conservative state for this finite
                # abstraction.  Once a summary has widened, later iterations may
                # discover where the Unknown flows but must not erase the cause
                # that forced widening in the first place.
                if previous.unknown:
                    summary = Summary(
                        summary.effects | previous.effects,
                        summary.killed_before & previous.killed_before,
                        True,
                        summary.unknown_reasons | previous.unknown_reasons,
                    )
                next_values[name] = summary
                if summary != previous:
                    changed = True
            summaries.update(next_values)
            if not changed:
                converged = True
                break
        if not converged:
            widened = True
            for name in members:
                summaries[name] = Summary(
                    frozenset(),
                    frozenset(),
                    True,
                    frozenset({f"scc-fixpoint-nonconvergent:{max_scc_iterations}"}),
                )
        recursive_component = len(members) > 1 or any(name in edges.get(name, set()) for name in members)
        if recursive_component:
            label = "recursive-scc:" + ",".join(sorted(members))
            member_unknown_labels = {f"callee-summary-unknown:{member}" for member in members}
            for name in members:
                summary = summaries[name]
                if summary.unknown:
                    # Calls within the same recursive SCC merely propagate an
                    # already-known loss of precision.  Keep the originating
                    # cause(s) and the SCC label, not noisy self-propagation.
                    reasons = (summary.unknown_reasons - member_unknown_labels) | frozenset({label})
                    summaries[name] = Summary(
                        summary.effects,
                        summary.killed_before,
                        True,
                        reasons,
                    )
        if widened:
            widened_sccs += 1
        solved.add(index)

    for i in range(len(sccs)):
        solve(i)

    recursive = 0
    for component in sccs:
        if len(component) > 1:
            recursive += 1
        else:
            name = str(component[0])
            if name in edges[name]:
                recursive += 1
    return summaries, SemanticSummaryStats(len(sccs), recursive, total_iterations, widened_sccs)


def _typed_expr_calls(expr: TExpr) -> set[int]:
    if isinstance(expr, TCall):
        out = {expr.function.function_id}
        for arg in expr.args:
            out.update(_typed_expr_calls(arg))
        return out
    if isinstance(expr, TDependentCall):
        out: set[int] = set()
        for arg in expr.args:
            out.update(_typed_expr_calls(arg))
        return out
    if isinstance(expr, TBuiltinCall):
        out: set[int] = set()
        for arg in expr.args:
            out.update(_typed_expr_calls(arg))
        return out
    if isinstance(expr, TBlockInvoke):
        out = _typed_expr_calls(expr.callee)
        for arg in expr.args:
            out.update(_typed_expr_calls(arg))
        return out
    if isinstance(expr, (TField, TIndex)):
        out = _typed_expr_calls(expr.base)
        if isinstance(expr, TIndex):
            out.update(_typed_expr_calls(expr.index))
        return out
    if isinstance(expr, TStructLiteral):
        out: set[int] = set()
        for _, value in expr.fields:
            out.update(_typed_expr_calls(value))
        return out
    if isinstance(expr, TSumConstruct):
        return set() if expr.payload is None else _typed_expr_calls(expr.payload)
    if isinstance(expr, TLoan):
        return _typed_expr_calls(expr.source) | _typed_block_calls(expr.body)
    if isinstance(expr, TBlockLiteral):
        return _typed_block_calls(expr.body)
    if isinstance(expr, TLoop):
        out: set[int] = set()
        for param in expr.params:
            out.update(_typed_expr_calls(param.initial))
        out.update(_typed_block_calls(expr.body))
        return out
    if isinstance(expr, TContinue):
        out: set[int] = set()
        for arg in expr.args:
            out.update(_typed_expr_calls(arg))
        return out
    if isinstance(expr, TBreak):
        return set() if expr.value is None else _typed_expr_calls(expr.value)
    if isinstance(expr, TMatch):
        out = _typed_expr_calls(expr.value)
        for arm in expr.arms:
            out.update(_typed_block_calls(arm.body))
        return out
    return set()


def _typed_block_calls(block) -> set[int]:
    out: set[int] = set()
    for stmt in block.statements:
        if isinstance(stmt, (TLet, TExprStmt)):
            out.update(_typed_expr_calls(stmt.value if isinstance(stmt, TLet) else stmt.expr))
    if block.tail is not None:
        out.update(_typed_expr_calls(block.tail))
    return out


_NEUTRAL_LIFECYCLE_BUILTINS = frozenset({"u32", "usize", "store", "replace", "len"})


def _typed_expr_lifecycle_sensitive(expr: TExpr) -> bool:
    if isinstance(expr, (TName, TInt, TAccessMode, TUnit)):
        return False
    if isinstance(expr, TCall):
        return any(_typed_expr_lifecycle_sensitive(arg) for arg in expr.args)
    if isinstance(expr, TDependentCall):
        return True
    if isinstance(expr, TBuiltinCall):
        return expr.name not in _NEUTRAL_LIFECYCLE_BUILTINS or any(
            _typed_expr_lifecycle_sensitive(arg) for arg in expr.args
        )
    if isinstance(expr, TLoop):
        # Loops are neutral only when their initializers/body are neutral and no
        # loop-carried identity/resource value requires relational post-state.
        from .typesys import LIFETIME_DOMAIN, PtrType, SlotType
        if any(param.type == LIFETIME_DOMAIN or isinstance(param.type, (PtrType, SlotType)) for param in expr.params):
            return True
        return any(_typed_expr_lifecycle_sensitive(param.initial) for param in expr.params) or typed_block_lifecycle_sensitive(expr.body)
    if isinstance(expr, TContinue):
        return any(_typed_expr_lifecycle_sensitive(arg) for arg in expr.args)
    if isinstance(expr, TBreak):
        return expr.value is not None and _typed_expr_lifecycle_sensitive(expr.value)
    if isinstance(expr, (TLoan, TBlockInvoke, TBlockLiteral, TMatch)):
        return True
    if isinstance(expr, TField):
        return _typed_expr_lifecycle_sensitive(expr.base)
    if isinstance(expr, TIndex):
        return _typed_expr_lifecycle_sensitive(expr.base) or _typed_expr_lifecycle_sensitive(expr.index)
    if isinstance(expr, TStructLiteral):
        return any(_typed_expr_lifecycle_sensitive(value) for _, value in expr.fields)
    if isinstance(expr, TSumConstruct):
        return expr.payload is not None and _typed_expr_lifecycle_sensitive(expr.payload)
    raise TypeError(f"unsupported typed expression {expr!r}")


def typed_block_lifecycle_sensitive(block) -> bool:
    for stmt in block.statements:
        expr = stmt.value if isinstance(stmt, TLet) else stmt.expr
        if _typed_expr_lifecycle_sensitive(expr):
            return True
    return block.tail is not None and _typed_expr_lifecycle_sensitive(block.tail)


def _typed_function_direct_sensitive(fn: TFunction) -> bool:
    return typed_block_lifecycle_sensitive(fn.body)


def infer_lifecycle_recursion_info(program: TProgram) -> LifecycleRecursionInfo:
    functions = {fn.symbol.function_id: fn for fn in program.functions}
    nodes = tuple(functions)
    edges: dict[object, set[object]] = {
        function_id: {callee for callee in _typed_block_calls(fn.body) if callee in functions}
        for function_id, fn in functions.items()
    }
    sccs = _tarjan(nodes, edges)
    recursive: set[int] = set()
    for component in sccs:
        if len(component) > 1:
            recursive.update(int(x) for x in component)
        else:
            function_id = int(component[0])
            if function_id in edges[function_id]:
                recursive.add(function_id)

    neutral = {function_id: not _typed_function_direct_sensitive(fn) for function_id, fn in functions.items()}
    changed = True
    while changed:
        changed = False
        for function_id in functions:
            value = neutral[function_id] and all(neutral.get(int(callee), False) for callee in edges[function_id])
            if value != neutral[function_id]:
                neutral[function_id] = value
                changed = True

    recursive_scc_count = sum(
        1
        for component in sccs
        if len(component) > 1 or int(component[0]) in edges[int(component[0])]
    )
    return LifecycleRecursionInfo(neutral, frozenset(recursive), len(sccs), recursive_scc_count)
