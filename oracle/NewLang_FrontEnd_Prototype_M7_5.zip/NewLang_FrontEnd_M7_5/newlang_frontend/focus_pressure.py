from __future__ import annotations

import random

from .authority_region_pressure import RegionReject, ResponsibilityOracle, SealedRegion


def _live_region(capacity: int, *, name: str) -> tuple[SealedRegion, ResponsibilityOracle, list[str]]:
    oracle = ResponsibilityOracle()
    region = SealedRegion(capacity, elem_size=8, elem_align=8, oracle=oracle, name=name)
    region.register_type("Token", size=8, align=8)
    tokens: list[str] = []
    for index in range(capacity):
        token = f"{name}:t{index}"
        tokens.append(token)
        oracle.create_external(token)
        claim = region.claim_vacant(index, "Token")
        region.initialize_vacant(claim, token)
    return region, oracle, tokens


def run_focus_pressure(*, seed: int = 20261004, traces: int = 300, steps: int = 64) -> dict[str, int]:
    """Pressure M6.4 focus/re-entry without a symbolic range solver."""

    rng = random.Random(seed)
    operations = 0
    reentry_rejects = 0
    duplicate_rejects = 0
    overlap_rejects = 0
    multi_success = 0
    range_success = 0

    for trace in range(traces):
        region, oracle, tokens = _live_region(8, name=f"focus-{trace}")
        for _ in range(steps):
            operations += 1
            choice = rng.randrange(5)
            if choice == 0:
                i = rng.randrange(8)
                claim = region.claim_live(i, expected_type="Token")
                j = rng.randrange(8)
                try:
                    region.claim_live(j, expected_type="Token")
                except RegionReject as exc:
                    if exc.code != "E_REGION_FOCUSED":
                        raise
                    reentry_rejects += 1
                else:
                    raise AssertionError("focused root allowed a second independent claim")
                region.return_live(claim)
            elif choice == 1:
                i, j = rng.sample(range(8), 2)
                claims = region.claim_many([
                    ("live", i, "Token"),
                    ("live", j, "Token"),
                ])
                if len(claims) != 2:
                    raise AssertionError("multi-claim did not return two claims")
                for claim in claims:
                    region.return_live(claim)
                multi_success += 1
            elif choice == 2:
                i = rng.randrange(8)
                try:
                    region.claim_many([
                        ("live", i, "Token"),
                        ("live", i, "Token"),
                    ])
                except RegionReject as exc:
                    if exc.code != "E_REGION_OVERLAPPING_CLAIMS":
                        raise
                    duplicate_rejects += 1
                else:
                    raise AssertionError("duplicate dynamic index was accepted")
            elif choice == 3:
                start = rng.randrange(0, 6)
                try:
                    region.claim_many_ranges([
                        ("live", start, 2, "Token"),
                        ("live", start + 1, 2, "Token"),
                    ])
                except RegionReject as exc:
                    if exc.code != "E_REGION_OVERLAPPING_CLAIMS":
                        raise
                    overlap_rejects += 1
                else:
                    raise AssertionError("partially overlapping ranges were accepted")
            else:
                split = rng.randrange(1, 7)
                left_count = split
                right_count = 8 - split
                claims = region.claim_many_ranges([
                    ("live", 0, left_count, "Token"),
                    ("live", split, right_count, "Token"),
                ])
                if len(claims) != 8:
                    raise AssertionError("adjacent ranges did not cover each element exactly once")
                for claim in claims:
                    region.return_live(claim)
                range_success += 1

            if region.open_claims:
                raise AssertionError("focus pressure leaked an open claim")
            for token in tokens:
                if oracle.owner(token) != region.region_id:
                    raise AssertionError("focus pressure lost hidden responsibility")
            oracle.assert_conserved()

        # Drain live values before unseal.
        for index, token in enumerate(tokens):
            live = region.claim_live(index, expected_type="Token")
            got, vacant = region.take_live(live)
            if got != token:
                raise AssertionError("focus pressure token mismatch")
            region.return_vacant(vacant)
        region.unseal()
        oracle.assert_conserved()

    return {
        "traces": traces,
        "operations": operations,
        "reentry_rejects": reentry_rejects,
        "duplicate_rejects": duplicate_rejects,
        "overlap_rejects": overlap_rejects,
        "multi_success": multi_success,
        "range_success": range_success,
        "mismatches": 0,
    }
