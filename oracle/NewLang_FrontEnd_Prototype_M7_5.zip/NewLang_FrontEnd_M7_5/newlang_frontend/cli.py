from __future__ import annotations

import argparse
from pathlib import Path
from pprint import pformat

from .driver import check_source
from .lexer import lex
from .parser import parse
from .source import SourceFile
from .symbols import SymbolBuilder
from .typecheck import TypeChecker


def main() -> int:
    ap = argparse.ArgumentParser(prog="newlang-m5.1")
    ap.add_argument(
        "command",
        choices=[
            "check",
            "dump-ast",
            "dump-resolved",
            "dump-typed-ir",
            "dump-requirements",
            "dump-generic-stats",
            "dump-recursion-stats",
        ],
    )
    ap.add_argument("file")
    ns = ap.parse_args()
    path = Path(ns.file)
    text = path.read_text(encoding="utf-8")
    if ns.command == "check":
        result = check_source(text, str(path))
        if result.accepted:
            print(f"ACCEPT: {result.semantic_reason}")
            return 0
        assert result.diagnostic is not None
        print(result.diagnostic.render())
        return 1
    source = SourceFile(str(path), text)
    tree = parse(lex(source))
    if ns.command == "dump-ast":
        print(pformat(tree, width=120))
        return 0
    symbols = SymbolBuilder(tree).build()
    if ns.command == "dump-resolved":
        print(pformat(symbols, width=120))
        return 0
    checker = TypeChecker(symbols)
    typed = checker.check_program()
    if ns.command == "dump-requirements":
        from .typesys import display_type
        for fn_name, reqs in typed.generic_requirements:
            print(fn_name + ":")
            if not reqs:
                print("  (none)")
            for req in reqs:
                args = ", ".join(display_type(t) for t in req.argument_types)
                recv = " receiver" if req.receiver_syntax else ""
                print(f"  {req.name}({args}) -> {display_type(req.result_type)}{recv}")
        return 0
    if ns.command == "dump-generic-stats":
        requirement_count = sum(len(reqs) for reqs in checker.generic_requirements.values())
        print(f"monomorphs: {len(checker.monomorph_cache)}")
        print(f"exact_cycle_hits: {checker.monomorph_cycle_hits}")
        print(f"max_active_depth: {checker.max_monomorph_depth_observed}")
        print(f"requirement_edges: {len(checker.generic_requirement_edges)}")
        print(f"effective_requirements: {requirement_count}")
        return 0
    if ns.command == "dump-recursion-stats":
        from .lower import lower_program
        from .recursive_summary import infer_lifecycle_recursion_info, infer_semantic_effect_summaries

        lowered = lower_program(typed)
        _, semantic_stats = infer_semantic_effect_summaries(lowered.functions)
        lifecycle_info = infer_lifecycle_recursion_info(typed)
        neutral_recursive = sum(
            1
            for function_id in lifecycle_info.recursive_function_ids
            if lifecycle_info.neutral.get(function_id, False)
        )
        print(f"semantic_sccs: {semantic_stats.scc_count}")
        print(f"semantic_recursive_sccs: {semantic_stats.recursive_scc_count}")
        print(f"semantic_fixpoint_iterations: {semantic_stats.iterations}")
        print(f"semantic_widened_sccs: {semantic_stats.widened_sccs}")
        print(f"lifecycle_sccs: {lifecycle_info.scc_count}")
        print(f"lifecycle_recursive_sccs: {lifecycle_info.recursive_scc_count}")
        print(f"lifecycle_neutral_recursive_functions: {neutral_recursive}")
        print(
            "lifecycle_transforming_recursive_functions: "
            f"{len(lifecycle_info.recursive_function_ids) - neutral_recursive}"
        )
        return 0
    print(pformat(typed, width=120))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
