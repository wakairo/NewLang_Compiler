from __future__ import annotations

import random
import sys
from dataclasses import dataclass, replace
from pathlib import Path

_VENDOR = Path(__file__).resolve().parent.parent / "vendor"
if str(_VENDOR) not in sys.path:
    sys.path.insert(0, str(_VENDOR))

from newlang_checker.model import (  # type: ignore[import-not-found]
    BackingRegion,
    ByteRange,
    SemanticState,
    SlotClaim,
    StorageClaim,
    ValuePackage,
)
from newlang_checker.semantics import apply_step, validate_state  # type: ignore[import-not-found]


class DynamicContainerReject(Exception):
    pass


@dataclass(slots=True)
class ContainerStats:
    operations: int = 0
    max_live_roots: int = 0
    materialize_slot_calls: int = 0
    absorb_empty_claim_calls: int = 0
    recover_whole_storage_calls: int = 0
    replace_calls: int = 0
    initial_typed_roots: int = 0
    logical_tag_slots: int = 0


class _BaseBuffer:
    def __init__(self, capacity: int, *, type_name: str = "T", name: str = "buffer") -> None:
        if capacity <= 0:
            raise ValueError("capacity must be positive")
        self.capacity = capacity
        self.type_name = type_name
        self.name = name
        self.backing = f"@alloc:{name}"
        self.state = SemanticState()
        self.state.backings[self.backing] = BackingRegion(self.backing, self.backing)
        self.state.sizeof[type_name] = 1
        self.stats = ContainerStats()
        self._serial = 0
        self._deallocated = False

    def fresh(self, prefix: str) -> str:
        self._serial += 1
        return f"@{self.name}:{prefix}:{self._serial}"

    def _range(self, index: int) -> ByteRange:
        if not 0 <= index < self.capacity:
            raise DynamicContainerReject(f"index {index} outside capacity {self.capacity}")
        return ByteRange(index, index + 1)

    def _value(self, logical: str | None) -> str:
        name = self.fresh("value")
        self.state.values[name] = ValuePackage(local=logical)
        return name

    def _note(self) -> None:
        self.stats.operations += 1
        live = sum(1 for root in self.state.roots.values() if root.placement.backing_region == self.backing)
        self.stats.max_live_roots = max(self.stats.max_live_roots, live)
        validate_state(self.state)

    def _ensure_live_allocation(self) -> None:
        backing = self.state.backings.get(self.backing)
        if self._deallocated or backing is None or not backing.live:
            raise DynamicContainerReject("allocation is not live")

    def logical_contents(self) -> tuple[str | None, ...]:
        raise NotImplementedError

    def recover_whole_storage(self) -> str:
        raise NotImplementedError

    def deallocate(self) -> None:
        self._ensure_live_allocation()
        storage = self.recover_whole_storage()
        claim = self.state.storages.pop(storage)
        if claim.byte_range != ByteRange(0, self.capacity):
            raise DynamicContainerReject("whole-storage recovery did not cover the allocation")
        self.state.backings[self.backing] = replace(self.state.backings[self.backing], live=False)
        self._deallocated = True
        self._note()


class TaggedOccupancyBuffer(_BaseBuffer):
    """Fully initialized occupancy: one live Maybe<T>-like root per capacity slot.

    This is the representation-pressure baseline. Every slot is a live typed object;
    empty/full is represented by the root package's logical tag. No dynamic slot
    materialization boundary is required for ordinary insert/remove.
    """

    EMPTY = "<empty>"

    def __init__(self, capacity: int, *, type_name: str = "T", name: str = "tagged") -> None:
        super().__init__(capacity, type_name=f"Maybe<{type_name}>", name=name)
        self.payload_type = type_name
        self.roots: list[str] = []
        self.stats.logical_tag_slots = capacity
        for index in range(capacity):
            slot = self.fresh("slot")
            self.state.slots[slot] = SlotClaim(self.type_name, self.backing, self._range(index))
            value = self._value(self.EMPTY)
            root = self.fresh("root")
            apply_step(
                self.state,
                {"op": "initialize", "slot": slot, "value": value, "result_root": root},
            )
            self.roots.append(root)
        self.stats.initial_typed_roots = capacity
        self._note()

    def logical_contents(self) -> tuple[str | None, ...]:
        out: list[str | None] = []
        for root in self.roots:
            package = self.state.roots[root].value_package
            out.append(None if package.local == self.EMPTY else package.local)
        return tuple(out)

    def insert(self, index: int, logical: str) -> None:
        self._ensure_live_allocation()
        root = self.roots[index]
        if self.state.roots[root].value_package.local != self.EMPTY:
            raise DynamicContainerReject("insert requires empty tagged slot")
        value = self._value(logical)
        old = self.fresh("old")
        apply_step(
            self.state,
            {"op": "replace_root_package", "root": root, "new_value": value, "result_old": old},
        )
        old_package = self.state.values.pop(old)
        if old_package.local != self.EMPTY:
            raise DynamicContainerReject("tagged replace returned a non-empty old package")
        self.stats.replace_calls += 1
        self._note()

    def remove(self, index: int) -> str:
        self._ensure_live_allocation()
        root = self.roots[index]
        current = self.state.roots[root].value_package.local
        if current == self.EMPTY:
            raise DynamicContainerReject("remove requires full tagged slot")
        value = self._value(self.EMPTY)
        old = self.fresh("old")
        apply_step(
            self.state,
            {"op": "replace_root_package", "root": root, "new_value": value, "result_old": old},
        )
        package = self.state.values.pop(old)
        self.stats.replace_calls += 1
        self._note()
        if package.local is None or package.local == self.EMPTY:
            raise DynamicContainerReject("tagged remove lost payload")
        return package.local

    def recover_whole_storage(self) -> str:
        self._ensure_live_allocation()
        if any(x is not None for x in self.logical_contents()):
            raise DynamicContainerReject("cannot recover tagged allocation while payloads remain live")
        storages: list[str] = []
        for root in self.roots:
            old_value = self.fresh("taken")
            slot = self.fresh("slot")
            apply_step(
                self.state,
                {"op": "take", "root": root, "result_value": old_value, "result_slot": slot},
            )
            package = self.state.values.pop(old_value)
            if package.local != self.EMPTY:
                raise DynamicContainerReject("tagged teardown found a full slot")
            storage = self.fresh("storage")
            apply_step(self.state, {"op": "erase_slot", "slot": slot, "result": storage})
            storages.append(storage)
        while len(storages) > 1:
            left, right = storages.pop(0), storages.pop(0)
            merged = self.fresh("merged")
            apply_step(self.state, {"op": "merge", "storages": [left, right], "result": merged})
            storages.insert(0, merged)
        self.roots.clear()
        self.stats.recover_whole_storage_calls += 1
        self._note()
        return storages[0]


class DenseMetadataBuffer(_BaseBuffer):
    """Dense/raw occupancy with container metadata as the single source of truth.

    Empty ranges have no persistent Storage/slot<T> value. The localized boundary
    materializes a slot only for an insertion transition and absorbs the empty claim
    back into the metadata invariant after removal. This intentionally models the
    Draft-17.2 dynamic-claim policy without fixing source syntax for the unchecked
    boundary.
    """

    def __init__(self, capacity: int, *, type_name: str = "T", name: str = "dense") -> None:
        super().__init__(capacity, type_name=type_name, name=name)
        self.metadata: list[str | None] = [None] * capacity
        self.roots: dict[int, str] = {}
        self.outstanding_slots: dict[int, str] = {}
        self._note()

    def logical_contents(self) -> tuple[str | None, ...]:
        return tuple(self.metadata)

    def _actual_root_for_index(self, index: int) -> str | None:
        target = self._range(index)
        matches = [
            root.root_id
            for root in self.state.roots.values()
            if root.placement.backing_region == self.backing and root.placement.byte_range == target
        ]
        if len(matches) > 1:
            raise DynamicContainerReject("multiple live roots occupy one dense element range")
        return matches[0] if matches else None

    def validate_metadata_invariant(self) -> None:
        self._ensure_live_allocation()
        for index, logical in enumerate(self.metadata):
            root = self._actual_root_for_index(index)
            tracked = self.roots.get(index)
            if logical is None:
                if root is not None or tracked is not None:
                    raise DynamicContainerReject("metadata says empty but a live root exists")
            else:
                if root is None or tracked != root:
                    raise DynamicContainerReject("metadata says full but the live root is missing")
                package = self.state.roots[root].value_package
                if package.local != logical:
                    raise DynamicContainerReject("metadata payload disagrees with current semantic value")
        for index, slot in self.outstanding_slots.items():
            if self.metadata[index] is not None:
                raise DynamicContainerReject("outstanding empty claim overlaps metadata-live element")
            claim = self.state.slots.get(slot)
            if claim is None or claim.backing_region != self.backing or claim.byte_range != self._range(index):
                raise DynamicContainerReject("outstanding dynamic slot claim is inconsistent")

    def materialize_slot(self, index: int) -> str:
        """Prototype of unchecked materialize_slot<T>(backing, metadata, location)."""
        self._ensure_live_allocation()
        self._range(index)
        if self.metadata[index] is not None or index in self.roots:
            raise DynamicContainerReject("cannot materialize an occupied element")
        if index in self.outstanding_slots:
            raise DynamicContainerReject("element already has an outstanding empty claim")
        if self._actual_root_for_index(index) is not None:
            raise DynamicContainerReject("actual occupancy contradicts metadata before materialization")
        slot = self.fresh("dynamic-slot")
        self.state.slots[slot] = SlotClaim(self.type_name, self.backing, self._range(index))
        self.outstanding_slots[index] = slot
        self.stats.materialize_slot_calls += 1
        validate_state(self.state)
        return slot

    def _absorb_empty_slot(self, index: int, slot: str) -> None:
        """Return an empty typed claim to the metadata invariant."""
        if self.outstanding_slots.get(index) not in {None, slot}:
            raise DynamicContainerReject("wrong outstanding slot for metadata absorption")
        storage = self.fresh("absorbed-storage")
        apply_step(self.state, {"op": "erase_slot", "slot": slot, "result": storage})
        claim = self.state.storages.pop(storage)
        if claim.backing_region != self.backing or claim.byte_range != self._range(index):
            raise DynamicContainerReject("absorbed Storage does not match metadata element")
        self.outstanding_slots.pop(index, None)
        self.stats.absorb_empty_claim_calls += 1

    def insert(self, index: int, logical: str) -> None:
        self._ensure_live_allocation()
        slot = self.materialize_slot(index)
        value = self._value(logical)
        root = self.fresh("root")
        # Memory/object lifetime changes first; metadata is published second.
        apply_step(self.state, {"op": "initialize", "slot": slot, "value": value, "result_root": root})
        self.outstanding_slots.pop(index, None)
        self.roots[index] = root
        self.metadata[index] = logical
        self.validate_metadata_invariant()
        self._note()

    def remove(self, index: int) -> str:
        self._ensure_live_allocation()
        logical = self.metadata[index]
        root = self.roots.get(index)
        if logical is None or root is None:
            raise DynamicContainerReject("remove requires a metadata-live dense element")
        value = self.fresh("taken")
        slot = self.fresh("empty-slot")
        # End object lifetime first, then publish empty metadata, then return the raw
        # responsibility to the metadata invariant.
        apply_step(self.state, {"op": "take", "root": root, "result_value": value, "result_slot": slot})
        package = self.state.values.pop(value)
        del self.roots[index]
        self.metadata[index] = None
        self._absorb_empty_slot(index, slot)
        self.validate_metadata_invariant()
        self._note()
        if package.local != logical or package.local is None:
            raise DynamicContainerReject("dense remove lost payload identity")
        return package.local

    def recover_whole_storage(self) -> str:
        """Prototype of unchecked recover_whole_storage(allocation, metadata)."""
        self._ensure_live_allocation()
        if any(item is not None for item in self.metadata):
            raise DynamicContainerReject("cannot recover whole Storage while metadata is live")
        if self.roots:
            raise DynamicContainerReject("cannot recover whole Storage while tracked roots remain")
        if self.outstanding_slots:
            raise DynamicContainerReject("cannot recover whole Storage with outstanding claims")
        for root in self.state.roots.values():
            if root.placement.backing_region == self.backing:
                raise DynamicContainerReject("cannot recover whole Storage while an untracked live root remains")
        for claim in self.state.slots.values():
            if claim.backing_region == self.backing:
                raise DynamicContainerReject("cannot recover whole Storage while an untracked slot remains")
        for claim in self.state.storages.values():
            if claim.backing_region == self.backing:
                raise DynamicContainerReject("cannot recover whole Storage while a raw claim remains external")
        storage = self.fresh("whole-storage")
        self.state.storages[storage] = StorageClaim(self.backing, ByteRange(0, self.capacity))
        self.stats.recover_whole_storage_calls += 1
        self._note()
        return storage


def differential_trace(*, seed: int, capacity: int, steps: int) -> dict[str, int]:
    rng = random.Random(seed)
    tagged = TaggedOccupancyBuffer(capacity, name=f"tagged-{seed}")
    dense = DenseMetadataBuffer(capacity, name=f"dense-{seed}")
    oracle: list[str | None] = [None] * capacity
    serial = 0
    for _ in range(steps):
        index = rng.randrange(capacity)
        if oracle[index] is None:
            serial += 1
            token = f"v{seed}:{serial}"
            tagged.insert(index, token)
            dense.insert(index, token)
            oracle[index] = token
        else:
            expected = oracle[index]
            assert expected is not None
            if tagged.remove(index) != expected or dense.remove(index) != expected:
                raise AssertionError("representation differential returned different payload")
            oracle[index] = None
        expected_contents = tuple(oracle)
        if tagged.logical_contents() != expected_contents or dense.logical_contents() != expected_contents:
            raise AssertionError("representation differential logical state mismatch")
    for index, item in enumerate(tuple(oracle)):
        if item is not None:
            if tagged.remove(index) != item or dense.remove(index) != item:
                raise AssertionError("representation differential drain mismatch")
            oracle[index] = None
    tagged.deallocate()
    dense.deallocate()
    return {
        "steps": steps,
        "capacity": capacity,
        "tagged_initial_roots": tagged.stats.initial_typed_roots,
        "tagged_max_live_roots": tagged.stats.max_live_roots,
        "tagged_tag_slots": tagged.stats.logical_tag_slots,
        "tagged_replace_calls": tagged.stats.replace_calls,
        "dense_initial_roots": dense.stats.initial_typed_roots,
        "dense_max_live_roots": dense.stats.max_live_roots,
        "dense_materializations": dense.stats.materialize_slot_calls,
        "dense_absorptions": dense.stats.absorb_empty_claim_calls,
    }


def run_generated_differential(*, seed: int = 20261003, traces: int = 1000, steps: int = 64) -> dict[str, int]:
    rng = random.Random(seed)
    total_steps = 0
    max_capacity = 0
    for index in range(traces):
        capacity = rng.randint(1, 32)
        trace_seed = rng.randrange(1 << 63)
        differential_trace(seed=trace_seed, capacity=capacity, steps=steps)
        total_steps += steps
        max_capacity = max(max_capacity, capacity)
    return {"traces": traces, "steps": total_steps, "max_capacity": max_capacity, "mismatches": 0}

class DensePrefixBuffer(_BaseBuffer):
    """Vec-like dense prefix occupancy using only `len` metadata.

    Live roots occupy exactly [0, length). Empty tail [length, capacity) is owned
    only by the container invariant. No per-slot occupancy table exists.
    """

    def __init__(self, capacity: int, *, type_name: str = "T", name: str = "dense-prefix") -> None:
        super().__init__(capacity, type_name=type_name, name=name)
        self.length = 0
        self.roots: list[str] = []
        self.outstanding_slot: tuple[int, str] | None = None
        self._note()

    def logical_contents(self) -> tuple[str | None, ...]:
        values: list[str | None] = []
        for root in self.roots:
            values.append(self.state.roots[root].value_package.local)
        return tuple(values + [None] * (self.capacity - self.length))

    def validate_metadata_invariant(self) -> None:
        self._ensure_live_allocation()
        if not 0 <= self.length <= self.capacity or len(self.roots) != self.length:
            raise DynamicContainerReject("dense-prefix len metadata is inconsistent")
        expected_ranges = {self._range(i) for i in range(self.length)}
        actual_roots = [
            root
            for root in self.state.roots.values()
            if root.placement.backing_region == self.backing
        ]
        actual_ranges = {root.placement.byte_range for root in actual_roots}
        if actual_ranges != expected_ranges:
            raise DynamicContainerReject("dense-prefix live roots do not match [0,len)")
        if self.outstanding_slot is not None:
            index, slot = self.outstanding_slot
            if index != self.length:
                raise DynamicContainerReject("dense-prefix outstanding slot is not at len")
            claim = self.state.slots.get(slot)
            if claim is None or claim.byte_range != self._range(index):
                raise DynamicContainerReject("dense-prefix outstanding slot is inconsistent")

    def _materialize_tail_slot(self) -> str:
        if self.length >= self.capacity:
            raise DynamicContainerReject("push exceeds dense-prefix capacity")
        if self.outstanding_slot is not None:
            raise DynamicContainerReject("dense-prefix already has an outstanding tail claim")
        index = self.length
        for root in self.state.roots.values():
            if root.placement.backing_region == self.backing and root.placement.byte_range == self._range(index):
                raise DynamicContainerReject("dense-prefix tail unexpectedly contains a live root")
        slot = self.fresh("tail-slot")
        self.state.slots[slot] = SlotClaim(self.type_name, self.backing, self._range(index))
        self.outstanding_slot = (index, slot)
        self.stats.materialize_slot_calls += 1
        validate_state(self.state)
        return slot

    def push(self, logical: str) -> None:
        self._ensure_live_allocation()
        index = self.length
        slot = self._materialize_tail_slot()
        value = self._value(logical)
        root = self.fresh("root")
        apply_step(self.state, {"op": "initialize", "slot": slot, "value": value, "result_root": root})
        self.outstanding_slot = None
        self.roots.append(root)
        # Publish len only after the object is live.
        self.length += 1
        self.validate_metadata_invariant()
        self._note()

    def pop(self) -> str:
        self._ensure_live_allocation()
        if self.length == 0:
            raise DynamicContainerReject("pop requires non-empty dense-prefix buffer")
        index = self.length - 1
        root = self.roots[-1]
        value = self.fresh("taken")
        slot = self.fresh("empty-slot")
        apply_step(self.state, {"op": "take", "root": root, "result_value": value, "result_slot": slot})
        package = self.state.values.pop(value)
        # Publish shorter len after the lifetime has ended, then absorb tail raw bytes.
        self.roots.pop()
        self.length -= 1
        storage = self.fresh("tail-storage")
        apply_step(self.state, {"op": "erase_slot", "slot": slot, "result": storage})
        claim = self.state.storages.pop(storage)
        if claim.byte_range != self._range(index):
            raise DynamicContainerReject("dense-prefix pop returned the wrong empty range")
        self.stats.absorb_empty_claim_calls += 1
        self.validate_metadata_invariant()
        self._note()
        if package.local is None:
            raise DynamicContainerReject("dense-prefix pop lost payload")
        return package.local

    def recover_whole_storage(self) -> str:
        self._ensure_live_allocation()
        if self.length != 0 or self.roots:
            raise DynamicContainerReject("cannot recover dense-prefix allocation while len is nonzero")
        if self.outstanding_slot is not None:
            raise DynamicContainerReject("cannot recover dense-prefix allocation with an outstanding tail claim")
        for root in self.state.roots.values():
            if root.placement.backing_region == self.backing:
                raise DynamicContainerReject("cannot recover dense-prefix allocation while untracked roots remain")
        storage = self.fresh("whole-storage")
        self.state.storages[storage] = StorageClaim(self.backing, ByteRange(0, self.capacity))
        self.stats.recover_whole_storage_calls += 1
        self._note()
        return storage


def differential_prefix_trace(*, seed: int, capacity: int, steps: int) -> dict[str, int]:
    rng = random.Random(seed)
    tagged = TaggedOccupancyBuffer(capacity, name=f"tagged-prefix-{seed}")
    dense = DensePrefixBuffer(capacity, name=f"dense-prefix-{seed}")
    oracle: list[str] = []
    serial = 0
    for _ in range(steps):
        do_push = not oracle or (len(oracle) < capacity and bool(rng.getrandbits(1)))
        if do_push:
            serial += 1
            value = f"p{seed}:{serial}"
            index = len(oracle)
            tagged.insert(index, value)
            dense.push(value)
            oracle.append(value)
        else:
            expected = oracle.pop()
            index = len(oracle)
            if tagged.remove(index) != expected or dense.pop() != expected:
                raise AssertionError("prefix representation differential returned different payload")
        expected_contents = tuple(oracle + [None] * (capacity - len(oracle)))
        if tagged.logical_contents() != expected_contents or dense.logical_contents() != expected_contents:
            raise AssertionError("prefix representation differential state mismatch")
    while oracle:
        expected = oracle.pop()
        index = len(oracle)
        if tagged.remove(index) != expected or dense.pop() != expected:
            raise AssertionError("prefix representation differential drain mismatch")
    tagged.deallocate()
    dense.deallocate()
    return {
        "steps": steps,
        "capacity": capacity,
        "tagged_tag_slots": tagged.stats.logical_tag_slots,
        "tagged_initial_roots": tagged.stats.initial_typed_roots,
        "dense_initial_roots": dense.stats.initial_typed_roots,
        "dense_materializations": dense.stats.materialize_slot_calls,
        "dense_absorptions": dense.stats.absorb_empty_claim_calls,
        "dense_metadata_scalars": 1,
    }


def run_generated_prefix_differential(*, seed: int = 20261003, traces: int = 1000, steps: int = 64) -> dict[str, int]:
    rng = random.Random(seed)
    total_steps = 0
    max_capacity = 0
    for _ in range(traces):
        capacity = rng.randint(1, 64)
        differential_prefix_trace(seed=rng.randrange(1 << 63), capacity=capacity, steps=steps)
        total_steps += steps
        max_capacity = max(max_capacity, capacity)
    return {"traces": traces, "steps": total_steps, "max_capacity": max_capacity, "mismatches": 0}
