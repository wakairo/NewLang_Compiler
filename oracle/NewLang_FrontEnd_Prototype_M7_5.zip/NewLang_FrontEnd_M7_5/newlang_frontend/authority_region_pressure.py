from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from pathlib import Path
import sys
from typing import Literal

_VENDOR = Path(__file__).resolve().parent.parent / "vendor"
if str(_VENDOR) not in sys.path:
    sys.path.insert(0, str(_VENDOR))

from newlang_checker.model import (  # type: ignore[import-not-found]
    BackingRegion,
    ByteRange,
    SemanticState,
    SlotClaim,
    StorageClaim,
    ValuePackage,
)
from newlang_checker.semantics import apply_step, validate_state  # type: ignore[import-not-found]


class RegionReject(Exception):
    def __init__(self, code: str, message: str) -> None:
        super().__init__(message)
        self.code = code
        self.message = message


@dataclass(slots=True)
class TokenRecord:
    owner: str
    address_sensitive: bool = False


class ResponsibilityOracle:
    """Debug/proof oracle. It is not production occupancy metadata.

    Each logical non-Discardable token has exactly one responsibility owner. The
    oracle is intentionally separate from the container's operational metadata.

    The M6.2 ``address_sensitive`` bit is only a conservative pressure-fixture
    label.  M7.1 demonstrates that real address sensitivity may be temporary
    library state (linked/anchored vs unlinked), not a forever nominal property.
    """

    def __init__(self) -> None:
        self.records: dict[str, TokenRecord] = {}

    def create_external(self, token: str, *, address_sensitive: bool = False) -> None:
        if token in self.records:
            raise RegionReject("E_TOKEN_DUPLICATE", f"token {token} already exists")
        self.records[token] = TokenRecord("external", address_sensitive)

    def transfer(self, token: str, expected: str, new: str) -> None:
        record = self.records.get(token)
        if record is None:
            raise RegionReject("E_TOKEN_UNKNOWN", f"unknown token {token}")
        if record.owner != expected:
            raise RegionReject(
                "E_RESPONSIBILITY_OWNER",
                f"token {token} responsibility is owned by {record.owner}, not {expected}",
            )
        record.owner = new

    def discharge(self, token: str, expected: str) -> None:
        self.transfer(token, expected, "discharged")

    def owner(self, token: str) -> str:
        return self.records[token].owner

    def is_address_sensitive(self, token: str) -> bool:
        return self.records[token].address_sensitive

    def assert_conserved(self) -> None:
        for token, record in self.records.items():
            if not record.owner:
                raise AssertionError(f"token {token} has no responsibility owner")


@dataclass(frozen=True, slots=True)
class Responsibility:
    kind: Literal["vacant", "live", "claimed_vacant", "claimed_live"]
    epoch: int
    root: str | None = None
    token: str | None = None
    type_name: str | None = None
    claim_id: str | None = None


@dataclass(frozen=True, slots=True)
class ClaimReceipt:
    claim_id: str
    region_id: str
    index: int
    epoch: int
    kind: Literal["vacant", "live"]
    type_name: str
    resource: str


@dataclass(frozen=True, slots=True)
class BorrowReceipt:
    borrow_id: str
    region_id: str
    index: int
    epoch: int


@dataclass(frozen=True, slots=True)
class TransitionReceipt:
    transition_id: str
    region_id: str


@dataclass(slots=True)
class RegionStats:
    vacant_claims: int = 0
    live_claims: int = 0
    claim_returns: int = 0
    initializations: int = 0
    takes: int = 0
    unseals: int = 0
    transitions_blocked: int = 0
    focus_reentry_blocked: int = 0
    multi_claim_batches: int = 0
    overlap_rejects: int = 0


def _round_up(value: int, align: int) -> int:
    return (value + align - 1) // align * align


class SealedRegion:
    """Authority-preserving dynamic-region prototype.

    The region *owns* the hidden live/vacant responsibilities. Metadata never
    mints a claim. Extracting a claim changes the region ledger from hidden to
    claimed, and returning/initializing/taking transfers that same responsibility.

    The region is created by consuming an original whole Storage claim. Unseal
    consumes the region and returns whole Storage only when every hidden
    responsibility is vacant and no scoped claim/borrow survives.
    """

    _serial = 0

    def __init__(
        self,
        capacity: int,
        *,
        elem_size: int = 1,
        elem_align: int = 1,
        base_align: int | None = None,
        name: str = "region",
        oracle: ResponsibilityOracle | None = None,
    ) -> None:
        if capacity <= 0:
            raise ValueError("capacity must be positive")
        if elem_size == 0:
            raise RegionReject(
                "E_M62_ZST_POLICY",
                "M6.2 byte-range region prototype does not assign logical multiplicity to zero-sized elements",
            )
        if elem_size < 0 or elem_align <= 0 or elem_align & (elem_align - 1):
            raise ValueError("invalid element layout")
        if base_align is None:
            base_align = elem_align
        if base_align < elem_align or base_align & (base_align - 1):
            raise RegionReject("E_REGION_ALIGNMENT", "backing alignment is insufficient for element layout")

        type(self)._serial += 1
        self.region_id = f"@sealed:{name}:{type(self)._serial}"
        self.backing = f"@backing:{self.region_id}"
        self.capacity = capacity
        self.elem_size = elem_size
        self.elem_align = elem_align
        self.stride = _round_up(elem_size, elem_align)
        self.byte_size = self.stride * capacity
        self.base_align = base_align
        self.state = SemanticState()
        self.state.backings[self.backing] = BackingRegion(self.backing, self.backing)
        self._origin = StorageClaim(self.backing, ByteRange(0, self.byte_size))
        self._sealed = True
        self._fresh = 0
        self.oracle = oracle or ResponsibilityOracle()
        self.responsibilities = [Responsibility("vacant", 0) for _ in range(capacity)]
        self.open_claims: dict[str, ClaimReceipt] = {}
        self.borrows: dict[str, BorrowReceipt] = {}
        self._active_transition: TransitionReceipt | None = None
        self.stats = RegionStats()
        self.type_layouts: dict[str, tuple[int, int]] = {}
        validate_state(self.state)

    def register_type(self, type_name: str, *, size: int | None = None, align: int | None = None) -> None:
        size = self.elem_size if size is None else size
        align = self.elem_align if align is None else align
        if size != self.elem_size:
            raise RegionReject("E_REGION_LAYOUT", f"{type_name} size {size} does not match slot extent {self.elem_size}")
        if align > self.base_align or self._offset(0) % align != 0:
            raise RegionReject("E_REGION_ALIGNMENT", f"{type_name} alignment {align} is unsupported by this region")
        self.type_layouts[type_name] = (size, align)
        self.state.sizeof[type_name] = size

    def _fresh_name(self, prefix: str) -> str:
        self._fresh += 1
        return f"{self.region_id}:{prefix}:{self._fresh}"

    def _ensure_sealed(self) -> None:
        if not self._sealed:
            raise RegionReject("E_REGION_CONSUMED", "sealed region has already been consumed")

    def _offset(self, index: int) -> int:
        if not 0 <= index < self.capacity:
            raise RegionReject("E_REGION_BOUNDS", f"index {index} outside region capacity {self.capacity}")
        return index * self.stride

    def _range(self, index: int) -> ByteRange:
        start = self._offset(index)
        return ByteRange(start, start + self.elem_size)

    def _layout(self, type_name: str) -> tuple[int, int]:
        layout = self.type_layouts.get(type_name)
        if layout is None:
            raise RegionReject("E_REGION_LAYOUT", f"type {type_name} is not registered for this region")
        return layout

    def responsibility(self, index: int) -> Responsibility:
        self._offset(index)
        return self.responsibilities[index]

    def _require_root_closed(self, operation: str) -> None:
        if self.open_claims:
            self.stats.focus_reentry_blocked += 1
            raise RegionReject(
                "E_REGION_FOCUSED",
                f"cannot {operation} while scoped claims are extracted from this root",
            )

    @staticmethod
    def _ranges_overlap(a: ByteRange, b: ByteRange) -> bool:
        return a.start < b.end and b.start < a.end

    @property
    def transition_active(self) -> bool:
        return self._active_transition is not None

    def _check_transition_access(self, transition: TransitionReceipt | None) -> None:
        active = self._active_transition
        if active is None:
            if transition is not None:
                raise RegionReject("E_REGION_STALE_TRANSITION", "transition receipt is no longer active")
            return
        if transition != active:
            self.stats.focus_reentry_blocked += 1
            raise RegionReject(
                "E_REGION_TRANSITION",
                "container invariant is unpublished; only the active transition receipt may open new claims",
            )

    def begin_transition(self) -> TransitionReceipt:
        self._ensure_sealed()
        if self.transition_active:
            raise RegionReject("E_REGION_REENTRY", "container transition is already active")
        self._require_root_closed("begin a container transition")
        transition = TransitionReceipt(self._fresh_name("transition"), self.region_id)
        self._active_transition = transition
        return transition

    def end_transition(self, transition: TransitionReceipt) -> None:
        if self._active_transition is None:
            raise RegionReject("E_REGION_TRANSITION", "no container transition is active")
        if transition != self._active_transition:
            raise RegionReject("E_REGION_STALE_TRANSITION", "transition receipt does not own the active transition")
        if self.open_claims:
            raise RegionReject("E_REGION_OUTSTANDING_CLAIM", "cannot publish container invariant while claims remain open")
        self._active_transition = None

    def require_public_observation(self) -> None:
        if self.transition_active:
            self.stats.transitions_blocked += 1
            raise RegionReject("E_REGION_TRANSITION", "container invariant is temporarily unpublished during transition")
        self._require_root_closed("observe the public container invariant")

    def _check_receipt(self, receipt: ClaimReceipt, kind: str | None = None) -> Responsibility:
        self._ensure_sealed()
        if receipt.region_id != self.region_id:
            raise RegionReject("E_REGION_WRONG_ROOT", "claim belongs to another sealed region")
        current = self.open_claims.get(receipt.claim_id)
        if current != receipt:
            raise RegionReject("E_REGION_STALE_CLAIM", "claim is not current or has already been consumed")
        resp = self.responsibility(receipt.index)
        if resp.epoch != receipt.epoch or resp.claim_id != receipt.claim_id:
            raise RegionReject("E_REGION_STALE_CLAIM", "claim epoch no longer matches region responsibility")
        if kind is not None and receipt.kind != kind:
            raise RegionReject("E_REGION_CLAIM_KIND", f"expected {kind} claim, got {receipt.kind}")
        return resp

    def _validate_vacant_claim(self, index: int, type_name: str) -> Responsibility:
        self._ensure_sealed()
        _, align = self._layout(type_name)
        offset = self._offset(index)
        if offset % align:
            raise RegionReject("E_REGION_ALIGNMENT", f"index {index} is not aligned for {type_name}")
        resp = self.responsibility(index)
        if resp.kind != "vacant":
            raise RegionReject("E_REGION_NOT_VACANT", f"index {index} responsibility is {resp.kind}, not vacant")
        return resp

    def _claim_vacant_validated(self, index: int, type_name: str, resp: Responsibility) -> ClaimReceipt:
        claim_id = self._fresh_name("claim-vacant")
        slot = self._fresh_name("slot")
        self.state.slots[slot] = SlotClaim(type_name, self.backing, self._range(index))
        receipt = ClaimReceipt(claim_id, self.region_id, index, resp.epoch, "vacant", type_name, slot)
        self.open_claims[claim_id] = receipt
        self.responsibilities[index] = Responsibility("claimed_vacant", resp.epoch, type_name=type_name, claim_id=claim_id)
        self.stats.vacant_claims += 1
        validate_state(self.state)
        return receipt

    def claim_vacant(
        self, index: int, type_name: str, *, transition: TransitionReceipt | None = None
    ) -> ClaimReceipt:
        self._check_transition_access(transition)
        self._require_root_closed("extract another claim")
        resp = self._validate_vacant_claim(index, type_name)
        return self._claim_vacant_validated(index, type_name, resp)

    def return_vacant(self, receipt: ClaimReceipt) -> None:
        resp = self._check_receipt(receipt, "vacant")
        slot = receipt.resource
        if slot not in self.state.slots:
            raise RegionReject("E_REGION_CLAIM_LOST", "vacant claim no longer owns its slot")
        storage = self._fresh_name("returned-storage")
        apply_step(self.state, {"op": "erase_slot", "slot": slot, "result": storage})
        claim = self.state.storages.pop(storage)
        if claim.backing_region != self.backing or claim.byte_range != self._range(receipt.index):
            raise RegionReject("E_REGION_WRONG_ROOT", "returned vacant claim does not belong to this region/index")
        del self.open_claims[receipt.claim_id]
        self.responsibilities[receipt.index] = Responsibility("vacant", resp.epoch + 1)
        self.stats.claim_returns += 1
        validate_state(self.state)

    def initialize_vacant(self, receipt: ClaimReceipt, token: str, *, type_name: str | None = None) -> str:
        resp = self._check_receipt(receipt, "vacant")
        type_name = receipt.type_name if type_name is None else type_name
        if type_name != receipt.type_name:
            raise RegionReject("E_REGION_CLAIM_KIND", "typed slot claim cannot initialize a different type")
        self.oracle.transfer(token, "external", self.region_id)
        value = self._fresh_name("value")
        self.state.values[value] = ValuePackage(local=token)
        root = self._fresh_name("root")
        apply_step(self.state, {"op": "initialize", "slot": receipt.resource, "value": value, "result_root": root})
        del self.open_claims[receipt.claim_id]
        self.responsibilities[receipt.index] = Responsibility("live", resp.epoch + 1, root=root, token=token, type_name=type_name)
        self.stats.initializations += 1
        validate_state(self.state)
        return root

    def _validate_live_claim(self, index: int, expected_type: str | None = None) -> Responsibility:
        self._ensure_sealed()
        resp = self.responsibility(index)
        if resp.kind != "live" or resp.root is None or resp.type_name is None:
            raise RegionReject("E_REGION_NOT_LIVE", f"index {index} responsibility is {resp.kind}, not live")
        if expected_type is not None and resp.type_name != expected_type:
            raise RegionReject("E_REGION_TYPE", f"index {index} holds {resp.type_name}, not {expected_type}")
        if any(b.index == index for b in self.borrows.values()):
            raise RegionReject("E_REGION_BORROWED", "cannot extract lifetime-ending live claim while stable borrow is outstanding")
        return resp

    def _claim_live_validated(self, index: int, resp: Responsibility) -> ClaimReceipt:
        assert resp.root is not None and resp.type_name is not None
        claim_id = self._fresh_name("claim-live")
        receipt = ClaimReceipt(claim_id, self.region_id, index, resp.epoch, "live", resp.type_name, resp.root)
        if resp.token is not None:
            self.oracle.transfer(resp.token, self.region_id, claim_id)
        self.open_claims[claim_id] = receipt
        self.responsibilities[index] = Responsibility(
            "claimed_live", resp.epoch, root=resp.root, token=resp.token, type_name=resp.type_name, claim_id=claim_id
        )
        self.stats.live_claims += 1
        return receipt

    def claim_live(
        self,
        index: int,
        *,
        expected_type: str | None = None,
        transition: TransitionReceipt | None = None,
    ) -> ClaimReceipt:
        self._check_transition_access(transition)
        self._require_root_closed("extract another claim")
        resp = self._validate_live_claim(index, expected_type)
        return self._claim_live_validated(index, resp)

    def claim_many(
        self,
        specs: list[tuple[Literal["vacant", "live"], int, str | None]],
        *,
        transition: TransitionReceipt | None = None,
    ) -> tuple[ClaimReceipt, ...]:
        """Atomically extract several disjoint element claims from one root.

        M6.4 deliberately does not introduce a symbolic range solver.  The caller
        presents all dynamic indices at one boundary; the region checks concrete
        byte ranges for pairwise non-overlap before any authority is transferred.
        """
        self._ensure_sealed()
        self._check_transition_access(transition)
        self._require_root_closed("extract a multi-claim focus")
        if not specs:
            return ()

        validated: list[tuple[str, int, str | None, Responsibility]] = []
        ranges: list[tuple[int, ByteRange]] = []
        for kind, index, type_name in specs:
            if kind == "vacant":
                if type_name is None:
                    raise RegionReject("E_REGION_TYPE", "vacant multi-claim requires a type")
                resp = self._validate_vacant_claim(index, type_name)
            elif kind == "live":
                resp = self._validate_live_claim(index, type_name)
            else:
                raise RegionReject("E_REGION_CLAIM_KIND", f"unknown multi-claim kind {kind}")
            byte_range = self._range(index)
            for other_index, other_range in ranges:
                if self._ranges_overlap(byte_range, other_range):
                    self.stats.overlap_rejects += 1
                    raise RegionReject(
                        "E_REGION_OVERLAPPING_CLAIMS",
                        f"dynamic claims for indices {other_index} and {index} overlap",
                    )
            ranges.append((index, byte_range))
            validated.append((kind, index, type_name, resp))

        receipts: list[ClaimReceipt] = []
        for kind, index, type_name, resp in validated:
            if kind == "vacant":
                assert type_name is not None
                receipts.append(self._claim_vacant_validated(index, type_name, resp))
            else:
                receipts.append(self._claim_live_validated(index, resp))
        self.stats.multi_claim_batches += 1
        return tuple(receipts)

    def claim_many_ranges(
        self,
        specs: list[tuple[Literal["vacant", "live"], int, int, str | None]],
        *,
        transition: TransitionReceipt | None = None,
    ) -> tuple[ClaimReceipt, ...]:
        """Element-granular range focus with concrete runtime overlap checks.

        Each input is (kind, start_index, count, type).  M6.4 intentionally
        limits the safe prototype to whole element slots: arbitrary sub-element
        byte ranges remain outside this mechanism.
        """
        self._ensure_sealed()
        self._check_transition_access(transition)
        self._require_root_closed("extract a multi-range focus")
        flattened: list[tuple[Literal["vacant", "live"], int, str | None]] = []
        spans: list[tuple[int, int]] = []
        for kind, start, count, type_name in specs:
            if count <= 0:
                raise RegionReject("E_M64_RANGE_GRANULARITY", "focused element range must contain at least one element")
            self._offset(start)
            self._offset(start + count - 1)
            lo = self._range(start).start
            hi = self._range(start + count - 1).end
            for other_lo, other_hi in spans:
                if lo < other_hi and other_lo < hi:
                    self.stats.overlap_rejects += 1
                    raise RegionReject(
                        "E_REGION_OVERLAPPING_CLAIMS",
                        f"dynamic focus range [{lo}, {hi}) overlaps [{other_lo}, {other_hi})",
                    )
            spans.append((lo, hi))
            for index in range(start, start + count):
                flattened.append((kind, index, type_name))
        return self.claim_many(flattened, transition=transition)

    def return_live(self, receipt: ClaimReceipt) -> None:
        resp = self._check_receipt(receipt, "live")
        if receipt.resource not in self.state.roots:
            raise RegionReject("E_REGION_CLAIM_LOST", "live claim no longer owns its root")
        if resp.token is not None:
            self.oracle.transfer(resp.token, receipt.claim_id, self.region_id)
        del self.open_claims[receipt.claim_id]
        self.responsibilities[receipt.index] = Responsibility(
            "live", resp.epoch + 1, root=receipt.resource, token=resp.token, type_name=resp.type_name
        )
        self.stats.claim_returns += 1

    def take_live(self, receipt: ClaimReceipt) -> tuple[str, ClaimReceipt]:
        resp = self._check_receipt(receipt, "live")
        if resp.token is None:
            raise RegionReject("E_REGION_VALUE", "live responsibility has no logical token")
        value = self._fresh_name("taken-value")
        slot = self._fresh_name("taken-slot")
        apply_step(self.state, {"op": "take", "root": receipt.resource, "result_value": value, "result_slot": slot})
        package = self.state.values.pop(value)
        if package.local != resp.token:
            raise RegionReject("E_REGION_VALUE", "taken semantic value disagrees with region responsibility")
        self.oracle.transfer(resp.token, receipt.claim_id, "external")
        del self.open_claims[receipt.claim_id]
        next_epoch = resp.epoch + 1
        vacant_claim_id = self._fresh_name("claim-vacant")
        vacant = ClaimReceipt(vacant_claim_id, self.region_id, receipt.index, next_epoch, "vacant", receipt.type_name, slot)
        self.open_claims[vacant_claim_id] = vacant
        self.responsibilities[receipt.index] = Responsibility(
            "claimed_vacant", next_epoch, type_name=receipt.type_name, claim_id=vacant_claim_id
        )
        self.stats.takes += 1
        validate_state(self.state)
        return resp.token, vacant

    def borrow_live(self, index: int) -> BorrowReceipt:
        self._check_transition_access(None)
        self._require_root_closed("start a stable borrow")
        resp = self.responsibility(index)
        if resp.kind != "live":
            raise RegionReject("E_REGION_NOT_LIVE", "stable borrow requires hidden live responsibility")
        bid = self._fresh_name("borrow")
        b = BorrowReceipt(bid, self.region_id, index, resp.epoch)
        self.borrows[bid] = b
        return b

    def end_borrow(self, borrow: BorrowReceipt) -> None:
        if borrow.region_id != self.region_id or self.borrows.get(borrow.borrow_id) != borrow:
            raise RegionReject("E_REGION_BORROW", "borrow does not belong to this region or is already ended")
        del self.borrows[borrow.borrow_id]

    def unseal(self) -> StorageClaim:
        self._ensure_sealed()
        if self.transition_active:
            raise RegionReject("E_REGION_TRANSITION", "cannot unseal while a transition is active")
        if self.open_claims:
            raise RegionReject("E_REGION_OUTSTANDING_CLAIM", "cannot unseal while scoped claims are outstanding")
        if self.borrows:
            raise RegionReject("E_REGION_BORROWED", "cannot unseal while borrows are outstanding")
        nonvacant = [i for i, r in enumerate(self.responsibilities) if r.kind != "vacant"]
        if nonvacant:
            raise RegionReject("E_REGION_LIVE_RESPONSIBILITY", f"cannot unseal while responsibilities remain at {nonvacant}")
        if any(r.placement.backing_region == self.backing for r in self.state.roots.values()):
            raise RegionReject("E_REGION_LIVE_RESPONSIBILITY", "cannot unseal while live roots remain")
        if any(s.backing_region == self.backing for s in self.state.slots.values()):
            raise RegionReject("E_REGION_OUTSTANDING_CLAIM", "cannot unseal while slot claims remain")
        if any(s.backing_region == self.backing for s in self.state.storages.values()):
            raise RegionReject("E_REGION_OUTSTANDING_CLAIM", "cannot unseal while raw claims remain")
        self._sealed = False
        self.stats.unseals += 1
        return self._origin

    def live_indices(self) -> set[int]:
        return {i for i, r in enumerate(self.responsibilities) if r.kind == "live"}


class DenseVecModel:
    def __init__(self, capacity: int, *, oracle: ResponsibilityOracle | None = None, name: str = "vec") -> None:
        self.oracle = oracle or ResponsibilityOracle()
        self.region = SealedRegion(capacity, elem_size=8, elem_align=8, name=name, oracle=self.oracle)
        self.region.register_type("Token", size=8, align=8)
        self.length = 0

    def _check_public(self) -> None:
        self.region.require_public_observation()
        expected = set(range(self.length))
        if self.region.live_indices() != expected:
            raise RegionReject("E_VEC_INVARIANT", "len does not match region live prefix")

    def logical_contents(self) -> tuple[str, ...]:
        self._check_public()
        out: list[str] = []
        for i in range(self.length):
            token = self.region.responsibility(i).token
            assert token is not None
            out.append(token)
        return tuple(out)

    def push(self, token: str, *, fail_at: str | None = None, reenter: bool = False) -> bool:
        self._check_public()
        if self.length == self.region.capacity:
            raise RegionReject("E_VEC_FULL", "vector is full")
        transition = self.region.begin_transition()
        index = self.length
        claim: ClaimReceipt | None = None
        initialized = False
        try:
            claim = self.region.claim_vacant(index, "Token", transition=transition)
            if fail_at == "after_claim":
                self.region.return_vacant(claim)
                claim = None
                return False
            self.region.initialize_vacant(claim, token)
            claim = None
            initialized = True
            if reenter:
                self._check_public()
            if fail_at == "after_initialize":
                live = self.region.claim_live(index, expected_type="Token", transition=transition)
                returned, vacant = self.region.take_live(live)
                assert returned == token
                self.region.return_vacant(vacant)
                initialized = False
                return False
            self.length += 1
            if fail_at == "after_publish":
                # Publication is ordinary mutable metadata, not authority.  A
                # normal error after publication must explicitly roll both the
                # metadata and the hidden live responsibility back.
                self.length -= 1
                live = self.region.claim_live(index, expected_type="Token", transition=transition)
                returned, vacant = self.region.take_live(live)
                assert returned == token
                self.region.return_vacant(vacant)
                initialized = False
                return False
            initialized = False
            return True
        finally:
            if claim is not None and claim.claim_id in self.region.open_claims:
                self.region.return_vacant(claim)
            if initialized:
                # Defensive rollback for an unexpected Python-side failure before publication.
                live = self.region.claim_live(index, expected_type="Token", transition=transition)
                _, vacant = self.region.take_live(live)
                self.region.return_vacant(vacant)
            self.region.end_transition(transition)

    def try_pop(self, *, fail_at: str | None = None) -> tuple[bool, str | None]:
        """Pop with deterministic normal-error injection and explicit rollback.

        The injected failures model recoverable error returns, not unwinding.
        Every failure path restores both public metadata and hidden responsibility
        before the transition receipt is closed.
        """
        self._check_public()
        if self.length == 0:
            raise RegionReject("E_VEC_EMPTY", "vector is empty")
        transition = self.region.begin_transition()
        index = self.length - 1
        live: ClaimReceipt | None = None
        vacant: ClaimReceipt | None = None
        token: str | None = None
        metadata_published = False
        vacant_returned = False
        try:
            live = self.region.claim_live(index, expected_type="Token", transition=transition)
            if fail_at == "after_claim":
                self.region.return_live(live)
                live = None
                return False, None

            token, vacant = self.region.take_live(live)
            live = None
            if fail_at == "after_take":
                self.region.initialize_vacant(vacant, token)
                vacant = None
                token = None
                return False, None

            self.length -= 1
            metadata_published = True
            if fail_at == "after_publish":
                self.length += 1
                metadata_published = False
                self.region.initialize_vacant(vacant, token)
                vacant = None
                token = None
                return False, None

            self.region.return_vacant(vacant)
            vacant = None
            vacant_returned = True
            if fail_at == "after_return":
                # Even after the empty claim has been returned to the region, a
                # recoverable error can restore the previous live responsibility.
                self.length += 1
                metadata_published = False
                restored = self.region.claim_vacant(index, "Token", transition=transition)
                self.region.initialize_vacant(restored, token)
                token = None
                return False, None

            result = token
            # Commit caller ownership before entering the defensive finally.
            token = None
            return True, result
        finally:
            # Defensive Python-side rollback for unexpected failures in this
            # prototype.  Normal injected failures above take explicit paths.
            if live is not None and live.claim_id in self.region.open_claims:
                self.region.return_live(live)
            if vacant is not None and vacant.claim_id in self.region.open_claims and token is not None:
                if metadata_published:
                    self.length += 1
                self.region.initialize_vacant(vacant, token)
            elif vacant_returned and token is not None:
                if metadata_published:
                    self.length += 1
                restored = self.region.claim_vacant(index, "Token", transition=transition)
                self.region.initialize_vacant(restored, token)
            self.region.end_transition(transition)

    def pop(self) -> str:
        ok, token = self.try_pop()
        assert ok and token is not None
        return token

    def borrow(self, index: int) -> BorrowReceipt:
        self._check_public()
        if not 0 <= index < self.length:
            raise RegionReject("E_VEC_BOUNDS", "borrow outside initialized prefix")
        return self.region.borrow_live(index)

    def grow(self, new_capacity: int, *, allocation_fails: bool = False) -> bool:
        self._check_public()
        if new_capacity <= self.region.capacity:
            raise RegionReject("E_VEC_GROW", "growth requires a larger capacity")
        if allocation_fails:
            return False
        if self.region.borrows:
            raise RegionReject("E_REGION_BORROWED", "cannot grow while stable borrows are outstanding")
        tokens = list(self.logical_contents())
        if any(self.oracle.is_address_sensitive(t) for t in tokens):
            raise RegionReject("E_ADDRESS_SENSITIVE_RELOCATION", "ordinary typed transfer cannot relocate address-sensitive value")
        new_region = SealedRegion(new_capacity, elem_size=8, elem_align=8, name="vec-grow", oracle=self.oracle)
        new_region.register_type("Token", size=8, align=8)
        # After allocation succeeds, primitive transfer is modeled as infallible.
        # The old root is unpublished for the whole transfer and only this receipt
        # may extract additional claims from it.
        old_region = self.region
        transition = old_region.begin_transition()
        try:
            for index in range(self.length):
                live = old_region.claim_live(index, expected_type="Token", transition=transition)
                token, vacant = old_region.take_live(live)
                old_region.return_vacant(vacant)
                claim = new_region.claim_vacant(index, "Token")
                new_region.initialize_vacant(claim, token)
        finally:
            old_region.end_transition(transition)
        old_region.unseal()
        self.region = new_region
        return True

    def drain(self) -> list[str]:
        return [self.pop() for _ in range(self.length)]

    def teardown(self) -> StorageClaim:
        self._check_public()
        if self.length:
            raise RegionReject("E_REGION_LIVE_RESPONSIBILITY", "non-Discardable elements must be returned before teardown")
        return self.region.unseal()


class Ring3Model:
    def __init__(self, *, oracle: ResponsibilityOracle | None = None, name: str = "ring") -> None:
        self.oracle = oracle or ResponsibilityOracle()
        self.region = SealedRegion(3, elem_size=8, elem_align=8, name=name, oracle=self.oracle)
        self.region.register_type("Token", size=8, align=8)
        self.head = 0
        self.length = 0

    def _indices(self) -> list[int]:
        return [(self.head + i) % 3 for i in range(self.length)]

    def observe(self) -> tuple[str, ...]:
        self.region.require_public_observation()
        if self.region.live_indices() != set(self._indices()):
            raise RegionReject("E_RING_INVARIANT", "head/len do not match live responsibilities")
        return tuple(self.region.responsibility(i).token or "" for i in self._indices())

    def push(self, token: str, *, reenter_after_initialize: bool = False) -> None:
        self.observe()
        if self.length == 3:
            raise RegionReject("E_RING_FULL", "ring is full")
        transition = self.region.begin_transition()
        index = (self.head + self.length) % 3
        initialized = False
        try:
            claim = self.region.claim_vacant(index, "Token", transition=transition)
            self.region.initialize_vacant(claim, token)
            initialized = True
            if reenter_after_initialize:
                self.observe()
            self.length += 1
            initialized = False
        finally:
            if initialized:
                live = self.region.claim_live(index, expected_type="Token", transition=transition)
                _, vacant = self.region.take_live(live)
                self.region.return_vacant(vacant)
            self.region.end_transition(transition)

    def pop(self) -> str:
        self.observe()
        if self.length == 0:
            raise RegionReject("E_RING_EMPTY", "ring is empty")
        transition = self.region.begin_transition()
        index = self.head
        try:
            live = self.region.claim_live(index, expected_type="Token", transition=transition)
            token, vacant = self.region.take_live(live)
            self.region.return_vacant(vacant)
            self.head = (self.head + 1) % 3
            self.length -= 1
            return token
        finally:
            self.region.end_transition(transition)


class Slab8Model:
    """8-slot slab with an inline live FreeNode in every logically free slot."""

    def __init__(self, *, oracle: ResponsibilityOracle | None = None, name: str = "slab") -> None:
        self.oracle = oracle or ResponsibilityOracle()
        self.region = SealedRegion(8, elem_size=16, elem_align=8, name=name, oracle=self.oracle)
        self.region.register_type("FreeNode", size=16, align=8)
        self.region.register_type("Token", size=16, align=8)
        self.free = [True] * 8
        for index in range(8):
            free_token = self._free_token(index, 0)
            self.oracle.create_external(free_token)
            claim = self.region.claim_vacant(index, "FreeNode")
            self.region.initialize_vacant(claim, free_token)

    @staticmethod
    def _free_token(index: int, epoch: int) -> str:
        return f"free:{index}:{epoch}"

    def observe(self) -> tuple[bool, ...]:
        self.region.require_public_observation()
        for i, is_free in enumerate(self.free):
            resp = self.region.responsibility(i)
            expected = "FreeNode" if is_free else "Token"
            if resp.kind != "live" or resp.type_name != expected:
                raise RegionReject("E_SLAB_INVARIANT", f"slot {i} metadata says {expected}, responsibility is {resp}")
        return tuple(self.free)

    def allocate_at(self, index: int, token: str) -> None:
        self.observe()
        if not self.free[index]:
            raise RegionReject("E_SLAB_OCCUPIED", "slot is already allocated")
        transition = self.region.begin_transition()
        try:
            live = self.region.claim_live(index, expected_type="FreeNode", transition=transition)
            free_token, vacant = self.region.take_live(live)
            self.oracle.discharge(free_token, "external")
            # `vacant` is typed for FreeNode. Return it, then extract a Token slot;
            # this keeps type-specific empty claims explicit while preserving one
            # underlying vacant responsibility.
            self.region.return_vacant(vacant)
            token_claim = self.region.claim_vacant(index, "Token", transition=transition)
            self.region.initialize_vacant(token_claim, token)
            self.free[index] = False
        finally:
            self.region.end_transition(transition)

    def free_at(self, index: int) -> str:
        self.observe()
        if self.free[index]:
            raise RegionReject("E_SLAB_FREE", "slot is already logically free")
        transition = self.region.begin_transition()
        try:
            live = self.region.claim_live(index, expected_type="Token", transition=transition)
            token, vacant = self.region.take_live(live)
            self.region.return_vacant(vacant)
            resp = self.region.responsibility(index)
            free_token = self._free_token(index, resp.epoch)
            self.oracle.create_external(free_token)
            free_claim = self.region.claim_vacant(index, "FreeNode", transition=transition)
            self.region.initialize_vacant(free_claim, free_token)
            self.free[index] = True
            return token
        finally:
            self.region.end_transition(transition)

    def teardown(self) -> StorageClaim:
        self.observe()
        if not all(self.free):
            raise RegionReject("E_REGION_LIVE_RESPONSIBILITY", "allocated Token remains in slab")
        transition = self.region.begin_transition()
        try:
            for index in range(8):
                live = self.region.claim_live(index, expected_type="FreeNode", transition=transition)
                free_token, vacant = self.region.take_live(live)
                self.oracle.discharge(free_token, "external")
                self.region.return_vacant(vacant)
        finally:
            self.region.end_transition(transition)
        return self.region.unseal()


def exhaustive_ring_sequences(depth: int = 7) -> dict[str, int]:
    """Explore all push/pop choices through a small capacity-3 ring."""
    explored = 0
    rejected_expected = 0
    q: deque[tuple[tuple[str, ...], tuple[str, ...]]] = deque([((), ())])
    # We replay each trace from scratch so the model need not implement cloning.
    while q:
        ops, expected = q.popleft()
        oracle = ResponsibilityOracle()
        ring = Ring3Model(oracle=oracle, name="ring-exhaustive")
        model: deque[str] = deque()
        serial = 0
        ok = True
        try:
            for op in ops:
                if op == "push":
                    serial += 1
                    token = f"t{serial}"
                    oracle.create_external(token)
                    ring.push(token)
                    model.append(token)
                else:
                    got = ring.pop()
                    want = model.popleft()
                    if got != want:
                        raise AssertionError((got, want))
                if ring.observe() != tuple(model):
                    raise AssertionError("ring logical state mismatch")
        except RegionReject as exc:
            if exc.code not in {"E_RING_FULL", "E_RING_EMPTY"}:
                raise
            rejected_expected += 1
            ok = False
        if ok:
            explored += 1
            if len(ops) < depth:
                q.append((ops + ("push",), tuple(model)))
                q.append((ops + ("pop",), tuple(model)))
    return {"explored": explored, "expected_boundary_rejects": rejected_expected, "depth": depth}


def run_generated_vec_authority_pressure(*, seed: int = 20261004, traces: int = 300, steps: int = 64) -> dict[str, int]:
    import random

    rng = random.Random(seed)
    operations = 0
    rolled_back = 0
    growth_failures = 0
    successful_growths = 0
    for trace in range(traces):
        oracle = ResponsibilityOracle()
        cap = rng.randint(1, 8)
        vec = DenseVecModel(cap, oracle=oracle, name=f"vec-rand-{trace}")
        model: list[str] = []
        serial = 0
        for _ in range(steps):
            operations += 1
            choice = rng.randrange(100)
            if choice < 48 and len(model) < vec.region.capacity:
                serial += 1
                t = f"t{trace}:{serial}"
                oracle.create_external(t)
                fail_roll = rng.randrange(20)
                fail_at = "after_claim" if fail_roll == 0 else "after_initialize" if fail_roll == 1 else None
                ok = vec.push(t, fail_at=fail_at)
                if ok:
                    model.append(t)
                else:
                    rolled_back += 1
                    if oracle.owner(t) != "external":
                        raise AssertionError("rolled-back push lost external responsibility")
            elif choice < 82 and model:
                expected = model.pop()
                got = vec.pop()
                if got != expected:
                    raise AssertionError("generated vec pop mismatch")
            elif choice < 92:
                old = tuple(model)
                if rng.choice([True, False]):
                    ok = vec.grow(vec.region.capacity + rng.randint(1, 5), allocation_fails=True)
                    if ok:
                        raise AssertionError("injected growth failure unexpectedly succeeded")
                    growth_failures += 1
                else:
                    ok = vec.grow(vec.region.capacity + rng.randint(1, 5))
                    if not ok:
                        raise AssertionError("infallible post-allocation growth failed")
                    successful_growths += 1
                if tuple(model) != old:
                    raise AssertionError("model changed during growth")
            if vec.logical_contents() != tuple(model):
                raise AssertionError("generated vec logical state mismatch")
            oracle.assert_conserved()
        while model:
            expected = model.pop()
            if vec.pop() != expected:
                raise AssertionError("generated vec drain mismatch")
        vec.teardown()
        oracle.assert_conserved()
    return {
        "traces": traces,
        "operations": operations,
        "rolled_back_transitions": rolled_back,
        "growth_failures": growth_failures,
        "successful_growths": successful_growths,
        "mismatches": 0,
    }


def run_generated_slab_authority_pressure(*, seed: int = 20261004, traces: int = 200, steps: int = 64) -> dict[str, int]:
    import random

    rng = random.Random(seed)
    operations = 0
    for trace in range(traces):
        oracle = ResponsibilityOracle()
        slab = Slab8Model(oracle=oracle, name=f"slab-rand-{trace}")
        model: list[str | None] = [None] * 8
        serial = 0
        for _ in range(steps):
            operations += 1
            index = rng.randrange(8)
            if model[index] is None:
                serial += 1
                t = f"s{trace}:{serial}"
                oracle.create_external(t)
                slab.allocate_at(index, t)
                model[index] = t
            else:
                expected = model[index]
                got = slab.free_at(index)
                if got != expected:
                    raise AssertionError("generated slab free mismatch")
                model[index] = None
            slab.observe()
            for i, expected in enumerate(model):
                resp = slab.region.responsibility(i)
                if expected is None:
                    if resp.type_name != "FreeNode":
                        raise AssertionError("logical free slot lost inline FreeNode responsibility")
                else:
                    if resp.type_name != "Token" or resp.token != expected:
                        raise AssertionError("allocated slab slot responsibility mismatch")
            oracle.assert_conserved()
        for index, expected in enumerate(model):
            if expected is not None:
                got = slab.free_at(index)
                if got != expected:
                    raise AssertionError("generated slab drain mismatch")
        slab.teardown()
        oracle.assert_conserved()
    return {"traces": traces, "operations": operations, "mismatches": 0}
