from __future__ import annotations

from dataclasses import dataclass, field

from . import ast
from .diagnostics import Diagnostic, FrontendError
from .symbols import FieldSymbol, FunctionSymbol, ModuleSymbol, SumSymbol, SymbolTable
from .typed_ir import (
    TAccessMode,
    TBuiltinCall,
    TBlock,
    TBlockInvoke,
    TBlockLiteral,
    TCall,
    TDependentCall,
    DependentRequirement,
    TExpr,
    TExprStmt,
    TField,
    TFunction,
    TIndex,
    TInt,
    TLet,
    TLoan,
    TLoop,
    TLoopParam,
    TContinue,
    TBreak,
    TMatch,
    TMatchArm,
    TName,
    TLayoutInfo,
    TProgram,
    TStructLiteral,
    TSumConstruct,
    TUnit,
)
from .typesys import (
    BOOL,
    INT_LITERAL,
    LIFETIME_DOMAIN,
    ALLOCATION,
    STORAGE,
    NEVER,
    NeverType,
    U32,
    UNIT,
    USIZE,
    AccessModeType,
    ArrayType,
    BlockType,
    ExclusiveRefType,
    IntLiteralType,
    NominalType,
    LayoutType,
    PtrType,
    RefType,
    SlotType,
    SpanType,
    SumType,
    TupleType,
    Type,
    TypeParamType,
    contains_type_param,
    dispatch_nominal,
    display_type,
    infer_type_substitution,
    substitute_type,
)


@dataclass(frozen=True, slots=True)
class GenericRequirementEdge:
    caller_function_id: int
    callee_function_id: int
    substitution: tuple[tuple[TypeParamType, Type], ...]
    span: object


@dataclass(frozen=True, slots=True)
class LoopContext:
    params: tuple[tuple[str, Type], ...]
    result_type: Type
    outer_names: frozenset[str]


@dataclass(slots=True)
class LoanState:
    ordinary: int = 0
    exclusive: bool = False


@dataclass(slots=True)
class Env:
    locals: dict[str, Type]
    loans: dict[str, LoanState] = field(default_factory=dict)
    consumed: set[str] = field(default_factory=set)

    def child(self) -> "Env":
        return Env(
            dict(self.locals),
            {k: LoanState(v.ordinary, v.exclusive) for k, v in self.loans.items()},
            set(self.consumed),
        )


class TypeChecker:
    DEFAULT_MAX_MONOMORPH_DEPTH = 32
    DEFAULT_MAX_MONOMORPHS = 256
    DEFAULT_MAX_REQUIREMENTS_PER_GENERIC = 128

    def __init__(
        self,
        symbols: SymbolTable,
        *,
        max_monomorph_depth: int = DEFAULT_MAX_MONOMORPH_DEPTH,
        max_monomorphs: int = DEFAULT_MAX_MONOMORPHS,
        max_requirements_per_generic: int = DEFAULT_MAX_REQUIREMENTS_PER_GENERIC,
    ):
        self.symbols = symbols
        self.max_monomorph_depth = max_monomorph_depth
        self.max_monomorphs = max_monomorphs
        self.max_requirements_per_generic = max_requirements_per_generic
        self.current_module: ModuleSymbol | None = None
        self.current_type_bindings: dict[str, Type] = {}
        self.current_generic_template: FunctionSymbol | None = None
        self.current_requirements: list[DependentRequirement] = []
        self.generic_definitions: dict[int, TFunction] = {}
        self.generic_requirements: dict[int, tuple[DependentRequirement, ...]] = {}
        self.monomorph_cache: dict[tuple[int, tuple[Type, ...]], FunctionSymbol] = {}
        self.monomorph_functions: list[TFunction] = []
        self.monomorph_in_progress: set[tuple[int, tuple[Type, ...]]] = set()
        self.monomorph_stack: list[tuple[int, tuple[Type, ...]]] = []
        self.monomorph_cycle_hits = 0
        self.max_monomorph_depth_observed = 0
        self.generic_requirement_edges: list[GenericRequirementEdge] = []
        self.instantiating_template_id: int | None = None
        self.loop_stack: list[LoopContext] = []
        self.layout_witnesses: dict[Type, TLayoutInfo] = {}
        all_ids = [f.function_id for f in symbols.top_functions.values()] + [f.function_id for m in symbols.modules.values() for f in m.functions.values()]
        self.next_instance_function_id = (max(all_ids) + 1) if all_ids else 1

    def check_program(self) -> TProgram:
        # Definition-time check generic bodies first. They are templates, not executable IR.
        for module in self.symbols.modules.values():
            self.current_module = module
            for fn in module.functions.values():
                if fn.type_params:
                    self.generic_definitions[fn.function_id] = self.check_function(fn, generic_definition=True)
        self.current_module = None
        for fn in self.symbols.top_functions.values():
            if fn.type_params:
                self.generic_definitions[fn.function_id] = self.check_function(fn, generic_definition=True)

        self._close_generic_requirement_graph()

        out: list[TFunction] = []
        for module in self.symbols.modules.values():
            self.current_module = module
            for fn in module.functions.values():
                if not fn.type_params:
                    out.append(self.check_function(fn))
        self.current_module = None
        for fn in self.symbols.top_functions.values():
            if not fn.type_params:
                out.append(self.check_function(fn))
        out.extend(self.monomorph_functions)
        metadata = tuple(
            (self._function_by_id(fid).qualified_name, reqs)
            for fid, reqs in sorted(self.generic_requirements.items())
        )
        layouts = tuple(
            self.layout_witnesses[t]
            for t in sorted(self.layout_witnesses, key=display_type)
        )
        return TProgram(tuple(out), metadata, layouts)

    def _function_by_id(self, fid: int) -> FunctionSymbol:
        for f in self.symbols.top_functions.values():
            if f.function_id == fid:
                return f
        for m in self.symbols.modules.values():
            for f in m.functions.values():
                if f.function_id == fid:
                    return f
        raise KeyError(fid)

    def check_function(
        self,
        fn: FunctionSymbol,
        *,
        generic_definition: bool = False,
        type_bindings: dict[str, Type] | None = None,
        symbol_override: FunctionSymbol | None = None,
    ) -> TFunction:
        prev_module = self.current_module
        prev_bindings = self.current_type_bindings
        prev_template = self.current_generic_template
        prev_requirements = self.current_requirements
        if fn.owner_module_id is None:
            self.current_module = None
        else:
            self.current_module = next(m for m in self.symbols.modules.values() if m.module_id == fn.owner_module_id)
        if type_bindings is None:
            self.current_type_bindings = {tp.name: tp for tp in fn.type_params}
        else:
            self.current_type_bindings = dict(type_bindings)
        self.current_generic_template = fn if generic_definition else (fn if fn.type_params else prev_template)
        self.current_requirements = []
        effective = fn if symbol_override is None else symbol_override
        if isinstance(effective.return_type, BlockType):
            self.error("E_BLOCK_ESCAPE_TYPE", "nonescaping block values cannot be function return types in M3", fn.decl.return_type.span)
        for _, ty in effective.params:
            self._validate_no_block_storage(ty, fn.decl.span)
        self._validate_no_block_storage(effective.return_type, fn.decl.return_type.span)
        env = Env({name: ty for name, ty in effective.params})
        body = self.check_block(fn.decl.body, env, expected_tail=effective.return_type)
        self.require_compatible(body.type, effective.return_type, fn.decl.body.span, allow_weakening=False)
        requirements = tuple(self.current_requirements) if generic_definition else ()
        if generic_definition:
            self.generic_requirements[fn.function_id] = requirements
        result = TFunction(effective, body, requirements)
        self.current_module = prev_module
        self.current_type_bindings = prev_bindings
        self.current_generic_template = prev_template
        self.current_requirements = prev_requirements
        return result

    def check_block(self, block: ast.Block, env: Env, *, propagate_consumption: bool = True, expected_tail: Type | None = None) -> TBlock:
        local = env.child()
        stmts = []
        for stmt in block.statements:
            if isinstance(stmt, ast.LetStmt):
                annotation = None if stmt.annotation is None else self.symbols_type(stmt.annotation)
                if annotation is not None:
                    self._validate_no_block_storage(annotation, stmt.annotation.span)
                value = self.check_expr(stmt.value, local, annotation)
                if annotation is not None:
                    self.require_compatible(value.type, annotation, stmt.value.span, allow_weakening=False)
                self.consume_direct_name(value, local)
                bindings = self.bind_pattern(stmt.pattern, annotation if annotation is not None else value.type, local)
                stmts.append(TLet(bindings, value, stmt.span))
            else:
                expr = self.check_expr(stmt.expr, local)
                if not self.is_discardable(expr.type):
                    self.error("E_NONDDiscardable_EXPR", f"cannot discard {display_type(expr.type)} expression result", stmt.span)
                stmts.append(TExprStmt(expr, stmt.span))
        tail = None if block.tail is None else self.check_expr(block.tail, local, expected_tail)
        if propagate_consumption:
            env.consumed |= {name for name in local.consumed if name in env.locals}
        return TBlock(tuple(stmts), tail, UNIT if tail is None else tail.type, block.span)

    def bind_pattern(self, pat: ast.Pattern, ty: Type, env: Env) -> tuple[tuple[str, Type], ...]:
        if isinstance(pat, ast.NamePattern):
            env.locals[pat.name] = ty
            return ((pat.name, ty),)
        if isinstance(pat, ast.TuplePattern):
            if not isinstance(ty, TupleType) or len(ty.items) != len(pat.items):
                self.error("E_PATTERN_TYPE", f"tuple pattern does not match {display_type(ty)}", pat.span)
            assert isinstance(ty, TupleType)
            out: list[tuple[str, Type]] = []
            for child, item_ty in zip(pat.items, ty.items, strict=True):
                out.extend(self.bind_pattern(child, item_ty, env))
            return tuple(out)
        nominal = self.resolve_type_name(pat.type_name, pat.span)
        if nominal != ty:
            self.error("E_PATTERN_TYPE", f"pattern {nominal.name} does not match {display_type(ty)}", pat.span)
        module = self.symbols.module_for_type(nominal)
        self.require_representation_access(module, pat.span, "E_PRIVATE_DESTRUCTURE", "destructure")
        out: list[tuple[str, Type]] = []
        for name in pat.fields:
            field = module.fields.get(name)
            if field is None:
                self.error("E_UNKNOWN_FIELD", f"unknown field {name} of {module.name}", pat.span)
            assert field is not None
            field_type = self._field_type(nominal, field)
            env.locals[name] = field_type
            out.append((name, field_type))
        return tuple(out)

    def _module_type_subst(self, module: ModuleSymbol, nominal: NominalType | None = None) -> dict[TypeParamType, Type]:
        if not module.type_params:
            return {}
        if nominal is not None:
            if nominal.type_id != module.nominal.type_id or len(nominal.args) != len(module.type_params):
                self.error("E_GENERIC_TYPE_ARITY", f"invalid instantiation of {module.name}", module.decl.span)
            return dict(zip(module.type_params, nominal.args, strict=True))
        return {tp: self.current_type_bindings.get(tp.name, tp) for tp in module.type_params}

    def _sum_type_subst(self, sum_sym: SumSymbol, sum_type: SumType) -> dict[TypeParamType, Type]:
        if len(sum_type.args) != len(sum_sym.type_params):
            self.error("E_GENERIC_TYPE_ARITY", f"invalid instantiation of {sum_sym.name}", sum_sym.decl.span)
        return dict(zip(sum_sym.type_params, sum_type.args, strict=True))

    def _current_self_type(self) -> NominalType:
        if self.current_module is None:
            raise AssertionError("Self outside module")
        subst = self._module_type_subst(self.current_module)
        result = substitute_type(self.current_module.nominal, subst)
        assert isinstance(result, NominalType)
        return result

    def _field_type(self, nominal: NominalType, field: FieldSymbol) -> Type:
        module = self.symbols.module_for_type(nominal)
        return substitute_type(field.type, self._module_type_subst(module, nominal))

    def _variant_payload_type(self, sum_type: SumType, variant: SumVariantSymbol) -> Type | None:
        if variant.payload is None:
            return None
        sum_sym = self.symbols.sum_for_type(sum_type)
        return substitute_type(variant.payload, self._sum_type_subst(sum_sym, sum_type))

    def check_expr(self, expr: ast.Expr, env: Env, expected: Type | None = None) -> TExpr:
        if isinstance(expr, ast.IntExpr):
            return TInt(expr.value, INT_LITERAL, expr.span)
        if isinstance(expr, ast.UnitExpr):
            return TUnit(UNIT, expr.span)
        if isinstance(expr, ast.AccessModeExpr):
            return TAccessMode(expr.mode, AccessModeType(expr.mode), expr.span)
        if isinstance(expr, ast.NameExpr):
            ty = env.locals.get(expr.name)
            if ty is None:
                self.error("E_UNKNOWN_NAME", f"unknown value {expr.name}", expr.span)
            if expr.name in env.consumed:
                self.error("E_USE_AFTER_CONSUME", f"value {expr.name} has already been consumed", expr.span)
            assert ty is not None
            return TName(expr.name, ty, expr.span)
        if isinstance(expr, ast.StructLiteralExpr):
            nominal = self.resolve_type_name(expr.type_name, expr.span)
            module = self.symbols.module_for_type(nominal)
            self.require_representation_access(module, expr.span, "E_PRIVATE_CONSTRUCTION", "construct")
            seen: set[str] = set()
            fields: list[tuple[FieldSymbol, TExpr]] = []
            for init in expr.fields:
                field = module.fields.get(init.name)
                if field is None:
                    self.error("E_UNKNOWN_FIELD", f"unknown field {init.name} of {module.name}", init.span)
                if init.name in seen:
                    self.error("E_DUP_FIELD_INIT", f"duplicate field {init.name}", init.span)
                seen.add(init.name)
                assert field is not None
                field_type = self._field_type(nominal, field)
                value = self.check_expr(init.expr, env, field_type)
                self.require_compatible(value.type, field_type, init.span, allow_weakening=False)
                self.consume_direct_name(value, env)
                fields.append((field, value))
            missing = set(module.fields) - seen
            if missing:
                self.error("E_MISSING_FIELD", f"missing fields: {', '.join(sorted(missing))}", expr.span)
            return TStructLiteral(nominal, tuple(fields), expr.span)
        if isinstance(expr, ast.FieldProjectionExpr):
            base = self.check_expr(expr.base, env)
            nominal = dispatch_nominal(base.type)
            if nominal is None:
                self.error("E_FIELD_BASE", f"{display_type(base.type)} has no fields", expr.span)
            assert nominal is not None
            module = self.symbols.module_for_type(nominal)
            field = module.fields.get(expr.field)
            if field is None:
                self.error("E_UNKNOWN_FIELD", f"unknown field {expr.field} of {module.name}", expr.field_span)
            self.require_representation_access(module, expr.field_span, "E_PRIVATE_FIELD", "access field")
            assert field is not None
            field_type = self._field_type(nominal, field)
            if isinstance(base.type, RefType):
                ty: Type = RefType(base.type.mode, field_type)
            elif isinstance(base.type, ExclusiveRefType):
                ty = ExclusiveRefType(base.type.mode, field_type)
            elif isinstance(base.type, PtrType):
                ty = PtrType(field_type)
            else:
                if not self.is_copy(field_type):
                    self.error("E_FIELD_VALUE_NONCOPY", "by-value field projection requires a Copy field", expr.span)
                ty = field_type
            return TField(base, field, ty, expr.span)
        if isinstance(expr, ast.IndexExpr):
            base = self.check_expr(expr.base, env)
            index = self.check_expr(expr.index, env)
            self.require_compatible(index.type, USIZE, index.span, allow_weakening=False)
            if isinstance(base.type, SpanType):
                return TIndex(base, index, RefType(base.type.mode, base.type.inner), expr.span)
            if isinstance(base.type, RefType) and isinstance(base.type.inner, ArrayType):
                return TIndex(base, index, RefType(base.type.mode, base.type.inner.inner), expr.span)
            if isinstance(base.type, PtrType) and isinstance(base.type.inner, ArrayType):
                return TIndex(base, index, PtrType(base.type.inner.inner), expr.span)
            if isinstance(base.type, ArrayType):
                self.error("E_ARRAY_VALUE_INDEX", "by-value Array indexing is not available; loan the Array or consume it as a whole", expr.span)
            self.error("E_INDEX_BASE", f"{display_type(base.type)} is not indexable in M3", expr.span)
        if isinstance(expr, ast.LoopExpr):
            result_type = self.symbols_type(expr.result_type)
            params: list[TLoopParam] = []
            child = env.child()
            outer_names = frozenset(env.locals)
            for param in expr.params:
                if param.name in env.locals:
                    self.error("E_LOOP_PARAM_SHADOW", f"loop parameter {param.name} may not shadow an existing binding in M4", param.span)
                ty = self.symbols_type(param.type)
                initial = self.check_expr(param.initial, env, ty)
                self.require_compatible(initial.type, ty, param.initial.span, allow_weakening=False)
                self.consume_direct_name(initial, env)
                child.locals[param.name] = ty
                child.consumed.discard(param.name)
                params.append(TLoopParam(param.name, ty, initial, param.span))
            ctx = LoopContext(tuple((p.name, p.type) for p in params), result_type, outer_names)
            self.loop_stack.append(ctx)
            try:
                body = self.check_block(expr.body, child, propagate_consumption=False)
            finally:
                self.loop_stack.pop()
            if body.type != NEVER:
                self.error("E_LOOP_FALLTHROUGH", "loop body must terminate with break(...) or continue(...) on every path", expr.body.span)
            return TLoop(tuple(params), result_type, body, result_type, expr.span)
        if isinstance(expr, ast.ContinueExpr):
            if not self.loop_stack:
                self.error("E_CONTINUE_OUTSIDE_LOOP", "continue(...) is only valid inside loop", expr.span)
            ctx = self.loop_stack[-1]
            if len(expr.args) != len(ctx.params):
                self.error("E_LOOP_CONTINUE_ARITY", f"continue expects {len(ctx.params)} loop-carried value(s), got {len(expr.args)}", expr.span)
            args: list[TExpr] = []
            for source, (name, ty) in zip(expr.args, ctx.params, strict=True):
                value = self.check_expr(source, env, ty)
                self.require_compatible(value.type, ty, source.span, allow_weakening=False)
                if self._requires_exact_loop_identity_carry(ty):
                    if not isinstance(value, TName) or value.name != name:
                        self.error(
                            "E_LOOP_CARRY_PRECISION",
                            f"M4 requires identity-bearing loop parameter {name} to be carried unchanged",
                            source.span,
                        )
                self.consume_direct_name(value, env)
                args.append(value)
            self._check_loop_scope_exit(env, ctx, expr.span)
            return TContinue(tuple(args), NEVER, expr.span)
        if isinstance(expr, ast.BreakExpr):
            if not self.loop_stack:
                self.error("E_BREAK_OUTSIDE_LOOP", "break(...) is only valid inside loop", expr.span)
            ctx = self.loop_stack[-1]
            value: TExpr | None = None
            if expr.value is None:
                if ctx.result_type != UNIT:
                    self.error("E_LOOP_BREAK_TYPE", f"break() requires unit loop result, not {display_type(ctx.result_type)}", expr.span)
            else:
                value = self.check_expr(expr.value, env, ctx.result_type)
                self.require_compatible(value.type, ctx.result_type, expr.value.span, allow_weakening=False)
                self.consume_direct_name(value, env)
            self._check_loop_scope_exit(env, ctx, expr.span)
            return TBreak(value, NEVER, expr.span)
        if isinstance(expr, ast.BlockLiteralExpr):
            child = env.child()
            params: list[tuple[str, Type]] = []
            for param in expr.params:
                ty = self.symbols_type(param.type)
                child.locals[param.name] = ty
                params.append((param.name, ty))
            before = set(child.consumed)
            param_names = {name for name, _ in params}
            saved_loops = self.loop_stack
            self.loop_stack = []
            try:
                body = self.check_block(expr.body, child)
            finally:
                self.loop_stack = saved_loops
            for name, ty in params:
                if not self.is_discardable(ty) and name not in child.consumed:
                    self.error("E_BLOCK_PARAM_NOT_CONSUMED", f"non-Discardable block parameter {name} must be consumed on normal exit", expr.span)
            captured_consumed = {
                name for name in child.consumed - before
                if name in env.locals and name not in param_names and not self.is_copy(env.locals[name])
            }
            if captured_consumed:
                self.error(
                    "E_CALLBACK_CAPTURE_CONSUME",
                    "0..N nonescaping block cannot permanently consume captured non-Copy binding(s): " + ", ".join(sorted(captured_consumed)),
                    expr.span,
                )
            return TBlockLiteral(tuple(params), body, BlockType(tuple(t for _, t in params), body.type), expr.span)
        if isinstance(expr, ast.MatchExpr):
            return self.check_match(expr, env)
        if isinstance(expr, ast.LoanExpr):
            source = self.check_expr(expr.source, env)
            if isinstance(source.type, (RefType, ExclusiveRefType)):
                self.error("E_LOAN_REF", "M1 direct loan syntax requires an object/domain place, not another ref", expr.source.span)
            source_key = expr.source.name if isinstance(expr.source, ast.NameExpr) else None
            child = env.child()
            if source_key is not None:
                state = child.loans.setdefault(source_key, LoanState())
                if expr.exclusive:
                    if state.exclusive or state.ordinary:
                        self.error("E_LOAN_CONFLICT", f"cannot create exclusive loan of {source_key} while another loan is live", expr.span)
                    state.exclusive = True
                else:
                    if state.exclusive:
                        self.error("E_LOAN_CONFLICT", f"cannot create ordinary loan of {source_key} while an exclusive loan is live", expr.span)
                    state.ordinary += 1
            loan_type: Type = (
                ExclusiveRefType(expr.mode, source.type)
                if expr.exclusive
                else RefType(expr.mode, source.type)
            )
            child.locals[expr.binding] = loan_type
            body = self.check_block(expr.body, child)
            env.consumed |= {name for name in child.consumed if name in env.locals}
            return TLoan(expr.mode, expr.exclusive, source, expr.binding, body, body.type, expr.span)
        if isinstance(expr, ast.QualifiedCallExpr):
            sum_sym = self.symbols.sums.get(expr.qualifier)
            if sum_sym is not None:
                variant = sum_sym.variants.get(expr.name)
                if variant is None:
                    self.error("E_UNKNOWN_VARIANT", f"unknown variant {expr.qualifier}::{expr.name}", expr.span)
                assert variant is not None
                args = tuple(self.check_expr(a, env) for a in expr.args)
                expected_count = 0 if variant.payload is None else 1
                if len(args) != expected_count:
                    self.error("E_ARGUMENT_COUNT", f"{expr.qualifier}::{expr.name} expects {expected_count} payload argument(s)", expr.span)
                payload = args[0] if args else None
                subst: dict[TypeParamType, Type] = {}
                if isinstance(expected, SumType) and expected.type_id == sum_sym.type.type_id:
                    if len(expected.args) == len(sum_sym.type_params):
                        subst.update(zip(sum_sym.type_params, expected.args, strict=True))
                if payload is not None:
                    assert variant.payload is not None
                    if not infer_type_substitution(variant.payload, payload.type, subst):
                        self.error("E_GENERIC_SUM_INFERENCE", f"cannot infer {sum_sym.name} type arguments from payload {display_type(payload.type)}", payload.span)
                if sum_sym.type_params:
                    missing = [tp for tp in sum_sym.type_params if tp not in subst]
                    if missing:
                        self.error("E_GENERIC_SUM_INFERENCE", "unbound sum type parameter(s): " + ", ".join(tp.name for tp in missing), expr.span)
                    sum_type = SumType(sum_sym.type.type_id, sum_sym.name, tuple(subst[tp] for tp in sum_sym.type_params))
                else:
                    sum_type = sum_sym.type
                self._validate_no_block_storage(sum_type, expr.span)
                concrete_payload_type = self._variant_payload_type(sum_type, variant)
                if payload is not None:
                    assert concrete_payload_type is not None
                    self.require_compatible(payload.type, concrete_payload_type, payload.span, allow_weakening=False)
                    self.consume_direct_name(payload, env)
                return TSumConstruct(sum_sym.name, variant, payload, sum_type, expr.span)
            module = self.symbols.modules.get(expr.qualifier)
            if module is None:
                self.error("E_UNKNOWN_QUALIFIER", f"unknown module/type {expr.qualifier}", expr.span)
            assert module is not None
            fn = module.functions.get(expr.name)
            if fn is None:
                self.error("E_UNKNOWN_FUNCTION", f"unknown qualified function {expr.qualifier}::{expr.name}", expr.span)
            assert fn is not None
            args = tuple(self.check_expr(a, env) for a in expr.args)
            target = self.instantiate_if_generic(fn, args, expr.span)
            call = self.finish_call(target, args, False, expr.span, expected_result=expected)
            self.consume_call_args(args, target, env)
            return call
        if isinstance(expr, ast.ReceiverCallExpr):
            recv = self.check_expr(expr.receiver, env)
            args = (recv,) + tuple(self.check_expr(a, env) for a in expr.args)
            dependent = self.dependent_call_if_needed(expr.name, args, True, expected, expr.span)
            if dependent is not None:
                return dependent
            fn = self.select_unqualified(expr.name, args, expr.span)
            target = self.instantiate_if_generic(fn, args, expr.span)
            call = self.finish_call(target, args, True, expr.span, expected_result=expected)
            self.consume_call_args(args, target, env)
            return call
        if isinstance(expr, ast.OrdinaryCallExpr):
            args = tuple(self.check_expr(a, env) for a in expr.args)
            name = expr.callee.name
            local_ty = env.locals.get(name)
            if isinstance(local_ty, BlockType):
                if name in env.consumed:
                    self.error("E_USE_AFTER_CONSUME", f"value {name} has already been consumed", expr.callee.span)
                if len(args) != len(local_ty.params):
                    self.error("E_ARGUMENT_COUNT", f"block {name} expects {len(local_ty.params)} arguments, got {len(args)}", expr.span)
                for arg, expected in zip(args, local_ty.params, strict=True):
                    self.require_compatible(arg.type, expected, arg.span, allow_weakening=True)
                    if not self.is_copy(expected):
                        self.consume_direct_name(arg, env)
                return TBlockInvoke(TName(name, local_ty, expr.callee.span), args, local_ty.result, expr.span)
            if name in {"u32", "usize"}:
                if len(args) != 1 or not isinstance(args[0].type, IntLiteralType):
                    self.error("E_NUMERIC_CONSTRUCTOR", f"{name}(...) requires one integer literal in M1", expr.span)
                return TBuiltinCall(name, args, U32 if name == "u32" else USIZE, expr.span)
            m2_builtin = self.check_m2_builtin(name, args, expr, env)
            if m2_builtin is not None:
                return m2_builtin
            builtin = self.check_lifecycle_builtin(name, args, expr, env, expected)
            if builtin is not None:
                return builtin
            if name == "store":
                return self.check_store(args, expr.span, env)
            if name == "replace":
                return self.check_replace(args, expr.span, env)
            if name == "swap":
                return self.check_swap(args, expr.span)
            dependent = self.dependent_call_if_needed(name, args, False, expected, expr.span)
            if dependent is not None:
                return dependent
            fn = self.select_unqualified(name, args, expr.span)
            target = self.instantiate_if_generic(fn, args, expr.span)
            call = self.finish_call(target, args, False, expr.span, expected_result=expected)
            self.consume_call_args(args, target, env)
            return call
        raise AssertionError(expr)

    def symbols_type(self, syntax: ast.TypeSyntax) -> Type:
        # Reuse the resolver's canonical type identities for block-literal params.
        # SymbolBuilder.resolve_type is stateful only through established symbols; reproduce the small lookup here.
        if isinstance(syntax, ast.RefTypeSyntax):
            return RefType(syntax.mode, self.symbols_type(syntax.inner))
        if isinstance(syntax, ast.ExclusiveRefTypeSyntax):
            return ExclusiveRefType(syntax.mode, self.symbols_type(syntax.inner))
        if isinstance(syntax, ast.ArrayTypeSyntax):
            return ArrayType(self.symbols_type(syntax.inner), syntax.length)
        if isinstance(syntax, ast.SpanTypeSyntax):
            return SpanType(syntax.mode, self.symbols_type(syntax.inner))
        if isinstance(syntax, ast.BlockTypeSyntax):
            return BlockType(tuple(self.symbols_type(p) for p in syntax.params), self.symbols_type(syntax.result))
        if isinstance(syntax, ast.TupleTypeSyntax):
            return TupleType(tuple(self.symbols_type(i) for i in syntax.items))
        if isinstance(syntax, ast.GenericTypeSyntax):
            if len(syntax.args) == 1 and syntax.name in {"ptr", "slot", "Layout"}:
                inner = self.symbols_type(syntax.args[0])
                if syntax.name == "ptr":
                    return PtrType(inner)
                if syntax.name == "slot":
                    return SlotType(inner)
                return LayoutType(inner)
            args = tuple(self.symbols_type(arg) for arg in syntax.args)
            module = self.symbols.modules.get(syntax.name)
            if module is not None:
                if len(args) != len(module.type_params):
                    self.error("E_GENERIC_TYPE_ARITY", f"{syntax.name} expects {len(module.type_params)} type argument(s), got {len(args)}", syntax.span)
                return NominalType(module.nominal.type_id, module.name, args)
            sum_sym = self.symbols.sums.get(syntax.name)
            if sum_sym is not None:
                if len(args) != len(sum_sym.type_params):
                    self.error("E_GENERIC_TYPE_ARITY", f"{syntax.name} expects {len(sum_sym.type_params)} type argument(s), got {len(args)}", syntax.span)
                return SumType(sum_sym.type.type_id, sum_sym.name, args)
            self.error("E_UNKNOWN_TYPE", f"unsupported generic type {syntax.name}", syntax.span)
        name = syntax.name
        if name in self.current_type_bindings:
            return self.current_type_bindings[name]
        if name == "u32": return U32
        if name == "usize": return USIZE
        if name == "unit": return UNIT
        if name == "bool": return BOOL
        if name == "LifetimeDomain": return LIFETIME_DOMAIN
        if name == "Allocation": return ALLOCATION
        if name == "Storage": return STORAGE
        if name == "Self":
            if self.current_module is None:
                self.error("E_SELF_OUTSIDE_MODULE", "Self is only valid in a module", syntax.span)
            assert self.current_module is not None
            return self._current_self_type()
        if name in self.symbols.modules:
            module = self.symbols.modules[name]
            if module.type_params:
                self.error("E_GENERIC_TYPE_ARGUMENTS_REQUIRED", f"generic type {name} requires type arguments", syntax.span)
            return module.nominal
        if name in self.symbols.sums:
            sum_sym = self.symbols.sums[name]
            if sum_sym.type_params:
                self.error("E_GENERIC_TYPE_ARGUMENTS_REQUIRED", f"generic type {name} requires type arguments", syntax.span)
            return sum_sym.type
        self.error("E_UNKNOWN_TYPE", f"unknown type {name}", syntax.span)
        raise AssertionError

    def check_match(self, expr: ast.MatchExpr, env: Env) -> TMatch:
        value = self.check_expr(expr.value, env)
        sum_ty: SumType | None = None
        ref_mode: str | None = None
        if isinstance(value.type, SumType):
            sum_ty = value.type
        elif isinstance(value.type, RefType) and isinstance(value.type.inner, SumType):
            sum_ty = value.type.inner
            ref_mode = value.type.mode
        else:
            self.error("E_MATCH_TYPE", f"match requires a sum value or ordinary sum ref, got {display_type(value.type)}", expr.value.span)
        assert sum_ty is not None
        sum_sym = self.symbols.sum_for_type(sum_ty)
        seen: set[str] = set()
        arms: list[TMatchArm] = []
        result_type: Type | None = None
        branch_consumed: set[str] = set()
        for arm in expr.arms:
            variant = sum_sym.variants.get(arm.pattern.variant)
            if variant is None:
                self.error("E_UNKNOWN_VARIANT", f"unknown variant {arm.pattern.variant} of {sum_sym.name}", arm.pattern.span)
            if arm.pattern.variant in seen:
                self.error("E_DUP_MATCH_ARM", f"duplicate match arm {arm.pattern.variant}", arm.pattern.span)
            seen.add(arm.pattern.variant)
            assert variant is not None
            payload_type = self._variant_payload_type(sum_ty, variant)
            if payload_type is None and (arm.pattern.binding is not None or arm.pattern.discard):
                self.error("E_MATCH_PATTERN", f"variant {variant.name} has no payload", arm.pattern.span)
            if payload_type is not None and arm.pattern.binding is None and not arm.pattern.discard:
                self.error("E_MATCH_PATTERN", f"variant {variant.name} requires payload pattern", arm.pattern.span)
            if ref_mode is None and payload_type is not None and arm.pattern.discard and not self.is_discardable(payload_type):
                self.error("E_NONDDiscardable_PATTERN", f"cannot discard non-Discardable payload of {variant.name}", arm.pattern.span)
            child = env.child()
            binding: tuple[str, Type] | None = None
            if payload_type is not None and arm.pattern.binding is not None:
                bty: Type = payload_type if ref_mode is None else RefType(ref_mode, payload_type)
                child.locals[arm.pattern.binding] = bty
                binding = (arm.pattern.binding, bty)
            body = self.check_block(arm.body, child)
            if ref_mode is None and binding is not None and not self.is_discardable(binding[1]) and binding[0] not in child.consumed:
                self.error("E_MATCH_PAYLOAD_NOT_CONSUMED", f"non-Discardable payload binding {binding[0]} must be consumed on normal arm exit", arm.body.span)
            branch_consumed |= {name for name in child.consumed if name in env.locals}
            if body.type != NEVER:
                if result_type is None or result_type == NEVER:
                    result_type = body.type
                else:
                    self.require_compatible(body.type, result_type, body.span, allow_weakening=False)
            elif result_type is None:
                result_type = NEVER
            if ref_mode is not None and binding is not None and isinstance(body.type, RefType):
                self.error("E_OCCURRENCE_ESCAPE", "payload ref cannot escape its match-arm occurrence scope in M3", arm.body.span)
            arms.append(TMatchArm(variant, binding, arm.pattern.discard, body, arm.span))
        missing = set(sum_sym.variants) - seen
        if missing:
            self.error("E_NONEXHAUSTIVE_MATCH", "missing match arm(s): " + ", ".join(sorted(missing)), expr.span)
        env.consumed |= branch_consumed
        if isinstance(value.type, SumType) and not self.is_copy(value.type):
            self.consume_direct_name(value, env)
        return TMatch(value, tuple(arms), result_type or UNIT, expr.span)

    def check_m2_builtin(
        self, name: str, args: tuple[TExpr, ...], source_expr: ast.OrdinaryCallExpr, env: Env
    ) -> TBuiltinCall | None:
        if name == "array_span":
            if len(args) != 1:
                self.error("E_ARGUMENT_COUNT", "array_span expects one Array ref", source_expr.span)
            arg = args[0]
            if not isinstance(arg.type, RefType) or not isinstance(arg.type.inner, ArrayType):
                self.error("E_ARRAY_SPAN", f"array_span requires ref<mode,Array<T,N>>, got {display_type(arg.type)}", arg.span)
            assert isinstance(arg.type, RefType) and isinstance(arg.type.inner, ArrayType)
            return TBuiltinCall(name, args, SpanType(arg.type.mode, arg.type.inner.inner), source_expr.span)
        if name == "len":
            if len(args) != 1 or not isinstance(args[0].type, SpanType):
                self.error("E_LEN", "len expects one span", source_expr.span)
            return TBuiltinCall(name, args, USIZE, source_expr.span)
        if name == "subspan":
            if len(args) != 3 or not isinstance(args[0].type, SpanType):
                self.error("E_SUBSPAN", "subspan expects span, start, count", source_expr.span)
            self.require_compatible(args[1].type, USIZE, args[1].span, allow_weakening=False)
            self.require_compatible(args[2].type, USIZE, args[2].span, allow_weakening=False)
            return TBuiltinCall(name, args, args[0].type, source_expr.span)
        if name == "consume_array":
            if len(args) != 2:
                self.error("E_ARGUMENT_COUNT", "consume_array expects Array and block", source_expr.span)
            array, callback = args
            if not isinstance(array.type, ArrayType):
                self.error("E_CONSUME_ARRAY", f"consume_array requires Array<T,N>, got {display_type(array.type)}", array.span)
            expected_block = BlockType((array.type.inner,), UNIT)
            self.require_compatible(callback.type, expected_block, callback.span, allow_weakening=False)
            if not self.is_copy(array.type):
                self.consume_direct_name(array, env)
            return TBuiltinCall(name, args, UNIT, source_expr.span)
        return None

    def check_lifecycle_builtin(
        self,
        name: str,
        args: tuple[TExpr, ...],
        source_expr: ast.OrdinaryCallExpr,
        env: Env,
        expected: Type | None = None,
    ) -> TBuiltinCall | None:
        if name == "layout":
            if args:
                self.error("E_ARGUMENT_COUNT", "layout expects no arguments", source_expr.span)
            if not isinstance(expected, LayoutType):
                self.error(
                    "E_LAYOUT_RESULT_REQUIRED",
                    "layout() requires an expected Layout<T> result type",
                    source_expr.span,
                )
            assert isinstance(expected, LayoutType)
            if not contains_type_param(expected.inner):
                self.register_layout_witness(expected.inner, source_expr.span)
            return TBuiltinCall(name, args, expected, source_expr.span)
        if name in {"layout_size", "layout_align", "layout_stride"}:
            if len(args) != 1 or not isinstance(args[0].type, LayoutType):
                self.error("E_LAYOUT_ARGUMENT", f"{name} expects one Layout<T> argument", source_expr.span)
            return TBuiltinCall(name, args, USIZE, source_expr.span)
        if name == "allocate_layout":
            if len(args) != 2 or not isinstance(args[0].type, LayoutType):
                self.error("E_LAYOUT_ARGUMENT", "allocate_layout expects Layout<T> and element count", source_expr.span)
            self.require_compatible(args[1].type, USIZE, args[1].span, allow_weakening=False)
            layout_ty = args[0].type
            assert isinstance(layout_ty, LayoutType)
            if not contains_type_param(layout_ty.inner):
                self.register_layout_witness(layout_ty.inner, source_expr.span)
            return TBuiltinCall(name, args, TupleType((ALLOCATION, STORAGE)), source_expr.span)
        if name == "storage_into_slot_layout":
            if len(args) != 2:
                self.error("E_ARGUMENT_COUNT", "storage_into_slot_layout expects Storage and Layout<T>", source_expr.span)
            self.require_compatible(args[0].type, STORAGE, args[0].span, allow_weakening=False)
            if not isinstance(args[1].type, LayoutType):
                self.error("E_LAYOUT_ARGUMENT", "storage_into_slot_layout expects Layout<T> as second argument", args[1].span)
            layout_ty = args[1].type
            assert isinstance(layout_ty, LayoutType)
            if not contains_type_param(layout_ty.inner):
                self.register_layout_witness(layout_ty.inner, source_expr.span)
            self.consume_direct_name(args[0], env)
            return TBuiltinCall(name, args, SlotType(layout_ty.inner), source_expr.span)
        if name == "lifetime_domain":
            if args:
                self.error("E_ARGUMENT_COUNT", "lifetime_domain expects no arguments", source_expr.span)
            return TBuiltinCall(name, args, LIFETIME_DOMAIN, source_expr.span)
        if name == "finalize_domain":
            if len(args) != 1:
                self.error("E_ARGUMENT_COUNT", "finalize_domain expects one argument", source_expr.span)
            self.require_compatible(args[0].type, LIFETIME_DOMAIN, args[0].span, allow_weakening=False)
            raw_arg = source_expr.args[0]
            if isinstance(raw_arg, ast.NameExpr):
                state = env.loans.get(raw_arg.name)
                if state is not None and (state.ordinary or state.exclusive):
                    self.error("E_LOAN_CONFLICT", f"cannot finalize {raw_arg.name} while a loan is live", source_expr.span)
            self.consume_direct_name(args[0], env)
            return TBuiltinCall(name, args, UNIT, source_expr.span)
        if name == "initialize":
            if len(args) != 3:
                self.error("E_ARGUMENT_COUNT", "initialize expects slot, value, and stable domain ref", source_expr.span)
            slot, value, stable = args
            if not isinstance(slot.type, SlotType):
                self.error("E_INITIALIZE_SLOT", f"initialize requires slot<T>, got {display_type(slot.type)}", slot.span)
            assert isinstance(slot.type, SlotType)
            self.require_compatible(value.type, slot.type.inner, value.span, allow_weakening=False)
            expected = RefType("read", LIFETIME_DOMAIN)
            self.require_compatible(stable.type, expected, stable.span, allow_weakening=False)
            self.consume_direct_name(slot, env)
            self.consume_direct_name(value, env)
            return TBuiltinCall(name, args, PtrType(slot.type.inner), source_expr.span)
        if name == "ref_from_ptr":
            if len(args) != 3:
                self.error("E_ARGUMENT_COUNT", "ref_from_ptr expects mode, ptr, and stable domain ref", source_expr.span)
            mode_arg, ptr, stable = args
            if not isinstance(mode_arg, TAccessMode) or mode_arg.mode not in {"read", "write"}:
                self.error("E_REF_FROM_PTR_MODE", "ref_from_ptr mode must be read or write", mode_arg.span)
            if not isinstance(ptr.type, PtrType):
                self.error("E_LIFETIME_PTR", f"ref_from_ptr requires ptr<T>, got {display_type(ptr.type)}", ptr.span)
            expected = RefType("read", LIFETIME_DOMAIN)
            self.require_compatible(stable.type, expected, stable.span, allow_weakening=False)
            assert isinstance(ptr.type, PtrType)
            return TBuiltinCall(name, args, RefType(mode_arg.mode, ptr.type.inner), source_expr.span)
        if name == "ptr_from_ref":
            if len(args) != 1:
                self.error("E_ARGUMENT_COUNT", "ptr_from_ref expects one ordinary ref argument in M1.1", source_expr.span)
            ref = args[0]
            if not isinstance(ref.type, RefType):
                self.error("E_PTR_FROM_REF", f"ptr_from_ref requires ref<read/write,T> in M1.1, got {display_type(ref.type)}", ref.span)
            assert isinstance(ref.type, RefType)
            return TBuiltinCall(name, args, PtrType(ref.type.inner), source_expr.span)
        if name == "owner_ptr":
            if len(args) != 1 or not isinstance(args[0].type, PtrType):
                self.error("E_OWNER_PTR", "owner_ptr expects one ptr<T> argument", source_expr.span)
            if not isinstance(expected, PtrType) or not isinstance(expected.inner, NominalType):
                self.error(
                    "E_OWNER_RESULT_REQUIRED",
                    "owner_ptr requires an expected ptr<Nominal> result type",
                    source_expr.span,
                )
            owner = expected.inner
            assert isinstance(owner, NominalType)
            module = self.symbols.module_for_type(owner)
            self.require_representation_access(
                module, source_expr.span, "E_PRIVATE_OWNER_RECOVERY", "recover an enclosing owner pointer"
            )
            return TBuiltinCall(name, args, expected, source_expr.span)
        if name in {"take", "destroy"}:
            if len(args) != 2:
                self.error("E_ARGUMENT_COUNT", f"{name} expects ptr and exclusive ending-domain ref", source_expr.span)
            ptr, ending = args
            if not isinstance(ptr.type, PtrType):
                self.error("E_LIFETIME_PTR", f"{name} requires ptr<T>, got {display_type(ptr.type)}", ptr.span)
            expected = ExclusiveRefType("read", LIFETIME_DOMAIN)
            self.require_compatible(ending.type, expected, ending.span, allow_weakening=False)
            assert isinstance(ptr.type, PtrType)
            self.consume_direct_name(ending, env)
            if name == "destroy":
                if not self.is_discardable(ptr.type.inner):
                    self.error("E_DESTROY_NONDISCARDABLE", f"destroy requires Discardable({display_type(ptr.type.inner)})", ptr.span)
                return TBuiltinCall(name, args, SlotType(ptr.type.inner), source_expr.span)
            return TBuiltinCall(name, args, TupleType((ptr.type.inner, SlotType(ptr.type.inner))), source_expr.span)
        if name == "allocate_storage":
            if len(args) != 2:
                self.error("E_ARGUMENT_COUNT", "allocate_storage expects byte count and alignment", source_expr.span)
            self.require_compatible(args[0].type, USIZE, args[0].span, allow_weakening=False)
            self.require_compatible(args[1].type, USIZE, args[1].span, allow_weakening=False)
            return TBuiltinCall(name, args, TupleType((ALLOCATION, STORAGE)), source_expr.span)
        if name == "split_storage":
            if len(args) != 2:
                self.error("E_ARGUMENT_COUNT", "split_storage expects Storage and offset", source_expr.span)
            self.require_compatible(args[0].type, STORAGE, args[0].span, allow_weakening=False)
            self.require_compatible(args[1].type, USIZE, args[1].span, allow_weakening=False)
            self.consume_direct_name(args[0], env)
            return TBuiltinCall(name, args, TupleType((STORAGE, STORAGE)), source_expr.span)
        if name == "merge_storage":
            if len(args) != 2:
                self.error("E_ARGUMENT_COUNT", "merge_storage expects two Storage values", source_expr.span)
            for arg in args:
                self.require_compatible(arg.type, STORAGE, arg.span, allow_weakening=False)
                self.consume_direct_name(arg, env)
            return TBuiltinCall(name, args, STORAGE, source_expr.span)
        if name == "storage_into_slot":
            if len(args) != 1:
                self.error("E_ARGUMENT_COUNT", "storage_into_slot expects one Storage", source_expr.span)
            self.require_compatible(args[0].type, STORAGE, args[0].span, allow_weakening=False)
            if not isinstance(expected, SlotType):
                self.error("E_SLOT_RESULT_REQUIRED", "storage_into_slot requires an expected slot<T> result type", source_expr.span)
            self.consume_direct_name(args[0], env)
            return TBuiltinCall(name, args, expected, source_expr.span)
        if name == "erase_slot":
            if len(args) != 1 or not isinstance(args[0].type, SlotType):
                self.error("E_ERASE_SLOT", "erase_slot expects slot<T>", source_expr.span)
            self.consume_direct_name(args[0], env)
            return TBuiltinCall(name, args, STORAGE, source_expr.span)
        if name == "deallocate_storage":
            if len(args) != 2:
                self.error("E_ARGUMENT_COUNT", "deallocate_storage expects Allocation and whole Storage", source_expr.span)
            self.require_compatible(args[0].type, ALLOCATION, args[0].span, allow_weakening=False)
            self.require_compatible(args[1].type, STORAGE, args[1].span, allow_weakening=False)
            self.consume_direct_name(args[0], env); self.consume_direct_name(args[1], env)
            return TBuiltinCall(name, args, UNIT, source_expr.span)
        if name in {"unchecked_dematerialize_storage", "unchecked_materialize_slot", "unchecked_recover_whole_storage"}:
            self.error(
                "E_M62_LEGACY_DYNAMIC_BRIDGE",
                f"{name} was an M6.1 experimental authority-reconstruction surface; M6.2 requires authority-preserving scoped claim transfer instead",
                source_expr.span,
            )
        return None

    def check_replace(self, args: tuple[TExpr, ...], span, env: Env) -> TBuiltinCall:
        if len(args) != 2:
            self.error("E_REPLACE_ARITY", "replace expects two arguments", span)
        dst, value = args
        if not isinstance(dst.type, RefType) or dst.type.mode != "write":
            self.error("E_REPLACE_DEST", f"replace destination must be ref<write,T>, got {display_type(dst.type)}", dst.span)
        assert isinstance(dst.type, RefType)
        self.require_compatible(value.type, dst.type.inner, value.span, allow_weakening=False)
        # Draft 17.2: replace returns the old value, so it does not require
        # Discardable(T). The new value is transferred into the destination.
        self.consume_direct_name(value, env)
        return TBuiltinCall("replace", args, dst.type.inner, span)

    def check_swap(self, args: tuple[TExpr, ...], span) -> TBuiltinCall:
        if len(args) != 2:
            self.error("E_SWAP_ARITY", "swap expects two arguments", span)
        left, right = args
        if not isinstance(left.type, RefType) or left.type.mode != "write":
            self.error("E_SWAP_DEST", f"swap left destination must be ref<write,T>, got {display_type(left.type)}", left.span)
        if not isinstance(right.type, RefType) or right.type.mode != "write":
            self.error("E_SWAP_DEST", f"swap right destination must be ref<write,T>, got {display_type(right.type)}", right.span)
        assert isinstance(left.type, RefType) and isinstance(right.type, RefType)
        self.require_compatible(right.type.inner, left.type.inner, right.span, allow_weakening=False)
        self.require_compatible(left.type.inner, right.type.inner, left.span, allow_weakening=False)
        # Draft 17.3: swap transfers both semantic value packages and therefore
        # requires neither Copy(T) nor Discardable(T).
        return TBuiltinCall("swap", args, UNIT, span)

    def check_store(self, args: tuple[TExpr, ...], span, env: Env) -> TBuiltinCall:
        if len(args) != 2:
            self.error("E_STORE_ARITY", "store expects two arguments", span)
        dst, value = args
        if not isinstance(dst.type, RefType) or dst.type.mode != "write":
            self.error("E_STORE_DEST", f"store destination must be ref<write,T>, got {display_type(dst.type)}", dst.span)
        assert isinstance(dst.type, RefType)
        self.require_compatible(value.type, dst.type.inner, value.span, allow_weakening=False)
        if not self.is_discardable(dst.type.inner):
            self.error("E_STORE_NONDISCARDABLE", f"store requires Discardable({display_type(dst.type.inner)})", dst.span)
        self.consume_direct_name(value, env)
        return TBuiltinCall("store", args, UNIT, span)

    @staticmethod
    def _layout_round_up(value: int, align: int) -> int:
        return (value + align - 1) // align * align

    def register_layout_witness(self, ty: Type, span) -> TLayoutInfo:
        """Register the compiler-owned target layout for a concrete ``T``.

        M6.3 intentionally exposes only extent/alignment/stride.  This helper
        may inspect nominal fields internally, but no field offset or C ABI
        promise is added to the source language.
        """

        prior = self.layout_witnesses.get(ty)
        if prior is not None:
            return prior
        size, align = self._compiler_layout(ty, span, frozenset())
        # M7.2: layout knowledge is allowed for zero-sized values.  This does
        # not imply that the v0 raw Storage/slot bridge can represent a finite
        # multiplicity of zero-byte object lifetimes; allocation/materialization
        # enforces that separate policy.
        stride = 0 if size == 0 else self._layout_round_up(size, align)
        info = TLayoutInfo(ty, size, align, stride)
        self.layout_witnesses[ty] = info
        return info

    def _compiler_layout(self, ty: Type, span, active: frozenset[Type]) -> tuple[int, int]:
        # Prototype target model only.  Exact ABI/layout remains an
        # implementation choice; Layout<T> is the capability to ask the
        # compiler, not a declaration that aggregate fields have a fixed ABI.
        if ty == U32:
            return 4, 4
        if ty == USIZE:
            return 8, 8
        if ty == BOOL:
            return 1, 1
        if ty == UNIT:
            return 0, 1
        if ty == LIFETIME_DOMAIN:
            return 8, 8
        if isinstance(ty, (PtrType, RefType, ExclusiveRefType)):
            return 8, 8
        if isinstance(ty, SpanType):
            return 16, 8
        if isinstance(ty, ArrayType):
            if ty.length == 0:
                return 0, 1
            inner_size, inner_align = self._compiler_layout(ty.inner, span, active)
            stride = self._layout_round_up(inner_size, inner_align)
            return stride * (ty.length - 1) + inner_size, inner_align
        if isinstance(ty, TupleType):
            if not ty.items:
                return 0, 1
            offset = 0
            max_align = 1
            for item in ty.items:
                size, align = self._compiler_layout(item, span, active)
                offset = self._layout_round_up(offset, align)
                offset += size
                max_align = max(max_align, align)
            return self._layout_round_up(offset, max_align), max_align
        if isinstance(ty, NominalType):
            if ty in active:
                self.error("E_RECURSIVE_VALUE_TYPE", f"recursive by-value layout for {display_type(ty)}", span)
            module = self.symbols.module_for_type(ty)
            subst = self._module_type_subst(module, ty)
            offset = 0
            max_align = 1
            for field in module.fields.values():
                fty = substitute_type(field.type, subst)
                size, align = self._compiler_layout(fty, field.decl.span, active | {ty})
                offset = self._layout_round_up(offset, align)
                offset += size
                max_align = max(max_align, align)
            return self._layout_round_up(offset, max_align), max_align
        if isinstance(ty, SumType):
            if ty in active:
                self.error("E_RECURSIVE_VALUE_TYPE", f"recursive by-value layout for {display_type(ty)}", span)
            sum_sym = self.symbols.sum_for_type(ty)
            subst = self._sum_type_subst(sum_sym, ty)
            # Prototype discriminant; the numeric choice is *not* a source ABI
            # guarantee.  It merely proves an opaque compiler witness can feed
            # generic storage logic without publishing variant offsets.
            tag_size, tag_align = 4, 4
            payload_size = 0
            payload_align = 1
            for variant in sum_sym.variants.values():
                if variant.payload is None:
                    continue
                vty = substitute_type(variant.payload, subst)
                size, align = self._compiler_layout(vty, variant.decl.span, active | {ty})
                payload_size = max(payload_size, size)
                payload_align = max(payload_align, align)
            align = max(tag_align, payload_align)
            payload_offset = self._layout_round_up(tag_size, payload_align)
            return self._layout_round_up(payload_offset + payload_size, align), align
        if isinstance(ty, TypeParamType):
            self.error("E_LAYOUT_DEPENDENT", f"layout of unresolved type parameter {ty.name} is not concrete yet", span)
        if isinstance(ty, (SlotType, LayoutType, BlockType, AccessModeType)) or ty in {ALLOCATION, STORAGE}:
            self.error("E_LAYOUT_UNSUPPORTED", f"Layout<{display_type(ty)}> is not a storable user-object layout in M6.3", span)
        self.error("E_LAYOUT_UNSUPPORTED", f"no compiler layout model for {display_type(ty)}", span)
        raise AssertionError

    def consume_direct_name(self, expr: TExpr, env: Env) -> None:
        if isinstance(expr, TName) and not self.is_copy(expr.type):
            if expr.name in env.consumed:
                self.error("E_USE_AFTER_CONSUME", f"value {expr.name} has already been consumed", expr.span)
            env.consumed.add(expr.name)

    def consume_call_args(self, args: tuple[TExpr, ...], fn: FunctionSymbol, env: Env) -> None:
        for arg, (_, formal_type) in zip(args, fn.params, strict=True):
            if not self.is_copy(formal_type):
                self.consume_direct_name(arg, env)

    def _check_loop_scope_exit(self, env: Env, ctx: LoopContext, span) -> None:
        owned = (set(env.locals) - set(ctx.outer_names)) | {name for name, _ in ctx.params}
        missing = [
            name for name in sorted(owned)
            if name in env.locals and not self.is_discardable(env.locals[name]) and name not in env.consumed
        ]
        if missing:
            self.error(
                "E_LOOP_NONDDiscardable_EXIT",
                "loop control would drop non-Discardable binding(s): " + ", ".join(missing),
                span,
            )

    @staticmethod
    def _requires_exact_loop_identity_carry(ty: Type) -> bool:
        return ty == LIFETIME_DOMAIN or isinstance(ty, (RefType, ExclusiveRefType, PtrType, SlotType, SpanType))

    def lexical_candidate(self, name: str) -> FunctionSymbol | None:
        if self.current_module is not None and name in self.current_module.functions:
            return self.current_module.functions[name]
        return self.symbols.top_functions.get(name)

    def dependent_call_if_needed(
        self,
        name: str,
        args: tuple[TExpr, ...],
        receiver_syntax: bool,
        expected: Type | None,
        span,
    ) -> TDependentCall | None:
        # Ordinary lexical lookup wins at definition time. Only an otherwise
        # unresolved unqualified call whose first argument depends on a generic
        # parameter may be deferred.
        if self.lexical_candidate(name) is not None:
            return None
        if not args or not contains_type_param(args[0].type):
            return None
        if expected is None:
            self.error(
                "E_DEPENDENT_RESULT_REQUIRED",
                f"dependent call {name}(...) requires a complete expected result type",
                span,
            )
        assert expected is not None
        req = DependentRequirement(name, tuple(a.type for a in args), expected, receiver_syntax, span)
        self._record_requirement(self.current_requirements, req, span)
        return TDependentCall(name, args, receiver_syntax, expected, span)

    @staticmethod
    def _requirement_key(req: DependentRequirement) -> tuple[str, tuple[Type, ...], Type]:
        # Receiver syntax is only surface sugar for the same associated lookup.
        # Source span is diagnostic provenance, not part of the semantic contract.
        return (req.name, req.argument_types, req.result_type)

    def _record_requirement(
        self,
        target: list[DependentRequirement],
        req: DependentRequirement,
        span,
    ) -> bool:
        key = self._requirement_key(req)
        if any(self._requirement_key(existing) == key for existing in target):
            return False
        if len(target) >= self.max_requirements_per_generic:
            self.error(
                "E_GENERIC_REQUIREMENT_BUDGET",
                f"generic requirement graph exceeded implementation budget ({self.max_requirements_per_generic} unique requirements)",
                span,
            )
        target.append(req)
        return True

    def _close_generic_requirement_graph(self) -> None:
        # Requirements of a symbolic generic callee are requirements of the
        # generic wrapper as well. Compute the small monotone closure here rather
        # than depending on source declaration order. Normalization by semantic
        # requirement key makes recursive wrapper SCCs converge.
        closed: dict[int, list[DependentRequirement]] = {
            fid: list(reqs) for fid, reqs in self.generic_requirements.items()
        }
        for fid in self.generic_definitions:
            closed.setdefault(fid, [])

        changed = True
        while changed:
            changed = False
            for edge in self.generic_requirement_edges:
                caller = closed.setdefault(edge.caller_function_id, [])
                subst = dict(edge.substitution)
                for req in tuple(closed.get(edge.callee_function_id, ())):
                    propagated = DependentRequirement(
                        req.name,
                        tuple(substitute_type(t, subst) for t in req.argument_types),
                        substitute_type(req.result_type, subst),
                        req.receiver_syntax,
                        edge.span,
                    )
                    if self._record_requirement(caller, propagated, edge.span):
                        changed = True

        self.generic_requirements = {fid: tuple(reqs) for fid, reqs in closed.items()}

    def _infer_generic_arg(self, pattern: Type, actual: Type, subst: dict[TypeParamType, Type]) -> bool:
        if isinstance(pattern, RefType) and isinstance(actual, RefType) and pattern.mode == "read" and actual.mode == "write":
            return infer_type_substitution(pattern.inner, actual.inner, subst)
        if isinstance(pattern, SpanType) and isinstance(actual, SpanType) and pattern.mode == "read" and actual.mode == "write":
            return infer_type_substitution(pattern.inner, actual.inner, subst)
        return infer_type_substitution(pattern, actual, subst)

    def instantiate_if_generic(self, fn: FunctionSymbol, args: tuple[TExpr, ...], span) -> FunctionSymbol:
        if not fn.type_params:
            return fn
        if len(args) != len(fn.params):
            self.error("E_ARGUMENT_COUNT", f"{fn.qualified_name} expects {len(fn.params)} arguments, got {len(args)}", span)
        subst: dict[TypeParamType, Type] = {}
        for arg, (_, pattern) in zip(args, fn.params, strict=True):
            if not self._infer_generic_arg(pattern, arg.type, subst):
                self.error("E_GENERIC_INFERENCE", f"cannot infer type parameters for {fn.qualified_name} from {display_type(arg.type)}", arg.span)
        missing = [tp for tp in fn.type_params if tp not in subst]
        if missing:
            self.error("E_GENERIC_INFERENCE", "unbound generic parameter(s): " + ", ".join(tp.name for tp in missing), span)
        type_args = tuple(subst[tp] for tp in fn.type_params)
        if any(contains_type_param(t) for t in type_args):
            # Definition-time symbolic generic-to-generic call. This is not a
            # monomorphization; it only checks the known signature under the
            # caller's symbolic type arguments. The concrete body is rechecked
            # when the outer generic is instantiated. M3.1 also records the
            # symbolic edge so effective dependent requirements can be closed
            # transitively after every generic definition has been checked.
            if self.current_generic_template is not None:
                edge = GenericRequirementEdge(
                    self.current_generic_template.function_id,
                    fn.function_id,
                    tuple((tp, subst[tp]) for tp in fn.type_params),
                    span,
                )
                if edge not in self.generic_requirement_edges:
                    self.generic_requirement_edges.append(edge)
            concrete_params = tuple((name, substitute_type(ty, subst)) for name, ty in fn.params)
            concrete_return = substitute_type(fn.return_type, subst)
            suffix = ",".join(display_type(t) for t in type_args)
            return FunctionSymbol(
                fn.function_id, fn.name, f"{fn.qualified_name}<{suffix}>", fn.owner_module_id, (),
                concrete_params, concrete_return, fn.decl, fn.function_id,
            )
        key = (fn.function_id, type_args)
        cached = self.monomorph_cache.get(key)
        if cached is not None:
            if key in self.monomorph_in_progress:
                # Exact recursion/mutual recursion at the same concrete key is a
                # cycle, not an expansion. The provisional symbol is sufficient
                # for checking the recursive call signature.
                self.monomorph_cycle_hits += 1
            return cached
        if len(self.monomorph_stack) >= self.max_monomorph_depth:
            self.error(
                "E_GENERIC_MONOMORPH_DEPTH",
                f"generic instantiation depth exceeded implementation budget ({self.max_monomorph_depth}) while instantiating {fn.qualified_name}",
                span,
            )
        if len(self.monomorph_cache) >= self.max_monomorphs:
            self.error(
                "E_GENERIC_MONOMORPH_BUDGET",
                f"generic monomorphization exceeded implementation budget ({self.max_monomorphs} instances)",
                span,
            )
        self.monomorph_in_progress.add(key)
        self.monomorph_stack.append(key)
        self.max_monomorph_depth_observed = max(
            self.max_monomorph_depth_observed, len(self.monomorph_stack)
        )
        instance_id = self.next_instance_function_id
        self.next_instance_function_id += 1
        concrete_params = tuple((name, substitute_type(ty, subst)) for name, ty in fn.params)
        concrete_return = substitute_type(fn.return_type, subst)
        suffix = ",".join(display_type(t) for t in type_args)
        instance = FunctionSymbol(
            instance_id,
            fn.name,
            f"{fn.qualified_name}<{suffix}>",
            fn.owner_module_id,
            (),
            concrete_params,
            concrete_return,
            fn.decl,
            fn.function_id,
        )
        self.monomorph_cache[key] = instance
        prev_inst = self.instantiating_template_id
        self.instantiating_template_id = fn.function_id
        bindings = {tp.name: subst[tp] for tp in fn.type_params}
        try:
            typed = self.check_function(fn, type_bindings=bindings, symbol_override=instance)
        except FrontendError:
            self.monomorph_cache.pop(key, None)
            raise
        finally:
            self.instantiating_template_id = prev_inst
            self.monomorph_in_progress.discard(key)
            assert self.monomorph_stack and self.monomorph_stack[-1] == key
            self.monomorph_stack.pop()
        self.monomorph_functions.append(typed)
        return instance

    def select_unqualified(self, name: str, args: tuple[TExpr, ...], span) -> FunctionSymbol:
        # Selection is deliberately independent of argument conversions/weakening.
        if self.current_module is not None and name in self.current_module.functions:
            return self.current_module.functions[name]
        if name in self.symbols.top_functions:
            return self.symbols.top_functions[name]
        if args:
            nominal = dispatch_nominal(args[0].type)
            if nominal is not None:
                fn = self.symbols.module_for_type(nominal).functions.get(name)
                if fn is not None and fn.receiver_capable:
                    return fn
        if self.instantiating_template_id is not None:
            reqs = self.generic_requirements.get(self.instantiating_template_id, ())
            if any(r.name == name and r.span.start == span.start and r.span.end == span.end for r in reqs):
                self.error("E_GENERIC_REQUIREMENT_UNSATISFIED", f"no associated function {name} satisfies the dependent generic requirement", span)
        self.error("E_UNKNOWN_FUNCTION", f"no function named {name}", span)
        raise AssertionError

    def finish_call(self, fn: FunctionSymbol, args: tuple[TExpr, ...], receiver_syntax: bool, span, expected_result: Type | None = None) -> TCall:
        if receiver_syntax and not fn.receiver_capable:
            self.error("E_NOT_RECEIVER_FUNCTION", f"{fn.qualified_name} has no first parameter named self", span)
        if len(args) != len(fn.params):
            self.error("E_ARGUMENT_COUNT", f"{fn.qualified_name} expects {len(fn.params)} arguments, got {len(args)}", span)
        weakenings: list[int] = []
        for i, (arg, (_, expected)) in enumerate(zip(args, fn.params, strict=True)):
            if self.require_compatible(arg.type, expected, arg.span, allow_weakening=True):
                weakenings.append(i)
        if expected_result is not None:
            try:
                self.require_compatible(fn.return_type, expected_result, span, allow_weakening=False)
            except FrontendError as exc:
                if self.instantiating_template_id is not None:
                    self.error("E_GENERIC_REQUIREMENT_RESULT", f"dependent call {fn.name} returns {display_type(fn.return_type)}, expected {display_type(expected_result)}", span)
                raise exc
        return TCall(fn, args, receiver_syntax, fn.return_type, span, tuple(weakenings))

    def require_compatible(self, actual: Type, expected: Type, span, *, allow_weakening: bool) -> bool:
        if actual == NEVER:
            return False
        if actual == expected:
            return False
        if isinstance(actual, IntLiteralType) and expected in {U32, USIZE}:
            return False
        if (
            allow_weakening
            and isinstance(actual, RefType)
            and isinstance(expected, RefType)
            and actual.mode == "write"
            and expected.mode == "read"
            and actual.inner == expected.inner
        ):
            return True
        if (
            allow_weakening
            and isinstance(actual, SpanType)
            and isinstance(expected, SpanType)
            and actual.mode == "write"
            and expected.mode == "read"
            and actual.inner == expected.inner
        ):
            return True
        self.error("E_ARGUMENT_TYPE", f"expected {display_type(expected)}, got {display_type(actual)}", span)
        raise AssertionError

    def resolve_type_name(self, name: str, span) -> NominalType:
        if name == "Self":
            if self.current_module is None:
                self.error("E_SELF_OUTSIDE_MODULE", "Self is only valid in a module", span)
            assert self.current_module is not None
            return self._current_self_type()
        module = self.symbols.modules.get(name)
        if module is None:
            self.error("E_UNKNOWN_TYPE", f"unknown nominal type {name}", span)
        assert module is not None
        if module.type_params:
            self.error("E_GENERIC_TYPE_ARGUMENTS_REQUIRED", f"generic type {name} requires type arguments; use Self inside its module", span)
        return module.nominal

    def require_representation_access(self, owner: ModuleSymbol, span, code: str, verb: str) -> None:
        if self.current_module is None or self.current_module.module_id != owner.module_id:
            self.error(code, f"cannot {verb} private representation of {owner.name} outside module {owner.name}", span)

    def _type_contains_stored_block(self, t: Type, seen: frozenset[Type] | None = None) -> bool:
        """True when a concrete value type would physically contain a nonescaping block.

        Direct function parameters of BlockType remain valid. The prohibition is on
        storing such a value inside an aggregate (including through generic
        substitution), matching SymbolBuilder's direct-field rule.
        """
        if isinstance(t, BlockType):
            return True
        if isinstance(t, TypeParamType):
            return False
        if isinstance(t, (RefType, ExclusiveRefType, PtrType, SlotType, ArrayType, SpanType)):
            return self._type_contains_stored_block(t.inner, seen)
        if isinstance(t, TupleType):
            return any(self._type_contains_stored_block(i, seen) for i in t.items)
        if isinstance(t, (NominalType, SumType)):
            seen = frozenset() if seen is None else seen
            if t in seen:
                return False
            branch_seen = seen | {t}
            if isinstance(t, NominalType):
                module = self.symbols.module_for_type(t)
                subst = self._module_type_subst(module, t)
                return any(
                    self._type_contains_stored_block(substitute_type(f.type, subst), branch_seen)
                    for f in module.fields.values()
                )
            sum_sym = self.symbols.sum_for_type(t)
            subst = self._sum_type_subst(sum_sym, t)
            return any(
                v.payload is not None
                and self._type_contains_stored_block(substitute_type(v.payload, subst), branch_seen)
                for v in sum_sym.variants.values()
            )
        return False

    def _validate_no_block_storage(self, t: Type, span) -> None:
        # A block itself may be a nonescaping function parameter/local. What is
        # forbidden is placing it inside a storable aggregate. Wrapper types are
        # traversed only to find such aggregates; ref<block(...)> alone is not
        # treated as aggregate storage here.
        def invalid(ty: Type, seen: frozenset[Type]) -> bool:
            if isinstance(ty, BlockType):
                return False
            if isinstance(ty, TypeParamType):
                return False
            if isinstance(ty, (RefType, ExclusiveRefType, PtrType, SlotType, SpanType)):
                return invalid(ty.inner, seen)
            if isinstance(ty, ArrayType):
                return self._type_contains_stored_block(ty.inner, seen)
            if isinstance(ty, TupleType):
                return any(self._type_contains_stored_block(i, seen) for i in ty.items)
            if isinstance(ty, (NominalType, SumType)):
                return self._type_contains_stored_block(ty, seen)
            return False

        if invalid(t, frozenset()):
            self.error(
                "E_BLOCK_ESCAPE_TYPE",
                f"nonescaping block value cannot be stored inside {display_type(t)}",
                span,
            )

    def is_copy(self, t: Type, seen: frozenset[Type] | None = None) -> bool:
        if t in {U32, USIZE, UNIT}:
            return True
        if isinstance(t, AccessModeType):
            return True
        if isinstance(t, (RefType, PtrType, LayoutType, SpanType, BlockType)):
            return True
        if isinstance(t, ExclusiveRefType):
            return False
        if isinstance(t, SlotType) or t in {LIFETIME_DOMAIN, ALLOCATION, STORAGE}:
            return False
        if isinstance(t, ArrayType):
            return self.is_copy(t.inner, seen)
        if isinstance(t, TupleType):
            return all(self.is_copy(i, seen) for i in t.items)
        if isinstance(t, SumType):
            seen = frozenset() if seen is None else seen
            if t in seen:
                return False
            branch_seen = seen | {t}
            sum_sym = self.symbols.sum_for_type(t)
            subst = self._sum_type_subst(sum_sym, t)
            return all(
                v.payload is None or self.is_copy(substitute_type(v.payload, subst), branch_seen)
                for v in sum_sym.variants.values()
            )
        if isinstance(t, NominalType):
            seen = frozenset() if seen is None else seen
            if t in seen:
                return False
            branch_seen = seen | {t}
            module = self.symbols.module_for_type(t)
            subst = self._module_type_subst(module, t)
            return all(
                self.is_copy(substitute_type(f.type, subst), branch_seen)
                for f in module.fields.values()
            )
        return False

    def is_discardable(self, t: Type, seen: frozenset[Type] | None = None) -> bool:
        if t in {U32, USIZE, UNIT}:
            return True
        if isinstance(t, AccessModeType):
            return True
        if isinstance(t, (RefType, ExclusiveRefType, PtrType, LayoutType, SpanType, BlockType)):
            return True
        if isinstance(t, SlotType) or t in {LIFETIME_DOMAIN, ALLOCATION, STORAGE}:
            return False
        if isinstance(t, ArrayType):
            return self.is_discardable(t.inner, seen)
        if isinstance(t, TupleType):
            return all(self.is_discardable(i, seen) for i in t.items)
        if isinstance(t, SumType):
            seen = frozenset() if seen is None else seen
            if t in seen:
                return False
            branch_seen = seen | {t}
            sum_sym = self.symbols.sum_for_type(t)
            subst = self._sum_type_subst(sum_sym, t)
            return all(
                v.payload is None or self.is_discardable(substitute_type(v.payload, subst), branch_seen)
                for v in sum_sym.variants.values()
            )
        if isinstance(t, NominalType):
            seen = frozenset() if seen is None else seen
            if t in seen:
                return False
            branch_seen = seen | {t}
            module = self.symbols.module_for_type(t)
            subst = self._module_type_subst(module, t)
            return all(
                self.is_discardable(substitute_type(f.type, subst), branch_seen)
                for f in module.fields.values()
            )
        return False

    @staticmethod
    def error(code: str, message: str, span) -> None:
        raise FrontendError(Diagnostic(code, message, span))
