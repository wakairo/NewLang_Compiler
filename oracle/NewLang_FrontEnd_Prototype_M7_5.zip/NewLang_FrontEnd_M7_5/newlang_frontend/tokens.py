from __future__ import annotations

from dataclasses import dataclass
from enum import Enum, auto

from .source import Span


class TokenKind(Enum):
    IDENT = auto()
    INT = auto()
    NEWLINE = auto()
    EOF = auto()

    MODULE = auto()
    STRUCT = auto()
    SUM = auto()
    FN = auto()
    LET = auto()
    END = auto()
    SELF_TYPE = auto()
    SELF_VALUE = auto()
    LOAN = auto()
    READ = auto()
    WRITE = auto()
    EXCLUSIVE = auto()
    AS = auto()
    UNIT = auto()
    MATCH = auto()
    BLOCK = auto()
    LOOP = auto()
    CONTINUE = auto()
    BREAK = auto()

    LBRACE = auto()
    RBRACE = auto()
    LPAREN = auto()
    RPAREN = auto()
    LBRACKET = auto()
    RBRACKET = auto()
    LT = auto()
    GT = auto()
    COLON = auto()
    COMMA = auto()
    EQ = auto()
    DOT = auto()
    AT = auto()
    PIPE = auto()
    DCOLON = auto()
    ARROW = auto()
    FATARROW = auto()


KEYWORDS = {
    "module": TokenKind.MODULE,
    "struct": TokenKind.STRUCT,
    "sum": TokenKind.SUM,
    "fn": TokenKind.FN,
    "let": TokenKind.LET,
    "end": TokenKind.END,
    "Self": TokenKind.SELF_TYPE,
    "self": TokenKind.SELF_VALUE,
    "loan": TokenKind.LOAN,
    "read": TokenKind.READ,
    "write": TokenKind.WRITE,
    "exclusive": TokenKind.EXCLUSIVE,
    "as": TokenKind.AS,
    "unit": TokenKind.UNIT,
    "match": TokenKind.MATCH,
    "block": TokenKind.BLOCK,
}


@dataclass(frozen=True, slots=True)
class Token:
    kind: TokenKind
    text: str
    span: Span
