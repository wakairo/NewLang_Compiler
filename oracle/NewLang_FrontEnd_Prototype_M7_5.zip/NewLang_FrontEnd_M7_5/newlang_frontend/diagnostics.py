from __future__ import annotations

from dataclasses import dataclass

from .source import Span


@dataclass(frozen=True, slots=True)
class Diagnostic:
    code: str
    message: str
    span: Span

    def render(self) -> str:
        line, col = self.span.start_line_col
        source_line = self.span.source.text.splitlines()[line - 1] if self.span.source.text.splitlines() else ""
        width = max(1, self.span.end - self.span.start)
        caret = " " * (col - 1) + "^" * min(width, max(1, len(source_line) - col + 1))
        return f"{self.span.source.name}:{line}:{col}: {self.code}: {self.message}\n{source_line}\n{caret}"


class FrontendError(Exception):
    def __init__(self, diagnostic: Diagnostic):
        super().__init__(diagnostic.message)
        self.diagnostic = diagnostic
