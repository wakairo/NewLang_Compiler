from __future__ import annotations

from dataclasses import dataclass
from itertools import product
from typing import Iterable, Literal

SemanticEffect = Literal["none", "change", "endroot", "unknown"]
Retention = Literal["no", "yes", "unknown"]
CallbackMode = Literal["none", "sync", "retain", "unknown"]
ControlMode = Literal["return", "nonlocal", "unknown"]
MemoryAccess = Literal["none", "read", "readwrite", "unknown"]


@dataclass(frozen=True)
class Exposure:
    """NewLang semantic facts that a foreign call can affect or outlive."""

    value_dependency: bool = False
    root_must_remain_live: bool = False
    borrowed_location: bool = False
    nonescaping_callback: bool = False


@dataclass(frozen=True)
class ForeignSummary:
    """Compiler-internal foreign-call contract, not proposed source syntax."""

    semantic_effect: SemanticEffect = "unknown"
    retention: Retention = "unknown"
    callback: CallbackMode = "unknown"
    control: ControlMode = "unknown"
    memory_access: MemoryAccess = "unknown"


@dataclass(frozen=True)
class ConcreteSummary:
    semantic_effect: Literal["none", "change", "endroot"]
    retains_location: bool
    callback: Literal["none", "sync", "retain"]
    nonlocal_exit: bool


def concrete_safe(exposure: Exposure, summary: ConcreteSummary) -> bool:
    """Small exact oracle for the M7.5 boundary model."""

    if summary.semantic_effect == "change" and exposure.value_dependency:
        return False
    if summary.semantic_effect == "endroot" and exposure.root_must_remain_live:
        return False
    if summary.retains_location and exposure.borrowed_location:
        return False
    if summary.callback == "retain" and exposure.nonescaping_callback:
        return False
    # v0 does not admit foreign unwind/longjmp/non-local transfer across the
    # checked boundary. This is deliberately stronger than LLVM nounwind.
    if summary.nonlocal_exit:
        return False
    return True


def _possible_effects(value: SemanticEffect) -> tuple[str, ...]:
    if value == "unknown":
        return ("none", "change", "endroot")
    return (value,)


def _possible_bools(value: Retention) -> tuple[bool, ...]:
    if value == "unknown":
        return (False, True)
    return (value == "yes",)


def _possible_callbacks(value: CallbackMode) -> tuple[str, ...]:
    if value == "unknown":
        return ("none", "sync", "retain")
    return (value,)


def _possible_control(value: ControlMode) -> tuple[bool, ...]:
    if value == "unknown":
        return (False, True)
    return (value == "nonlocal",)


def concrete_refinements(summary: ForeignSummary) -> Iterable[ConcreteSummary]:
    for effect, retain, callback, nonlocal_exit in product(
        _possible_effects(summary.semantic_effect),
        _possible_bools(summary.retention),
        _possible_callbacks(summary.callback),
        _possible_control(summary.control),
    ):
        yield ConcreteSummary(effect, retain, callback, nonlocal_exit)  # type: ignore[arg-type]


def oracle_accept(exposure: Exposure, summary: ForeignSummary) -> bool:
    """Accept iff every concrete behavior admitted by the summary is safe."""

    return all(concrete_safe(exposure, c) for c in concrete_refinements(summary))


def checked_accept(exposure: Exposure, summary: ForeignSummary) -> bool:
    """Finite symbolic checker to differential-test against ``oracle_accept``."""

    if summary.semantic_effect in {"change", "unknown"} and exposure.value_dependency:
        return False
    if summary.semantic_effect in {"endroot", "unknown"} and exposure.root_must_remain_live:
        return False
    if summary.retention in {"yes", "unknown"} and exposure.borrowed_location:
        return False
    if summary.callback in {"retain", "unknown"} and exposure.nonescaping_callback:
        return False
    if summary.control != "return":
        return False
    return True


@dataclass(frozen=True)
class BackendProofs:
    """Proof origins that may justify LLVM attributes independently."""

    pointer_no_provenance_capture: bool = False
    no_exception_unwind: bool = False
    no_callback_into_module: bool = False


def llvm_lowering_attributes(summary: ForeignSummary, proofs: BackendProofs) -> tuple[str, ...]:
    """Return only LLVM promises justified by matching backend facts.

    NewLang semantic effects are intentionally *not* converted into LLVM memory
    attributes. The two facts have different proof origins.
    """

    attrs: list[str] = []
    if summary.memory_access == "none":
        attrs.append("memory(none)")
    elif summary.memory_access == "read":
        attrs.append("memory(read)")
    # readwrite / unknown: omission is the conservative LLVM representation.

    if proofs.pointer_no_provenance_capture:
        attrs.append("captures(none)")
    if proofs.no_exception_unwind:
        attrs.append("nounwind")
    if proofs.no_callback_into_module:
        attrs.append("nocallback")
    return tuple(attrs)


@dataclass(frozen=True)
class BackingRegion:
    name: str
    abstract_backing: str
    start: int
    size: int

    @property
    def end(self) -> int:
        return self.start + self.size


@dataclass(frozen=True)
class OpaqueExternalView:
    name: str
    abstract_backing: str
    start: int
    size: int


class ExternalBackingRegistry:
    """Model the ordinary-safe BackingRegion import obligation."""

    def __init__(self) -> None:
        self.safe_regions: list[BackingRegion] = []
        self.opaque_views: list[OpaqueExternalView] = []

    def import_safe(
        self,
        *,
        name: str,
        abstract_backing: str,
        start: int,
        size: int,
        liveness_proven: bool,
        alignment_proven: bool,
        access_proven: bool,
        nonalias_proven: bool,
    ) -> BackingRegion:
        if size <= 0:
            raise ValueError("safe external backing requires a non-empty range")
        if not all((liveness_proven, alignment_proven, access_proven, nonalias_proven)):
            raise ValueError("external safe-backing proof obligation not established")
        candidate = BackingRegion(name, abstract_backing, start, size)
        for region in self.safe_regions:
            if region.abstract_backing != candidate.abstract_backing:
                continue
            if max(region.start, candidate.start) < min(region.end, candidate.end):
                raise ValueError("distinct live safe BackingRegions would overlap abstract bytes")
        self.safe_regions.append(candidate)
        return candidate

    def import_opaque(self, *, name: str, abstract_backing: str, start: int, size: int) -> OpaqueExternalView:
        if size <= 0:
            raise ValueError("opaque external view requires a non-empty range")
        view = OpaqueExternalView(name, abstract_backing, start, size)
        self.opaque_views.append(view)
        return view


@dataclass(frozen=True)
class ForeignInitEvidence:
    representation_complete: bool
    semantic_package_complete: bool
    semantic_package_trivial: bool
    raw_location_retained: bool


def can_start_foreign_initialized_root(evidence: ForeignInitEvidence) -> bool:
    """Whether a privileged boundary may create the first safe ptr<T>."""

    if not evidence.representation_complete:
        return False
    if evidence.raw_location_retained:
        return False
    if not (evidence.semantic_package_trivial or evidence.semantic_package_complete):
        return False
    return True
