from __future__ import annotations

import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

_VENDOR = Path(__file__).resolve().parent.parent / "vendor"
if str(_VENDOR) not in sys.path:
    sys.path.insert(0, str(_VENDOR))

from newlang_checker.ir import Effect  # type: ignore[import-not-found]
from newlang_checker.source_ir import (  # type: ignore[import-not-found]
    AddDepStmt,
    CallStmt,
    EffectStmt,
    ExactSourceRunner,
    FunctionDef,
    IfStmt,
    KillDepStmt,
    LoopStmt,
    SourceProgram,
    Stmt,
)

from .place import Place
from .recursive_summary import infer_semantic_effect_summaries
from .source import Span
from .typed_ir import (
    TBuiltinCall,
    TBlockInvoke,
    TBlockLiteral,
    TCall,
    TExpr,
    TExprStmt,
    TField,
    TFunction,
    TIndex,
    TInt,
    TLet,
    TLoan,
    TLoop,
    TContinue,
    TBreak,
    TMatch,
    TName,
    TProgram,
    TStructLiteral,
    TSumConstruct,
)
from .typesys import ArrayType, BlockType, ExclusiveRefType, RefType, SumType


@dataclass(frozen=True, slots=True)
class SemanticOutcome:
    accepted: bool
    reason: str
    origin: Span | None = None


@dataclass(frozen=True, slots=True)
class CallbackBinding:
    block: TBlockLiteral
    capture_aliases: dict[str, Place]


PlaceAliases = dict[str, Place]
CallbackBindings = dict[str, CallbackBinding]


def _constant_index(expr: TExpr) -> str:
    if isinstance(expr, TBuiltinCall) and expr.name == "usize" and len(expr.args) == 1 and isinstance(expr.args[0], TInt):
        return str(expr.args[0].value)
    if isinstance(expr, TInt):
        return str(expr.value)
    return "*"


def place_of(expr: TExpr, aliases: PlaceAliases) -> Place | None:
    if isinstance(expr, TField):
        base = place_of(expr.base, aliases)
        return None if base is None else base.field(expr.field.name)
    if isinstance(expr, TIndex):
        base = place_of(expr.base, aliases)
        return None if base is None else base.index(_constant_index(expr.index))
    if isinstance(expr, TName):
        return aliases.get(expr.name, Place(expr.name))
    return None


def _semantic_actual_places(expr: TCall, aliases: PlaceAliases) -> tuple[str | None, ...]:
    out: list[str | None] = []
    for arg, (_, formal_type) in zip(expr.args, expr.function.params, strict=True):
        place = place_of(arg, aliases) if isinstance(formal_type, (RefType, ExclusiveRefType)) else None
        out.append(None if place is None else place.render())
    return tuple(out)


def _inline_callback(
    binding: CallbackBinding,
    args: tuple[TExpr, ...],
    caller_aliases: PlaceAliases,
    functions: dict[int, TFunction],
    callbacks: CallbackBindings,
    depth: int,
) -> list[Stmt]:
    block = binding.block
    child = dict(binding.capture_aliases)
    for index, ((name, ty), arg) in enumerate(zip(block.params, args, strict=True)):
        if isinstance(ty, (RefType, ExclusiveRefType)):
            actual = place_of(arg, caller_aliases)
            child[name] = actual if actual is not None else Place(f"@callback-ref:{depth}:{index}:{name}")
        else:
            child[name] = Place(f"@callback-value:{depth}:{index}:{name}")
    return lower_block(block.body, child, functions, callbacks, depth + 1)


def _lower_consume_array(
    expr: TBuiltinCall,
    aliases: PlaceAliases,
    functions: dict[int, TFunction],
    callbacks: CallbackBindings,
    depth: int,
) -> list[Stmt]:
    array, callback = expr.args
    out = lower_expr(array, aliases, functions, callbacks, depth)
    if not isinstance(array.type, ArrayType):
        return out
    binding: CallbackBinding | None = None
    if isinstance(callback, TBlockLiteral):
        binding = CallbackBinding(callback, dict(aliases))
    elif isinstance(callback, TName):
        binding = callbacks.get(callback.name)
    if binding is None:
        out.append(EffectStmt(Effect("Unknown", "*"), expr.span))
        return out
    for i in range(array.type.length):
        # Element transfer is by value. The callback receives a fresh parameter;
        # captured aliases still point to caller state.
        fake = TName(f"@element{i}", array.type.inner, expr.span)
        out.extend(_inline_callback(binding, (fake,), aliases, functions, callbacks, depth + 1))
    return out


def _inline_function_with_callbacks(
    expr: TCall,
    aliases: PlaceAliases,
    functions: dict[int, TFunction],
    callbacks: CallbackBindings,
    depth: int,
) -> list[Stmt]:
    if depth > 24:
        return [EffectStmt(Effect("Unknown", "*"), expr.span)]
    callee = functions[expr.function.function_id]
    out: list[Stmt] = []
    for arg in expr.args:
        out.extend(lower_expr(arg, aliases, functions, callbacks, depth + 1))
    child_aliases: PlaceAliases = {}
    child_callbacks: CallbackBindings = {}
    for i, (arg, (formal_name, formal_type)) in enumerate(zip(expr.args, callee.symbol.params, strict=True)):
        if isinstance(formal_type, BlockType):
            if isinstance(arg, TBlockLiteral):
                child_callbacks[formal_name] = CallbackBinding(arg, dict(aliases))
            elif isinstance(arg, TName) and arg.name in callbacks:
                child_callbacks[formal_name] = callbacks[arg.name]
            else:
                return out + [EffectStmt(Effect("Unknown", "*"), expr.span)]
        elif isinstance(formal_type, (RefType, ExclusiveRefType)):
            actual = place_of(arg, aliases)
            child_aliases[formal_name] = actual if actual is not None else Place(f"@inline-ref:{depth}:{i}:{formal_name}")
        else:
            child_aliases[formal_name] = Place(f"@inline-value:{depth}:{i}:{formal_name}")
    return out + lower_block(callee.body, child_aliases, functions, child_callbacks, depth + 1)


def lower_expr(
    expr: TExpr,
    aliases: PlaceAliases,
    functions: dict[int, TFunction],
    callbacks: CallbackBindings,
    depth: int = 0,
) -> list[Stmt]:
    out: list[Stmt] = []
    if isinstance(expr, TCall):
        if any(isinstance(t, BlockType) for _, t in expr.function.params):
            return _inline_function_with_callbacks(expr, aliases, functions, callbacks, depth)
        for arg in expr.args:
            out.extend(lower_expr(arg, aliases, functions, callbacks, depth))
        out.append(CallStmt(expr.function.qualified_name, _semantic_actual_places(expr, aliases), expr.span))
    elif isinstance(expr, TBlockInvoke):
        for arg in expr.args:
            out.extend(lower_expr(arg, aliases, functions, callbacks, depth))
        if isinstance(expr.callee, TName) and expr.callee.name in callbacks:
            out.extend(_inline_callback(callbacks[expr.callee.name], expr.args, aliases, functions, callbacks, depth))
        else:
            out.append(EffectStmt(Effect("Unknown", "*"), expr.span))
    elif isinstance(expr, TBuiltinCall):
        if expr.name == "consume_array":
            return _lower_consume_array(expr, aliases, functions, callbacks, depth)
        for arg in expr.args:
            out.extend(lower_expr(arg, aliases, functions, callbacks, depth))
        if expr.name in {"store", "replace"}:
            destination = place_of(expr.args[0], aliases)
            if destination is None:
                raise AssertionError(f"{expr.name} destination lost its semantic place")
            rendered = destination.render()
            out.append(EffectStmt(Effect("Change", rendered), expr.span))
            dst_type = expr.args[0].type
            if isinstance(dst_type, RefType) and isinstance(dst_type.inner, SumType):
                out.append(EffectStmt(Effect("Reset", rendered), expr.span))
        elif expr.name == "swap":
            left = place_of(expr.args[0], aliases)
            right = place_of(expr.args[1], aliases)
            if left is None or right is None:
                raise AssertionError("swap destination lost its semantic place")
            # Draft 17.3 same-place swap is a semantic no-op.  Otherwise both
            # current-value facts change simultaneously.
            if left != right:
                for arg, place in zip(expr.args, (left, right), strict=True):
                    rendered = place.render()
                    out.append(EffectStmt(Effect("Change", rendered), expr.span))
                    if isinstance(arg.type, RefType) and isinstance(arg.type.inner, SumType):
                        out.append(EffectStmt(Effect("Reset", rendered), expr.span))
    elif isinstance(expr, (TField, TIndex)):
        out.extend(lower_expr(expr.base, aliases, functions, callbacks, depth))
        if isinstance(expr, TIndex):
            out.extend(lower_expr(expr.index, aliases, functions, callbacks, depth))
    elif isinstance(expr, TStructLiteral):
        for _, value in expr.fields:
            out.extend(lower_expr(value, aliases, functions, callbacks, depth))
    elif isinstance(expr, TSumConstruct):
        if expr.payload is not None:
            out.extend(lower_expr(expr.payload, aliases, functions, callbacks, depth))
    elif isinstance(expr, TLoan):
        out.extend(lower_expr(expr.source, aliases, functions, callbacks, depth))
        source_place = place_of(expr.source, aliases)
        child_aliases = dict(aliases)
        child_aliases[expr.binding] = source_place if source_place is not None else Place(expr.binding)
        out.extend(lower_block(expr.body, child_aliases, functions, callbacks, depth))
    elif isinstance(expr, TLoop):
        child = dict(aliases)
        for param in expr.params:
            out.extend(lower_expr(param.initial, aliases, functions, callbacks, depth))
            initial_place = place_of(param.initial, aliases)
            child[param.name] = initial_place if initial_place is not None else Place(param.name)
        body = tuple(lower_block(expr.body, child, functions, callbacks, depth + 1))
        out.append(LoopStmt(body, max_exact_iterations=3, include_zero_iterations=False))
    elif isinstance(expr, TContinue):
        for arg in expr.args:
            out.extend(lower_expr(arg, aliases, functions, callbacks, depth))
    elif isinstance(expr, TBreak):
        if expr.value is not None:
            out.extend(lower_expr(expr.value, aliases, functions, callbacks, depth))
    elif isinstance(expr, TMatch):
        out.extend(lower_expr(expr.value, aliases, functions, callbacks, depth))
        parent = place_of(expr.value, aliases)
        ref_sum = isinstance(expr.value.type, RefType) and isinstance(expr.value.type.inner, SumType)
        branches: list[tuple[Stmt, ...]] = []
        for arm in expr.arms:
            branch: list[Stmt] = []
            child = dict(aliases)
            dep = parent.render() if ref_sum and parent is not None else None
            if dep is not None:
                branch.append(AddDepStmt(dep, arm.span))
            if arm.binding is not None:
                name, _ = arm.binding
                if parent is not None:
                    child[name] = parent.field(f"$payload:{arm.variant.name}")
            branch.extend(lower_block(arm.body, child, functions, callbacks, depth))
            if dep is not None:
                branch.append(KillDepStmt(dep, arm.span))
            branches.append(tuple(branch))
        out.append(IfStmt(tuple(branches)))
    elif isinstance(expr, TBlockLiteral):
        pass
    return out


def lower_block(
    block,
    aliases: PlaceAliases,
    functions: dict[int, TFunction],
    callbacks: CallbackBindings,
    depth: int = 0,
) -> list[Stmt]:
    out: list[Stmt] = []
    local_aliases = dict(aliases)
    for stmt in block.statements:
        if isinstance(stmt, TLet):
            out.extend(lower_expr(stmt.value, local_aliases, functions, callbacks, depth))
            for name, _ in stmt.bindings:
                local_aliases[name] = Place(name)
        elif isinstance(stmt, TExprStmt):
            out.extend(lower_expr(stmt.expr, local_aliases, functions, callbacks, depth))
    if block.tail is not None:
        out.extend(lower_expr(block.tail, local_aliases, functions, callbacks, depth))
    return out


def lower_program(program: TProgram) -> SourceProgram:
    by_id = {fn.symbol.function_id: fn for fn in program.functions}
    functions = {}
    for fn in program.functions:
        param_aliases = {name: Place(name) for name, _ in fn.symbol.params}
        functions[fn.symbol.qualified_name] = FunctionDef(
            fn.symbol.qualified_name,
            tuple(lower_block(fn.body, param_aliases, by_id, {}, 0)),
            tuple(name for name, _ in fn.symbol.params),
        )
    summaries, _ = infer_semantic_effect_summaries(functions)
    return SourceProgram(functions, function_summaries=summaries)


def run_semantic_detailed(
    program: TProgram,
    entry: str = "main",
    initial_deps: Iterable[str] = (),
) -> SemanticOutcome:
    lowered = lower_program(program)
    if entry not in lowered.functions:
        return SemanticOutcome(False, f"missing semantic entry {entry}")
    result = ExactSourceRunner(lowered).run(entry, initial_deps)
    if result.exact_accepts:
        return SemanticOutcome(True, "exact Draft-17.2 source semantic runner accepted")
    rejected = next((path for path in result.paths if path.rejected), None)
    if rejected is None:
        return SemanticOutcome(False, "semantic checker rejected")
    origin = rejected.rejection_origin if isinstance(rejected.rejection_origin, Span) else None
    return SemanticOutcome(False, rejected.reason or "semantic checker rejected", origin)


def run_semantic(
    program: TProgram,
    entry: str = "main",
    initial_deps: Iterable[str] = (),
) -> tuple[bool, str]:
    outcome = run_semantic_detailed(program, entry, initial_deps)
    return outcome.accepted, outcome.reason
