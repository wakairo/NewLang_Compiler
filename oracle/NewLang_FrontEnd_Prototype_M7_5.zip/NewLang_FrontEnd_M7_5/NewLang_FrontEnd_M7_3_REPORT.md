# NewLang Front-End Prototype M7.3 Report

## 1. Scope

M7.3 is the backend-contract milestone of the C-substitutability phase.

It falsifies the tempting lowering:

```text
ref<write,T> -> LLVM ptr noalias
```

and establishes a conservative v0.1 mapping for:

- `ref<read,T>`;
- `ref<write,T>`;
- source `exclusive ref`;
- persistent locator capture from refs;
- LLVM alias-scope metadata;
- target-sensitive dereferenceability/non-null assumptions;
- NewLang typed-object lifetime versus LLVM stack lifetime intrinsics.

No new NewLang source mechanism is introduced.

## 2. Direct source evidence: write refs may alias

Existing source fixture:

```text
13_semantic_aliased_actuals_conflict.nl
```

passes the same `ref<write,Box>` as both `self` and `other`.  It is accepted.

Therefore `ref<write,T>` cannot mean restrict/noalias-style exclusive access.

M7.3 preserves the existing principle:

```text
write permission != exclusivity
```

## 3. LLVM noalias destructive probe

`backend_probe/m7_3_noalias_probe.ll` contains two otherwise identical functions.

One uses ordinary pointer parameters.  The other incorrectly annotates both parameters `noalias`.  The caller deliberately aliases the arguments, matching behavior NewLang ordinary write refs permit.

Local probe (Clang 17):

```text
-O0 combined exit: 202
-O2 combined exit: 201
```

The `-O2` optimized IR replaces the noalias function's final load with:

```text
ret i32 1
```

while the ordinary-pointer function must still load after the second store.

This demonstrates that an unjustified noalias annotation is semantic, not merely an optimization hint.  A NewLang frontend that emitted it would turn a defined source program into LLVM UB.

## 4. Read ref lowering

LLVM `readonly` is a weaker and appropriate baseline fact for a read-ref parameter.  It forbids writes through the pointer argument but does not assert non-aliasing.

`backend_probe/m7_3_readonly_probe.ll` aliases a readonly pointer with a writer pointer.  At `-O2` the read observes the writer's update and exits with `2`.

Baseline:

```text
ref<read,T>  -> may use readonly
ref<read,T>  -> no noalias by type
ref<write,T> -> no readonly/writeonly/noalias by type
```

`ref<write>` is not `writeonly`, because NewLang write refs can be read/weakened.

## 5. Exclusive authority is not automatically LLVM noalias

Source `exclusive ref` is a NewLang resource/authority property.  LLVM parameter `noalias` is a dynamic access-set contract.

M7.3 therefore requires a distinct checked backend fact before `noalias` may be emitted:

```text
proven_access_exclusive(range, dynamic_extent)
```

The source type spelling alone is insufficient.

This leaves room for a future Checked MIR to derive noalias where it really is true, without changing NewLang's source permission model.

## 6. Nonescaping ref is not LLVM nocapture

New fixture:

```text
241_ref_locator_capture_ok.nl
```

contains:

```text
fn save_locator(value: ref<read,Box>) -> ptr<Box> {
  ptr_from_ref(value)
}
```

and is accepted.

Thus ref capability lifetime is scoped, while persistent pointer provenance can escape.  `captures(none)` / nocapture-like facts must be inferred from the body, not the source ref type.

## 7. Dereferenceable/non-null policy

M7.3 deliberately does not attach baseline `dereferenceable(N)`/`nonnull` from ref type alone.

Current LLVM semantics make `dereferenceable(N)` imply non-null in addrspace(0) unless the function uses `null_pointer_is_valid`.  NewLang intends to cover embedded/bare-metal targets and does not yet have a fixed target policy that excludes address-zero objects.

The backend may add dereferenceability later when target lowering owns:

```text
positive concrete extent
address space
null-address policy
program point
```

## 8. LLVM lifetime intrinsics are not NewLang typed lifetime

Current LLVM LangRef restricts `llvm.lifetime.start/end` to `alloca` or `llvm.structured.alloca` stack objects.

Therefore NewLang:

```text
initialize heap/raw slot<T>
take
destroy
semantic incarnation end/restart
```

must not lower to those intrinsics in general.

They remain available for compiler stack storage when the stack allocation lifetime itself matches exactly.

## 9. Alias metadata

`alias.scope`/`noalias` instruction metadata is also a UB-producing alias promise.  It is emitted only from a separately proven disjoint-access fact, not ordinary `ref` kinds.

M7.3 adds an executable `backend_contract.py` model recording this rule.

## 10. Validation

Final M7.3 front-end tree:

```text
pytest:      436 / 436 PASS
compileall:  PASS
```

Measured in this prototype environment:

```text
full pytest elapsed: ~8.9 s
peak RSS:            ~138 MB
```

Independent Draft 17.2 closure, fresh extraction:

```text
pytest:      110 / 110 PASS
generated:   100,000 cases
mismatch:    0
false accept:0
false reject:0
```

M7.2/M7.1/M7 generated result files were rerun and exactly matched their published baselines.

## 11. M7.3 contract summary

```text
ptr<T>
    -> locator; no dereferenceability/alias promise by type

ref<read,T>
    -> may use readonly
    -> not noalias

ref<write,T>
    -> ordinary read/write access
    -> not noalias
    -> not writeonly

exclusive ref<...>
    -> source authority only
    -> noalias only with separate checked access-exclusivity proof

ref nonescape
    -> does not imply provenance nocapture

semantic object lifetime
    -> does not generally map to llvm.lifetime.*

alias.scope/noalias metadata
    -> only from proven disjoint access sets
```

## 12. Design conclusion

M7.3 is a **PASS**.

The existing NewLang principle `write != exclusive` survives contact with LLVM, but it creates a concrete production-backend obligation: Checked MIR must preserve access exclusivity as an optional fact independent of source ref mode.

No source-language change or Draft 17.4 revision is required solely by M7.3.

The most important backend rule is now explicit and executable:

> Never strengthen a NewLang capability into an LLVM UB-producing alias promise merely because the source type name sounds stronger.

## 13. Remaining M7 closure work

The next backend/C-substitutability pressures are:

1. C ABI / calling convention / by-value aggregate boundary;
2. FFI / external backing / opaque-call summary boundary.

After those, consolidate M7 into a backend/interop closure and begin the planned C implementation spine when useful (M8 or M9; no need to rush).
