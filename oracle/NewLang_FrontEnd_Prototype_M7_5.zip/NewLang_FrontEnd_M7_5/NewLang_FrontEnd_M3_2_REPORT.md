# NewLang Front-End Prototype M3.2 — Recursive Semantic/Lifecycle SCC Closure Report

> Status: **completed M3.2 implementation-quality closure**
>
> Semantic baseline: `NewLang_v0_spec_Draft17_2.md`
>
> Starting point: Front-End Prototype M3.1
>
> Purpose: close the recursion boundary exposed by M3.1 once, at the shared interprocedural semantic/lifecycle layer, rather than adding generic-specific recursion exceptions.

---

## 1. Executive result

M3.2 closes the first real-source recursion boundary without adding new NewLang source syntax or a source-visible effect/lifetime system.

M3.1 had already shown that recursive generic **instantiation** itself can be finite:

```text
loop<u32> -> loop<u32>

a<u32> -> b<u32> -> a<u32>
```

reuse exact monomorph keys.

But after type checking, two later bridges still treated recursion as an implementation boundary:

```text
semantic source runner:
    recursive call -> Unknown("*")

exact / production lifecycle bridges:
    recursive call -> body inline until call-depth limit
```

M3.2 separates three cases:

```text
1. recursive caller-visible semantic effects
   -> finite SCC may-effect summary

2. lifecycle-neutral recursive SCC
   -> finite recursion summary; no resource-state transition is invented

3. dependency-post-state / resource-transforming / identity-bearing recursion
   -> explicit precision boundary, never assumed empty
```

No Draft-18-level semantic redesign was required.

---

## 2. Why the M3.1 boundary was broader than generics

The M3.1 failure appeared first on generic recursion because generic pressure tests exercised recursion directly.

The actual problem was not generic lookup or monomorphization.

After monomorphization, the same front-end representations are used by ordinary and generic functions:

```text
TFunction / TCall
    ↓
shared semantic lowering
    ↓
shared lifecycle bridges
```

Therefore a generic-only recursion workaround would have duplicated semantics and hidden the ordinary-recursion defect.

M3.2 instead implements shared recursion analysis used by both kinds of function.

---

## 3. Semantic recursion: finite caller-visible may-effect summaries

The shared source semantic IR already represents caller-visible invalidation as:

```text
Change(P)
Reset(P)
EndRoot(P)
Unknown
```

and function calls carry formal-to-actual place substitution.

M3.2 adds compiler-inferred `function_summaries` to `SourceProgram`.

For an SCC such as:

```text
A(x):
    Change(x.left)
    B(x)

B(x):
    Reset(x.right)
    A(x)
```

the least finite may-effect fixed point is:

```text
summary(A) = {
    Change(x.left),
    Reset(x.right),
}

summary(B) = {
    Change(x.left),
    Reset(x.right),
}
```

When the exact runner reaches an already-active callee, it applies that summary after ordinary formal/actual substitution instead of inserting `Unknown("*")`.

Non-recursive calls remain body-sensitive and ordered exactly as before.

---

## 4. Recursive effect summaries do not launder dependencies

M3.2 adds a real-source recursive effect case:

```text
fn recursive_set(x: ref<write,Box>) -> unit {
    recursive_set(x)
    Box::set(x)
}
```

where `Box::set` performs:

```text
Change(x.value)
```

With no caller dependency, the program is accepted.

With the test-only injected live dependency:

```text
box.value
```

the recursive call summary substitutes:

```text
Change(x.value)
    -> Change(box.value)
```

and the program is rejected with:

```text
E_SEMANTIC_CONFLICT
```

So recursion is not a semantic laundering boundary.

The former M3.1 program:

```text
108_generic_effectful_recursion_precision_error.nl
```

is consequently renamed:

```text
108_generic_effectful_recursion_ok.nl
```

It now passes normally, while the injected dependency regression still rejects.

---

## 5. Summary growth itself can be recursive

A recursive summary domain is only useful if the compiler also terminates.

The destructive unit case:

```text
summary body:
    Change(x.value)
    call self(x.next)
```

induces:

```text
Change(x.value)
Change(x.next.value)
Change(x.next.next.value)
...
```

A naive set-union fixpoint does not converge.

M3.2 therefore gives semantic summary inference a finite implementation budget:

```text
max_effects_per_function = 64   # prototype default
max_scc_iterations       = 128  # prototype default
```

If the effect graph exceeds the finite domain, the SCC widens to:

```text
Unknown
```

This is a compiler precision/resource rule, not NewLang source semantics.

The important invariant is:

> failure to obtain a finite summary never becomes permission.

---

## 6. Dependency post-state is not approximated as empty

The effect-only summary intentionally does **not** claim to model:

```text
AddDep
KillDep
callback result dependencies
unresolved generic semantic post-state
```

If a recursive SCC contains such state, its summary becomes `Unknown`.

M3.2 adds both a direct shared-IR destructive test and a real `.nl` case using occurrence-sensitive `match` dependencies:

```text
114_recursive_dependency_poststate_error.nl
```

It remains conservatively rejected rather than treating recursive dependency post-state as empty.

This is consistent with the Draft 17.2 rule that unknown post-state must not be treated as dependency-free.

---

## 7. Lifecycle recursion is a different abstraction problem

Semantic may-effects are set-like.

Lifecycle transitions are relational:

```text
input identities / slots / domains / ptrs
    ->
post-state identities / occupancy / authority / returned handles
```

Therefore M3.2 does not pretend that an effect-set summary is a lifecycle transformer.

Instead it computes a small transitive property for every typed function:

```text
lifecycle-neutral
or
lifecycle-transforming / precision-sensitive
```

The current neutral allowlist includes ordinary computations such as:

```text
u32 / usize construction
store                    # semantic effect, lifecycle-neutral
len
ordinary calls to lifecycle-neutral functions
```

The conservative side includes operations/constructs whose recursive treatment may carry resource or scoped state, including:

```text
LifetimeDomain operations
initialize / take / destroy
ptr_from_ref / ref_from_ptr
span/resource operations
loan
block invocation / block values
match occurrence state
unresolved dependent calls
```

Neutrality is propagated transitively through the call graph.

---

## 8. Lifecycle-neutral recursive SCCs now close

When exact or production lifecycle analysis reaches an already-active function in a lifecycle-neutral SCC, M3.2 does not inline forever.

It returns a finite abstract result for the currently supported passive result classes:

```text
unit
usize
ordinary BuiltinType values such as u32 / bool
```

No lifetime root, ptr identity, slot identity, domain identity, ref anchor, or span anchor is invented.

This closes:

```text
ordinary direct recursion
ordinary mutual recursion
generic direct recursion after monomorphization
generic mutual recursion after monomorphization
recursive semantic-store wrappers
```

through **both** lifecycle paths.

Representative validation:

```text
95  generic direct recursion          exact PASS / production PASS
96  generic mutual recursion          exact PASS / production PASS
108 recursive generic store effect    exact PASS / production PASS
109 ordinary direct recursion         exact PASS / production PASS
110 ordinary mutual recursion         exact PASS / production PASS
111 recursive ordinary store effect   exact PASS / production PASS
```

---

## 9. Resource-transforming recursive SCCs remain explicit

M3.2 adds:

```text
112_recursive_lifecycle_transform_error.nl
```

The recursive function creates/finalizes a `LifetimeDomain` before recurring.

Although this particular source may have locally balanced operations, proving a general recursive resource transformer requires more than a boolean neutrality summary.

Both exact and production bridges therefore reject at the cycle with:

```text
E_LIFETIME_RECURSIVE_SUMMARY
```

message:

```text
recursive lifecycle SCC requires a resource/post-state transformer
```

This replaces an accidental call-depth failure with a semantic implementation boundary that identifies the missing abstraction.

---

## 10. Identity-bearing recursive results are not fabricated

A lifecycle-neutral recursive body can still return a value whose identity matters.

M3.2 adds:

```text
113_recursive_identity_result_error.nl
```

with a recursive result:

```text
ptr<u32>
```

The bridge must not manufacture a fresh arbitrary ptr token and pretend it is the recursive result.

Therefore both lifecycle paths reject with:

```text
E_LIFETIME_RECURSIVE_RESULT
```

This boundary applies before attempting richer result transformers for:

```text
ptr<T>
slot<T>
LifetimeDomain
ref<...>
exclusive ref<...>
span<...>
resource-bearing tuples/sums/aggregates
```

---

## 11. Exact and production lifecycle paths use the same recursion classification

M3.2 deliberately does not let the exact bridge accept a recursion pattern that the finite production bridge rejects for a different reason.

Both use the same `infer_lifecycle_recursion_info(...)` analysis.

The positive neutral SCC corpus is accepted by both.

The two explicit negative boundaries produce the same diagnostic class in both:

```text
112 -> E_LIFETIME_RECURSIVE_SUMMARY
113 -> E_LIFETIME_RECURSIVE_RESULT
```

This is more important than maximizing the number of currently accepted recursive resource programs.

---

## 12. SCC analysis and observability

M3.2 adds:

```text
python -m newlang_frontend dump-recursion-stats file.nl
```

Example for ordinary mutual recursion:

```text
semantic_sccs: 2
semantic_recursive_sccs: 1
semantic_fixpoint_iterations: 2
semantic_widened_sccs: 0
lifecycle_sccs: 2
lifecycle_recursive_sccs: 1
lifecycle_neutral_recursive_functions: 2
lifecycle_transforming_recursive_functions: 0
```

For the resource-transforming recursive case:

```text
lifecycle_recursive_sccs: 1
lifecycle_neutral_recursive_functions: 0
lifecycle_transforming_recursive_functions: 1
```

This is compiler tooling, not source semantics.

---

## 13. Real `.nl` M3.2 corpus

M3.2 adds programs `109` through `114`:

```text
109 ordinary direct recursion
110 ordinary mutual recursion
111 recursive caller-visible effect summary
112 recursive lifecycle/resource-transform precision boundary
113 recursive identity-bearing result precision boundary
114 recursive occurrence/dependency-post-state precision boundary
```

It also reclassifies/renames M3.1 program `108` from an expected semantic precision failure to an accepted recursion regression.

---

## 14. Shared-checker change

Unlike M3.1, M3.2 **does modify** the vendored shared source semantic checker:

```text
vendor/newlang_checker/source_ir.py
```

The change is narrow:

```text
SourceProgram.function_summaries
recursive-call summary application in ExactSourceRunner
```

The effect inference itself lives in the front-end shared recursion module:

```text
newlang_frontend/recursive_summary.py
```

All existing front-end/shared-IR regressions are rerun as part of the full suite.

The separately packaged independent Draft 17.2 110-test closure tree is not contained in the supplied M3.1 bundle, so M3.2 does not claim a fresh run of that external suite.

---

## 15. Validation

Final M3.2 front-end suite:

```text
180 tests collected
180 passed
compileall PASS
```

Commands:

```text
PYTHONPATH=. python -m pytest -q
python -m compileall -q newlang_frontend vendor tests
```

`ruff`, `mypy`, and `pyright` are not installed in the execution environment, so this report does not claim those checks passed.

The last independently recorded Draft 17.2 closure baseline remains the M3 record:

```text
110 tests collected
110 passed
compileall PASS
```

---

## 16. Architecture after M3.2

The relevant path is now:

```text
real .nl source
    ↓
typed call graph
    ↓
        ┌───────────────────────────────┐
        │ semantic recursion analysis   │
        │ SCC may-effect fixed point    │
        │ finite budget / Unknown widen │
        └───────────────────────────────┘
                    ↓
      body-sensitive exact runner
      recursive re-entry -> summary
                    ↓
        caller place substitution
        ordinary conflict algebra

and independently:

real .nl source
    ↓
typed call graph
    ↓
lifecycle-neutral transitive summary
    ↓
exact + finite production lifecycle bridges
    ├─ neutral recursive re-entry -> finite passive result
    └─ resource/identity transformer needed -> explicit reject
```

Generic and non-generic functions share both paths.

---

## 17. What M3.2 deliberately does not add

M3.2 does not introduce:

```text
source-visible recursion annotations
source-visible effects(...)
source-visible lifetime/post-state constraints
general relational lifecycle summary language
recursive ptr/slot/domain identity transformer
general recursive dependency-state transformer
termination checking
tail-call semantics
general loop syntax
```

It also does not interpret nontermination as a type or safety error.

The summaries answer safety questions, not termination questions.

---

## 18. Pressure result

The experiment falsified one overly broad implementation assumption:

```text
"recursive call == Unknown / depth-limit boundary"
```

That assumption was unnecessary for a substantial useful class.

A small compiler-internal SCC summary is enough for:

```text
ordinary recursion
generic recursion after monomorphization
caller-visible Change/Reset/EndRoot propagation
lifecycle-neutral recursion
```

But the pressure also confirms a real boundary:

```text
dependency post-state
resource identity post-state
identity-bearing recursive results
```

cannot safely be reduced to an effect set or an empty/no-op summary.

---

## 19. M3.2 judgment

**Front-End Prototype M3.2 passes as a recursive interprocedural-analysis closure.**

The strongest result is not that recursion was made permissive.

It is that the implementation now distinguishes:

```text
finite information we can summarize
from
information for which a richer transformer is actually required
```

without adding user-written effect/lifetime machinery.

No Draft-18-level semantic redesign is indicated by this pressure pass.

The next language-feature milestone no longer needs to carry the accidental M3.1 recursion boundary. If later real workloads require recursive resource transformations or dependency-bearing recursive results, that concrete workload should drive the next post-state transformer extension rather than adding one speculatively now.
