# NewLang Front-End Prototype M6.1 — Raw Storage / Allocation Surface Closure

> Status: completed experimental M6.1 implementation
>
> Semantic baseline: NewLang v0 Draft 17.2
>
> Starting point: Front-End Prototype M6
>
> Purpose: expose the M6 dynamic-claim mechanism through a minimal real-source raw-storage surface, then pressure reallocation, live-reference interference, alignment, and `sizeof(T) > 1` without introducing compiler-tracked dynamic partial initialization.

## 1. Scope

M6.1 adds an experimental real-source vertical slice for:

```text
Allocation
Storage

allocate_storage(bytes, align) -> (Allocation, Storage)
split_storage(Storage, offset) -> (Storage, Storage)
merge_storage(Storage, Storage) -> Storage
storage_into_slot(Storage) -> slot<T>       // T from expected result type
erase_slot(slot<T>) -> Storage
deallocate_storage(Allocation, whole Storage) -> unit
```

The privileged metadata bridge is deliberately spelled provisionally as:

```text
unchecked_dematerialize_storage(Allocation, Storage) -> Allocation
unchecked_materialize_slot(Allocation, byte_offset) -> (Allocation, slot<T>)
unchecked_recover_whole_storage(Allocation) -> (Allocation, Storage)
```

This spelling is an implementation experiment, not a proposal to freeze the final `unchecked` syntax.

## 2. Authority model

`Allocation` and `Storage` are non-Copy and non-Discardable compiler-known resource values.

The safe claim algebra is linear:

```text
Allocation + whole Storage
    -> split Storage
    -> exact Storage -> slot<T>
    -> initialize / take
    -> slot<T> -> Storage
    -> merge Storage
    -> Allocation + whole Storage
    -> deallocate
```

Operations consume their input authority and return replacement authority. The source surface therefore does not create duplicate persistent claims.

## 3. Exact slot conversion and layout

M6.1 intentionally does not make ordinary nominal aggregate layout part of the language contract.

For this prototype, fixed raw layout is known only for a small builtin/structural subset needed to falsify the mechanism:

```text
bool   1 byte / align 1
u32    4 bytes / align 4
usize  8 bytes / align 8
Array<T,N> = N * sizeof(T), alignof(T)
```

`storage_into_slot` requires an exact byte-length match and compatible alignment. A raw `Storage` of 8 bytes cannot be converted directly to `slot<u32>`, and offset 2 cannot materialize a `u32` slot from 4-byte-aligned backing.

Ordinary nominal layout remains opaque. `slot<Box>` cannot be materialized from raw Storage merely because `Box` currently contains one `u32` field.

## 4. Privileged metadata bridge

M6 already established that dense runtime containers need a localized bridge between metadata-owned raw backing and typed object lifetime.

M6.1 carries that mechanism through typed source while keeping metadata as the single source of truth.

`unchecked_dematerialize_storage` transfers an explicit raw claim into the library's metadata invariant. The same operation also absorbs a partial empty claim returned by `take -> erase_slot`.

`unchecked_materialize_slot` temporarily materializes one exact typed empty claim. The exact bridge rejects overlap with:

```text
live roots
outstanding slot claims
outstanding Storage claims
```

`unchecked_recover_whole_storage` succeeds only when no live root or outstanding claim remains in the allocation backing.

The compiler does not track the dynamic initialized-index set.

## 5. Safe split/slot/merge workload

Program `193_storage_split_slot_roundtrip_ok.nl` allocates 8 bytes with 4-byte alignment, splits it at byte 4, converts both 4-byte claims into `slot<u32>`, initializes two roots, takes both values back out, erases both slots, merges the raw claims, and deallocates the original allocation.

This validates `sizeof(u32) > 1`, alignment, split/merge conservation, and typed lifetime roundtrip in one source workload.

Both exact and production lifecycle bridges accept this safe algebra without precision loss.

## 6. Dynamic materialization workload

Program `194_dynamic_materialize_u32_ok.nl`:

```text
allocate 8 bytes
-> dematerialize whole raw Storage into metadata responsibility
-> materialize slot<u32> at byte offset 4
-> initialize / take
-> erase slot
-> absorb partial raw claim back into metadata
-> recover whole Storage
-> deallocate
```

The exact lifecycle bridge accepts this end-to-end.

The finite production bridge deliberately reports:

```text
E_M61_DYNAMIC_PRODUCTION_BOUNDARY
```

for the privileged metadata materialization operations. M6 already validates the dynamic-claim checker directly; M6.1 does not fake a production summary for an unchecked metadata invariant that the current production IR cannot represent.

## 7. Reallocation / growth

Program `199_reallocate_typed_transfer_ok.nl` models growth without raw byte relocation:

```text
old allocation (4 bytes)
    -> live u32 root
    -> take old value
new allocation (8 bytes)
    -> split head/tail
    -> initialize moved value into new head
    -> take again for teardown
old/new raw claims recovered
    -> deallocate both
```

The workload passes both exact and production lifecycle bridges.

This demonstrates that growth can use ordinary typed transfer where the value is available as a semantic value; raw relocation is not automatically required merely because backing changes.

## 8. Live ref blocks growth/move

Program `200_reallocate_live_ref_error.nl` keeps a stable ordinary ref live and attempts to acquire the exclusive ending authority required for `take`.

It is rejected with:

```text
E_LOAN_CONFLICT
```

Therefore reallocation cannot silently invalidate a live safe ref. This falls out of the existing LifetimeDomain stability rule rather than requiring a reallocation-specific borrow rule.

## 9. Alignment and opaque-layout break tests

The M6.1 source corpus fixes the following boundaries:

```text
misaligned u32 dynamic slot              -> E_SLOT_ALIGNMENT
8-byte Storage -> slot<u32>              -> E_SLOT_SIZE
live root during whole recovery          -> E_DYNAMIC_OCCUPANCY
duplicate/overlapping dynamic slot claim -> E_DYNAMIC_OCCUPANCY
ordinary nominal raw layout              -> E_OPAQUE_LAYOUT
```

This is intentional: adding raw-storage APIs does not make native aggregate offsets/layout source-visible.

## 10. Implementation bug found by full regression

The full M0-M6 regression exposed a pre-existing implementation hazard in the implicit-local-root bridge.

Auxiliary maps used `id(handle)` as scope-local keys but retained those keys after the owning lexical scope ended. Python may reuse an object id later, causing an unrelated handle to alias stale owner metadata. This appeared only in the full suite, not in isolated execution.

M6.1 clears the owner/id auxiliary entries at scope exit in both exact and production bridges. This is an implementation fix, not a language-semantics change.

## 11. Validation

Fresh M6.1 front-end validation:

```text
310 tests collected
310 passed
compileall PASS
```

Independent Draft 17.2 closure rerun:

```text
110 tests collected
110 passed
compileall PASS
executable closure vectors: 12 / 12 PASS
generated differential: 100,000 cases
mismatch: 0
false accept: 0
false reject: 0
```

`ruff`, `mypy`, and `pyright` were not installed in the execution environment.

## 12. Judgment

M6.1 supports the Draft 17.2 design direction.

The pressure result is not "put partial initialization into the compiler core". It is:

```text
safe explicit claim algebra
    +
localized privileged metadata/lifetime bridge
```

for dense dynamic containers.

No Draft-18-level semantic redesign was required.

The strongest remaining implementation pressure is now allocator/reallocation policy rather than object-lifetime semantics itself: failure representation, growth policy, byte-preserving relocation/copy where typed transfer is not appropriate, and the exact privileged boundary contract for metadata transition ordering.

The provisional `unchecked_*` function spellings should not be frozen yet. A later API-polish pass can decide whether these become `requires fn`, dedicated privileged intrinsics, or library-facing compiler hooks while preserving the authority model tested here.
