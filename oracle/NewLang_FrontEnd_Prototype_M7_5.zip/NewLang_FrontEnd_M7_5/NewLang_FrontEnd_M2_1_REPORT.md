# NewLang Front-End Prototype M2.1 — Pre-M3 Closure Report

> Status: **completed experimental M2.1 implementation-quality closure**
>
> Semantic baseline: `NewLang_v0_spec_Draft17_2.md`
>
> Starting point: Front-End Prototype M2
>
> Purpose: close the highest-value implementation gaps exposed by M2 before adding generic dependent-call / associated-lookup front-end machinery in M3.

## 1. Scope

M2.1 concentrates on four areas that became concrete only after real-source Array/span/sum/callback code existed:

```text
1. dynamic Array/span index/range handling
2. production lifecycle coverage for M2 composite source constructs
3. ordinary lexical-local root modeling for ptr_from_ref
4. structural/wildcard place overlap in the shared source semantic checker
```

A fifth candidate from the M2 review — a general result/post-state dependency transformer for values returned from a match arm — was reviewed but not invented in M2.1 because the current source surface still has no by-value operation that needs such a transformer. Payload refs already carry an explicit arm scope dependency and are rejected on escape. The result-transformer extension point remains in the shared semantic-call layer for the first source construct that actually requires it.

No Draft 17.2 semantic change is introduced.

---

## 2. Dynamic Array/span indices no longer require compile-time constants

M2's exact lifecycle simulator required:

```text
array_ref[usize(CONSTANT)]
span[usize(CONSTANT)]
subspan(span, CONSTANT, CONSTANT)
```

whenever concrete bounds/resource simulation was needed.

M2.1 replaces that implementation restriction with a finite-domain representation.

New compiler-internal handles:

```text
UsizeHandle(
    exact finite set
    | unknown
)

ChoiceHandle(
    finite alternatives
)
```

For a dynamic:

```text
i: usize
a: ref<read, Array<T,3>>
a[i]
```

the lifecycle simulator does not reject merely because `i` is unknown.

Instead, under the language's existing index precondition:

```text
i < 3
```

the valid semantic alternatives are:

```text
element 0
element 1
element 2
```

and the derived access capability is represented as a finite `ChoiceHandle`.

This is not a runtime bounds-checking policy. The Draft 17.2 operation has a precondition; the simulator enumerates the values satisfying that precondition.

---

## 3. Dynamic subspan

For:

```text
subspan(
    s,
    start,
    count
)
```

with dynamic `usize` values, M2.1 enumerates the finite valid pairs satisfying:

```text
start <= len(s)
count <= len(s) - start
```

for the statically known finite span extent.

The resulting span is a finite alternative set.

Consequently this real source now passes the lifecycle bridge:

```text
fn main(
    values: Array<u32,3>,
    start: usize,
    count: usize
) -> usize {
    loan read values as a {
        let s = array_span(a)
        let part = subspan(s, start, count)
        len(part)
    }
}
```

Constant invalid cases continue to reject as `E_BOUNDS`.

This closes M2's explicit `E_M2_DYNAMIC_INDEX` implementation limitation for fixed Array/span source programs.

---

## 4. Span scope dependency correction

M2 represented a `span` as an access capability, but the lifecycle handle carried only a possible `LifetimeDomain` stability anchor.

That was insufficient for a span derived from an ordinary lexical array ref:

```text
loan read values as a {
    array_span(a)
}
```

The span must not outlive `a`.

M2.1 adds a separate access-capability anchor to `SpanHandle`.

The dependency chain is now:

```text
array ref
    -> array_span
    -> subspan
    -> indexed element ref
```

and every derived capability remains tied to the original lexical access ref.

Therefore this now rejects:

```text
fn main(values: Array<u32,3>) -> span<read,u32> {
    loan read values as a {
        array_span(a)
    }
}
```

with:

```text
E_SCOPE_ESCAPE
```

This was a real M2 bridge bug, not a language-design change.

---

## 5. Structured dynamic index place semantics

M2 already introduced a compiler-internal:

```text
Place(root, projections...)
```

representation, but a nonconstant index lowered to:

```text
$index:*
```

while the old source semantic checker compared places mostly by exact string equality.

That was unsafe for cases such as:

```text
dependency:
    values.$index:0

effect:
    Change(values.$index:*)
```

M2.1 corrects the shared source semantic checker.

Place overlap now understands:

```text
ancestor / descendant overlap
dynamic index wildcard overlap
distinct concrete index non-overlap
```

Examples:

```text
Change(box)
    conflicts Value-like dependency box.value

Change(values.$index:*)
    conflicts values.$index:0
    conflicts values.$index:2

Change(values.$index:0)
    does not conflict values.$index:1
```

The bounded source analyzer uses the same overlap relation.

This is a semantic-checker implementation correction with broader value than the dynamic-index feature itself: parent-place effects can no longer silently miss descendant dependencies.

---

## 6. Real-source dynamic-index effect regression

M2.1 adds:

```text
fn set_at(
    values: ref<write, Array<u32,3>>,
    i: usize
) -> unit {
    store(values[i], u32(9))
}
```

With an injected developer-test dependency:

```text
values.$index:0
```

the source lowering produces a dynamic-index effect and both:

```text
ExactSourceRunner
BoundedSourceAnalyzer
```

reject.

A dependency on a concrete different index still remains distinct from a concrete write to another concrete index.

---

## 7. Ordinary lexical local roots

M1.1 deliberately rejected:

```text
loan read local as r {
    ptr_from_ref(r)
}
```

because the lifecycle bridge had not given ordinary lexical locals a root/incarnation representation.

M2.1 closes that bridge gap.

When a lexical local first needs persistent location identity, the compiler creates an **internal implicit local lifetime root** consisting of:

```text
synthetic backing identity
synthetic occupancy slot
implicit LifetimeDomain identity
fresh root incarnation
persistent ptr token
```

This is compiler-internal modeling of the already-existing Draft 17.2 implicit-local lifetime concept; none of these identities become source syntax.

The lifetime shadow contains no user-visible/value-owned authority. Source value ownership remains checked by the normal type/availability and semantic-value layers.

The local root is owned by the lexical block that owns the source binding.

At block exit, the compiler-internal root is ended, its ptrs become stale, and its implicit domain is finalized.

---

## 8. `ptr_from_ref(local)` now works

The old M1.1 negative regression:

```text
45_ptr_from_local_ref_bridge_limit_error.nl
```

has become the positive regression:

```text
45_ptr_from_local_ref_ok.nl
```

Example:

```text
let box = Box::make(u32(1))

loan read box as r {
    let p = ptr_from_ref(r)
    unit
}
```

now passes both exact and production lifecycle bridges.

A field ref can likewise preserve a projected origin ptr without promoting the field to an independent lifetime root.

The persistent ptr may outlive the access ref; if it outlives the lexical object itself it is only a dangling/stale location token, which remains consistent with the existing `ptr<T>` model.

---

## 9. Production lifecycle bridge widened to M2 composite source constructs

M1.1's production lifecycle bridge handled the explicit ptr/domain lifecycle slice but not the M2 composite handles.

M2.1 extends it to source-level:

```text
ArrayHandle
SpanHandle
SumHandle
BlockHandle
UsizeHandle
ChoiceHandle
```

including:

```text
Array entry seeding
array/span projection
dynamic finite index alternatives
array_span
len
dynamic subspan
sum construction
runtime-known sum match
nonescaping block invocation
consume_array
```

Lifecycle-bearing elements such as:

```text
Array<LifetimeDomain,N>
```

therefore execute their callback lifecycle operations through the production IR as well.

Representative exact/production comparisons now include:

```text
51_span_index_len_ok.nl
54_subspan_bounds_error.nl
56_consume_array_nondiscardable_ok.nl
58_consume_array_zero_ok.nl
63_sum_nondiscardable_payload_ok.nl
71_dynamic_array_index_ok.nl
72_dynamic_subspan_ok.nl
73_span_escape_error.nl
45_ptr_from_local_ref_ok.nl
```

The two bridges agree on every tested case.

Accepted production cases complete without `precision_loss`.

---

## 10. Local-root support in the production bridge

The production bridge now creates the same conceptual implicit local root, expressed with existing finite-production core statements:

```text
CreateDomain
InstallValue
Initialize
...
DestroyRoot
FinalizeDomain
```

The synthetic local occupancy is compiler-internal and unique.

This is deliberately not exposed as a source `slot<T>` or `LifetimeDomain`.

No new language primitive was needed.

---

## 11. Dynamic-index source programs added

M2.1 adds source programs `71` through `74`:

```text
71_dynamic_array_index_ok.nl
72_dynamic_subspan_ok.nl
73_span_escape_error.nl
74_dynamic_array_index_effect.nl
```

They cover:

```text
dynamic Array element projection
dynamic subspan finite precondition domain
span lexical-scope escape rejection
dynamic-index semantic-effect overlap
```

The former M1.1 local-root limitation program was renamed:

```text
45_ptr_from_local_ref_ok.nl
```

because it is now accepted.

---

## 12. Source-semantic overlap regressions

New unit regressions verify:

```text
Change(values.$index:*)
    conflicts values.$index:2

Change(box)
    conflicts box.value

Change(values.$index:0)
    does not conflict values.$index:1
```

for both the exact source runner and the bounded source analyzer.

This closes a correctness issue that was more important than adding any new surface syntax.

---

## 13. Match result-dependency review

M2.1 did **not** add a speculative general result/post-state dependency language.

Current source cases already enforce:

```text
payload ref
    cannot escape match-arm occurrence scope
```

through the typed/lifecycle path, and the source semantic layer represents the arm-local occurrence conflict while the arm is active.

A future operation may return a **by-value semantic value whose hidden dependency survives the arm/call**. That will require the previously identified result/post-state dependency transformer.

No current M2 source operation creates such a surviving by-value dependency.

Therefore M2.1 keeps this as an explicit future bridge extension rather than manufacturing a mechanism before a real source case exists.

---

## 14. Validation

Final M2.1 front-end suite:

```text
131 tests collected
131 passed
compileall PASS
```

This includes all M0 through M2 regressions plus:

```text
dynamic index/range source tests
local-root positive regression
M2 exact-vs-production lifecycle comparisons
span scope-dependency regression
structural/wildcard place-overlap regressions
```

The independent Draft 17.2 closure prototype was rerun unchanged:

```text
110 tests collected
110 passed
compileall PASS
```

No upstream Draft 17.2 regression was observed.

`ruff`, `mypy`, and `pyright` were not available in the execution environment, so this report does not claim those checks passed.

---

## 15. Remaining implementation boundaries before/inside M3

M2.1 materially reduces the pre-M3 backlog.

Still intentionally open:

```text
general generic source instantiation
dependent named-call obligations
generic associated lookup
dynamic-container span creation
source-visible loops/recursion
production lifecycle first-class sum occurrence state
general result/post-state dependency transformer
full semantic-value package modeling inside implicit lexical-local roots
```

The local-root lifecycle shadow is sufficient for place/incarnation/ptr safety in the tested front-end slice; it is not a replacement for the semantic-value package checker.

---

## 16. M2.1 judgment

**M2.1 passes.**

The most important outcome is not additional syntax.

Three implementation assumptions were falsified and corrected:

```text
nonconstant fixed-range access need not collapse to "unsupported"

access-derived spans need their lexical access anchor, not only domain stability

plain string-equality place conflicts are insufficient once structural/index projections exist
```

In addition, the M1.1 ordinary-local `ptr_from_ref` bridge gap is now closed for the real-source lifecycle path, and the finite production lifecycle bridge covers the representative M2 composite workloads.

No Draft-18-level semantic redesign is indicated.

**Recommendation: proceed to M3**, with M3 focused on generic definition-time checking, dependent named-function lookup, associated/coherence resolution, and monomorphized real-source instantiation rather than further broadening unrelated surface syntax.
