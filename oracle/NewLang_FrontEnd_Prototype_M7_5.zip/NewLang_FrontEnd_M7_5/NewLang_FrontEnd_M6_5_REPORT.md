# NewLang Front-End Prototype M6.5 Report

## 1. Scope

M6.5 is the second **convergence-closure** milestone after the Draft 17.3 prior-art survey.

It targets the Vault/access-permission failure mode behind NewLang's `CurrentValueVersion` idea:

```text
same place / same type
!=
same current semantic value fact
```

The milestone pressure-tests:

- field-local update versus known-disjoint sibling dependency;
- whole aggregate update;
- alias-mediated write;
- same-place and distinct-place `swap`;
- A -> B -> A value return (ABA-style value equality);
- hidden dependency on fixed-subobject current-value facts;
- exact-vs-production agreement.

The goal is **not** to add a general state-dependent permission language or runtime version counter.

## 2. Normative baseline

Semantic baseline: `NewLang_v0_spec_Draft17_3.md`.

The relevant rule is:

```text
subplace update P:
    Value(P) changes
    Value(ancestors(P)) changes
    Value(known-disjoint siblings(P)) is preserved

whole-value update P:
    structural current-value facts under P change
    fixed object/subobject incarnations remain live
```

A value returning to the same visible value later does not restore an earlier current-value fact.

## 3. Important implementation defect found

Before M6.5, the source semantic layer already represented structural overlap correctly through `Change(P)`.

However, the shared exact/production lifecycle semantics had a narrower whole-root model:

```text
replace/store/swap whole root
    -> root_value_fact refreshed
    -> fixed_subobject incarnation preserved
    -> fixed_subobject value_fact accidentally preserved   // wrong
```

That last line contradicted Draft 17.3. A dependency on the old value of `root.field` could therefore remain apparently valid after replacing the whole aggregate.

M6.5 fixes this.

After a whole-value `replace` / `store` / distinct-place `swap`:

```text
root incarnation                  preserved
fixed-subobject incarnation       preserved
root current-value fact           fresh
fixed-subobject current-value fact fresh
```

No runtime counter is introduced. These remain compiler/checker ghost identities.

## 4. Structural positive/negative cases

For:

```text
Pair {
    a,
    b,
}
```

with a live dependency on `Value(p.a)`:

```text
update p.b       -> accepted
update p.a       -> rejected
update whole p   -> rejected
```

This verifies that M6.5 does not solve the problem by rejecting every mutation of the aggregate.

The source layer retains the existing place-overlap relation:

```text
Change(P) conflicts Value(Q)
iff P and Q may semantically overlap
```

Thus an update of one known-disjoint sibling preserves dependencies on another sibling, while ancestor dependencies are invalidated.

## 5. Alias-mediated write

The same distinction survives function-boundary substitution.

A wrapper that eventually writes `p.a` rejects a caller-visible dependency on `p.a`.
A wrapper that writes only `p.b` preserves the dependency on `p.a`.

No special alias-version mechanism was added; existing actual-place substitution plus the structural `Change` relation is sufficient for these cases.

## 6. `swap` vertical slice

Draft 17.3 already specifies `swap`; M6.5 connects a minimal source vertical slice so the CurrentValueVersion rules can be falsified at source level.

Type rule:

```text
swap(ref<write,T>, ref<write,T>) -> unit
```

It adds no `Copy(T)` or `Discardable(T)` requirement.

### same place

```text
swap(P, P)
```

is a complete semantic no-op:

- no `Change`;
- no `Reset`;
- no current-value fact refresh;
- no incarnation change.

### distinct places

```text
swap(A, B)
```

produces `Change(A)` and `Change(B)` and refreshes the structural current-value fact families at both targets while preserving their fixed incarnations.

Dependencies on a third known-disjoint sibling remain valid.

## 7. A -> B -> A does not resurrect an old fact

The exact checker was exercised with:

```text
Current(P) = A      fact V0
replace(P, B)       fact V1
replace(P, A)       fact V2
```

Result:

```text
visible semantic value == A
V2 != V1
V2 != V0
V0 is not live
old fixed-subobject facts are not live
```

Therefore equality of the later semantic value with an earlier value does not revive an old capability/dependency.

This is the intended protection against an ABA-style interpretation of CurrentValueVersion.

## 8. Hidden fixed-subobject dependency break test

A low-level semantic package was made to depend on the old fixed-field value fact `LVA`.

Then the whole root was replaced.

Both exact and production checkers reject because `LVA` is no longer live:

```text
DanglingSemanticDependency
```

Before the M6.5 structural-fact fix this production shape could retain the old fixed fact.

Conversely, a dependency on `right.a` survives a whole update of distinct root `left`.

This gives both a negative and a positive oracle.

## 9. Generated CurrentValueVersion pressure

Seed: `20261004`.

Twelve operation/dependency families were generated across:

- replace;
- store;
- same-place swap;
- distinct-place swap;
- root dependency;
- fixed-field dependency;
- unrelated-root dependency;
- incoming value dependency;
- A -> B -> A.

Result:

```text
20,000 cases
accepted:   6,530
rejected:  13,470
mismatches:     0
```

The comparison is between the exact semantic transition model and the finite production checker.

## 10. Front-end validation

Final M6.5 tree:

```text
pytest:      386 / 386 PASS
compileall:  PASS
```

The increase from M6.4 is from the M6.5 source/current-value tests and swap vertical slice.

## 11. Independent Draft 17.2 closure regression

Fresh independent closure checker rerun:

```text
pytest:      110 / 110 PASS
compileall:  PASS
closure executable vectors: 12 / 12 PASS
```

Generated Draft 17.2 differential:

```text
100,000 cases
mismatches:     0
false accepts:  0
false rejects:  0
```

## 12. What M6.5 does not claim

M6.5 deliberately does **not** add or claim:

- a runtime version counter;
- a general state-dependent permission calculus;
- source-visible CurrentValueVersion tokens;
- general symbolic alias solving;
- general relocation/address-stability rules;
- full reconstruction of conditional sum payload occurrences in the shared lifecycle fixture model.

Whole-sum conditional occurrence changes remain represented by the existing source-level `Reset(P)` semantics. M6.5's shared lifecycle correction is specifically about **fixed structural current-value facts**.

## 13. Small harness correction

The exact semantic `load_initial` helper now loads initial semantic values/dependencies, matching the production abstract loader. This is needed for exact-vs-production hidden-dependency pressure and does not change language semantics.

## 14. Decision

M6.5 **passes** the second convergence-closure milestone.

Current judgment:

```text
runtime CurrentValueVersion counter required?        no evidence
source-visible version/capability syntax required?   no evidence
general state-dependent permission calculus needed? no evidence
structural current-value facts required?             yes
known-disjoint sibling precision valuable?           yes
same-place swap special case required?                yes
whole-value structural fact refresh required?         yes
```

The result strengthens the interpretation of CurrentValueVersion as a **ghost semantic identity / dependency relation**, not a runtime object-generation mechanism.

## 15. Draft 17.3 impact

No Draft 18-style redesign is indicated.

Draft 17.3 already states the correct structural rule. M6.5 primarily brings the executable shared lifecycle model into conformance with it.

A future consolidation may clarify that whole-value transitions refresh current-value facts for fixed descendants while preserving their incarnations, but the current Draft already says this substantially.

## 16. Next milestone

Proceed to **M6.6 Analysis / Unknown / Failure Closure**.

The main question becomes whether body-sensitive inference can remain finite, conservative, diagnosable, and practical under:

- recursive SCCs;
- branch-correlated dependencies;
- generic instantiation;
- callback 0..N invocation;
- precision loss / `Unknown`;
- normal error exits with live responsibilities.

This is the convergence-closure milestone with the greatest risk of forcing a larger process or language change.
