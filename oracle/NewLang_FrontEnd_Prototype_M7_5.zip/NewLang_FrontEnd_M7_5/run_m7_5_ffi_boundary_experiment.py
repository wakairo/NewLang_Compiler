from __future__ import annotations

import json
import random
from dataclasses import asdict
from pathlib import Path

from newlang_frontend.ffi_boundary_pressure import Exposure, ForeignSummary, checked_accept, oracle_accept


def main() -> None:
    rng = random.Random(20261004)
    effects = ("none", "change", "endroot", "unknown")
    retentions = ("no", "yes", "unknown")
    callbacks = ("none", "sync", "retain", "unknown")
    controls = ("return", "nonlocal", "unknown")
    memory = ("none", "read", "readwrite", "unknown")

    cases = 100_000
    mismatch = false_accept = false_reject = 0
    accepted = 0
    sample_mismatches: list[dict[str, object]] = []

    for _ in range(cases):
        exposure = Exposure(
            value_dependency=bool(rng.getrandbits(1)),
            root_must_remain_live=bool(rng.getrandbits(1)),
            borrowed_location=bool(rng.getrandbits(1)),
            nonescaping_callback=bool(rng.getrandbits(1)),
        )
        summary = ForeignSummary(
            semantic_effect=rng.choice(effects),
            retention=rng.choice(retentions),
            callback=rng.choice(callbacks),
            control=rng.choice(controls),
            memory_access=rng.choice(memory),
        )
        got = checked_accept(exposure, summary)
        expected = oracle_accept(exposure, summary)
        accepted += int(got)
        if got != expected:
            mismatch += 1
            false_accept += int(got and not expected)
            false_reject += int(expected and not got)
            if len(sample_mismatches) < 10:
                sample_mismatches.append({
                    "exposure": asdict(exposure),
                    "summary": asdict(summary),
                    "checked": got,
                    "oracle": expected,
                })

    result = {
        "seed": 20261004,
        "cases": cases,
        "accepted": accepted,
        "mismatch": mismatch,
        "false_accept": false_accept,
        "false_reject": false_reject,
        "sample_mismatches": sample_mismatches,
    }
    Path("m7_5_ffi_boundary_results.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
