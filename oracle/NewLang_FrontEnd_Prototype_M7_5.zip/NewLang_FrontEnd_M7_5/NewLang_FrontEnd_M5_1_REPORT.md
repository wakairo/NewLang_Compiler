# NewLang Front-End Prototype M5.1 Report

## 1. Scope

M5.1 is an implementation-pressure closure on top of M5. It does not add a new headline language feature. Its purpose is to stress the generic nominal/sum/container path under:

```text
nested generic instantiation
repeated same-owner generic fields
mutually-recursive generic nominal/sum graphs
resource-bearing nested aggregates
nonescaping block substitution through generics
monomorphization growth/code-size pressure
non-Copy container API design
dynamic-occupancy alternatives
```

The semantic baseline remains **NewLang v0 Draft 17.2**.

The principal question was whether M5's generic nominal layer remained sound and practical under composition, and whether a real workload would force dynamic partial initialization into the v0 core.

---

## 2. Main result

M5.1 found five concrete implementation defects/omissions and closed them without changing the Draft 17.2 semantic kernel:

1. nested generic `Copy` / `Discardable` derivation used declaration `type_id` as the recursion key and therefore falsely treated finite repeated instantiations as cycles;
2. a generic type argument could launder a nonescaping `block(...)` value into a nominal field or sum payload;
3. struct field initialization did not pass the known field type as the expected type to a payloadless generic sum constructor;
4. invoking a block value did not consume non-Copy actual arguments according to the block parameter types;
5. the lifecycle bridges flattened every structural aggregate at `let` binding time, conflating whole-value name binding with destructuring.

All five are implementation corrections. None requires traits, source-visible constraints, partial-move state, or a new lifetime/effect language.

---

## 3. Nested generic capability derivation

M5 derived capabilities structurally after substitution, but its recursion guard was too coarse.

The old implementation effectively used:

```text
seen = { nominal type_id }
```

This makes:

```text
Box<Box<u32>>
```

look recursive merely because both levels share the `Box` declaration identity.

It also polluted sibling traversal: a type such as:

```text
Pair<Box<u32>> {
    left: Box<u32>,
    right: Box<u32>,
}
```

could cause the second occurrence to be treated as a cycle after the first occurrence had updated a shared `seen` set.

M5.1 changes the capability walk to use **concrete type instantiation identity on the current recursion path**:

```text
seen: frozenset[Type]
```

and branches with:

```text
branch_seen = seen | { current_concrete_type }
```

Consequently:

```text
Box<Box<u32>>                   Copy + Discardable
Pair<Box<u32>>                  Copy + Discardable
Maybe<Maybe<u32>>               Copy + Discardable

Box<Box<LifetimeDomain>>        non-Copy + non-Discardable
Maybe<Maybe<LifetimeDomain>>    non-Copy + non-Discardable
```

while true by-value recursive declarations remain rejected by the separate Sized recursion validation.

This preserves the important distinction:

```text
same generic declaration used again
    !=
recursive value-layout cycle
```

---

## 4. Generic substitution may not launder nonescaping block storage

Direct declaration-time storage of a nonescaping block was already rejected:

```text
struct { callback: block() -> unit }
```

However, M5 allowed:

```text
module Box<T>
  struct { value: T }
end

Box<block() -> unit>
```

and similarly:

```text
Maybe<block() -> unit>
```

because the declaration body contains only symbolic `T`.

M5.1 adds concrete aggregate well-formedness validation after substitution. It recursively checks nominal fields and sum payloads and rejects any concrete instantiation that would physically store a nonescaping block.

The check is deliberately about **storage**, not about banning block types from all generic use. A direct nonescaping block parameter remains valid, and a generic function may still operate synchronously on it under the existing block rules.

New negative cases include:

```text
Box<block() -> unit>
Maybe<block() -> unit>
Outer<block() -> unit>  // where Outer<T> stores Box<T>
Box::make({ || unit })  // inference must not launder the same case
Maybe::Full({ || unit })
```

All reject with `E_BLOCK_ESCAPE_TYPE`.

---

## 5. Expected type now flows into struct field initialization

M5 already allowed a payloadless generic sum constructor when a complete expected sum type was known:

```text
let x: Maybe<u32> = Maybe::Empty()
```

But this failed inside a struct literal even when the field type was known:

```text
module Slot<T>
  struct { value: Maybe<T> }

  fn from(value: T) -> Self {
    Self { value: Maybe::Empty() }
  }
end
```

The field checker previously type-checked the initializer first and only compared it against the field type afterwards.

M5.1 resolves the concrete field type first and supplies it as the expected type while checking the initializer.

This is not associated-output inference. The expected type is already known from the selected nominal field declaration after substitution.

It is therefore consistent with the existing rule:

> do not infer generic output from candidate search, but do use an already-known complete expected type.

---

## 6. Block invocation now transfers non-Copy arguments

M5.1 found an ownership bookkeeping hole in ordinary nonescaping block invocation.

For:

```text
fn apply<T>(value: T, f: block(T) -> unit) -> unit {
    f(value)
}
```

`T` is unconstrained and therefore non-Copy must be assumed possible. Passing `value` to `f` transfers ownership to the block invocation.

The old checker verified the argument type but did not mark a non-Copy actual as consumed. This caused valid code to be rejected later because the source binding appeared to remain unconsumed.

M5.1 applies the same value-transfer rule used by ordinary function calls:

```text
if block formal is non-Copy:
    consume direct-name actual
```

The real-source regression instantiates this with `LifetimeDomain` and finalizes the domain inside the callback. Both lifecycle bridges accept.

---

## 7. Structural aggregate name binding vs destructuring

M5 introduced `StructHandle` so resource-bearing nominal aggregates could preserve their owned resource identities through lifecycle analysis.

Pressure with a two-field generic container exposed that every `TLet` was calling `flatten_handle` unconditionally.

That conflated:

```text
let slots = make_slots(...)
```

with:

```text
let Slots2 { first, second } = slots
```

For a one-field structural aggregate, M5 happened to work because flattening produced one child and therefore matched one name. A two-field aggregate correctly exposed the bug as `E_LIFETIME_BIND`.

M5.1 changes both exact and production lifecycle bridges:

```text
if there is one binding
and its typed binding type equals the whole handle type:
    bind the whole handle
else:
    flatten for tuple/struct destructuring
```

This preserves aggregate identity for ordinary name binding while retaining existing destructuring behavior.

---

## 8. Nested resource-bearing aggregates

M5.1 validates resource structure recursively across multiple generic owners:

```text
Box<Fixed2<LifetimeDomain>>
```

The workload constructs:

```text
Array<LifetimeDomain,2>
    -> Fixed2<LifetimeDomain>
    -> Box<Fixed2<LifetimeDomain>>
```

then drains the outer box, drains the inner fixed container, and finalizes both domains.

Results:

```text
exact lifecycle bridge       PASS
production lifecycle bridge  PASS
production precision loss    false
```

This confirms that M5's structural handle extension is not limited to one aggregate layer.

---

## 9. Non-Copy container update without in-place mutation

M5.1 deliberately tested whether a useful non-Copy update API already exists using only whole-value transfer.

A generic `Cell<T>` implements:

```text
replace_then(self: Self, new_value: T, f: block(Self,T) -> unit)
```

by:

```text
consume old Cell<T>
extract old T
construct new Cell<T>
transfer (new cell, old T) to a nonescaping callback
```

For `T = LifetimeDomain`, the caller finalizes the old domain and later drains/finalizes the new domain.

Both lifecycle bridges accept with no precision loss.

This is important negative evidence against prematurely adding a new ownership model:

> generic non-Copy containers do not intrinsically require partial initialization or in-place replacement.

Whole-value transfer remains sufficient for a meaningful class of APIs.

---

## 10. Fully-initialized occupancy encoding

To test dynamic-partial-initialization pressure rather than assume it, M5.1 builds a small fixed-capacity container using:

```text
Maybe<T>
```

as explicit occupancy metadata:

```text
module Slots2<T>
  struct {
    first: Maybe<T>,
    second: Maybe<T>,
  }
end
```

The workload begins with:

```text
Full(old), Empty
```

and uses whole-value transfer to produce:

```text
Full(old), Full(new)
```

while transferring the previous second slot (`Empty`) to the caller. It then drains both occupied values.

With `T = LifetimeDomain`:

```text
exact lifecycle bridge       PASS
production lifecycle bridge  PASS
production precision loss    false
```

Thus a fully initialized representation can model occupancy safely without uninitialized typed storage.

The cost is representational/runtime overhead and less convenient in-place indexing, not a semantic impossibility.

---

## 11. Where in-place occupancy pressure actually appears

The corresponding in-place generic operation:

```text
store(ref<write,Maybe<T>>, Maybe::Full(value))
```

is correctly rejected at generic definition time:

```text
E_STORE_NONDISCARDABLE
```

because `Maybe<T>` cannot be assumed `Discardable` for unconstrained `T`.

For a concrete discardable specialization such as `Maybe<u32>`, the same `store` shape is valid.

This is the first useful boundary for future work:

```text
whole-value update                       already works
fully-initialized Maybe<T> occupancy      already works
in-place overwrite of generic occupancy  requires old value to be returned
```

Draft 17.2 already has the semantic operation:

```text
replace(ref<write,T>, new:T) -> T
```

but this front-end prototype has not yet wired `replace` through the real-source/lifecycle path.

Therefore M5.1 does **not** conclude that dynamic partial initialization must be added next. The smaller next experiment is to wire the existing `replace` mechanism and see how far a `Maybe<T>`-backed container can go before raw/partially-initialized storage is actually required.

Dynamic partial initialization remains justified only if later workloads need one or more of:

```text
dense T storage without per-slot sum tags
runtime capacity with live_count < capacity
allocator-backed raw storage
construction directly into vacant storage
avoiding eager initialization of every capacity slot
```

That is implementation/workload pressure, not yet a proven v0 semantic requirement.

---

## 12. Recursive generic structure pressure

M5.1 adds mutual recursion cases across:

```text
nominal <-> nominal
sum <-> sum
nominal <-> sum
```

Pointer-indirected forms are accepted:

```text
A<T> -> ptr<B<T>> -> ptr<A<T>>
Left<T> -> ptr<Right<T>> -> ptr<Left<T>>
Node<T> -> Link<T> -> ptr<Node<T>>
```

By-value cycles are rejected with `E_RECURSIVE_VALUE_TYPE`.

No new recursive-type rule was needed.

---

## 13. Monomorphization / code-size pressure

M5.1 checks two generic-nominal resource cases.

### Type-growing recursive instantiation

```text
grow<T>(x)
    -> Box::make<T>(x)
    -> grow<Box<T>>(...)
    -> Box::make<Box<T>>(...)
    -> ...
```

terminates with the existing implementation diagnostic:

```text
E_GENERIC_MONOMORPH_DEPTH
```

rather than Python recursion failure or unbounded compiler growth.

### Wide independent nominal instantiation

A generated test creates multiple distinct `Box<...>` associated-function instances while setting a deliberately low total monomorph budget.

It terminates with:

```text
E_GENERIC_MONOMORPH_BUDGET
```

This demonstrates that M3.1's generic resource controls also cover the M5 nominal-type path; a second nominal-specific budget is unnecessary.

---

## 14. Associated ownership under nested instantiation

For:

```text
Box<Box<u32>>
```

a receiver call instantiates:

```text
Box::tag<Box<u32>>
```

but its `owner_module_id` remains the single `Box` declaration owner.

Nested instantiation therefore does not create associated-set proliferation or an overlap/ranking problem.

---

## 15. Source corpus

M5.1 adds programs `156` through `182` (27 programs), covering:

```text
156 nested nominal Copy/Discardable positive
157 nested nominal non-Discardable rejection
158 repeated same generic field capability positive
159 nested generic sum capability positive
160 nested generic sum non-Discardable rejection
161 generic nominal block-storage rejection
162 generic sum block-storage rejection
163 mutual generic nominal recursion via ptr
164 mutual generic nominal by-value rejection
165 mutual generic sum recursion via ptr
166 mutual generic sum by-value rejection
167 nested resource-bearing generic drain
168 whole-value non-Copy Cell replacement
169 generic Maybe<T> Array store rejection
170 concrete discardable Maybe<u32> Array store
171 type-growing nominal monomorph depth budget
172 nested generic associated owner
173 nominal/sum mutual recursion via ptr
174 nominal/sum mutual by-value rejection
175 nested generic block-storage rejection
176 functional Maybe<T>-occupancy container with LifetimeDomain
177 payloadless generic sum inferred from struct field expected type
178 non-Copy transfer through block invocation
179 inferred generic nominal block-storage rejection
180 inferred generic sum block-storage rejection
181 nested sum/nominal block-storage rejection
182 in-place generic optional-slot store rejection
```

A dedicated `tests/test_m5_1_pressure.py` adds capability, lifecycle, ownership, associated-owner, and compiler-budget assertions.

---

## 16. Validation

Final M5.1 front-end suite:

```text
267 tests collected
267 passed
compileall PASS
```

The independently supplied Draft 17.2 closure tree was rerun fresh:

```text
110 tests collected
110 passed
compileall PASS
```

Executable closure vectors:

```text
12 / 12 PASS
```

Generated closure differential, seed `20261003`:

```text
alignment_padding   25,000  mismatch 0
mixed_width_add     25,000  mismatch 0
operation_matrix    25,000  mismatch 0
split_coordinate    25,000  mismatch 0
-------------------------------------
total              100,000  mismatch 0
false accept                 0
false reject                 0
```

`ruff`, `mypy`, and `pyright` were not installed in the execution environment, so M5.1 does not claim those checks passed.

---

## 17. Architecture judgment

M5.1 strengthens, rather than expands, the architecture:

```text
concrete generic instantiation
    -> aggregate well-formedness after substitution
    -> branch-local structural capability derivation
    -> expected-type propagation into nested constructors
    -> ordinary ownership transfer through callbacks
    -> whole-value structural lifecycle handling
```

The pressure pass specifically did **not** require:

```text
traits/interfaces
specialization
overload ranking
ADL-style lookup
source-visible Copy/Discardable constraints
partial-move aggregate state
destructors
general relational post-state language
dynamic partial initialization
```

The strongest design conclusion is that dynamic partial initialization should not be added merely because a generic container exists. A smaller fully-initialized representation and whole-value transfer remain viable. The next mechanism to pressure is the already-specified `replace` operation, followed by an actual allocator/runtime-capacity workload if needed.

---

## 18. Remaining boundaries after M5.1

Still intentionally open:

```text
real-source replace(ref<write,T>,T)->T bridge
swap real-source bridge
explicit generic call-site type arguments
runtime-sized / allocator-backed containers
dense partial occupancy without per-slot tags
safe pre-lifetime field construction
array construction/rebuilding surface beyond incoming Array values
escaping callbacks
separate compilation artifacts
resource-mutating loop/recursive relational post-state transformers
```

---

## 19. M5.1 judgment

**Front-End Prototype M5.1 passes.**

M5.1 found and fixed real generic-composition defects while preserving the Draft 17.2 kernel. It also provides useful negative evidence: a non-Copy fixed-capacity container can be expressed with fully initialized occupancy and whole-value transfer, so dynamic partial initialization is not yet forced by correctness.

The highest-information next step is a small **M5.2 / pre-M6 replace-and-occupancy closure**: wire the existing `replace` semantic operation through real source and both lifecycle bridges, then attempt an indexed `Array<Maybe<T>,N>` fixed-capacity container. Only if that still forces raw vacant storage should M6 introduce partial-initialization/storage construction mechanisms.
