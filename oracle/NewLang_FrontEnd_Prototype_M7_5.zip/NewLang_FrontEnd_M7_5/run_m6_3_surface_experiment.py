from __future__ import annotations

import json
from pathlib import Path

from newlang_frontend.driver import check_source
from newlang_frontend.lexer import lex
from newlang_frontend.parser import parse
from newlang_frontend.region_surface_pressure import run_surface_experiment
from newlang_frontend.source import SourceFile
from newlang_frontend.symbols import SymbolBuilder
from newlang_frontend.typecheck import TypeChecker
from newlang_frontend.typesys import display_type

ROOT = Path(__file__).resolve().parent
PROGRAMS = ROOT / "tests" / "programs"


def typed(name: str):
    path = PROGRAMS / name
    source = SourceFile(str(path), path.read_text())
    symbols = SymbolBuilder(parse(lex(source))).build()
    return TypeChecker(symbols).check_program()


def check(name: str) -> dict[str, object]:
    path = PROGRAMS / name
    result = check_source(path.read_text(), str(path))
    return {
        "accepted": result.accepted,
        "diagnostic": None if result.diagnostic is None else result.diagnostic.code,
    }


def main() -> None:
    layout_program = typed("213_layout_generic_monomorph_ok.nl")
    result = {
        "schema": "newlang.m6_3_layout_and_region_surface/v1",
        "layout_witnesses": [
            {
                "type": display_type(info.type),
                "size": info.size,
                "align": info.align,
                "stride": info.stride,
                "field_offsets_exposed": False,
            }
            for info in layout_program.layouts
        ],
        "region_surface": run_surface_experiment(),
        "block_token_threading": {
            name: check(name)
            for name in [
                "209_claim_token_block_thread_ok.nl",
                "210_claim_token_block_double_use_error.nl",
                "211_claim_token_block_zero_invoke_ok.nl",
                "212_claim_token_block_drop_error.nl",
            ]
        },
    }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
