# NewLang Front-End Prototype M3 — Generic / Dependent Lookup / Monomorphization Report

> Status: **completed experimental M3 implementation**
>
> Semantic baseline: `NewLang_v0_spec_Draft17_2.md`
>
> Starting point: Front-End Prototype M2.1
>
> Purpose: put the Draft 17.2 generic design through the real `.nl` front end, concentrating on definition-time checking, delayed dependent named-function lookup, associated/coherent lookup, inferred requirements, and concrete monomorphization.

## 1. M3 scope

M3 adds provisional source syntax for generic functions:

```text
fn identity<T>(x: T) -> T {
    x
}

fn f<A,B>(a: A, b: B) -> A {
    a
}
```

and typed local bindings:

```text
let h: u32 = hash(key)
```

The typed binding exists primarily so a dependent call can receive the complete expected result type required by the Draft 17.2 generic model.

M3 implements:

```text
generic function type parameters
definition-time symbolic checking
dependent unqualified named calls
receiver-form dependent calls
first-argument associated lookup
expected-result requirement
inferred generic requirements
concrete type-argument inference
monomorphization
monomorphization memoization
generic-to-generic symbolic calls
generic associated-function targets
generic lifecycle wrappers
semantic-effect checking after dependent target resolution
```

M3 deliberately does not yet add:

```text
generic nominal struct/module declarations
generic sum declarations
explicit generic call-site type arguments
traits / interfaces / where clauses
associated output type inference
specialization / overload ranking
general overload sets
separate compilation artifacts
```

---

## 2. Generic type parameter representation

A source generic parameter is represented by a compiler-internal identity:

```text
TypeParamType(
    owning function id,
    parameter index,
    source name
)
```

It is not identified only by the spelling `T`.

Thus two unrelated generic functions with a parameter named `T` receive distinct semantic type-parameter identities.

Type substitution recursively handles the M3 type vocabulary:

```text
T
ref<mode,T>
exclusive ref<mode,T>
ptr<T>
slot<T>
Array<T,N>
span<mode,T>
block(T,...) -> R
tuples
```

---

## 3. Default capabilities of generic T

The M3 checker follows the Draft 17.2 rule that an unconstrained generic `T` may be transferred/consumed but is not assumed to be:

```text
Copy
Discardable
hashable
equatable
or otherwise user-capable
```

In the prototype:

```text
is_copy(TypeParam)        -> false
is_discardable(TypeParam) -> false
```

unless a concrete instantiation later supplies a type with those properties.

This gives the expected definition-time rejection:

```text
fn overwrite<T>(
    dst: ref<write,T>,
    value: T
) -> unit {
    store(dst, value)
}
```

because:

```text
store(...)
    requires Discardable(T)
```

and unconstrained `T` does not satisfy that condition.

No `T: Discardable` constraint syntax is introduced.

---

## 4. Definition-time checking

Generic bodies are checked once symbolically before any concrete call site is processed.

Known operations remain ordinary definition-time checks.

Example accepted at definition time:

```text
fn count_elements<T>(
    values: ref<read, Array<T,2>>
) -> usize {
    let s = array_span(values)
    len(s)
}
```

Array/span structure is known even though the element type is symbolic.

Unknown structural duck typing remains rejected:

```text
fn bad<T>(x: T) -> u32 {
    x@value
}
```

produces:

```text
E_FIELD_BASE
```

M3 does not defer field existence to instantiation time.

---

## 5. Dependent named call

Only an otherwise-unresolved **unqualified named call** whose first argument depends on a generic type parameter may become a delayed dependent call.

Example:

```text
fn generic_hash<K>(
    key: ref<read,K>
) -> u32 {
    hash(key)
}
```

At definition time, if there is no lexical `hash`, the typed template contains:

```text
TDependentCall(
    name = "hash"
    argument types = (ref<read,K>,)
    expected result = u32
)
```

and the generic contract records:

```text
hash(ref<read,K>) -> u32
```

No candidate is guessed from all functions in the compilation unit.

---

## 6. Receiver syntax uses the same generic rule

The equivalent generic definition:

```text
fn generic_hash<K>(
    key: ref<read,K>
) -> u32 {
    key.hash()
}
```

records the same associated operation requirement, with receiver syntax noted only as source metadata.

At concrete instantiation, receiver syntax and ordinary:

```text
hash(key)
```

use the same associated lookup mechanism after the receiver has been placed in argument position 0.

No second "method dispatch" system was introduced.

---

## 7. Lexical lookup remains prior and separate

M3 explicitly tests:

```text
fn hash(x: u32) -> u32 { ... }

fn bad<K>(
    key: ref<read,K>
) -> u32 {
    hash(key)
}
```

This is **not** converted into a dependent associated lookup.

The lexical `hash` is selected at definition time and its argument mismatch is reported:

```text
E_ARGUMENT_TYPE
```

The checker does not fall through to associated lookup.

This preserves:

```text
ordinary lexical lookup
    != dependent associated candidate set
```

and avoids ADL-style candidate mixing.

---

## 8. Expected result type is mandatory

M3 implements both current useful expected-type sources:

```text
function tail:
    fn f<K>(...) -> u32 {
        hash(key)
    }

annotated local:
    let h: u32 = hash(key)
```

Without such a context:

```text
let h = hash(key)
```

inside a generic definition rejects as:

```text
E_DEPENDENT_RESULT_REQUIRED
```

M3 does not infer the result type by looking at future associated candidates.

A concrete associated target whose result disagrees with the stored requirement rejects as:

```text
E_GENERIC_REQUIREMENT_RESULT
```

---

## 9. Associated lookup and coherence

For a concrete instantiation, dependent lookup uses only:

```text
outer nominal type of argument 0
    -> that nominal type/module's associated function set
```

For:

```text
ref<read,Key>
ref<write,Key>
ptr<Key>
```

the dispatch nominal is `Key`.

The current experimental module surface naturally provides the associated home:

```text
module Key
  struct { ... }

  fn hash(self: ref<read,Self>) -> u32 {
      ...
  }
end
```

No external associated-registration syntax exists in M3, so an associated function can only originate from the defining module in this surface.

The prototype's same-name rule is currently **stricter** than the eventual Draft 17.2 overlap rule: one module cannot declare two functions with the same source name at all. M3 therefore validates closed/coherent ownership, but does not claim to implement a future non-overlapping overload-set design.

---

## 10. Unsatisfied requirement diagnostics

If a concrete dispatch type has no registered associated operation:

```text
generic_hash<NoHash>(...)
```

the instantiation rejects at the original dependent-call source location with:

```text
E_GENERIC_REQUIREMENT_UNSATISFIED
```

rather than degrading into an unknown/opaque semantic call.

---

## 11. Inferred requirements are retained as metadata

`TProgram` now carries generic requirement metadata.

For:

```text
fn generic_hash<K>(
    key: ref<read,K>
) -> u32 {
    hash(key)
}
```

the prototype exposes:

```text
generic_hash:
  hash(ref<read,K>) -> u32
```

The CLI adds:

```text
python -m newlang_frontend dump-requirements file.nl
```

so requirements are inspectable without inventing source `where` syntax.

---

## 12. Concrete type inference

Generic function calls currently infer type arguments from ordinary actual arguments.

Example:

```text
fn identity<T>(x: T) -> T { x }

identity(u32(9))
```

infers:

```text
T = u32
```

Repeated occurrences must agree:

```text
fn same<T>(a: T, b: T) -> T
```

called as:

```text
same(u32_value, Key_value)
```

rejects:

```text
E_GENERIC_INFERENCE
```

Multiple type parameters are inferred independently:

```text
first<A,B>(u32_value, Key_value)
    -> first<u32,Key>
```

The inference step also understands the already-adopted post-selection authority weakening shape for matching:

```text
formal: ref<read,T>
actual: ref<write,Key>
```

which can infer:

```text
T = Key
```

before the selected concrete call records the normal write-to-read weakening.

---

## 13. Monomorphization

M3 rechecks a generic body under concrete substitutions and produces a concrete `FunctionSymbol`.

Example:

```text
identity<T>
    + T = u32
```

becomes internally:

```text
identity<u32>
```

with concrete parameter/result types.

The generic template itself is not lowered as executable semantic IR.

Only concrete non-generic functions and created monomorphs enter the source/lifecycle semantic program.

---

## 14. Monomorphization memoization

The cache key is:

```text
(template function identity, concrete type-argument tuple)
```

Two calls:

```text
identity(u32(1))
identity(u32(2))
```

create one:

```text
identity<u32>
```

monomorph.

Calls at two distinct types create two monomorphs:

```text
identity<Key>
identity<u32>
```

The tests inspect the concrete program and cache directly.

---

## 15. Generic-to-generic symbolic calls

M3 does not prematurely monomorphize this definition:

```text
fn identity<T>(x: T) -> T { x }

fn wrapper<U>(x: U) -> U {
    identity(x)
}
```

At definition time, `identity<U>` is checked symbolically as a known generic signature.

At concrete instantiation:

```text
wrapper<u32>
```

the body is rechecked and creates/reuses:

```text
identity<u32>
```

This keeps ordinary generic composition separate from dependent associated lookup.

---

## 16. Dependent lookup may resolve to a generic associated target

M3 also exercises:

```text
module Box
  fn echo<T>(
      self: ref<read,Self>,
      value: T
  ) -> T {
      value
  }
end

fn generic_echo<K,V>(
    key: ref<read,K>,
    value: V
) -> V {
    echo(key, value)
}
```

Instantiating with:

```text
K = Box
V = u32
```

resolves the dependent operation to the generic associated target and creates:

```text
generic_echo<Box,u32>
Box::echo<u32>
```

No trait/interface object or ranking mechanism is involved.

---

## 17. Deferred semantic compatibility is checked after target resolution

M3 validates the semantic side, not only types.

Example structure:

```text
module Box
  fn set(self: ref<write,Self>) -> unit {
      store(self@value, ...)
  }
end

fn set_any<T>(
    x: ref<write,T>
) -> unit {
    set(x)
}
```

At generic definition time, `set(x)` is a dependent operation.

At concrete `T = Box` instantiation, the target body becomes known and is lowered normally.

With a live injected dependency:

```text
box.value
```

the shared semantic checker sees the monomorphized associated call's:

```text
Change(box.value)
```

and rejects with:

```text
E_SEMANTIC_CONFLICT
```

The generic boundary therefore does not launder caller-visible effects.

No source-visible generic effect constraint syntax was added.

---

## 18. Generic lifecycle wrapper

M3 also tests a generic operation that does not require `Discardable(T)`:

```text
fn move_out<T>(
    p: ptr<T>,
    ending: exclusive ref<read,LifetimeDomain>
) -> (T, slot<T>) {
    take(p, ending)
}
```

A concrete:

```text
move_out<Box>
```

runs end-to-end through:

```text
real source
type checking
monomorphization
exact lifecycle bridge
finite production lifecycle bridge
```

and both lifecycle paths accept.

This is useful evidence that generic instantiation reuses the existing lifetime-root semantics rather than creating a second generic-specific ownership model.

---

## 19. Real `.nl` M3 corpus

M3 adds programs `75` through `94`, covering:

```text
dependent associated hash
receiver-form dependent hash
missing associated requirement
missing expected result
annotated dependent result
generic identity
monomorph memoization
lexical lookup priority
generic field duck-typing rejection
dependent result mismatch
unconstrained Discardable property rejection
write-to-read inference
two concrete identity instantiations
generic associated semantic effect
generic-to-generic call
known generic Array/span operations
repeated type-parameter mismatch
multiple independent type parameters
generic lifecycle take wrapper
dependent lookup to generic associated target
```

---

## 20. Validation

Final M3 front-end suite:

```text
154 tests collected
154 passed
compileall PASS
```

The independent Draft 17.2 closure prototype was rerun from its own root with:

```text
PYTHONPATH=.
python -m pytest -q
```

Result:

```text
110 tests collected
110 passed
compileall PASS
```

No upstream Draft 17.2 regression was observed.

`ruff`, `mypy`, and `pyright` are not installed in the execution environment, so this report does not claim those checks passed.

---

## 21. Important M3 limitations

### 21.1 Generic nominal type declarations

M3 implements generic **functions**, not user-defined generic primary structs/modules or generic sums.

That broader syntax is not required to test the dependent-call/monomorphization design itself.

### 21.2 Explicit type arguments

M3 has argument-based inference only.

No source syntax such as:

```text
f<u32>(...)
```

is fixed.

### 21.3 General overload / overlap machinery

The experimental module function table remains one function per source name.

This is coherent and ranking-free, but stricter than a possible future implementation that permits provably non-overlapping declarations.

### 21.4 Recursion / instantiation resource pressure

The cache architecture is in place, and symbolic generic-to-generic calls are supported.

M3 does not yet present a dedicated large recursive-generic/SCC or compiler-resource stress corpus through the real source front end.

This is a compiler-quality follow-up, not a semantic gap discovered by the present workloads.

### 21.5 Generic post-state/result dependency metadata

Dependent calls are concretely rechecked and their resulting effects/lifecycle state are validated at instantiation.

A general stable serialized result/post-state transformer for separate compilation is still deliberately absent.

The v0 model permits the same-compilation-unit generic body to remain the semantic source of truth.

---

## 22. Architecture judgment

The M0 -> M2.1 architecture survives M3.

The front end now has a useful separation:

```text
Parsed generic source
    ↓
symbolic type parameters
    ↓
definition-time ordinary checking
    ↓
TDependentCall only at the permitted lookup boundary
    ↓
inferred requirement metadata
    ↓
concrete argument inference
    ↓
monomorphization + body recheck
    ↓
associated target resolution
    ↓
existing semantic/lifecycle lowering
```

The strongest result is that the generic feature did **not** require:

```text
traits/interfaces
structural duck typing
ADL-style candidate mixing
overload ranking
associated output inference
source-visible effect/lifetime constraints
```

to run the representative real-source workloads.

---

## 23. M3 judgment

**Front-End Prototype M3 passes.**

The core Draft 17.2 generic hypothesis survives the first real-source compiler implementation:

```text
definition-time checking is the default

only dependent unqualified named calls are deferred

first-argument nominal associated lookup is sufficient for the tested generic operation dispatch

complete expected result type avoids associated-output inference

requirements can be inferred and surfaced as metadata

monomorphization can re-use the ordinary semantic/lifetime checker
```

No Draft-18-level semantic redesign is indicated by M3.

The highest-value next step is a focused **M3.1 compiler-pressure closure**, rather than adding unrelated syntax immediately. Candidate pressure points are:

```text
recursive / mutually-recursive generic instantiation
monomorphization depth and total-budget diagnostics
larger requirement graphs
generic requirement changes through wrappers
non-overlap/coherence stress
generic semantic post-state/result-dependency cases when a real source construct first needs them
```

After that, the front end is in a much better position for allocator/container-scale generic workloads and later source/API polishing.
