from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PROBE = ROOT / "backend_probe"
OUT = PROBE / "out_script"
OUT.mkdir(exist_ok=True)


def run(args: list[str], *, check: bool = True) -> subprocess.CompletedProcess[str]:
    return subprocess.run(args, cwd=ROOT, text=True, capture_output=True, check=check)


def compile_and_run(name: str, opt: str, sources: list[str]) -> dict[str, object]:
    exe = OUT / f"{name}_{opt.replace('-', '')}"
    run(["clang", opt, *[str(PROBE / s) for s in sources], "-o", str(exe)])
    proc = run([str(exe)], check=False)
    return {"returncode": proc.returncode, "stdout": proc.stdout.strip(), "stderr": proc.stderr.strip()}


def emit_ir(src: str, outname: str) -> str:
    path = OUT / outname
    run(["clang", "-O2", "-S", "-emit-llvm", str(PROBE / src), "-o", str(path)])
    return path.read_text(encoding="utf-8")


def main() -> None:
    version = run(["clang", "--version"]).stdout.splitlines()[0]
    unknown = compile_and_run(
        "unknown", "-O2", ["m7_5_unknown_call_probe.c", "m7_5_mutate_impl.c", "m7_5_unknown_main.c"]
    )
    invalid_o0 = compile_and_run(
        "invalid", "-O0", ["m7_5_invalid_summary_probe.c", "m7_5_mutate_impl.c", "m7_5_invalid_main.c"]
    )
    invalid_o2 = compile_and_run(
        "invalid", "-O2", ["m7_5_invalid_summary_probe.c", "m7_5_mutate_impl.c", "m7_5_invalid_main.c"]
    )
    external_alias = compile_and_run("external_alias", "-O2", ["m7_5_external_alias_probe.c"])

    unknown_ir = emit_ir("m7_5_unknown_call_probe.c", "unknown.ll")
    invalid_ir = emit_ir("m7_5_invalid_summary_probe.c", "invalid.ll")
    noescape_ir = emit_ir("m7_5_noescape_probe.c", "noescape.ll")

    result = {
        "clang": version,
        "unknown_call": {
            **unknown,
            "load_i32_count": len(re.findall(r"\bload i32\b", unknown_ir)),
            "declaration_has_memory_read": bool(re.search(r"declare i32 @mutate.*memory\(read\)", unknown_ir)),
        },
        "deliberately_invalid_pure_summary": {
            "O0": invalid_o0,
            "O2": invalid_o2,
            "ir_has_memory_read": "memory(read)" in invalid_ir,
            "load_i32_count": len(re.findall(r"\bload i32\b", invalid_ir)),
        },
        "noescape": {
            "clang17_emits_nocapture": "nocapture" in noescape_ir,
            "current_llvm_equivalent_contract": "captures(none)",
        },
        "external_alias": external_alias,
    }

    # Assertions define the executable evidence expected by the milestone.
    assert unknown["returncode"] == 0 and unknown["stdout"] == "x=15 r=12"
    assert result["unknown_call"]["load_i32_count"] == 2
    assert not result["unknown_call"]["declaration_has_memory_read"]
    assert invalid_o0["returncode"] == 0 and invalid_o0["stdout"] == "x=15 r=12"
    assert invalid_o2["returncode"] == 1 and invalid_o2["stdout"] == "x=15 r=7"
    assert result["deliberately_invalid_pure_summary"]["ir_has_memory_read"]
    assert result["deliberately_invalid_pure_summary"]["load_i32_count"] == 0
    assert result["noescape"]["clang17_emits_nocapture"]
    assert external_alias["returncode"] == 0
    assert external_alias["stdout"] == "aliases=1 distinct_virtual_addresses=1"

    path = ROOT / "m7_5_backend_probe_results.json"
    path.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
