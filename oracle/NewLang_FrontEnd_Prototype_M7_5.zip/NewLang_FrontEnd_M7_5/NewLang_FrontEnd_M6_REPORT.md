# NewLang Front-End Prototype M6 — Runtime-Sized Dense Container / Dynamic Claim Bridge Pressure Report

> Status: **completed experimental M6 pressure milestone**
>
> Semantic baseline: **NewLang v0 Draft 17.2**
>
> Starting point: **Front-End Prototype M5.2**
>
> Purpose: determine whether runtime-sized / allocator-backed dense containers actually force a new safe partial-initialization language mechanism, or whether Draft 17.2's metadata-owned occupancy plus localized dynamic claim bridge is sufficient.

---

## 1. M6 question

M5.1 and M5.2 showed that fixed-capacity containers can remain fully initialized by storing `Maybe<T>`-like occupancy and using `replace` to return the old value. That establishes correctness for tagged occupancy, including non-Discardable update patterns.

It does **not** answer the representation question faced by a Vec/ring/hash-table style container:

```text
capacity is runtime-sized
live count is smaller than capacity
empty capacity should not require live T/Maybe<T> objects
per-slot occupancy tags may be undesirable
```

M6 therefore compares two representations under one logical container workload:

```text
A. tagged fully initialized occupancy
   one live Maybe<T>-like typed root per capacity slot
   empty/full represented in every slot

B. dense/raw occupancy
   empty bytes are owned only by container metadata
   typed slot<T> exists only transiently during lifetime transition
```

No source syntax for Allocation / Storage / materialize_slot / recover_whole_storage is fixed in M6.

---

## 2. Why M6 does not add source syntax

The existing semantic baseline already separates:

```text
raw backing responsibility
Storage / slot<T> claims
live object roots
container metadata
```

and permits a dynamic-container library to use localized privileged bridges conceptually equivalent to:

```text
materialize_slot<T>(backing, metadata, location)
recover_whole_storage(allocation, metadata)
```

The source spelling and allocator API are intentionally still open.

The highest-information test is therefore to make this model executable first, not to freeze a public API around it.

---

## 3. New experimental module

M6 adds:

```text
newlang_frontend/dynamic_container_pressure.py
```

It uses the vendored Draft 17.2 checker records and transitions directly:

```text
BackingRegion
StorageClaim
SlotClaim
initialize
take
erase_slot
merge
replace_root_package
validate_state
```

The experiment is therefore exercising the same object-lifetime / backing-claim model used by the front-end lifecycle bridge, rather than a separate Boolean occupancy simulator.

---

## 4. TaggedOccupancyBuffer

`TaggedOccupancyBuffer(capacity)` models the fully initialized alternative.

Allocation begins with:

```text
capacity typed roots
capacity logical empty/full tags
```

Every slot is always a live `Maybe<T>`-like object.

Insertion/removal is modeled by:

```text
replace_root_package(root, new_package) -> old_package
```

so no raw-vacant typed location is ever exposed.

This is the direct representation analogue of the M5.2 `Array<Maybe<T>,N>` result.

### Consequence

For capacity `N`, before any element is inserted:

```text
typed live roots = N
logical occupancy tags = N
```

The representation is safe without a dynamic claim boundary, but its occupancy representation scales with capacity.

---

## 5. DenseMetadataBuffer — scattered occupancy

`DenseMetadataBuffer(capacity)` models hash-table/free-list style scattered occupancy.

Initially:

```text
typed live roots = 0
persistent slot<T> claims = 0
persistent Storage subclaims = 0
```

Empty ranges are represented only by container metadata.

### Insertion

For an empty index `i`:

```text
metadata says empty
    -> localized materialize_slot(i)
    -> transient slot<T> claim for element range
    -> initialize(slot, value)
    -> typed root becomes live
    -> publish metadata full
```

### Removal

For a live index `i`:

```text
metadata says full
    -> take(root)
    -> value + empty slot<T>
    -> publish metadata empty
    -> erase_slot(slot) -> Storage
    -> absorb raw range back into metadata invariant
```

The experiment explicitly rejects:

```text
double materialization
materialization of occupied range
metadata/root disagreement
whole-storage recovery while metadata is live
whole-storage recovery with outstanding claims
whole-storage recovery with untracked live roots
```

---

## 6. DensePrefixBuffer — Vec-like dense prefix

The scattered model still has per-index occupancy metadata, so M6 also adds the stronger Vec-like case:

```text
DensePrefixBuffer(capacity)
```

Its runtime occupancy metadata is only:

```text
len: usize
```

There is no per-slot occupancy table.

Invariant:

```text
[0, len)        live T roots
[len, capacity) raw/vacant backing owned by the container invariant
```

### push

```text
index = len
materialize tail slot<T>
initialize
len += 1
```

### pop

```text
index = len - 1
take live root
len -= 1
erase/absorb empty tail claim
```

The ordering intentionally models the Draft 17.2 rule that temporary disagreement between memory state and metadata must remain inside a small non-observable transition.

---

## 7. Runtime capacity pressure

M6 includes a direct runtime-capacity case:

```text
DenseMetadataBuffer(capacity = 257)
```

Before insertion:

```text
typed roots = 0
```

After inserting only index 256:

```text
typed roots = 1
```

After removal:

```text
typed roots = 0
```

The unused 256 element ranges never become persistent typed objects or persistent `slot<T>` values.

A separate Vec-like test uses capacity `1024` with `len` as the only occupancy metadata.

---

## 8. Representation differential testing

M6 runs the tagged and dense representations against the same logical oracle after every operation.

### Scattered occupancy

Representative run:

```text
capacity                  16
operations              1000
tagged initial roots      16
tagged tag slots           16
tagged replace calls     1008
dense initial roots        0
dense max live roots      14
dense materializations   504
dense absorptions        504
logical mismatches          0
```

Generated differential:

```text
500 traces
32,000 operations
capacity range 1..32
mismatches 0
```

### Vec-like prefix occupancy

Representative run:

```text
capacity                   64
operations               2000
tagged initial roots       64
tagged tag slots            64
dense initial roots         0
dense occupancy metadata    1 scalar (`len`)
dense materializations   1010
dense absorptions        1010
logical mismatches           0
```

Generated differential:

```text
500 traces
32,000 operations
capacity range 1..64
mismatches 0
```

The exact generated results are stored in:

```text
m6_dynamic_container_experiment_results.json
```

---

## 9. What M6 establishes

The experiment separates two claims that should not be conflated.

### Claim A — safe dynamic partial initialization must become a core per-element checker state

M6 does **not** support this claim.

The compiler does not need to statically track a dynamic initialized-index set such as:

```text
{0, 2, 5, ...}
```

The library metadata can remain the single source of truth.

### Claim B — a dense runtime-sized container needs a way to transition raw empty backing into/out of a typed object lifetime

M6 **does** support this claim.

Without a raw-vacant/lifetime bridge, the fully initialized alternative pays for occupancy in every capacity slot.

For Vec-like prefix occupancy the dense alternative requires only `len`, but it necessarily needs localized operations equivalent to:

```text
metadata empty tail
    <-> transient slot<T>
    <-> live T root
```

Thus the pressure justifies the **dynamic claim bridge**, not a general source-visible partial-initialization state machine.

---

## 10. Whole-storage recovery and allocation teardown

The dense models do not permit deallocation merely because a container value is being discarded.

Before backing teardown:

```text
all metadata must report empty
no tracked live roots
no untracked live roots
no outstanding slot claims
no external Storage subclaims
```

Only then does the prototype reconstruct:

```text
Storage(backing, [0, capacity))
```

and mark the BackingRegion dead.

This directly exercises the intended conservation rule:

```text
raw responsibility
    -> temporary typed claims / live roots
    -> raw responsibility
    -> backing teardown
```

---

## 11. Important limitation: this is not yet a source Allocation API

M6 deliberately does not claim that allocator surface design is closed.

The prototype uses a `BackingRegion` as the allocation identity and models teardown after whole-Storage recovery. It does not introduce source-level:

```text
Allocation
allocate(...)
deallocate(...)
Storage construction API
unchecked materialize_slot syntax
unchecked recover_whole_storage syntax
```

Those remain API/surface work.

The point of M6 is to establish the semantic requirement before choosing the spelling.

---

## 12. New tests

M6 adds `tests/test_m6_dynamic_container_pressure.py` covering:

```text
tagged vs scattered dense differential
tagged vs Vec-like prefix dense differential
runtime capacity without capacity-many typed roots
double dynamic-claim rejection
occupied materialization rejection
metadata/root corruption detection
whole-storage recovery preconditions
untracked-root recovery rejection
tagged teardown payload obligation
Vec-like len-only occupancy invariant
generated scattered differential
generated prefix differential
```

M6 adds no new `.nl` syntax programs because freezing the privileged boundary syntax is explicitly outside this pressure milestone.

---

## 13. Front-end validation

Final M6 front-end tree:

```text
296 tests collected
296 passed
compileall PASS
```

`ruff`, `mypy`, and `pyright` were not installed in the execution environment.

---

## 14. Independent Draft 17.2 validation

The independent closure tree was rerun fresh:

```text
110 tests collected
110 passed
compileall PASS
```

Executable closure vectors:

```text
12 / 12 PASS
```

Generated closure differential, seed `20261003`:

```text
alignment_padding   25,000  mismatch 0
mixed_width_add     25,000  mismatch 0
operation_matrix    25,000  mismatch 0
split_coordinate    25,000  mismatch 0
-------------------------------------
total              100,000  mismatch 0
false accept                 0
false reject                 0
```

No semantic-kernel regression was observed.

---

## 15. M6 judgment

**Front-End Prototype M6 pressure milestone passes.**

The main result is narrower than "add partial initialization":

> A genuinely dense runtime-sized container does justify raw vacant backing plus explicit lifetime construction/destruction boundaries. It does not justify compiler-tracked dynamic per-element initialization state.

The M5.2 tagged representation remains a valid safe alternative. M6 shows what is purchased by accepting a localized privileged bridge:

```text
no capacity-many live Maybe<T>-like roots
no per-slot tag for Vec-like prefix occupancy
runtime capacity independent of source-level Array length
```

The existing Draft 17.2 direction — metadata as single source of truth, with localized claim materialization/recovery — survives the pressure test.

---

## 16. Highest-information next step

The next step should be a small **M6.1 Storage/Allocation surface closure**, not a general partial-initialization feature.

It should pressure only the source/API spelling needed to express the mechanism already validated here:

```text
Allocation-backed Storage acquisition
Storage split/merge / exact slot conversion
localized unchecked dynamic materialize/recover boundary
teardown/deallocate conservation
reallocation/growth with live elements
borrow/span invalidation across growth
alignment and sizeof(T) > 1
```

If this source/API exercise forces a semantic change, that would be evidence for a new mechanism. M6 itself does not.
