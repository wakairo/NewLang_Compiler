from __future__ import annotations

import json
from pathlib import Path

from newlang_frontend.authority_region_pressure import RegionReject, ResponsibilityOracle, SealedRegion
from newlang_frontend.focus_pressure import run_focus_pressure
from newlang_frontend.region_surface_pressure import ClosureSurface


def targeted_checks() -> dict[str, object]:
    oracle = ResponsibilityOracle()
    region = SealedRegion(4, elem_size=8, elem_align=8, oracle=oracle, name="m64-target")
    region.register_type("Token", size=8, align=8)
    tokens = [f"x{i}" for i in range(4)]
    for i, token in enumerate(tokens):
        oracle.create_external(token)
        c = region.claim_vacant(i, "Token")
        region.initialize_vacant(c, token)

    closure = ClosureSurface(region)
    reentry_code = None
    def reenter(_claim):
        nonlocal reentry_code
        try:
            closure.with_live(1, lambda _: None, expected_type="Token")
        except RegionReject as exc:
            reentry_code = exc.code
    closure.with_live(0, reenter, expected_type="Token")

    duplicate_code = None
    try:
        region.claim_many([("live", 0, "Token"), ("live", 0, "Token")])
    except RegionReject as exc:
        duplicate_code = exc.code

    overlap_code = None
    try:
        region.claim_many_ranges([("live", 0, 2, "Token"), ("live", 1, 2, "Token")])
    except RegionReject as exc:
        overlap_code = exc.code

    adjacent = region.claim_many_ranges([("live", 0, 2, "Token"), ("live", 2, 2, "Token")])
    adjacent_count = len(adjacent)
    for claim in adjacent:
        region.return_live(claim)

    transition = region.begin_transition()
    ambient_transition_code = None
    try:
        region.claim_live(0, expected_type="Token")
    except RegionReject as exc:
        ambient_transition_code = exc.code
    authorized = region.claim_live(0, expected_type="Token", transition=transition)
    region.return_live(authorized)
    region.end_transition(transition)

    for i, token in enumerate(tokens):
        live = region.claim_live(i, expected_type="Token")
        got, vacant = region.take_live(live)
        assert got == token
        region.return_vacant(vacant)
    region.unseal()
    oracle.assert_conserved()

    return {
        "closure_reentry": reentry_code,
        "duplicate_index": duplicate_code,
        "partial_overlap": overlap_code,
        "adjacent_claim_count": adjacent_count,
        "ambient_transition_claim": ambient_transition_code,
        "authority_conserved": True,
    }


def main() -> None:
    result = {
        "schema": "newlang.m6_4_focus_closure/v1",
        "seed": 20261004,
        "targeted": targeted_checks(),
        "generated": run_focus_pressure(seed=20261004, traces=300, steps=64),
        "judgment": {
            "general_permission_calculus_required": False,
            "symbolic_range_solver_required": False,
            "ordinary_claim_policy": "one independent focus at a time per root",
            "multiple_claim_policy": "single atomic boundary with concrete pairwise non-overlap checks",
            "transition_policy": "new claim extraction requires the active scoped transition receipt while invariant is unpublished",
            "sub_element_range_focus": "deferred; M6.4 safe prototype is whole-element-granular",
        },
    }
    out = Path("m6_4_focus_closure_results.json")
    out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(out.read_text(), end="")


if __name__ == "__main__":
    main()
