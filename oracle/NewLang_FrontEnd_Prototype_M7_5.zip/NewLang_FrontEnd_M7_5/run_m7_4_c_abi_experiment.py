from __future__ import annotations

import json
import re
import subprocess
from pathlib import Path

from newlang_frontend.c_abi_boundary import baseline_c_abi_matrix
from newlang_frontend.c_abi_pressure import run_pressure


TARGETS = [
    "x86_64-unknown-linux-gnu",
    "x86_64-pc-windows-msvc",
    "aarch64-unknown-linux-gnu",
    "riscv64-unknown-linux-gnu",
]


def clang_version() -> str:
    return subprocess.check_output(["clang", "--version"], text=True).splitlines()[0]


def compile_ir(source: Path, target: str, output: Path) -> str:
    subprocess.run(
        ["clang", "-target", target, "-S", "-emit-llvm", "-O0", str(source), "-o", str(output)],
        check=True,
        capture_output=True,
        text=True,
    )
    return output.read_text(encoding="utf-8")


def signatures(ir: str) -> dict[str, str]:
    out: dict[str, str] = {}
    for line in ir.splitlines():
        if not line.startswith("define "):
            continue
        m = re.search(r"@([A-Za-z0-9_]+)\(", line)
        if m:
            out[m.group(1)] = line.strip()
    return out


def build_and_run_shim(tmp: Path) -> dict[str, object]:
    api = Path("backend_probe/m7_4_c_api.c")
    shim = Path("backend_probe/m7_4_native_shim.c")
    api_o = tmp / "c_api.o"
    shim_o = tmp / "native_shim.o"
    exe = tmp / "shim_probe"
    subprocess.run(["clang", "-O2", "-c", str(api), "-o", str(api_o)], check=True, capture_output=True, text=True)
    subprocess.run(["clang", "-O2", "-c", str(shim), "-o", str(shim_o)], check=True, capture_output=True, text=True)
    subprocess.run(["clang", str(api_o), str(shim_o), "-o", str(exe)], check=True, capture_output=True, text=True)
    cp = subprocess.run([str(exe)], check=False)
    return {"exit": cp.returncode, "passed": cp.returncode == 0}


def main() -> None:
    tmp = Path("backend_probe/.m7_4_tmp")
    tmp.mkdir(exist_ok=True)
    source = Path("backend_probe/m7_4_abi_probe.c")

    target_sigs: dict[str, dict[str, str]] = {}
    for target in TARGETS:
        out = tmp / (target.replace("-", "_") + ".ll")
        target_sigs[target] = signatures(compile_ir(source, target, out))

    paird = {target: sigs["paird_id"] for target, sigs in target_sigs.items()}
    big = {target: sigs["big_id"] for target, sigs in target_sigs.items()}
    paird_unique = len(set(paird.values()))
    big_unique = len(set(big.values()))

    pressure = run_pressure()
    shim = build_and_run_shim(tmp)

    result = {
        "clang": clang_version(),
        "targets": target_sigs,
        "paird_unique_llvm_signatures": paird_unique,
        "big_unique_llvm_signatures": big_unique,
        "target_specific_aggregate_classification_observed": paird_unique >= 3 and big_unique >= 2,
        "explicit_marshalling_pressure": pressure,
        "host_generated_c_shim": shim,
        "contract": baseline_c_abi_matrix(),
        "conclusion": (
            "NewLang native aggregate layout stays opaque. C by-value aggregate interoperability uses a distinct "
            "explicit C representation plus field/variant marshalling; sret/byval/register coercions are target ABI "
            "lowering details handled by a target classifier or generated C shim, never native source semantics."
        ),
    }
    Path("m7_4_c_abi_results.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
