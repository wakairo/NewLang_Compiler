from __future__ import annotations
import json, re, subprocess
from pathlib import Path

src = Path("backend_probe/m7_1_address_move.c")
ir = Path("backend_probe/m7_1_address_move.ll")
version = subprocess.check_output(["clang", "--version"], text=True).splitlines()[0]
subprocess.run(["clang", "-S", "-emit-llvm", "-O1", str(src), "-o", str(ir)], check=True)
text = ir.read_text(encoding="utf-8")
move = re.search(r"define[^@]*@move_node\([^\n]*\).*?\n}\n", text, re.S)
fix = re.search(r"define[^@]*@fix_self\([^\n]*\).*?\n}\n", text, re.S)
move_text = move.group(0) if move else ""
fix_text = fix.group(0) if fix else ""
result = {
    "clang": version,
    "ordinary_move_uses_memcpy": "llvm.memcpy" in move_text,
    "ordinary_move_contains_self_fixup": bool(re.search(r"store ptr %0, ptr %0", move_text)),
    "explicit_fix_contains_self_store": bool(re.search(r"store ptr %0, ptr %0", fix_text)),
    "integer_pointer_roundtrip": "ptrtoint" in text or "inttoptr" in text,
    "conclusion": "ordinary aggregate move preserves embedded pointer bits; address-sensitive fixup is a separate operation",
}
Path("m7_1_backend_probe_results.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps(result, indent=2, sort_keys=True))
