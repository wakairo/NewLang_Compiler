from __future__ import annotations

import json
import subprocess
from pathlib import Path

from newlang_frontend.backend_contract import baseline_contract_matrix
from newlang_frontend.driver import check_source


def compile_and_run(ir: Path, opt: str, out: Path) -> int:
    subprocess.run(["clang", opt, str(ir), "-o", str(out)], check=True, capture_output=True, text=True)
    cp = subprocess.run([str(out)], check=False)
    return cp.returncode


def main() -> None:
    version = subprocess.check_output(["clang", "--version"], text=True).splitlines()[0]

    noalias = Path("backend_probe/m7_3_noalias_probe.ll")
    readonly = Path("backend_probe/m7_3_readonly_probe.ll")
    tmp = Path("backend_probe/.m7_3_tmp")
    tmp.mkdir(exist_ok=True)

    noalias_o0 = compile_and_run(noalias, "-O0", tmp / "noalias_o0")
    noalias_o2 = compile_and_run(noalias, "-O2", tmp / "noalias_o2")
    readonly_o2 = compile_and_run(readonly, "-O2", tmp / "readonly_o2")

    optimized = tmp / "noalias_optimized.ll"
    subprocess.run(["clang", "-O2", "-S", "-emit-llvm", str(noalias), "-o", str(optimized)], check=True, capture_output=True, text=True)
    optimized_text = optimized.read_text(encoding="utf-8")

    source_alias = Path("tests/programs/13_semantic_aliased_actuals_conflict.nl")
    alias_result = check_source(source_alias.read_text(encoding="utf-8"), str(source_alias))
    source_capture = Path("tests/programs/241_ref_locator_capture_ok.nl")
    capture_result = check_source(source_capture.read_text(encoding="utf-8"), str(source_capture))

    matrix = baseline_contract_matrix()
    result = {
        "clang": version,
        "newlang_aliasing_write_refs_accepted": alias_result.accepted,
        "newlang_ref_can_export_persistent_locator": capture_result.accepted,
        "noalias_probe_o0_exit": noalias_o0,
        "noalias_probe_o2_exit": noalias_o2,
        "noalias_optimizer_changed_result": noalias_o0 != noalias_o2,
        "optimized_noalias_function_returns_constant_1": "ret i32 1" in optimized_text,
        "readonly_alias_probe_o2_exit": readonly_o2,
        "readonly_preserves_alias_observation": readonly_o2 == 2,
        "contract": matrix,
        "conclusion": (
            "ordinary NewLang ref<write> and ref<read> must not lower to LLVM noalias by type alone; "
            "readonly is a safe one-way fact for read refs, while noalias/alias.scope requires a separate checked access-exclusivity proof"
        ),
    }
    Path("m7_3_backend_contract_results.json").write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
