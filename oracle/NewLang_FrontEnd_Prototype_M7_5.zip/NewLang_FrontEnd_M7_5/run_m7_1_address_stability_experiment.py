import json
from pathlib import Path
from newlang_frontend.address_stability_pressure import run_address_stability_pressure

out = run_address_stability_pressure(seed=20261004, cases=20_000)
path = Path("m7_1_address_stability_results.json")
path.write_text(json.dumps(out, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps(out, indent=2, sort_keys=True))
