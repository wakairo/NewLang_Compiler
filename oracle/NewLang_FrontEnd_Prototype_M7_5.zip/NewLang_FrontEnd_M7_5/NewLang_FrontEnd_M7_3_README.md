# NewLang Front-End M7.3

M7.3 closes the first LLVM alias/lifetime backend contract.

Key result:

```text
ref<write,T> != LLVM noalias
```

and more generally:

```text
source permission/authority != backend optimizer promise
```

The bundle contains:

- executable conservative lowering model: `newlang_frontend/backend_contract.py`;
- LLVM `noalias` destructive probe;
- LLVM `readonly` alias probe;
- source proof that write refs may alias;
- source proof that scoped refs may export persistent ptr provenance;
- `NewLang_Backend_Contract_v0_1.md`;
- full regression suite.

Status: **PASS**.  No new source-visible mechanism is introduced.
