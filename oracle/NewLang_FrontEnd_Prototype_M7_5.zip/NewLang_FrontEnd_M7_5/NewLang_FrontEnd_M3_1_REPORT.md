# NewLang Front-End Prototype M3.1 — Generic Compiler-Pressure Closure Report

> Status: **completed M3.1 implementation-quality closure**
>
> Semantic baseline: `NewLang_v0_spec_Draft17_2.md`
>
> Starting point: Front-End Prototype M3
>
> Purpose: stress the M3 generic design under recursive instantiation, compiler-resource growth, inferred-requirement graph growth, wrapper propagation, coherence pressure, and semantic-effect preservation without adding a broader generic constraint/effect language.

---

## 1. Executive result

M3.1 did **not** uncover a Draft-18-level semantic defect.

The main failures found by compiler pressure were implementation-quality failures:

```text
unbounded type-changing generic recursion could end in Python RecursionError

inferred requirements were only direct requirements of a template;
generic wrappers did not expose transitive effective requirements

requirement equality included source span / receiver spelling,
so semantically identical requirements could duplicate

there were no explicit monomorphization or requirement-graph resource budgets
```

M3.1 closes those failures with:

```text
exact-cycle reuse
active-depth budget
total monomorph budget
normalized requirement identity
symbolic generic-call edges
fixed-point requirement propagation
requirement graph budget
observation tooling
```

The language model remains:

```text
no traits/interfaces
no source-visible generic capability constraints
no ADL-style candidate mixing
no overload ranking
no associated-output inference
no source-visible generic effect/lifetime system
```

---

## 2. Exact recursive instantiation is not expansion

M3 already inserted a provisional concrete function symbol into the monomorph cache before rechecking its body.

That architecture turns:

```text
loop<u32> -> loop<u32>
```

and:

```text
a<u32> -> b<u32> -> a<u32>
```

into finite cache cycles rather than new instantiations.

M3.1 makes that behavior explicit and tested.

When a cached key is encountered while that exact key is still in progress:

```text
(template function id, concrete type-argument tuple)
```

is treated as an **exact cycle hit** and the provisional symbol is reused.

Real-source tests verify:

```text
95_generic_direct_recursion_monomorph.nl
    -> one loop<u32> monomorph

96_generic_mutual_recursion_monomorph.nl
    -> a<u32>, b<u32>
```

No recursive clone chain is generated.

The compiler now records `monomorph_cycle_hits` for observation.

---

## 3. Type-changing recursion is expansion and must be bounded

A materially different case is:

```text
fn grow<T>(x: T) -> unit {
  loan read x as r {
    grow(ptr_from_ref(r))
  }
}
```

Concrete instantiation creates:

```text
grow<u32>
grow<ptr<u32>>
grow<ptr<ptr<u32>>>
...
```

There is no exact repeated monomorph key.

Before M3.1 this eventually produced a host-language `RecursionError`.

M3.1 adds an implementation resource boundary:

```text
E_GENERIC_MONOMORPH_DEPTH
```

with a prototype default active depth of:

```text
32
```

The threshold is an implementation choice, **not NewLang language semantics**.

`97_generic_growth_depth_error.nl` verifies that the compiler terminates with a normal source diagnostic instead of exhausting the Python stack.

---

## 4. Total monomorph budget

Depth alone does not bound wide instantiation graphs.

M3.1 therefore also adds:

```text
E_GENERIC_MONOMORPH_BUDGET
```

with a prototype default total cache budget of:

```text
256 instances
```

A dedicated regression lowers the budget to two instances and supplies three independent concrete `identity<T>` instantiations.

This distinguishes:

```text
deep expansion
```

from:

```text
wide finite expansion
```

and gives each a graceful diagnostic.

Again, the concrete threshold is intentionally non-normative.

---

## 5. Requirement identity is semantic, not source-positional

M3 stored `DependentRequirement` values directly, including:

```text
source span
receiver-syntax flag
```

in dataclass equality.

As a result, two calls such as:

```text
let first: u32 = hash(x)
hash(x)
```

could become two metadata requirements even though the public generic contract is the same:

```text
hash(ref<read,K>) -> u32
```

M3.1 defines the internal requirement identity as:

```text
(name, argument types, result type)
```

Receiver form remains surface spelling for the same associated lookup and source span remains diagnostic provenance.

`100_generic_requirement_dedup_ok.nl` verifies that duplicate source sites produce one effective requirement.

---

## 6. Generic wrapper requirements now propagate transitively

M3 correctly rechecked concrete nested generic bodies, so execution safety did not depend on transitive metadata.

However, the visible generic API contract was incomplete for:

```text
fn need_hash<K>(x: ref<read,K>) -> u32 {
  hash(x)
}

fn wrapper<U>(x: ref<read,U>) -> u32 {
  need_hash(x)
}
```

`wrapper<U>` can only instantiate where the effective operation requirement is satisfied, but M3 reported the requirement only on `need_hash<K>`.

M3.1 records a compiler-internal symbolic edge for generic-to-generic calls:

```text
caller template
callee template
callee-type-parameter -> caller symbolic type substitution
```

After all generic definitions are checked, the compiler computes a monotone fixed point over these edges.

The result is declaration-order independent.

For:

```text
need_hash<K>
wrapper<U>
outer<V>
```

`dump-requirements` now reports:

```text
need_hash:
  hash(ref<read,K>) -> u32
wrapper:
  hash(ref<read,U>) -> u32
outer:
  hash(ref<read,V>) -> u32
```

This aligns the visible metadata with the effective inferred generic contract.

---

## 7. Requirement SCCs converge

Mutually recursive generic wrappers can create a requirement graph SCC.

M3.1 tests:

```text
a<T> -> b<T>
b<T> -> a<T>
```

with one direct dependent requirement in the SCC.

Normalized requirement identity makes the fixed point finite:

```text
a: hash(ref<read,T>) -> u32
b: hash(ref<read,U>) -> u32
```

with one effective requirement each.

No requirement duplication occurs merely because the call graph is cyclic.

---

## 8. Type-transforming requirement cycles can grow forever

A more dangerous symbolic case is conceptually:

```text
R(T)
T -> ptr<T>
```

which can generate:

```text
R(T)
R(ptr<T>)
R(ptr<ptr<T>>)
...
```

without concrete monomorphization.

`105_generic_requirement_growth_source.nl` constructs this pressure case through real source.

M3.1 adds:

```text
E_GENERIC_REQUIREMENT_BUDGET
```

with a prototype default of:

```text
128 unique effective requirements per generic
```

The regression lowers that budget and verifies graceful termination.

This is important because monomorphization budgets alone do not protect definition-time symbolic requirement closure.

---

## 9. Larger requirement chains remain bounded and predictable

`107_generic_requirement_chain_pressure_ok.nl` contains:

```text
3 direct dependent operations
8 generic wrapper levels
```

The effective metadata contains:

```text
9 generic functions * 3 requirements = 27 effective requirements
```

with no duplicates and no accidental combinatorial growth.

This is also observable through:

```text
python -m newlang_frontend dump-generic-stats ...
```

which reports:

```text
requirement_edges: 8
effective_requirements: 27
```

---

## 10. Coherence / non-overlap pressure

M3.1 deliberately does **not** add general overload sets.

Two distinct nominal owners may each own the same associated function name:

```text
KeyA::hash
KeyB::hash
```

`106_associated_same_name_distinct_owners_ok.nl` verifies that:

```text
generic_hash<KeyA>
generic_hash<KeyB>
```

resolve independently through each nominal type's associated-function set.

There is no global same-name candidate mixing.

Within one owner, the current experimental symbol table still permits only one function per name.

`101_associated_duplicate_coherence_error.nl` therefore rejects even signatures that a future non-overlap scheme might distinguish:

```text
E_DUP_FUNCTION
```

This is stricter than a future provably non-overlapping overload model, but it remains coherent, ranking-free, and safe for v0 experimentation.

M3.1 found no reason to introduce specialization, ranking, or ADL-style search.

---

## 11. Generic wrappers still do not launder semantic effects

M3 already proved one dependent call could expose the concrete associated target's `Change(...)` effect after monomorphization.

M3.1 adds another wrapper level:

```text
outer<U>
    -> set_any<U>
        -> associated set(...)
            -> store(self@value, ...)
```

`102_generic_wrapper_effect.nl` verifies that a caller-visible live dependency on:

```text
box.value
```

still conflicts with:

```text
Change(box.value)
```

and produces:

```text
E_SEMANTIC_CONFLICT
```

The new requirement-metadata closure therefore does not replace body-sensitive semantic checking; both compose.

---

## 12. Generic result/post-state dependency: no speculative mechanism added

The M3.1 pressure pass explicitly revisited whether generic wrappers now require a general source-visible or serialized result/post-state dependency language.

The answer remains **no for the current source surface**.

Current tests exercise caller-visible invalidation/effects after dependent-target resolution, but the source language still does not provide a case where a generic dependent call returns a by-value semantic value whose hidden current-value dependency survives the call and must be represented independently of the body.

This is the same boundary already identified before M3:

```text
if a real source operation produces a surviving hidden dependency,
add the compiler-internal result/post-state transformer then
```

M3.1 therefore does **not** add:

```text
generic lifetime parameters
generic effect annotations
source-visible post-state constraints
general effect polymorphism
```

The same-compilation-unit body remains the semantic source of truth.

---

## 13. Recursive call summaries remain a separate interprocedural-analysis boundary

M3.1 closes **generic monomorphization cycles**.

That does not mean the current front-end bridges have a general recursive semantic/lifecycle summary.

For a direct recursive generic such as:

```text
loop<u32> -> loop<u32>
```

type checking and monomorphization terminate with one cached instance.

The current exact semantic bridge still maps a recursive call cycle to:

```text
Unknown effect
```

and conservatively rejects.

The lifecycle bridge likewise has a finite call-depth guard rather than a recursive lifecycle summary/fixpoint.

This limitation also applies to ordinary recursive functions; it is not caused by generics.

`108_generic_effectful_recursion_precision_error.nl` explicitly verifies that an effectful recursive generic is not accidentally accepted.

M3.1 intentionally does not hide this with a generic-specific special case. A future recursion pass should solve recursive function summaries/SCC fixpoints at the interprocedural semantic/lifecycle layer shared by generic and non-generic code.

---

## 14. Generic pressure observation tooling

M3.1 adds:

```text
python -m newlang_frontend dump-generic-stats file.nl
```

It reports:

```text
monomorphs
exact_cycle_hits
max_active_depth
requirement_edges
effective_requirements
```

Example for the mutual-recursion source:

```text
monomorphs: 2
exact_cycle_hits: 1
max_active_depth: 2
requirement_edges: 2
effective_requirements: 0
```

This is compiler tooling, not NewLang source semantics.

---

## 15. Real `.nl` M3.1 pressure corpus

M3.1 adds programs `95` through `108`:

```text
95  direct recursive generic monomorph cycle
96  mutually recursive generic monomorph cycle
97  type-growing recursion / depth budget
98  transitive wrapper requirement propagation
99  requirement SCC fixed point
100 semantic requirement deduplication
101 strict same-owner associated duplicate rejection
102 wrapper-chain semantic effect preservation
103 total monomorph budget source
104 direct requirement budget source
105 type-transforming requirement graph growth
106 same associated name under distinct nominal owners
107 larger wrapper/requirement chain
108 effectful recursive generic precision boundary
```

These are pressure/regression programs, not proposals for new syntax.

---

## 16. Validation

Final M3.1 front-end suite:

```text
169 tests collected
169 passed
compileall PASS
```

The suite contains every M0 through M3 regression plus the M3.1 pressure tests.

The execution environment does not contain:

```text
ruff
mypy
pyright
```

so this report does not claim those checks passed.

The supplied `NewLang_FrontEnd_Prototype_M3.zip` does not contain the separate upstream Draft 17.2 closure-test tree. Therefore M3.1 does **not** claim a fresh independent 110-test rerun.

The M3 report records the previous independent baseline as:

```text
110 tests collected
110 passed
compileall PASS
```

M3.1's final code does not modify the vendored semantic checker files relative to the supplied M3 bundle.

---

## 17. Implementation defaults are not language limits

M3.1 currently uses:

```text
DEFAULT_MAX_MONOMORPH_DEPTH = 32
DEFAULT_MAX_MONOMORPHS = 256
DEFAULT_MAX_REQUIREMENTS_PER_GENERIC = 128
```

These values exist to make resource exhaustion diagnosable in the prototype.

They must not be interpreted as normative NewLang limits.

A production implementation may expose larger/configurable budgets, adaptive accounting, caching, SCC-specific policies, or other resource controls while preserving the same language-level result for programs within supported resource bounds.

---

## 18. Architecture after M3.1

The generic path is now:

```text
Parsed generic source
    ↓
symbolic type parameters
    ↓
definition-time ordinary checking
    ↓
direct dependent requirements
    +
symbolic generic-call edges
    ↓
normalized requirement fixed point
    ↓
concrete argument inference
    ↓
monomorph cache
    ├─ exact key cycle -> reuse provisional symbol
    └─ new key -> budget checks -> body recheck
    ↓
associated target resolution
    ↓
existing semantic/lifecycle lowering
```

The pressure pass did not force a second generic-specific ownership, effect, or lookup system.

---

## 19. M3.1 judgment

**Front-End Prototype M3.1 passes as a generic compiler-pressure closure.**

The important outcome is that the first serious pressure did not call for a larger generic language.

It called for ordinary compiler engineering mechanisms:

```text
memoization
cycle recognition
resource budgets
normalization
fixed-point propagation
observation tooling
```

The one visible unresolved pressure point—recursive function semantic/lifecycle summaries—is broader than generics and should be solved once at the shared interprocedural-analysis layer rather than patched into generic instantiation.

No Draft-18-level semantic redesign is indicated by M3.1.
