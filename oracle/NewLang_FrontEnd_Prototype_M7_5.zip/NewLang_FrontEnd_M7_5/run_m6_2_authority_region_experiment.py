from __future__ import annotations

import json

from newlang_frontend.authority_region_pressure import (
    ResponsibilityOracle,
    SealedRegion,
    DenseVecModel,
    Slab8Model,
    RegionReject,
    exhaustive_ring_sequences,
    run_generated_slab_authority_pressure,
    run_generated_vec_authority_pressure,
)


def counterexamples() -> dict[str, str]:
    out: dict[str, str] = {}

    oracle = ResponsibilityOracle()
    vec = DenseVecModel(3, oracle=oracle, name="metadata-corruption")
    oracle.create_external("hidden")
    vec.push("hidden")
    vec.length = 0
    try:
        vec.region.unseal()
    except RegionReject as exc:
        out["metadata_empty_does_not_recover_authority"] = exc.code

    slab = Slab8Model(name="inline-free")
    try:
        slab.region.claim_vacant(0, "Token")
    except RegionReject as exc:
        out["logical_free_with_live_freenode_is_not_vacant"] = exc.code

    a = SealedRegion(1, elem_size=8, elem_align=8, name="wrong-root-a")
    b = SealedRegion(1, elem_size=8, elem_align=8, name="wrong-root-b")
    a.register_type("Token", size=8, align=8)
    b.register_type("Token", size=8, align=8)
    claim = a.claim_vacant(0, "Token")
    try:
        b.return_vacant(claim)
    except RegionReject as exc:
        out["wrong_root_return"] = exc.code
    a.return_vacant(claim)

    zst = "unexpected_accept"
    try:
        SealedRegion(4, elem_size=0, elem_align=1, name="zst")
    except RegionReject as exc:
        zst = exc.code
    out["zst_policy"] = zst

    return out


def main() -> None:
    result = {
        "schema": "newlang.frontend.m6_2.authority_region/v1",
        "principle": "metadata describes occupancy; authority/responsibility is conserved and transferred, never reconstructed from metadata",
        "generated_vec": run_generated_vec_authority_pressure(seed=20261004, traces=500, steps=64),
        "generated_slab": run_generated_slab_authority_pressure(seed=20261004, traces=300, steps=64),
        "ring_exhaustive": exhaustive_ring_sequences(depth=8),
        "counterexamples": counterexamples(),
        "source_surface": {
            "safe_storage_slot_algebra": "retained",
            "m6_1_unchecked_materialize_recover": "retired with E_M62_LEGACY_DYNAMIC_BRIDGE",
            "sealed_region_spelling": "not fixed; internal prototype only",
        },
    }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
