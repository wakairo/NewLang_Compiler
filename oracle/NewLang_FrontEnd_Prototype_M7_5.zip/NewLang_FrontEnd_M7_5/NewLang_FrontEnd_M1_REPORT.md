# NewLang Front-End Prototype M1 — Lifetime / Pointer Vertical Slice Report

> Status: **completed experimental M1 implementation**
>
> Semantic baseline: `NewLang_v0_spec_Draft17_2.md`
>
> Starting point: Front-End Prototype M0.1
>
> Purpose: extend the real `.nl` front end through explicit lifetime-root operations without changing Draft 17.2 semantics.

## 1. M1 scope

M1 adds the source/type/front-end path for:

```text
ptr<T>
slot<T>
LifetimeDomain

ref<read/write,T>
exclusive ref<read/write,T>

loan read ...
loan write ...
loan exclusive read ...
loan exclusive write ...

lifetime_domain()
finalize_domain(...)

initialize(slot, value, stable)
take(ptr, ending)
destroy(ptr, ending)
```

It also adds the minimal tuple type/pattern support needed to represent:

```text
take(...) -> (T, slot<T>)
```

The module/private-field/receiver-call surface from M0/M0.1 remains experimental and unchanged.

M1 deliberately does **not** yet add:

```text
Storage / Allocation / into_slot
ref_from_ptr
ptr_from_ref
sum / match
Array / span
callbacks
generics
requires / unchecked
code generation
```

Entry parameters of type `slot<T>` are backed by synthetic distinct slots in the M1 test harness. This is a prototype convention only; real `Storage -> slot<T>` source construction belongs to a later milestone.

---

## 2. Parser / type-system additions

The front end now parses and resolves:

```text
ptr<Box>
slot<Box>
LifetimeDomain
exclusive ref<read, LifetimeDomain>
(Box, slot<Box>)
```

and tuple patterns:

```text
let (value, empty) = take(...)
```

Exclusive loan syntax is:

```text
loan exclusive read life as ending {
    ...
}
```

The existing punctuation split remains:

```text
Foo::make(...)
p.destroy_like(...)
p@field
```

`ptr<T>@field` is typed structural projection and produces `ptr<Field>`. It does not dereference the pointer.

---

## 3. Lifecycle builtin type checking

### initialize

```text
initialize(
    slot<T>,
    T,
    ref<read,LifetimeDomain>
) -> ptr<T>
```

The slot and value types must agree exactly.

An ordinary domain read ref is required. Passing the `LifetimeDomain` value itself is rejected.

### take

```text
take(
    ptr<T>,
    exclusive ref<read,LifetimeDomain>
) -> (T, slot<T>)
```

### destroy

```text
destroy(
    ptr<T>,
    exclusive ref<read,LifetimeDomain>
) -> slot<T>
```

`destroy` additionally checks `Discardable(T)` in the supported M1 type universe.

No write-to-read contextual weakening is applied to `exclusive ref`; the existing ordinary-ref rule remains separate.

---

## 4. Loan conflict checking

M1 gives the front end a small lexical loan-state check sufficient for the new domain authority slice.

For one source place:

```text
ordinary loan(s) live
    => new exclusive loan rejected

exclusive loan live
    => new ordinary/exclusive loan rejected
```

This directly validates the intended lifetime-domain implication:

```text
stable ordinary domain ref live
    => exclusive ending-domain ref unavailable
```

The first M1 implementation attempt exposed an important compiler-side issue:

> a `loan { ... }` body is an exactly-once lexical block, so consumption of an outer non-Copy binding inside the body must propagate to the enclosing flow state.

The front-end availability state now propagates such consumption out of a loan body.

Example:

```text
loan read life as stable {
    initialize(slot, value, stable)
}
```

consumes the outer affine `slot`.

A later use of the same `slot` is rejected as:

```text
E_USE_AFTER_CONSUME
```

rather than being left solely to the lifecycle checker.

---

## 5. Minimal affine availability

M1 introduces the first source-level availability checks needed by actual affine core values.

At least:

```text
slot<T>
LifetimeDomain
exclusive ref<...>
```

are non-Copy in this front-end slice.

Direct repeated use after a consuming operation is rejected.

Examples covered:

```text
initialize(slot, ...)
initialize(slot, ...)       // reject
```

and:

```text
finish(life)                // by-value non-Copy transfer
finish(life)                // reject
```

`LifetimeDomain` finalization consumes the domain value.

The implementation remains deliberately small; it is not yet a general final availability implementation for every future aggregate/generic combination.

---

## 6. Shared semantic checker bridge

M1 does not implement independent `initialize` / `take` / `destroy` object-lifetime semantics in the type checker.

A new lifecycle bridge maps typed source bindings into the existing Draft-17 exact semantic-state representation and delegates core transitions to:

```text
newlang_checker.semantics.apply_step
```

The front end supplies source-level bindings for:

```text
slot
semantic value
ptr
LifetimeDomain identity
ordinary/exclusive domain ref
```

and the shared checker owns:

```text
slot -> live root
live root -> value + slot
live root -> slot
object incarnation
placement
ptr token staleness
occupancy validation
```

Function calls are executed body-sensitively in the M1 lifecycle bridge, so lifecycle authority is preserved through wrappers.

Positive test:

```text
destroy_box(p, ending)
```

works through a known wrapper.

Negative test:

```text
destroy_box(p, ending_from_wrong_domain)
```

still rejects with the root/domain mismatch.

---

## 7. Domain identity checks

The vendored exact semantic model was extended with explicit live domain identities.

M1 checks:

```text
initialize:
    governing domain must be live

take/destroy:
    ending domain must be live
    ending domain identity must equal root governing domain

finalize_domain:
    domain must be live
    no live root may still be governed by it
```

A mismatch produces:

```text
E_LIFETIME_DOMAIN_MISMATCH
```

A finalization while a root is live produces:

```text
E_DOMAIN_STILL_GOVERNS_ROOT
```

---

## 8. Stale pointer correction found by M1

M1 found one concrete gap in the vendored exact checker.

The existing `take` transition marked pointers to the ended incarnation stale, but the existing `destroy` transition did not.

That is inconsistent with the Draft 17.2 object-incarnation rule:

```text
lifetime ends
    => ptr to old incarnation may remain only as stale/dangling token
```

The M1 vendored checker now marks all ptr tokens to the destroyed incarnation stale as part of `destroy`, matching `take`.

A direct shared-checker regression test confirms that a second use is rejected.

This is an implementation-model correction, not a language semantic change.

---

## 9. Fixed-subobject ptr break-test

M1 also exercises:

```text
ptr<Box>@value -> ptr<u32>
```

inside the defining module.

The projected pointer remains a typed location derivation, but M1 marks it as not independently lifetime-root-capable.

Attempting:

```text
destroy(projected_ptr, ending)
```

rejects as:

```text
E_NOT_LIFETIME_ROOT
```

This preserves the existing Draft 17.2 rule that fixed fields are not independently lifetime-ending roots.

---

## 10. Real `.nl` lifecycle corpus

M1 adds 17 new source programs (`15` through `31`) covering:

```text
initialize -> destroy round trip
initialize -> take round trip
wrong ending domain
stable ordinary loan vs exclusive loan
initialize without stable ref
take without exclusive ref
stale ptr after destroy
finalize live governing domain
projected ptr is not lifetime root
slot double-use
finalize while stability loan is live
use-after-finalize
lifecycle wrapper success
lifecycle wrapper wrong domain
LifetimeDomain double transfer
unfinalized LifetimeDomain
unreturned slot<T>
```

Representative accepted source:

```text
fn main(slot: slot<Box>) -> slot<Box> {
  let life = lifetime_domain()

  let p = loan read life as stable {
    initialize(slot, Box::make(u32(42)), stable)
  }

  let empty = loan exclusive read life as ending {
    destroy(p, ending)
  }

  finalize_domain(life)
  empty
}
```

Representative diagnostic:

```text
E_LIFETIME_DOMAIN_MISMATCH:
root is governed by D#1, not D#2
```

with the primary source span on the actual `destroy(...)` expression.

---

## 11. Validation

Final M1 front-end suite:

```text
50 tests passed
compileall PASS
```

This includes all M0/M0.1 regressions plus the new M1 source and shared-checker tests.

The latest independent Draft 17.2 closure prototype was also rerun unchanged:

```text
110 tests passed
compileall PASS
```

No upstream semantic-checker regression was observed.

`ruff`, `mypy`, and `pyright` were not available in the execution environment, so this report does not claim those checks passed.

---

## 12. Architecture judgment

M1 did not require a redesign of the M0/M0.1 pipeline.

The current vertical slice is now:

```text
real .nl source
    ↓
lexer / parser + SourceSpan
    ↓
module / nominal / type resolution
    ↓
receiver + private representation checking
    ↓
ordinary ref + exclusive ref checking
    ↓
minimal affine availability
    ↓
M0.1 effect/dependency semantic-call bridge
    +
M1 exact lifecycle semantic-state bridge
```

Two implementation corrections emerged from real-source pressure:

```text
exactly-once loan body must propagate outer non-Copy consumption

destroy must stale ptr tokens to the ended incarnation
```

Both were resolved without changing Draft 17.2.

---

## 13. Remaining boundary before later milestones

M1 intentionally does not yet validate:

```text
ptr -> safe ref acquisition (`ref_from_ptr`)
Storage -> slot construction
general external/raw backing
sum occurrence semantics
Array/span/callback semantics
generic instantiation
production abstract-state analysis for the new source lifecycle bridge
```

The M1 lifecycle bridge currently uses the exact semantic state as the oracle for the new lifecycle operations. That is appropriate for the semantic/source vertical slice, but a later implementation-quality pass should route the same typed source into the production-like finite abstract checker as well.

The most important missing pointer-side operation is `ref_from_ptr`, because it is what turns the LifetimeDomain stability rule into safe object access. It can be added as a small M1.1-style continuation before, or together with, the next larger M2 surface slice.

---

## 14. Final judgment

**Front-End Prototype M1 passes.**

The real-source syntax for:

```text
ptr<T>
slot<T>
LifetimeDomain
exclusive ref
loan exclusive
initialize
take
destroy
finalize_domain
```

maps coherently onto the Draft 17.2 lifetime-root model.

No Draft-18-level semantic change was indicated.

The strongest next choice is either:

```text
small M1.1:
    ref_from_ptr / ptr_from_ref
    stability-dependent safe ref
    exact-vs-production lifecycle bridge comparison

or

M2:
    sum / match
    Array / consume_array
    span / callback
```

Given that `ref_from_ptr` is the remaining core link between `ptr` and the lifetime-stability model, the M1.1 path has higher local closure value before broadening the surface.
