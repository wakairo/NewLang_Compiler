# NewLang Front-End Prototype M7.1 Report

## 1. Scope

M7.1 is the second **C-substitutability / backend pressure** milestone.

It targets address-sensitive values and abstractions:

- self pointers;
- interior pointers;
- intrusive links/backlinks;
- external address registries/observers;
- whole-value `replace` / `swap`;
- consume-transfer (`take` + initialize elsewhere);
- physical relocation/reallocation;
- localized relocation fixup.

The pressure question is:

> Does NewLang need a core `Pin` / `Unpin` / `Relocatable` / nonmovable type property now, or can v0 keep ordinary value semantics and enforce address-stable abstractions by placing the physical object behind stable backing and a library-owned handle?

Draft 17.3 remains the normative semantic baseline.

## 2. Result

**PASS, without adding a core Pin/relocation capability.**

The experiment supports the existing Draft 17.3 decomposition:

```text
ordinary semantic value transfer
    !=
physical address-stability invariant
```

Ordinary transfer remains memory-safe by ending the source incarnation and leaving old persistent ptr tokens stale.
It does **not** repair self/interior pointers.

Ordinary `swap` is even more revealing: the two object incarnations remain live, so a pre-existing ptr to the left place remains live but now observes the semantic value swapped into that place.
Therefore a library invariant that means “this semantic object stays at this address” cannot be inferred from ordinary ptr liveness.

For safe address-stable abstractions, M7.1 instead uses the pattern:

```text
stable backing containing T
+
movable owner/handle value
+
private pointee location
+
no whole-T by-value exposure while anchored
```

This matches Draft 17.3 §17.4.

## 3. Important distinction: address sensitivity is often state-dependent

M6.2 had a conservative pressure-fixture `address_sensitive` bit on a token. M7.1 demonstrates why that should not become a nominal forever-property without further evidence.

The same logical `Node` can be:

```text
unlinked / no self invariant     -> movable
self-reference installed        -> address-stable
intrusive backlinks installed   -> address-stable
links/self invariant removed     -> movable again
```

Thus the natural axis is often **current abstraction state**, not “type T can never move”.

This is one reason not to add a v0 `!Relocatable`/`Pin` capability merely because self-referential workloads exist.

## 4. Ordinary relocation: memory-safe but invariant-breaking

`ordinary_relocate` models the existing consume-transfer semantics:

```text
source incarnation ends
old ptr tokens may remain as values but become stale
semantic value appears at fresh destination incarnation
```

No address-sensitive fixup is performed.

The generated pressure confirms 20,000/20,000 cases where the old locator is stale after the move and the destination has a different address/root.

A source-level workload also demonstrates the same rule:

```text
ptr<Node> saved in Holder
Node taken from old root
Node initialized at new root
saved old ptr -> ref_from_ptr(...)
```

is rejected with `E_STALE_PTR`.

This is not a memory-safety failure. It is exactly the defined persistent-ptr behavior.

## 5. Ordinary swap: the stronger abstraction counterexample

For two live places A and B:

```text
ptrA -> place A / semantic A
ptrB -> place B / semantic B

swap(A, B)

ptrA -> place A / semantic B
ptrB -> place B / semantic A
```

The ptr tokens remain live because `swap` preserves both object incarnations.

The generated pressure records this semantic/location mismatch in 20,000/20,000 cases.
The source-level `235_swap_keeps_location_observer_live_ok.nl` is accepted by both exact and production lifecycle runners.

Therefore:

> ptr liveness / provenance says which **place** is addressed, not which movable semantic value identity a higher-level library wishes to associate with that place.

This is why an address-stable abstraction must prevent client whole-value swap/replace by API structure rather than expecting ptr semantics to do so automatically.

## 6. Stable-place owner pattern

M7.1 models `StablePlaceOwner` and adds a source-level `StableNode` workload.

The source wrapper owns:

```text
Allocation
ptr<Node>
LifetimeDomain
```

while the physical `Node` lives in separately allocated stable backing.

The wrapper itself is a non-Copy value and can be transferred through functions:

```text
owner -> pass(owner) -> moved_owner
```

without moving the pointee.

The pointee field is private; outside code attempting `owner@node` is rejected with `E_PRIVATE_FIELD`.

This is the crucial representation pattern:

> move the **handle**, not the address-sensitive physical object.

The exact anchored/unanchored library surface remains Provisional; M7.1 does not add a source-visible `Stable<T>` core type.

## 7. Anchored operations in the pressure model

While a self/intrusive invariant is active, the library model rejects generic whole-value operations:

```text
whole replace  -> E_ADDRESS_STABILITY
whole swap     -> E_ADDRESS_STABILITY
take/relocate  -> E_ADDRESS_STABILITY
```

but permits same-place field/payload mutation that does not invalidate the address invariant.

20,000 generated cases each confirm:

- anchored replace rejected;
- anchored swap rejected;
- anchored take rejected;
- same-place payload update succeeds;
- moving the owner handle succeeds while pointee address stays fixed.

After the self/intrusive invariant is explicitly discharged, ordinary move is permitted again.
This is the experimental evidence for state-dependent rather than nominal-forever address sensitivity.

## 8. Localized fixup is possible, but not general

M7.1 includes a privileged **self-only** relocation/fixup model.

When the only address-sensitive relation is the object's own self pointer, a localized trusted boundary can:

1. discharge its private invariant;
2. perform the relocation;
3. install the fresh destination ptr;
4. rebuild the self relation.

20,000/20,000 self-only fixups succeed in the pressure model.

However, if an external intrusive observer/backlink exists, the same helper rejects with:

```text
E_NONLOCAL_RELOCATION_FIXUP
```

20,000/20,000 such cases are rejected.

This distinction is important:

```text
fix my private self pointer
```

is local, while:

```text
repair every escaped backlink / registry / callback context
```

is not a generic relocation primitive.

M7.1 therefore supports Draft 17.3's rule that `relocate_opaque` must not auto-retarget self/interior/link/registry pointers.

## 9. Backend probe

A C probe was compiled with the available Clang 17:

```c
typedef struct Node Node;
struct Node { Node *self; long value; };

void move_node(Node *dst, Node *src) { *dst = *src; }
void fix_self(Node *p) { p->self = p; }
```

At `-O1`, ordinary aggregate move lowers to `llvm.memcpy`.
The move body contains no self-pointer retargeting.
The explicit fix function lowers to a separate pointer store.

Probe result:

```text
ordinary_move_uses_memcpy:          true
ordinary_move_contains_self_fixup:  false
explicit_fix_contains_self_store:   true
integer_pointer_roundtrip:           false
```

This validates the backend assumption used by NewLang's semantics:

> ordinary representation transfer preserves pointer bits; structure-specific address repair is a separate semantic operation.

## 10. Generated M7.1 pressure

Seed: `20261004`.

```text
20,000 cases

ordinary relocation -> stale old locator       20,000
ordinary swap -> location/value mismatch        20,000
stable owner handle move                        20,000
anchored replace rejection                      20,000
anchored swap rejection                         20,000
anchored take rejection                         20,000
same-place payload update                       20,000
unanchor then ordinary move                     20,000
privileged self-only fixup                      20,000
non-local fixup rejection                       20,000
```

Experiment-level conclusions:

```text
runtime_pin_flag_required:               false
core_pin_type_required_by_experiment:    false
nominal_forever_nonrelocatable_required: false
general_relocation_fixup_safe:           false
```

These booleans are claims about the tested design space, not universal impossibility results.

## 11. Front-end validation

Final working tree before clean packaging:

```text
pytest:      422 / 422 PASS
compileall:  PASS
```

Measured in this prototype environment:

```text
full pytest elapsed: ~8.46 s
peak RSS:             ~134 MB
```

## 12. Independent Draft 17.2 closure regression

Fresh extraction of the independent closure prototype:

```text
pytest:      110 / 110 PASS
compileall:  PASS
closure executable vectors: 12 / 12 PASS
```

Generated differential:

```text
100,000 cases
mismatches:     0
false accepts:  0
false rejects:  0
```

## 13. Draft 17.3 comparison

M7.1 found no need for a Draft 17.4 semantic revision.

Draft 17.3 already states that:

- generic move/replace/swap do not repair self/interior/intrusive pointers;
- stable backing / handle indirection is the preferred library strategy;
- exposing address-sensitive representation as unrestricted first-class by-value `T` prevents representation hiding alone from blocking generic `swap`;
- v0 does not introduce Pin/Unpin/nonmovable/nonswappable/relocation traits;
- opaque relocation does not retarget arbitrary escaped pointers.

M7.1 is implementation evidence for those rules rather than a contradiction of them.

One wording refinement for a future consolidation may be useful:

> address sensitivity is often a dynamic abstraction state, not necessarily a permanent nominal type property.

This does not justify a semantic revision by itself.

## 14. What M7.1 does not claim

M7.1 deliberately does **not** claim:

- that no future stable-address core feature will ever be useful;
- that every stack/static self-reference API is ergonomic without Pin-like syntax;
- that library typestate spelling for anchored/unanchored owners is final;
- that arbitrary external backlinks can be repaired automatically;
- that concurrency/reclamation address stability is solved;
- that FFI code will respect NewLang stable-place abstractions;
- that `relocate_opaque` should become ordinary safe code;
- that no runtime metadata is ever useful for a particular allocator/runtime.

The narrower result is that the tested C-substitutability workloads do not currently force a general Pin/relocation type system into v0.

## 15. M7.1 judgment

**PASS.**

The preferred v0 decomposition remains:

```text
ordinary by-value T
    movable under normal NewLang value rules

persistent ptr<T>
    location/provenance token; may become stale

address-sensitive abstraction
    keep physical T behind stable backing
    expose movable logical owner/handle
    hide whole-T by-value mutation while invariant is active

special relocation
    localized privileged transition
    explicit structure-specific fixup if needed
```

No runtime pin flag, source-visible Pin type, or nominal forever-nonrelocatable property is required by M7.1.

## 16. Recommended next pressure

Continue the backend/C-substitutability phase with:

1. **over-aligned storage + explicit ZST policy**;
2. backend lowering of `ref<read/write>` and lifetime-ending authority, especially the rule `ref<write,T> != LLVM noalias`;
3. then C ABI / by-value aggregate boundary and FFI/external backing.

The strongest next semantic/backend falsification target is the alias contract: a backend optimization must not strengthen NewLang write permission into exclusivity that the source language did not grant.
