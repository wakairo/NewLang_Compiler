# NewLang Front-End Prototype M6.6 Report

## 1. Scope

M6.6 is the third and final pre-Gate-A **convergence-closure** milestone.

It targets the prior-art risk that removing source-visible lifetime/effect/permission annotations does not remove their complexity, but merely moves it into compiler inference and privileged-library failure paths.

The milestone pressure-tests:

- recursive SCC effect summaries;
- projection-growing recursion and finite widening;
- dependency/post-state information that the small summary language cannot represent;
- branch-correlated finite analysis under a bounded alternative budget;
- resolved/unknown generic and callback behavior;
- precision-loss diagnostics and source origin;
- normal recoverable error exits while dynamic-region responsibility is temporarily open;
- responsibility conservation across claim, initialization, publication, take, claim return, and allocation-failure boundaries.

The goal is not to add a general permission/effect language.  The success criterion is smaller:

```text
analysis must terminate
Unknown must never become permission
precision loss must have a useful source/cause diagnostic
normal error exits must not lose or duplicate responsibility
```

## 2. Normative baseline

Semantic baseline remains `NewLang_v0_spec_Draft17_3.md`.

M6.6 does not introduce a new source-visible lifetime, effect, focus, version, or failure syntax.

The relevant Draft 17.3 stance is:

```text
body-sensitive information may be inferred
finite summaries / widening are allowed
Unknown is conservative
responsibility is never silently discarded on a normal exit
```

## 3. Unknown is now diagnosable, not merely conservative

Before M6.6, the recursive semantic summary already widened unsupported dependency/callback post-state to `Unknown`, and production-style analysis already rejected Top/non-convergent states conservatively.

The weakness was diagnostic provenance.  A recursive call could eventually report only:

```text
Unknown effect
```

M6.6 extends the internal `Summary` fixture with diagnostic-only finite `unknown_reasons`.

Examples include:

```text
dependency-post-state
callback-post-state
generic-resolution-or-post-state
effect-budget-exceeded:4
scc-fixpoint-nonconvergent:32
recursive-scc:recurse
```

These labels do **not** refine semantics.  `Unknown` remains a may-conflict and therefore rejects when required for safety.

The source diagnostic now identifies both the call site and the reason.  For the existing recursive dependency fixture:

```text
E_SEMANTIC:
Unknown effect: recursive summary for recurse lost precision
(dependency-post-state, recursive-scc:recurse)
```

and the diagnostic span points at the recursive call.

Propagation-only labels from calls inside the same SCC are filtered from the final user-facing cause set; the originating cause and SCC context remain.

## 4. Important implementation correction: Unknown cause must be monotone

A useful defect was found while adding diagnostics.

A projection-growing SCC could first exceed the finite effect budget and become `Unknown`, but a later fixpoint iteration could replace the original reason with merely:

```text
callee-summary-unknown
```

The semantic result stayed conservative, but the *cause* of precision loss disappeared.

M6.6 makes `Unknown` an absorbing state for the finite summary abstraction and monotonically preserves the original widening causes.

This does not make the analysis more permissive.  It makes the reason for conservative rejection stable and diagnosable.

## 5. Termination pressure

Projection-growing recursion was exercised with bounded effect and SCC-iteration budgets.

Example shape:

```text
fn grow(x) {
    Change(x.value)
    grow(x.next)
}
```

With a small effect budget, the summary widens rather than diverges.

M6.6 verifies:

- finite SCC iteration;
- finite reason labels;
- widening to `Unknown` when the effect set grows beyond the configured abstraction;
- no later refinement from `Unknown` back to permission.

Call-depth exhaustion and unresolved generic calls also produce conservative `Unknown` rejection with a precise reason instead of being treated as no-effect calls.

## 6. Callback / generic pressure

M6.6 keeps the existing v0 rule that unsupported callback/generic post-state does not become an empty summary.

Covered cases include:

- recursive callback post-state -> `Unknown`;
- unresolved generic call -> `Unknown`;
- 0..N nonescaping callback whose effect conflicts with a live dependency -> rejection on the called path;
- ordinary resolved paths continue to use body-sensitive substitution.

No new callback effect syntax was added.

## 7. Bounded branch-correlation pressure

A generated differential pressure test attacks the small bounded may-analysis directly.

Seed: `20261004`.

Generated cases:

```text
20,000
```

Each case contains 1..16 correlated alternatives over dependency/effect places.  The production-like alternative budget is 8, so many generated cases intentionally force relation loss/widening.

Result:

```text
exact accepts:       3,467
exact rejects:      16,533
bounded accepts:     3,129
bounded rejects:    16,871
false accepts:           0
false rejects:         338
precision rejections: 10,155
```

The critical soundness result is:

```text
false accept = 0
```

The 338 false rejects are also important.  They are roughly 9.7% of exact-safe cases in this deliberately adversarial synthetic distribution.

This is **not** an estimate of ordinary NewLang program rejection rate: alternative counts are uniformly stressed across and beyond the budget.  It is a Gate-A warning metric.  If similar conservative rejection becomes common in real workloads, the project should consider a small explicit/modular summary mechanism rather than increasing heuristic inference complexity.

M6.6 does not add backtracking or heuristic search to recover these cases.

## 8. Normal-error responsibility closure

M6.2 already had failure guards around DenseVec initialization.  M6.6 extends the test surface through publication and claim-return boundaries.

### Push failure points

```text
after claim
after initialize
after public metadata update
```

Every injected failure returns the new Token responsibility to the caller and restores the vector to its pre-operation state.

### Pop failure points

```text
after live claim
after take
after public metadata update
after vacant-claim return
```

Every injected failure restores the old live Token responsibility to the container and restores public length/content.

### Grow failure

Allocation failure occurs before transfer and preserves the old allocation and all Token responsibilities.

The model distinguishes a normal error return from unwind/foreign non-local exit.  M6.6 does not claim a general unwind model.

## 9. Success/rollback boundary defect found during implementation

The first `try_pop` implementation exposed a concrete harness error: the defensive `finally` rollback also ran after a successful pop and restored the Token into the vector after it had been returned to the caller.

The tests caught this immediately.

The fix makes successful ownership transfer an explicit commit before the defensive rollback block.

This is a small prototype bug, but it validates the design requirement:

```text
normal rollback obligation
!=
successfully committed responsibility transfer
```

## 10. Generated failure pressure

Seed: `20261004`.

```text
300 traces
19,200 operations

push failures:       2,427
pop failures:        2,046
growth failures:     3,384
successful pushes:   4,977
successful pops:     4,134
mismatches:              0
```

After every operation, including every injected failure:

- no transition receipt remains active;
- no scoped claim remains open;
- public metadata agrees with hidden responsibility;
- every non-Discardable token has exactly one owner.

## 11. Front-end validation

Final M6.6 tree:

```text
pytest:      396 / 396 PASS
compileall:  PASS
```

Measured in this prototype environment:

```text
full pytest elapsed:  ~8.5 s
peak RSS:              ~133.5 MB

M6.6 generated experiment elapsed: ~2.0 s
peak RSS:                         ~95.8 MB
```

These numbers are baselines for future milestones, not compiler performance claims.

## 12. Independent Draft 17.2 closure regression

Fresh independent checker rerun:

```text
pytest:      110 / 110 PASS
compileall:  PASS
closure executable vectors: 12 / 12 PASS
```

Generated closure differential:

```text
100,000 cases
mismatches:     0
false accepts:  0
false rejects:  0
```

## 13. What M6.6 does not claim

M6.6 deliberately does **not** claim:

- that whole-unit/body-sensitive inference will scale to arbitrarily large programs;
- that incremental compilation is solved;
- that FFI/opaque external calls need no contracts;
- that all safe programs can be inferred without annotations;
- that branch-correlation false rejects are negligible in real workloads;
- a general unwind / foreign exception / `longjmp` model;
- a source-visible summary/effect language;
- a general permission calculus;
- proof of compiler correctness.

The result is narrower: the current finite abstraction has an explicit safe stopping behavior, and the prototype can explain important precision-loss causes.

## 14. Gate A evaluation

M6.4, M6.5, and M6.6 together provide the planned convergence-closure evidence.

### M6.4

Focus/re-entry/multiple-claim pressure closed with:

```text
single-root focus discipline
+ atomic concrete multi-claim boundary
```

without a general permission language or symbolic range solver.

### M6.5

CurrentValueVersion pressure closed with structural ghost value identities, ancestor invalidation, and known-disjoint sibling preservation, without a runtime version counter or source-visible state-permission calculus.

### M6.6

Body-sensitive analysis remains finite/conservative in the tested abstraction, and normal errors preserve responsibility without destructor/unwind machinery.

### Gate A judgment

**PASS, with an explicit inference-precision watch condition.**

There is currently no evidence that ordinary v0 semantics require:

```text
general permission language
large source-visible lifetime/effect annotations
proof terms
heuristic/backtracking-heavy inference
runtime value-version counters
```

The main remaining risk is practical precision/scalability, not an already-observed soundness hole.

The project should therefore continue as NewLang rather than merge into ATS/Austral/etc. at this point, while retaining this stop condition:

> If real systems workloads routinely hit conservative `Unknown`/correlation rejection, prefer a small explicit summary boundary over increasingly clever inference.

## 15. Next phase

Gate A permits moving from semantic convergence closure to **C-substitutability / backend pressure**.

Recommended order:

1. intrusive list / owner recovery (`container_of` pressure);
2. self-reference / address-sensitive values;
3. over-aligned storage and explicit ZST policy;
4. lowering of `ref<read/write>` and lifetime-ending authority to backend alias/lifetime contracts;
5. C ABI / by-value aggregate boundary;
6. FFI / external backing and opaque-call summaries.

The first backend rule to falsify should be:

```text
ref<write,T> != LLVM noalias
```

because NewLang deliberately separates write permission from exclusivity/lifetime-ending authority.
