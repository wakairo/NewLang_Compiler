# NewLang Front-End Prototype M6.3 — Layout Witness / Region-Claim Surface Closure

> Status: **completed experimental M6.3 implementation**
>
> Semantic baseline: `NewLang_v0_spec_Draft17_2.md`
>
> Starting point: Front-End Prototype M6.2
>
> Purpose: close two M6.2 Provisional questions without reintroducing metadata-driven authority reconstruction.

## 1. M6.3 scope

M6.3 tests two questions:

1. Can an opaque generic `T` participate in raw-storage allocation and typed placement without exposing aggregate field layout or requiring C-compatible layout?
2. What is the smallest source-level shape for the M6.2 authority-preserving dynamic-region bridge?

The M6.2 invariant remains unchanged:

```text
metadata describes occupancy
authority/responsibility is conserved and transferred
metadata never mints or erases responsibility
```

M6.3 deliberately does **not** add:

```text
compiler dynamic initialized-index-set tracking
metadata -> authority reconstruction
implicit object creation
transparent pointer rebinding
source-visible Pin/relocation traits
an exactly-once callable kind
source-visible requires/effect syntax
field offsets / C-compatible nominal layout
```

## 2. Compiler-provided `Layout<T>` witness

M6.3 adds the experimental type:

```text
Layout<T>
```

and the minimal source operations:

```text
layout() -> Layout<T>               // T comes from expected result type
layout_size(Layout<T>) -> usize
layout_align(Layout<T>) -> usize
layout_stride(Layout<T>) -> usize

allocate_layout(Layout<T>, count)
    -> (Allocation, Storage)

storage_into_slot_layout(Storage, Layout<T>)
    -> slot<T>
```

The key design choice is that `Layout<T>` is **not raw-memory authority** and is **not a field-layout descriptor**.

It communicates only the compiler-selected target facts needed by generic storage code:

```text
size
alignment
stride
```

The typed IR witness deliberately has no field-offset map.

### 2.1 Expected-type-only construction

M6.3 does not add explicit call-site type arguments merely to construct a layout witness.

Instead:

```text
let witness: Layout<Box<u32>> = layout()
```

is accepted, while:

```text
let witness = layout()
```

is rejected with:

```text
E_LAYOUT_RESULT_REQUIRED
```

This preserves the M3 rule that generic result types are not freely inferred backwards from arbitrary calls.

### 2.2 Opaque nominal layout remains opaque

M6.1 correctly rejected:

```text
4-byte Storage -> slot<Box>
```

when `Box` was an ordinary opaque nominal, because source code was guessing its representation.

M6.3 now permits:

```text
let witness: Layout<Box<u32>> = layout()
let slot: slot<Box<u32>> = storage_into_slot_layout(raw, witness)
```

because the size/alignment decision comes from the compiler witness rather than from user-written assumptions.

This is an important distinction:

```text
source guesses Box layout          => rejected
compiler supplies Layout<Box<T>>   => accepted
```

No field offset becomes source-visible.

## 3. Prototype target-layout model

The M6.3 compiler prototype computes concrete target layout after generic instantiation.

The exact numeric ABI is **not normative NewLang semantics**. The prototype model exists to test whether an opaque witness is sufficient for generic storage algorithms.

Current prototype rules cover:

- `u32`, `usize`, `bool`
- pointer/reference-shaped values
- arrays
- tuples
- ordinary nominal aggregates
- sum types
- concrete generic instantiations
- `LifetimeDomain` as a concrete prototype value representation

Aggregate field offsets may be computed internally, but only final extent/alignment/stride enter `TLayoutInfo`.

For example:

```text
module Padded
  struct { a: u32, b: usize }
end
```

produces, on the prototype target:

```text
Layout<Padded>
size   = 16
align  = 8
stride = 16
```

without exposing the offset of either field.

## 4. Generic monomorphization

A generic body may request a witness:

```text
fn witness_from_ref<T>(value: ref<read,T>) -> Layout<T> {
  layout()
}
```

At generic definition time the layout remains symbolic.

After concrete instantiation, e.g. `T = Padded`, the compiler registers a concrete witness.

This is compatible with the existing M3 generic strategy:

```text
definition-time generic checking
+
concrete monomorphization
+
body recheck
```

No new trait/concept requirement language was needed.

The resulting `Layout<T>` is a type/target witness, not a capability dependent on the particular `value` or its loan. A witness produced inside a loan may therefore leave that loan scope without keeping the object stable.

## 5. Layout witness and authority remain separate

`Layout<T>` is Copy/Discardable in the prototype.

Copying a witness does not duplicate any of:

```text
Allocation authority
Storage responsibility
slot<T> responsibility
live object responsibility
LifetimeDomain authority
```

The witness answers only:

> if storage authority is independently available, what target extent/alignment/stride does this `T` require?

This keeps the M6.2 rule intact:

```text
knowledge != authority
metadata != authority
layout != authority
```

## 6. ZST policy

M6.2 already showed that a purely byte-range dynamic region does not automatically model logical multiplicity for zero-sized values.

M6.3 therefore rejects a requested zero-sized layout witness for dynamic-storage use with:

```text
E_M63_ZST_POLICY
```

This is a Provisional v0 boundary, not a claim that NewLang can never support zero-sized types.

The important point is that M6.3 does not silently equate:

```text
0 bytes
```

with:

```text
0 logical object responsibilities
```

## 7. Region-claim source-surface comparison

M6.2 established the semantic rule but intentionally left source spelling open.

M6.3 compares three candidate layers:

```text
A. explicit receipt/token
B. nonescaping closure
C. requires/dependent privileged hook
```

The comparison is performed against the same `SealedRegion` authority ledger, so no candidate is allowed to mint authority from metadata.

## 8. Candidate A — linear receipt/token

The experimental `ReceiptSurface` wraps the existing rooted M6.2 claim receipt in a conceptual linear token.

A token is:

```text
non-duplicating
single-consumption
root/region-bound
index/epoch-bound
claim-kind-bound
```

The underlying region still validates:

```text
root identity
epoch
open-claim membership
vacant/live state
borrow conflicts
```

The token wrapper additionally rejects reuse with:

```text
E_M63_CLAIM_TOKEN_CONSUMED
```

This candidate is the best semantic base because it matches NewLang's existing rules directly:

```text
non-Copy
non-Discardable
explicit transfer
responsibility conservation
```

No new ownership system is required.

## 9. Candidate B — nonescaping closure

The initial concern was that NewLang's existing callable block has `0..N` synchronous invocation semantics, so a dynamic claim might require a new exactly-once callable kind.

M6.3 found that this conclusion was too strong.

### 9.1 Source break test

The following shape is accepted:

```text
fn thread<T>(claim: slot<T>, f: block(slot<T>) -> Storage) -> Storage {
  f(claim)
}
```

The linear claim is consumed by the callback invocation.

Calling the callback twice with the same claim is rejected by existing availability checking:

```text
E_USE_AFTER_CONSUME
```

A zero-invocation path is also valid if that path itself consumes/returns the claim:

```text
fn skip<T>(claim: slot<T>, f: block(slot<T>) -> Storage) -> Storage {
  erase_slot(claim)
}
```

Dropping the claim instead is rejected at lifecycle exit:

```text
E_SLOT_NOT_CONSUMED
```

### 9.2 Consequence

Therefore:

> callback cardinality does not have to carry the authority proof.

The authority proof can remain in the linear token that is threaded through the helper implementation.

A nonescaping closure can be ergonomic sugar over receipt/token semantics.

M6.3 does **not** add an exactly-once callable category.

For more complicated vacant->live or live->vacant transitions, the closure helper still needs an explicit post-state protocol internally; the closure itself is not the semantic owner of authority.

## 10. Candidate C — dependent / privileged hook

A privileged library hook can safely implement high-level operations such as:

```text
install(index, value)
remove(index) -> value
```

by using the receipt protocol internally.

This keeps claims out of ordinary user code and is useful for container/library implementations.

However it is not a replacement for the authority model.

A dependent named function / inferred generic requirement determines:

```text
which operation implementation is available
```

It does not determine:

```text
who owns the hidden vacant/live responsibility
```

If every lifecycle operation is represented only as a privileged hook, the trusted surface grows per operation:

```text
install
remove
replace
drain
move-range
swap-bucket
...
```

Thus the M6.3 conclusion is:

```text
privileged/dependent hook = implementation/dispatch layer
linear receipt/token      = authority layer
```

## 11. Surface decision after M6.3

The experimental comparison produces:

| Candidate | Authority conservation | New callable semantics | Trusted surface growth | M6.3 judgment |
|---|---:|---:|---:|---|
| linear receipt/token | yes | no | constant | **best semantic base** |
| nonescaping closure | yes, when built on token threading | no | constant | **good ergonomic sugar** |
| privileged/dependent hook | yes internally | no | per-operation | **useful implementation layer, not authority model** |

The concrete source spelling remains Provisional.

M6.3 does **not** freeze names such as:

```text
RegionClaim<T>
VacantClaim<T>
LiveClaim<T>
SealedRegion<T>
```

The important semantic commitment is only that any eventual spelling behaves like a linear rooted receipt rather than metadata-driven authority reconstruction.

## 12. Relation to M6.2 research correction

M6.2 corrected the old model from:

```text
metadata says vacant
    -> reconstruct authority
```

to:

```text
rooted region already owns responsibility
    -> temporarily transfer part of that responsibility
    -> return or transform it
```

M6.3 confirms that this stronger authority rule is compatible with a small source model.

No compiler dynamic initialized-index set is required.

No metadata-derived whole-storage authority reconstruction is reintroduced.

## 13. Source cases added

M6.3 adds source cases 202..213:

```text
202 opaque nominal Layout<T> placement
203 generic allocate_layout
204 layout() expected-type requirement
205 explicit ZST policy boundary
206 zero-count layout allocation rejection
207 generic sum Layout<T>
208 non-Discardable nominal Layout<T>
209 linear claim through one block invocation
210 double invocation / token reuse rejection
211 zero-invocation path consumes claim itself
212 dropped claim rejection
213 generic monomorphized layout witness + stride split
```

## 14. Experiment results

`m6_3_layout_and_region_surface_results.json` records:

```text
receipt:
    authority conserved
    double token use rejected

closure:
    unused scoped claim closed
    lifecycle transition closed
    new exactly-once callable kind required = false

hook:
    authority conserved
    general claim protocol not exposed
    trusted operations exercised = 2
```

The source block-token cases record:

```text
209 accepted
210 E_USE_AFTER_CONSUME
211 accepted
212 E_SLOT_NOT_CONSUMED
```

## 15. Validation

Fresh front-end validation:

```text
351 tests collected
351 passed
compileall PASS
```

Independent Draft 17.2 closure rerun:

```text
110 tests collected
110 passed
compileall PASS
executable closure vectors: 12 / 12 PASS
generated differential: 100,000 cases
mismatch: 0
false accept: 0
false reject: 0
```

`ruff`, `mypy`, and `pyright` were not installed in the execution environment.

## 16. Semantic judgment

M6.3 strengthens the case that the current NewLang core can support generic dense containers without adopting C/C++ aggregate-layout exposure or Rust-style source lifetime parameters.

The emerging decomposition is:

```text
compiler target knowledge:
    Layout<T>

safe raw-storage authority:
    Allocation / Storage / slot<T>

container hidden authority:
    rooted/sealed responsibility owner

dynamic extraction:
    linear rooted receipt/token

ergonomics:
    nonescaping closure sugar

customization/dispatch:
    dependent or privileged hook
```

These layers are orthogonal enough that one does not need to impersonate another.

## 17. Fix / Provisional / Deferred after M6.3

### Fix candidate

```text
storage / typed-empty slot / live object remain distinct
metadata != authority
layout knowledge != authority
responsibility is conserved through dynamic lifetime transitions
claim origin/root identity is preserved
compiler core need not track arbitrary dynamic initialized-index sets
opaque aggregate field layout remains hidden
compiler may provide generic target layout facts without making them ABI promises
```

### Provisional

```text
exact source spelling of linear region receipt/token
whether Layout<T> is materialized at runtime or compiler-erased
exact set of Layout<T> query operations
ZST logical multiplicity policy
safe prefix/two-range helper APIs
region-consume -> whole Storage source spelling
in-place destruction for address-sensitive values
```

### Deferred

```text
metadata/pointer -> authority reconstruction
general implicit object creation
transparent old-pointer rebinding
general relocation/Pin framework
full external backing / FFI lifetime admission
concurrent reclamation API
```

## 18. Recommended next step

M6.3 removes the need for another immediate dynamic-container feature milestone.

The next high-information work should be a **Draft 17.3 semantic consolidation pass**, not M6.4 feature growth.

That pass should:

1. add the small general rules discovered by M6.2/M6.3 to the normative draft:
   - metadata does not mint authority;
   - hidden responsibility must be conserved;
   - compiler-provided layout knowledge is separate from layout authority/ABI exposure;
2. keep receipt/token spelling Provisional;
3. explicitly record the v0 ZST policy boundary;
4. state that closure helpers may be built on linear claim threading without creating a new exactly-once callable kind;
5. preserve `Layout<T>` as a provisional source surface until codegen/ABI work determines whether the witness is runtime data or compile-time erased.

After that consolidation, the next implementation milestone should probably move outward toward code generation / ABI / FFI pressure rather than continue inventing container primitives.
