# NewLang Front-End Prototype M5 Report

## 1. Scope

M5 starts from the revalidated M4 front end and adds the next vertical slice:

```text
generic nominal modules
user-defined generic sum types
nominal type-argument substitution
associated-function ownership across nominal instantiations
structural Copy / Discardable derivation after substitution
Sized recursion validation
resource-bearing generic aggregate lifecycle handling
real generic container workloads composed with M4 loops
```

The semantic baseline remains **NewLang v0 Draft 17.2**. M5 does not introduce a new trait/interface system, specialization, overload ranking, ADL-style candidate mixing, source-visible lifetime/effect constraints, mutable locals, or a layout guarantee.

The principal question was not whether `Box<T>` syntax could be parsed. It was whether generic nominal identity, associated lookup, capability derivation, sum occurrence semantics, resource ownership, loops, and monomorphization could compose without weakening the Draft 17.2 boundaries.

---

## 2. Source surface

Generic nominal modules extend the existing module form:

```text
module Box<T>
  struct { value: T }

  fn make(value: T) -> Self {
    Self { value: value }
  }
end
```

Generic sums extend the existing sum form:

```text
sum Maybe<T> {
  None,
  Some(T),
}
```

Concrete types use the already-existing generic type syntax:

```text
Box<u32>
Maybe<Box<u32>>
ptr<Node<T>>
Array<T,2>
```

No explicit generic call-site syntax such as:

```text
Box<u32>::make(...)
f<u32>(...)
```

is added in M5. Generic associated functions continue to use argument-based inference. This preserves the M3 rule that ordinary generic function inference is argument-driven.

A generic sum constructor is not modeled as a generic function. For payload variants, sum arguments are inferred from the payload. For payloadless variants, a complete expected sum type may supply the arguments:

```text
let x: Maybe<u32> = Maybe::None()

fn none_u32() -> Maybe<u32> {
    Maybe::None()
}
```

Without payload evidence or expected type:

```text
let x = Maybe::None()
```

M5 rejects with `E_GENERIC_SUM_INFERENCE` rather than inventing a type.

---

## 3. Nominal identity and type arguments

M5 deliberately separates:

```text
nominal declaration identity
```

from:

```text
concrete type arguments
```

Conceptually:

```text
Box<u32>  = Nominal(type_id = Box, args = [u32])
Box<Key>  = Nominal(type_id = Box, args = [Key])
```

They are distinct concrete types, but both belong to the same nominal declaration `Box`.

The same representation is used for generic sums:

```text
Maybe<u32>
Maybe<LifetimeDomain>
```

`display_type` now preserves concrete arguments, which also prevents compiler diagnostics / lifecycle type identities from collapsing `Box<u32>` and `Box<Key>` to the same display name.

---

## 4. Nominal type parameters in associated functions

A generic module's type parameters are compiler-internal generic parameters of its associated functions.

For:

```text
module Box<T>
  struct { value: T }

  fn make(value: T) -> Self { ... }

  fn echo<U>(
      self: ref<read,Self>,
      value: U
  ) -> U {
      value
  }
end
```

M5 conceptually checks:

```text
Box::make<T>(T) -> Box<T>
Box::echo<T,U>(ref<read,Box<T>>, U) -> U
```

but this does not create a second source-visible generic syntax.

A concrete call can therefore produce:

```text
Box::make<u32>
Box::echo<u32,u32>
```

while the source remains:

```text
Box::make(u32(1))
r.echo(u32(2))
```

A function-level type parameter may not shadow a nominal parameter of the same name. M5 diagnoses that as `E_DUP_TYPE_PARAM`.

---

## 5. Associated lookup and coherence

Generic instantiation does **not** create a new associated-function owner.

The ownership relation remains:

```text
Box declaration
    owns associated set
        make
        hash
        echo
```

not:

```text
Box<u32> owns one set
Box<Key> owns another set
...
```

At lookup time the concrete first argument carries `Box<...>`; `dispatch_nominal` extracts the declaration identity `Box`, and the selected function is then instantiated using the concrete type arguments inferred from the call.

This preserves the M3/Draft 17.2 coherence model:

```text
one nominal owner
no ADL candidate mixing
no specialization
no ranking
no cross-module open extension
```

The destructive workload `140_generic_nominal_associated_lookup_ok.nl` verifies that:

```text
generic_hash<K>(ref<read,K>)
```

still records:

```text
hash(ref<read,K>) -> u32
```

and `K = Box<u32>` resolves to the associated `Box::hash<u32>`.

`151_generic_nominal_generic_associated_target_ok.nl` further verifies an associated target with both nominal and function parameters:

```text
Box::echo<u32,u32>
generic_echo<Box<u32>,u32>
```

without a second method-dispatch mechanism.

---

## 6. Field and payload substitution

Generic declaration fields and sum payloads remain templates.

For:

```text
module Fixed2<T>
  struct { values: Array<T,2> }
end
```

projecting `values` from `Fixed2<Key>` yields:

```text
Array<Key,2>
```

not `Array<T,2>`.

Likewise:

```text
sum Maybe<T> {
    None,
    Some(T),
}
```

matched as `Maybe<LifetimeDomain>` binds `Some(x)` as:

```text
x: LifetimeDomain
```

M5 applies the same substitution to:

```text
struct construction
private field projection
private struct destructuring
sum construction
sum match payload binding
Copy derivation
Discardable derivation
```

This is important: capability derivation uses the **current concrete instantiation**, not the template declaration.

---

## 7. Copy / Discardable pressure

M5 verifies that nominal generics do not acquire unconditional capabilities.

For:

```text
module Box<T>
  struct { value: T }
end
```

M5 derives:

```text
Box<u32>               Copy + Discardable
Box<LifetimeDomain>    non-Copy + non-Discardable
```

from the concrete field type.

The same rule applies to generic sums:

```text
Maybe<u32>               Discardable
Maybe<LifetimeDomain>    non-Discardable
```

Consequently:

```text
store(ref<write,Box<LifetimeDomain>>, ...)
store(ref<write,Maybe<LifetimeDomain>>, ...)
```

are rejected with `E_STORE_NONDISCARDABLE`, while the corresponding `u32` instantiations are accepted.

No `T: Discardable` or trait constraint syntax was added.

---

## 8. Sized recursive nominal validation

Draft 17.2 treats generic type parameters as `Sized`. M5 therefore closes an important nominal-type hole: a by-value recursive nominal declaration must not silently create an infinitely sized type.

Rejected:

```text
module Node<T>
  struct {
    next: Self,
    value: T,
  }
end
```

with:

```text
E_RECURSIVE_VALUE_TYPE
```

Accepted:

```text
module Node<T>
  struct {
    next: ptr<Self>,
    value: T,
  }
end
```

The validation follows concrete structural containment through generic nominal/sum substitution, not merely textual declaration edges. Therefore this indirect form is also rejected:

```text
sum Maybe<T> {
    None,
    Some(T),
}

module Node<T>
  struct {
    next: Maybe<Self>,
    value: T,
  }
end
```

because substituting `T = Self` makes the recursive by-value occurrence visible.

Pointer/ref/span/block/slot indirections terminate the by-value sizedness walk.

Generic sums receive the same validation:

```text
sum Chain<T> {
    End,
    More(Chain<T>),
}
```

is rejected, while:

```text
sum Chain<T> {
    End,
    More(ptr<Chain<T>>),
}
```

is accepted.

---

## 9. Lifecycle bridge: resource-bearing generic aggregates

M5 pressure exposed a real implementation gap.

Before M5, ordinary struct values were intentionally represented by the lifecycle bridge as opaque `ValueHandle`s. That was sufficient for workloads such as:

```text
Box { value: u32 }
```

but it loses ownership structure for:

```text
Fixed2<LifetimeDomain> {
    values: Array<LifetimeDomain,2>
}
```

If the aggregate were collapsed to an opaque value, destructuring it could not recover the two `LifetimeDomain` identities and `consume_array` could not discharge them.

M5 therefore adds a narrowly scoped compiler-internal `StructHandle`.

The policy is:

```text
ordinary scalar-only struct
    -> retain prior opaque ValueHandle behavior

struct containing lifecycle-structural children
    -> preserve field handles structurally
```

The structural representation is used by both the exact and finite production lifecycle bridges.

This is an implementation representation change, not a source-level layout guarantee. It does **not** expose field offsets/order/ABI or turn native layout into part of the language semantics.

It also improves ref-to-field projection when the lifecycle runner has a structural aggregate: a ref to `Fixed2<T>` projected to `values` now targets the actual `ArrayHandle`, allowing the existing `array_span` semantics to operate without a generic-specific path.

Existing M0-M4 ordinary struct/lifetime regressions remain unchanged and passed.

---

## 10. Real non-Copy container workload

`143_generic_container_nondiscardable_drain_ok.nl` is the first M5 ownership container workload:

```text
module Fixed2<T>
  struct { values: Array<T,2> }

  fn make(values: Array<T,2>) -> Self {
    Self { values: values }
  }

  fn drain(self: Self, f: block(T) -> unit) -> unit {
    let Self { values } = self
    consume_array(values, f)
  }
end
```

It is instantiated as:

```text
Fixed2<LifetimeDomain>
```

and drained with:

```text
{|d: LifetimeDomain| finalize_domain(d) }
```

This proves that M5 does not require `T: Discardable` to own a fixed-size container. Ownership exits through whole-value decomposition using the already-existing `consume_array` mechanism.

Both lifecycle paths accept:

```text
exact lifecycle bridge       PASS
production lifecycle bridge  PASS, no precision loss
```

No partial-move array state or destructor/Drop mechanism was introduced.

---

## 11. Generic container + M4 loop workload

`144_generic_container_loop_find_ok.nl` composes the new nominal layer with the previous milestones:

```text
Fixed2<T>
Array<T,2>
ref<read,Self>
private field projection
array_span
M4 loop
loop-carried usize
dynamic indexing
dependent equal(...)
associated lookup
sum match
break / continue
monomorphization
```

The generic method records:

```text
Fixed2::find:
    equal(ref<read,T>, ref<read,T>) -> Decision
```

and instantiating `Fixed2<Key>` generates:

```text
Fixed2::make<Key>
Fixed2::find<Key>
```

The workload is executed from `main(Array<Key,2>, Key)`, not merely type-checked in a dead function. Both exact and production lifecycle bridges accept it without production precision loss.

This is the strongest M5 result because it demonstrates that generic nominal types are not an isolated syntax feature: they compose with the loop/dependency/associated-lookup stack already built in M3-M4.

---

## 12. Deliberate inference boundary

M5 retains M3's argument-based generic-function inference.

Therefore a module generic parameter that appears only in the result cannot currently be selected by expected-result inference:

```text
module Empty<T>
  struct { }
  fn make() -> Self { Self { } }
end

let x = Empty::make()
```

is rejected with `E_GENERIC_INFERENCE`.

M5 does not add explicit call-site type arguments simply to make this case work.

This is deliberately different from a payloadless generic sum constructor, where the sum type itself is the constructed value and an already-complete expected sum type may select the instantiation.

Future explicit generic-call syntax can close the static-constructor case without changing nominal identity or associated lookup semantics.

---

## 13. Source corpus

M5 adds programs `132` through `155` (24 programs):

```text
132 generic nominal make/ref field
133 two nominal instantiations
134 generic nominal arity rejection
135 missing nominal type arguments
136 generic sum payload construction/match
137 payloadless sum expected-type inference
138 payloadless sum unbound rejection
139 non-Discardable generic sum payload
140 generic nominal associated lookup
141 ptr-indirected recursive nominal
142 by-value recursive nominal rejection
143 non-Discardable Fixed2<T> drain workload
144 Fixed2<T> + M4 loop + dependent equal workload
145 non-Discardable generic nominal store rejection
146 discardable generic nominal store
147 non-Discardable generic sum store rejection
148 discardable generic sum store
149 ptr-indirected recursive generic sum
150 by-value recursive generic sum rejection
151 generic nominal + generic associated target
152 two nominal type parameters
153 recursive nominal through substituted generic sum rejection
154 nominal/function type parameter shadow rejection
155 unbound static generic-module constructor inference rejection
```

A dedicated `tests/test_m5_generic_nominals.py` adds semantic-structure assertions in addition to source accept/reject tests.

---

## 14. Validation

Final M5 front-end suite:

```text
232 tests collected
232 passed
compileall PASS
```

The separately supplied independent Draft 17.2 closure tree was rerun fresh:

```text
110 tests collected
110 passed
compileall PASS
```

Executable Draft 17.2 closure vectors:

```text
12 / 12 PASS
```

Generated closure differential, seed `20261003`:

```text
alignment_padding   25,000  mismatch 0
mixed_width_add     25,000  mismatch 0
operation_matrix    25,000  mismatch 0
split_coordinate    25,000  mismatch 0
-------------------------------------
total              100,000  mismatch 0
false accept                 0
false reject                 0
```

`ruff`, `mypy`, and `pyright` were not installed in the execution environment, so M5 does not claim those checks passed.

---

## 15. Architecture judgment

M5 did not falsify the Draft 17.2 generic model.

The current path is now:

```text
generic nominal declaration
    -> one nominal declaration identity
    -> symbolic nominal type parameters
    -> generic associated function definition-time checking
    -> concrete nominal type arguments
    -> argument-based associated-function monomorphization
    -> field/payload substitution
    -> existing semantic/effect lowering
    -> existing lifecycle model
```

and for generic sums:

```text
generic sum declaration
    -> symbolic payload type
    -> payload/expected-type constructor inference
    -> concrete SumType(args)
    -> substituted match payload type
    -> existing occurrence/lifecycle rules
```

The only substantive implementation extension forced by a real systems workload was preserving lifecycle structure inside resource-bearing nominal aggregates. That is precisely the kind of pressure M5 was intended to expose.

No evidence from M5 requires:

```text
traits/interfaces
specialization
overload ranking
ADL
structural duck typing
source-visible effect/lifetime constraints
general post-state language
partial-move aggregate state
destructors
native-layout guarantees
```

---

## 16. Remaining boundaries after M5

Still intentionally open:

```text
explicit generic call-site type arguments
generic type aliases
generic nominal/sum separate-compilation artifact format
escaping closures
allocator surface
dynamic partial initialization
runtime-sized containers
source-visible safe pre-lifetime field construction
full relational lifecycle transformer for resource-mutating loops/recursion
layout/FFI-specific aggregate mechanisms
```

M5's `Fixed2<T>` uses already-initialized fixed-size `Array<T,2>`. It does not solve `Vec<T>`-style dynamic occupancy. That distinction should remain explicit.

---

## 17. M5 judgment

**Front-End Prototype M5 passes.**

The important result is not merely that `Box<T>` and `Maybe<T>` parse.

M5 demonstrates that:

```text
nominal identity is stable across instantiations
associated ownership remains declaration-based
field/payload semantics substitute concretely
Copy/Discardable derive structurally from concrete arguments
recursive Sized violations are rejected structurally
a non-Discardable generic owner container can drain safely
M4 loop + M3 dependent lookup work inside a generic nominal method
resource-bearing aggregate state remains visible to both lifecycle bridges
```

without changing the Draft 17.2 semantic kernel.
