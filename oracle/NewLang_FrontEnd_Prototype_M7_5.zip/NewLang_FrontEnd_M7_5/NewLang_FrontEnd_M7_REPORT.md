# NewLang Front-End Prototype M7 Report

## 1. Scope

M7 begins the **C-substitutability / backend pressure** phase after Gate A.

The first workload is intrusive-owner recovery, i.e. the capability normally provided in C by `container_of` / `offsetof`-based pointer recovery:

```text
ptr<embedded Link> -> ptr<enclosing Node>
```

The pressure question is deliberately narrower than “add C pointer arithmetic”:

> Can NewLang recover an enclosing owner for intrusive data structures while keeping ordinary aggregate layout opaque, keeping `ptr` separate from access authority, and without turning field offsets into source-visible semantics?

Draft 17.3 remains the semantic baseline.  M7 treats the exact source spelling `owner_ptr(...)` as experimental / Provisional.

## 2. Result

**PASS for the owner-recovery problem.**

The tested mechanism is:

```text
safe typed field projection
    -> ptr carries opaque projection provenance
    -> inverse typed projection may recover a proven ancestor
```

not:

```text
integer address
    - programmer supplied offsetof
    -> cast to ptr<Owner>
```

No source-visible field offset, padding map, general pointer arithmetic, or integer pointer round-trip was required.

## 3. Opaque inverse projection

M7 adds a prototype `ProjectionFrame` to the front-end ptr handle.  Each safe fixed-field projection records only semantic compiler metadata:

```text
owner nominal type
projection / field identity
```

The source does not receive the physical byte offset.

For example:

```text
ptr<Node> --field(first)--> ptr<Link>
```

retains enough hidden provenance that an owner-module operation can later perform:

```text
ptr<Link> --inverse projection--> ptr<Node>
```

The physical offset is a backend fact, not a source semantic value.

This is consistent with Draft 17.3's existing rule that projected ptrs retain semantic location derivation/provenance and with its opaque `ProjectionId` model.

## 4. Experimental source surface

M7 uses:

```text
owner_ptr(projected_ptr)
```

with an expected result type such as `ptr<Node>`.

This spelling is not proposed as final syntax.

The type checker requires:

1. one `ptr<T>` argument;
2. an expected `ptr<Nominal>` result type;
3. representation access to the owner nominal at the intrinsic site.

Therefore normal user code is expected to expose an owner-specific wrapper from the owner module, e.g. conceptually:

```text
module Node
  fn owner_from_link(link: ptr<Link>) -> ptr<Self> {
    owner_ptr(link)
  }
end
```

The owner module may intentionally export that wrapper without exposing its field offset or private field representation.

## 5. Provenance is required; address equality is not enough

The safe operation succeeds only when the actual ptr semantic value carries a matching typed projection path.

A standalone `ptr<Link>` root cannot be converted into `ptr<Node>` merely because the expected type is `ptr<Node>`.

Source case:

```text
Link root ptr
    -> Node::owner_from_link(...)
    -> E_OWNER_PROJECTION
```

The generated pressure model additionally forges a token with the same numeric field address but no projection provenance.  All such attempts are rejected.

Therefore:

```text
numeric address equality != enclosing-owner proof
```

## 6. Same-type fields are not ambiguous

A `Node` may contain two fields of the same nominal type:

```text
Node {
    first: Link,
    second: Link,
}
```

Both projected `ptr<Link>` values recover the same enclosing `Node` correctly.

No “find the unique field of type Link” rule is used.  The actual projection identity is part of ptr provenance, so same-type fields remain distinct without exposing layout.

## 7. Nested owner recovery

M7 also tests:

```text
Outer.inner.link
```

with projection path conceptually:

```text
Outer -> Inner -> Link
```

A `ptr<Link>` can recover:

- `ptr<Inner>` as an intermediate ancestor;
- `ptr<Outer>` as the root ancestor.

The intermediate recovery does **not** mint independent lifetime-root authority.  Attempting:

```text
destroy(recovered_inner, ending)
```

is rejected with `E_NOT_LIFETIME_ROOT` because `Inner` remains a fixed subobject of `Outer`.

This is important: inverse projection changes the locator, not the object-lifetime authority structure.

## 8. Dangling ptr derivation correction

M7 exposed an older prototype mismatch with Draft 17.3.

Draft 17.3 defines `ptr<T>` as a persistent Copy locator token that may dangle, and says typed projection itself does not access memory.

Before M7, the exact `derive_ptr_token` helper and production `ClonePtr` rejected stale ptrs.  This incorrectly made location derivation depend on liveness.

M7 corrects this:

```text
copy / typed projection / inverse typed projection
    may operate on dangling ptr tokens

safe ref acquisition / dereference-like access
    still requires a live matching incarnation/domain
```

Tested sequence:

```text
live ptr<Node>
    -> destroy Node
    -> dangling ptr<Node>
    -> project dangling ptr<Link>
    -> recover dangling ptr<Node>
```

is accepted as locator manipulation.

Trying to materialize `ref` from the recovered ptr is still rejected with `E_STALE_PTR`.

Thus inverse projection cannot revive an ended incarnation.

## 9. `ptr_from_ref` provenance bug found and fixed

A second pre-existing prototype defect was found by the M7 workload.

For:

```text
node_ref@link
    -> ptr_from_ref(...)
```

`ptr_from_ref` previously preferred the ref's `target` when it happened to be represented by a `PtrHandle`, rather than the projected ref's `origin_ptr`.

The result could therefore carry the base Node ptr identity while being typed as `ptr<Link>`.

M7 changes the rule to:

```text
if ref has origin_ptr:
    use origin_ptr
else if target itself is a ptr:
    use target
```

The existing M1.1 projected-ref roundtrip still passes, and the new owner-recovery roundtrip now preserves the full projection path.

## 10. Provenance survives ordinary value flow

M7 verifies that projection provenance survives:

- function argument / return flow;
- ptr copy semantics;
- `ref -> projected ref -> ptr_from_ref`;
- storage inside an ordinary aggregate value and later extraction.

This is necessary for intrusive structures: provenance belongs to the ptr semantic value, not merely to the local expression that originally projected it.

## 11. Generated layout / owner-recovery pressure

Seed: `20261004`.

```text
20,000 generated cases
20,000 successful owner recoveries
20,000 same-type-field recoveries
20,000 nested recoveries
20,000 forged-address rejections
20,000 stale locator recoveries
20,000 stale-access rejections
10,000 reordered-layout cases
0 backend lowering mismatches
```

The model uses multiple private physical layouts for the same nominal field structure.  Owner recovery remains correct because source semantics uses projection identity rather than a published field offset.

A deterministic three-node intrusive-ring traversal is also exercised for each layout variant.

Results: `m7_intrusive_owner_recovery_results.json`.

## 12. Backend lowering model

The prototype backend pressure lowers inverse projection conceptually as:

```text
field ptr
    -> compiler-private negative byte delta
    -> owner ptr
```

while retaining the pointer's provenance and avoiding `ptrtoint` / `inttoptr`.

The public NewLang program never observes the delta.

Current LLVM documentation is compatible with this direction:

- `getelementptr` performs address computation, not memory access;
- negative indices are allowed;
- GEP results remain “based on” the pointer operand;
- `inbounds` constrains the result to the allocated object, and the current LangRef explicitly notes that the allocated object does not need to remain live for this address relation.

References:

- https://llvm.org/docs/GetElementPtr.html
- https://llvm.org/docs/LangRef.html#getelementptr-instruction

This does **not** yet constitute a complete proof of the final LLVM lowering.  It is a strong feasibility check for the intended direction.

## 13. Clang `container_of` probe

A small C probe was compiled with the available Clang 17 toolchain.

For:

```c
struct Node {
    char small;
    struct Link first;
    long word;
    struct Link second;
};
```

classic `offsetof`-style recovery lowered to:

```text
from_first:  getelementptr inbounds i8 ... -4
from_second: getelementptr inbounds i8 ... -16
```

with no `ptrtoint` or `inttoptr`.

The C and LLVM IR probe are retained under `backend_probe/` and summarized by `m7_backend_probe_results.json`.

The relevant distinction is that C computes these offsets at the source/ABI representation level, whereas the NewLang candidate lets the compiler derive them from an opaque projection identity.

## 14. Source cases

New M7 source cases:

```text
223 owner recovery from embedded link                       ACCEPT
224 independent Link root masquerading as Node field       REJECT E_OWNER_PROJECTION
225 direct private owner recovery outside owner module      REJECT E_PRIVATE_OWNER_RECOVERY
226 two same-type Link fields                               ACCEPT
227 nested Outer -> Inner -> Link owner recovery            ACCEPT
228 owner recovery on dangling projected token              ACCEPT
229 safe access through recovered dangling owner            REJECT E_STALE_PTR
230 field projection from dangling owner ptr                ACCEPT
231 intermediate fixed-subobject owner used as root         REJECT E_NOT_LIFETIME_ROOT
232 ref -> field ref -> ptr roundtrip preserves provenance  ACCEPT
233 projected ptr stored/extracted through aggregate value  ACCEPT
```

Exact and production lifecycle bridges agree on the core cases.

## 15. Front-end validation

Final M7 tree:

```text
pytest:      411 / 411 PASS
compileall:  PASS
```

Measured in this prototype environment:

```text
full pytest elapsed: ~8.4 s
peak RSS:             ~134 MB
```

The M6.6 20k analysis/failure experiment reproduces exactly after the changes.

## 16. Independent Draft 17.2 closure regression

A fresh extraction of the independent Draft 17.2 closure prototype was rerun:

```text
pytest:      110 / 110 PASS
compileall:  PASS
closure executable vectors: 12 / 12 PASS
```

Generated closure differential:

```text
100,000 cases
mismatches:     0
false accepts:  0
false rejects:  0
```

## 17. What M7 does not claim

M7 does **not** yet claim:

- final source spelling for inverse projection;
- arbitrary pointer arithmetic;
- source-visible `offsetof`;
- C-compatible native aggregate layout;
- safe recovery from an arbitrary foreign/raw field pointer;
- complete exported-function / separate-compilation contracts for provenance preconditions;
- automatic repair of self-references or intrusive links after relocation;
- complete LLVM provenance/alias proof for every target;
- C ABI aggregate compatibility.

In particular, a raw/foreign field pointer that lacks NewLang projection provenance will require a localized foreign/unchecked boundary to establish the missing relation, if that relation can legitimately be guaranteed.

## 18. Semantic judgment

The first C-substitutability pressure does **not** force NewLang to abandon opaque native aggregate layout.

A useful decomposition is now visible:

```text
source semantic relation:
    opaque typed projection provenance

safe owner recovery:
    inverse proven projection

backend fact:
    concrete target field offset

access authority:
    still separate from ptr

lifetime-ending authority:
    still separate from owner recovery
```

This is preferable to introducing general `offsetof`, byte pointer arithmetic, or arbitrary ptr casts into the native core merely to support intrusive containers.

The mechanism should remain **Provisional** until address-sensitive/self-referential workloads are run.  No Draft 17.4 consolidation is recommended solely from M7.

## 19. Next milestone

The next C-substitutability pressure should be **M7.1: self-reference / address-sensitive values**.

It should attack:

- self pointer installed after lifetime start;
- intrusive links whose correctness depends on physical address;
- move / replace / swap of address-sensitive values;
- relocation and stale interior/owner ptrs;
- explicit fixup versus a future Pin/relocation policy;
- external registries / callback contexts containing own address.

The critical question is whether NewLang can keep address sensitivity as a localized library invariant without introducing a general Pin/Unpin or relocation trait system into v0.
