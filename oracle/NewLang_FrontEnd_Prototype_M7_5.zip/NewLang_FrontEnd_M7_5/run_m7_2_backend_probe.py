from __future__ import annotations
import json, re, subprocess
from pathlib import Path

src = Path('backend_probe/m7_2_alignment.c')
ir = Path('backend_probe/m7_2_alignment.ll')
version = subprocess.check_output(['clang','--version'], text=True).splitlines()[0]
subprocess.run(['clang','-std=c2x','-S','-emit-llvm','-O1',str(src),'-o',str(ir)], check=True)
text = ir.read_text(encoding='utf-8')

empty = Path('backend_probe/m7_2_empty_struct.c')
empty_obj = Path('backend_probe/m7_2_empty_struct.o')
cp = subprocess.run(['clang','-std=c2x','-pedantic-errors','-c',str(empty),'-o',str(empty_obj)], text=True, capture_output=True)
if empty_obj.exists(): empty_obj.unlink()

result = {
    'clang': version,
    'stack64_alloca_align_64': bool(re.search(r'alloca %struct\.Wide64, align 64', text)),
    'stack4096_alloca_align_4096': bool(re.search(r'alloca %struct\.Wide4096, align 4096', text)),
    'heap_aligned_alloc_return_align_64': bool(re.search(r'call noalias align 64 .*@aligned_alloc', text)),
    'aligned_alloc_decl_has_allocalign': 'allocalign' in text,
    'c2x_pedantic_empty_struct_rejected': cp.returncode != 0,
    'empty_struct_diagnostic_mentions_extension': 'extension' in cp.stderr.lower(),
    'conclusion': 'LLVM/Clang can preserve large target alignment explicitly; standard C does not require zero-byte complete objects, so v0 ZST dynamic-storage support is not needed for C substitutability',
}
Path('m7_2_backend_probe_results.json').write_text(json.dumps(result, indent=2, sort_keys=True)+'\n', encoding='utf-8')
print(json.dumps(result, indent=2, sort_keys=True))
