# NewLang Front-End Prototype M1.1 — ptr/ref Stability Closure Report

> Status: **completed experimental M1.1 implementation**
>
> Semantic baseline: `NewLang_v0_spec_Draft17_2.md`
>
> Starting point: Front-End Prototype M1
>
> Purpose: close the remaining `ptr<T>` / `ref<T>` / `LifetimeDomain` stability loop before broadening the front end to M2.

## 1. M1.1 scope

M1.1 adds the real-source path for the workload-tested conversion surface:

```text
ref_from_ptr(read,  p, stable) -> ref<read, T>
ref_from_ptr(write, p, stable) -> ref<write, T>

ptr_from_ref(r) -> ptr<T>
```

The new safe-ref acquisition path enforces:

```text
ptr is current/live
target root governing domain == stable domain
stable is an ordinary ref<read,LifetimeDomain>
derived ref cannot outlive stable
```

M1.1 also connects the real-source lifecycle slice to an oracle-independent finite production-style checker and differential-tests it against the exact checker.

No Draft 17.2 semantic change is introduced.

---

## 2. Source syntax

The adopted provisional spelling follows Surface Draft 1.1:

```text
loan read life as stable {
    let r = ref_from_ptr(read, p, stable)
    inspect(r)
}
```

and:

```text
let q =
    loan read life as stable {
        let r = ref_from_ptr(read, p, stable)
        ptr_from_ref(r)
    }
```

The access mode is a dedicated syntactic operand of `ref_from_ptr`; it is not an ordinary source binding or overload argument.

Supported in M1.1:

```text
read
write
```

Any other first operand is rejected.

---

## 3. Type checking

### `ref_from_ptr`

Required shape:

```text
ref_from_ptr(
    read | write,
    ptr<T>,
    ref<read,LifetimeDomain>
)
```

Result:

```text
read  -> ref<read,T>
write -> ref<write,T>
```

M1.1 does not accept an `exclusive ref<read,LifetimeDomain>` as the stability operand.

This keeps the already-established distinction:

```text
ordinary domain ref
    = stability evidence

exclusive domain ref
    = lifetime-ending authority access
```

### `ptr_from_ref`

M1.1 source typing accepts ordinary:

```text
ref<read,T>
ref<write,T>
```

and returns:

```text
ptr<T>
```

`exclusive ref` is deliberately not silently consumed or weakened by this prototype builtin.

---

## 4. Exact lifecycle bridge: stability validation

The vendored exact semantic checker now has explicit reusable helpers:

```text
require_stability_domain(state, ptr, domain)
derive_ptr_token(state, source_ptr, result_ptr)
```

`require_stability_domain` proves:

```text
ptr token exists
ptr token is not stale
ptr still denotes the current root incarnation
LifetimeDomain is live
root governing domain == supplied stability domain
```

A mismatching stability domain therefore rejects with:

```text
E_LIFETIME_DOMAIN_MISMATCH
```

A stale pointer rejects with:

```text
E_STALE_PTR
```

---

## 5. Hidden scope dependency of `ref_from_ptr`

This was the most important M1.1 front-end correction.

A ref returned by:

```text
ref_from_ptr(..., stable)
```

carries a compiler-internal dependency on the exact ordinary domain ref used as stability evidence.

The dependency is not encoded as a source-visible lifetime parameter.

Therefore this is rejected:

```text
let escaped =
    loan read life as stable {
        ref_from_ptr(read, p, stable)
    }
```

with:

```text
E_SCOPE_ESCAPE
```

The same rejection occurs through a wrapper:

```text
fn identity_ref(x: ref<read,Box>) -> ref<read,Box> {
    x
}

let escaped =
    loan read life as stable {
        let r = ref_from_ptr(read, p, stable)
        identity_ref(r)
    }
```

This validates the intended implication:

```text
target ref live
    => stability evidence live
```

across a known function boundary without introducing source-visible lifetime syntax.

---

## 6. `ptr_from_ref` deliberately breaks only the access-scope dependency

A persistent `ptr<T>` is allowed to survive after the temporary access capability ends.

Therefore:

```text
let q =
    loan read life as stable {
        let r = ref_from_ptr(read, p, stable)
        ptr_from_ref(r)
    }
```

is accepted.

The resulting `q` still denotes the same object incarnation and does **not** gain dereference authority.

A later access still requires fresh matching stability evidence:

```text
loan read life as stable {
    let r2 = ref_from_ptr(read, q, stable)
    ...
}
```

This is the intended ptr/ref separation.

---

## 7. Fixed-subobject pointer correction

M1 treated:

```text
p@field
```

as a source-level projected `ptr<Field>`, but the exact lifecycle bridge did not insert the projected token into the semantic ptr-token table because M1 only needed to reject lifetime-ending operations on it.

M1.1 corrects that approximation.

A projected ptr now preserves the source token's:

```text
root identity
root incarnation
backing/provenance relation
staleness
```

while its front-end handle remains:

```text
root_capable = false
```

Consequently both of these properties hold:

```text
ref_from_ptr(read, p@field, stable)
    -> valid safe field access

destroy(p@field, ending)
    -> E_NOT_LIFETIME_ROOT
```

The ptr can also round-trip through an ordinary ref:

```text
p@field
    -> ref_from_ptr(...)
    -> ptr_from_ref(...)
```

without gaining independent lifetime-root authority.

---

## 8. Function-boundary break tests

M1.1 checks the ptr/ref conversion path through known wrappers.

Covered cases include:

```text
ref derived from ptr -> wrapper -> attempted escape
    reject

ref derived from ptr -> wrapper calls ptr_from_ref -> ptr escapes
    accept

wrong-domain stability ref -> wrapper -> ref_from_ptr
    reject
```

This reuses the M0.1 actual-argument/body-sensitive call path; no parallel method or effect system was introduced.

---

## 9. Production lifecycle bridge

M1 used the exact semantic state as the lifecycle oracle.

M1.1 adds a second, oracle-independent finite production-style path based on the existing Draft-17 finite abstract semantic-state prototype.

Vendored production components:

```text
language_ir.py
abstract_semantics.py
production_analysis.py
```

were extended narrowly for the M1.1 lifecycle slice.

Added finite core statements:

```text
CreateDomain
FinalizeDomain
ValidatePtrDomain
ClonePtr
```

and ending-domain information is now carried by:

```text
TakeRoot
DestroyRoot
```

The production abstract state also tracks the finite live-domain set used by this straight-line front-end slice.

---

## 10. Production-side corrections found

Two consistency fixes were required.

### 10.1 `destroy` stale propagation

The production finite transformer, like the earlier exact checker before M1, did not stale ptr alternatives when a root was destroyed.

M1.1 now makes:

```text
destroy root
    => every ptr alternative to that incarnation becomes stale
```

matching `take` and the exact checker.

### 10.2 domain checks were not represented in old production core statements

The earlier production prototype stored `governing_domain` in roots but `TakeRoot` / `DestroyRoot` did not carry ending-domain identity.

M1.1 adds it and proves:

```text
ending domain is live
root governing domain == ending domain
```

before the lifetime-ending transition.

`Initialize` likewise requires its governing domain to be live.

---

## 11. Real-source exact-vs-production comparison

The M1.1 production bridge lowers typed real source by body-inlining known calls with the same actual resource identities used by the exact bridge.

The comparison corpus covers accepted and rejected source programs including:

```text
initialize -> destroy
initialize -> take
wrong ending domain
stale ptr use
finalize while root live
projected ptr not lifetime root
wrapper lifecycle call
ref_from_ptr read/write
wrong stability domain
ref escape
ptr_from_ref escape
projected ptr/ref/ptr round trip
wrapper ref escape
wrapper wrong-domain ref acquisition
```

All compared source cases produce the same accept/reject judgment in exact and production paths.

No production precision rejection occurred in the accepted M1/M1.1 straight-line comparison cases.

---

## 12. Generated differential experiment

A deterministic generated differential test runs:

```text
seed: 20261003
cases: 10,000
```

over ten lifecycle families:

```text
correct-domain destroy
correct-domain take
wrong-domain destroy
correct stability acquisition
wrong-domain stability acquisition
ptr clone + acquisition
stale ptr after destroy
finalize while root live
finalize after destroy
cloned ptr stale after destroy
```

Result:

```text
exact / production mismatch: 0
false production accept:     0
false production reject:     0
```

This is a falsification/regression result, not a soundness proof.

---

## 13. Real `.nl` additions

M1.1 adds source programs `32` through `45` covering:

```text
read ref_from_ptr
write ref_from_ptr
wrong stability domain
stale ptr ref acquisition
direct ref escape
ptr escape through ptr_from_ref
fixed-subobject ptr/ref round trip
exclusive-domain-ref rejected as stability evidence
invalid ref_from_ptr mode
exclusive ref rejected by ptr_from_ref
ref escape through wrapper
ptr escape through wrapper
wrong domain through wrapper
current local-ref bridge limitation
```

---

## 14. One deliberate implementation limit remains

The M1.1 lifecycle bridge fully models `ptr_from_ref` when the ref is derived from an existing semantic `ptr<T>`.

It does **not yet** materialize an implicit semantic root for an arbitrary lexical local solely because code takes a ref to it.

Therefore this currently produces an explicit prototype diagnostic:

```text
loan read local as r {
    ptr_from_ref(r)
}
```

```text
E_PTR_FROM_REF_LOCAL_UNMODELED
```

This is **not** proposed NewLang semantics.

It is an implementation boundary in the current source-to-semantic bridge.

Closing it correctly requires lexical local bindings to participate in the same root/incarnation model rather than fabricating or duplicating a `ValuePackage`. Doing that as a small ad-hoc exception would risk exactly the place/value duplication that the Draft 17 model was designed to avoid.

Recommendation:

> keep this limit explicit until the front end introduces a unified representation for ordinary local object roots; do not fake local ptr provenance inside `ptr_from_ref`.

This does not obstruct the explicit allocated-object lifecycle path being validated before M2.

---

## 15. Validation

Final M1.1 suite:

```text
84 tests collected
84 passed
compileall PASS
```

The suite includes the M0/M0.1/M1 regressions, 14 new M1.1 real-source ptr/ref cases, source exact-vs-production comparison, and the 10,000-case generated differential test.

The independent Draft 17.2 closure prototype was rerun unchanged:

```text
110 passed
compileall PASS
```

No normative Draft 17.2 regression was observed.

`ruff`, `mypy`, and `pyright` were not available in the execution environment, so this report does not claim those checks passed.

---

## 16. M1.1 judgment

**M1.1 passes.**

The explicit allocated-object path now forms a complete cycle:

```text
slot<T>
    -> initialize(..., stable)
    -> ptr<T>
    -> ref_from_ptr(..., stable)
    -> ref<read/write,T>
    -> ptr_from_ref(...)
    -> ptr<T>
    -> take/destroy(..., ending)
    -> slot<T>
```

with:

```text
stability domain identity preserved
derived ref scope bounded
persistent ptr allowed to outlive access ref
stale incarnation detected
fixed subobject not promoted to lifetime root
known wrappers preserving the same rules
exact and finite production checks agreeing on tested lifecycle families
```

No Draft-18-level semantic change was indicated.

The remaining local-root `ptr_from_ref` bridge issue is a compiler representation task, not evidence that the semantic core needs widening.

**Recommendation: proceed to M2**, while keeping local-object root unification on the implementation backlog and revisiting it when M2 aggregate/sum/local-place work gives a natural integration point.
