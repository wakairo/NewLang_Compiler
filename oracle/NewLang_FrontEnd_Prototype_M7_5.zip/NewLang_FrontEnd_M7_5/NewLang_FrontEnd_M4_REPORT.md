# NewLang Front-End Prototype M4 — Loop / Loop-Carried State Closure Report

> Status: **completed M4 vertical slice**
>
> Semantic baseline: `NewLang_v0_spec_Draft17_2.md`
>
> Starting point: Front-End Prototype M3.2
>
> Purpose: add source-visible iteration without introducing mutable locals, then pressure ownership, semantic effects, generic dependent calls, and lifecycle identity across the back-edge.

---

## 1. Executive result

M4 adds a minimal value-producing loop form:

```text
loop (
    i: usize = usize(0),
    state: State = initial_state
) -> Result {
    ...
    continue(next_i, next_state)
    ...
    break(result)
}
```

The important semantic choice is not the spelling. It is the state model:

```text
current iteration bindings
    -- continue(args) consumes/transfers -->
fresh next-iteration bindings
```

There is no mutable local / reassignment state added to NewLang.

M4 therefore treats loop-carried state like explicit SSA/phi parameters rather than introducing a second variable model.

The implementation composes with:

```text
single-assignment
non-Copy consume/transfer
non-Discardable exit checking
generic type parameters
dependent associated calls
dynamic indexed places
semantic effect summaries
LifetimeDomain identity
exact lifecycle bridge
finite production lifecycle bridge
```

No Draft-18-level semantic redesign was required.

---

## 2. Surface form is deliberately small and still provisional

The prototype surface is:

```text
loop (name: Type = initial, ...) -> ResultType {
    ...
}

continue(value, ...)
break(value)
break()              // unit-result loop only
```

The explicit loop result type is intentional in M4. It keeps:

```text
break result checking
branch diagnostics
dependent-call expected-result flow
```

simple and deterministic while the semantic model is being pressure-tested.

This does **not** require the final surface to retain the explicit `-> ResultType`; future API/syntax polish may infer it from an enclosing expected type if doing so remains simple.

`loop`, `break`, and `continue` are contextual rather than globally reserved in the implementation. Existing source such as:

```text
fn loop(x: u32) -> u32 { ... }
fn break(x: u32) -> u32 { ... }
fn continue(x: u32) -> u32 { ... }
```

remains legal outside loop-control context.

---

## 3. Internal control-flow type

M4 adds an internal `never` type for expressions that do not return normally:

```text
continue(...): never
break(...):    never
```

This is used to type exhaustive `match` expressions whose every arm transfers control.

For example:

```text
match state {
    Again(x) => { continue(next(x)) }
    Done(x)  => { break(x) }
}
```

has type `never` inside the enclosing loop body.

A loop body that can fall through normally is rejected:

```text
E_LOOP_FALLTHROUGH
```

M4 does not add a source-spellable general `never` type.

---

## 4. Back-edge ownership is explicit transfer, not inferred mutation

A loop parameter is a fresh binding each iteration.

For a non-Copy value:

```text
loop (value: T = x) -> T {
    continue(value)
}
```

`continue(value)` consumes the current iteration's `value` and transfers that semantic value into the fresh next-iteration binding.

The outer initializer is also ordinary ownership transfer:

```text
let domain = lifetime_domain()
loop (current: LifetimeDomain = domain) -> LifetimeDomain { ... }

// `domain` is consumed by loop entry.
```

A later use of the old outer binding is rejected with the existing:

```text
E_USE_AFTER_CONSUME
```

No loop-specific ownership model was introduced.

---

## 5. Non-Discardable values cannot disappear at continue/break

Every `continue(...)` / `break(...)` is also a scope-exit boundary for the current iteration.

If a loop-owned non-Discardable binding is still live there, M4 rejects:

```text
E_LOOP_NONDDiscardable_EXIT
```

Example:

```text
loop (domain: LifetimeDomain = lifetime_domain()) -> unit {
    break()
}
```

would silently lose the domain authority without this check and is rejected.

The rule also applies to non-Discardable locals created inside the iteration.

This is simply the existing NewLang responsibility rule applied to a back-edge / loop exit.

---

## 6. Loop parameter contract

`continue(...)` must provide exactly one next value for every loop parameter.

Diagnostics include:

```text
E_LOOP_CONTINUE_ARITY
E_ARGUMENT_TYPE
```

`break(...)` must match the explicitly declared loop result:

```text
E_LOOP_BREAK_TYPE
```

This means type/ownership consistency at the back-edge does not require a general data-flow type inference fixed point. The loop header itself is the invariant.

This is an important simplification:

> the compiler checks the back-edge against an explicit finite contract instead of inferring a mutable-variable state lattice.

---

## 7. Generic `T` can be loop-carried without assuming Copy

M4 adds the real-source case:

```text
fn carry<T>(x: T) -> T {
    loop (value: T = x) -> T {
        break(value)
    }
}
```

This definition is valid for unconstrained `T`.

The generic definition does not assume:

```text
Copy(T)
Discardable(T)
```

The value is transferred exactly once through the explicit loop binding and returned.

A concrete `carry<u32>` monomorph is also generated successfully.

---

## 8. Semantic effects lower through the existing loop IR

The vendored Draft-17 source semantic IR already had a `LoopStmt` used by earlier checker experiments.

M4 now lowers real `.nl` `TLoop` bodies into that representation.

Caller-visible effect inference treats loop effects as may-effects over repeated execution.

Example:

```text
fn touch(values: ref<write,Array<u32,2>>) -> unit {
    loop (i: usize = usize(0)) -> unit {
        store(values[i], u32(1))
        break()
    }
}
```

produces the normalized summary:

```text
Change(values.$index:*)
```

rather than inventing a concrete index.

This reuses the M2.1 structural/wildcard place algebra.

---

## 9. Loop boundaries do not launder semantic conflicts

M4 also places an ordinary caller-visible mutation inside a loop:

```text
loop (...) -> unit {
    Box::set(w)
    break()
}
```

`Box::set` produces:

```text
Change(box.value)
```

With a test-only live dependency on:

```text
box.value
```

the program still rejects with:

```text
E_SEMANTIC_CONFLICT
```

So iteration is not a semantic laundering boundary.

Current real source does not yet create a hidden dependency that survives one iteration and is carried into the next. Therefore M4 does not manufacture a general loop-carried dependency/post-state language. When such a workload appears, the existing `Unknown`/widening rule remains the safe boundary.

---

## 10. Lifecycle execution follows concrete continue/break transfer

Both lifecycle bridges now understand loop control directly.

Conceptually:

```text
initializers
    -> carried handles
    -> execute iteration body
       -> continue(next handles): re-enter with fresh bindings
       -> break(result handle): return loop result
```

The exact and production bridges agree on the M4 positive corpus.

A two-iteration concrete state machine is exercised with:

```text
Again(value)
    -> continue(Done(value))
Done(value)
    -> break(value)
```

This verifies actual back-edge transfer rather than only parsing/type checking the syntax.

---

## 11. LifetimeDomain identity survives a fresh iteration binding

The important identity workload is:

```text
loop (
    domain: LifetimeDomain = lifetime_domain(),
    state: Step = Step::Again()
) -> LifetimeDomain {
    match state {
        Again => { continue(domain, Step::Done()) }
        Done  => { break(domain) }
    }
}
```

`domain` is a fresh source binding at the next iteration, but the `LifetimeDomain` semantic identity moves with the value.

Both exact and production lifecycle bridges accept this program.

This supports the existing NewLang distinction:

```text
binding/incarnation identity
    !=
semantic identity carried by a value
```

without adding loop-specific identity semantics.

---

## 12. M4 deliberately does not infer arbitrary identity joins

For identity-bearing loop-carried types such as:

```text
LifetimeDomain
ptr<T>
slot<T>
ref<...>
span<...>
```

M4's lifecycle bridge currently requires the corresponding `continue` value to be the same loop parameter binding.

For example, replacing:

```text
continue(current)
```

with another domain binding is rejected by the prototype with:

```text
E_LOOP_CARRY_PRECISION
```

This is an **implementation precision boundary**, not a claim that the language can never permit a finite join of alternative identities.

The purpose is to avoid silently widening exact identity into an invented one before a real workload justifies a richer representation.

---

## 13. Diverging loops are not treated as compiler-budget failures

A systems language needs ordinary spin loops.

This is valid:

```text
fn main() -> u32 {
    loop (i: u32 = u32(1)) -> u32 {
        continue(i)
    }
}
```

There is no `break`, so the declared `u32` result is never produced on a normal path.

For a lifecycle-neutral loop, the bridges validate one iteration's transfer contract and then classify the path as diverging rather than unrolling until an arbitrary limit and reporting an error.

The exact bridge reports acceptance as a diverging loop, and the production bridge agrees without precision loss.

---

## 14. Resource-transforming infinite loops remain an explicit precision boundary

M4 does **not** generalize the lifecycle analyzer into a full loop relational post-state solver.

A loop that repeatedly performs resource transitions, even if a human can see that each iteration balances them, currently reaches:

```text
E_LOOP_LIFECYCLE_BUDGET
```

Example pressure shape:

```text
loop (...) -> unit {
    let domain = lifetime_domain()
    finalize_domain(domain)
    continue(...)
}
```

This is conservative.

The implementation does not infer that arbitrary resource-transforming iteration is a post-state identity function.

That transformer should be added only when a real systems workload requires it.

---

## 15. Generic linear-search shape now composes

M4's representative integration workload is a generic span search shape:

```text
fn find<K>(items: span<read,K>, key: ref<read,K>) -> usize {
    loop (i: usize = usize(0)) -> usize {
        let decision: Decision = equal(items[i], key)
        match decision {
            Found => { break(i) }
            Next  => { continue(next(i)) }
        }
    }
}
```

This composes:

```text
loop-carried usize state
dynamic span index
first-argument dependent associated lookup
complete expected dependent result type
match-based control
break result
continue back-edge
generic monomorphization
```

The generic requirement remains:

```text
equal(ref<read,K>, ref<read,K>) -> Decision
```

and a concrete:

```text
find<Box>
```

is generated successfully when an associated `Box::equal` is available.

The prototype `next(i)` is intentionally only a type-level workload placeholder; M4 does not attempt to settle the broader integer operator surface.

---

## 16. Control forms do not escape callback boundaries

A `break`/`continue` in a nonescaping block literal does not target the lexically surrounding loop.

M4 resets the loop-control context when type-checking a block literal.

Therefore:

```text
loop (...) -> u32 {
    let callback = { || break(...) }
    ...
}
```

is rejected with:

```text
E_BREAK_OUTSIDE_LOOP
```

This avoids accidentally introducing non-local control transfer through callbacks.

Nested ordinary loops remain valid and each `break`/`continue` targets the innermost loop.

---

## 17. Real `.nl` M4 corpus

M4 adds source programs `115` through `131`:

```text
115 loop break result
116 concrete continue -> next iteration -> break
117 unconstrained generic T carry
118 LifetimeDomain identity carry
119 non-Discardable loop-exit rejection
120 continue arity rejection
121 continue type rejection
122 break result rejection
123 fallthrough rejection
124 outer non-Copy initializer consume
125 identity-change precision boundary
126 nested loops
127 generic linear-search composition
128 semantic-effect conflict through loop
129 dynamic-index wildcard effect summary
130 lifecycle-neutral diverging loop
131 resource-transforming diverging-loop precision boundary
```

The M4 test module adds 19 focused regressions/destructive tests.

---

## 18. Validation

Final front-end validation:

```text
199 tests collected
199 passed
compileall PASS
```

Commands:

```bash
PYTHONPATH=. python -m pytest -q
python -m compileall -q newlang_frontend vendor tests
```

`ruff`, `mypy`, and `pyright` are not installed in the execution environment, so this report does not claim those checks passed.

The independent Draft 17.2 closure tree was subsequently supplied separately and rerun fresh alongside the final M4 bundle:

```text
110 tests collected
110 passed
compileall PASS
executable closure vectors: 12/12 PASS
generated closure differential: 100,000 cases, 0 mismatch, 0 false accept, 0 false reject
```

This provides an independent semantic-regression check in addition to the M4 front-end suite.

---

## 19. Architectural judgment

The strongest result is that source-visible iteration did **not** require:

```text
mutable locals
assignment statements
implicit phi ownership inference
general source-visible effect annotations
general source-visible lifetime constraints
general relational loop post-state syntax
```

The core composition is instead:

```text
explicit loop parameter invariant
    + ordinary consume/transfer
    + never-typed control exits
    + existing structural place/effect algebra
    + existing semantic identity values
```

This is a good fit for NewLang's policy-neutral / mechanism-strict direction.

---

## 20. Remaining M4 precision boundaries

Deliberately not closed in M4:

```text
identity-changing loop-carried joins
loop-carried hidden result/dependency state
resource-transforming infinite-loop post-state transformer
general arithmetic/operator surface
while/for ergonomic sugar
break/continue labels for multi-level control
escaping/non-local callback loop control
```

None was required by the representative M4 workload.

The important rule remains:

> loss of proof precision is a reason to reject or widen conservatively, not permission to invent a safe post-state.

---

## 21. M4 judgment and next milestone

**Front-End Prototype M4 passes.**

M4 now gives the front end enough iteration structure to pressure realistic generic containers rather than only synthetic generic signatures.

The highest-value next milestone is therefore **M5: generic nominal types / generic sums with a real small container workload**, not another loop-specific syntax expansion.

A good M5 pressure target is a fixed-capacity or caller-backed generic container that combines:

```text
generic nominal type parameters
loop-based traversal
non-Copy elements
dynamic occupancy metadata
fallible insert/remove ownership return
span/ref projection
associated hash/equal only if the workload actually needs them
```

That workload should determine whether dynamic partial initialization, richer loop lifecycle post-state, or allocator/storage surface needs to move from Deferred into the next implementation slice.
