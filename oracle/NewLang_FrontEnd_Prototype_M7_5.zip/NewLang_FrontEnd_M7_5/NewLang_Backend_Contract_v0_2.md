# NewLang Backend Contract v0.1 — LLVM alias / lifetime lowering

Status: **M7.3 provisional backend contract**.  This document is a lowering contract, not a new NewLang source-language mechanism.

## 1. Governing rule

NewLang capabilities and LLVM optimizer promises are not isomorphic.

```text
write permission          != access exclusivity
source exclusive authority != LLVM noalias by spelling alone
ref nonescape             != pointer-provenance nocapture
NewLang object lifetime   != llvm.lifetime.* in general
```

The backend may erase NewLang proof/capability state only after translating it to LLVM facts that are **no stronger** than the checked NewLang semantics.

## 2. Baseline matrix

| NewLang fact | Baseline LLVM lowering | M7.3 decision |
|---|---|---|
| `ptr<T>` | plain `ptr` locator | no `noalias`, `readonly`, `dereferenceable`, or capture claim by type alone |
| `ref<read,T>` | pointer access; parameter may be `readonly` | **not** `noalias`; capture is body-sensitive |
| `ref<write,T>` | ordinary read/write pointer access | **not** `noalias`; **not** `writeonly` because write refs may be read/weakened |
| `exclusive ref<...>` | same access mode as the ref | source `exclusive` alone does **not** imply LLVM `noalias` |
| checked access-exclusive range fact | `noalias` or scoped alias metadata may be considered | only if checker proves the LLVM dynamic-extent/access-set condition |
| stable read | statically prevents conflicting NewLang update | `readonly` is sufficient baseline; `llvm.invariant.*` is deferred optimization |
| lifetime-ending authority | compiler semantic authority | no direct LLVM attribute |
| NewLang typed lifetime start/end in heap/raw `Storage` | semantic only | **do not** emit `llvm.lifetime.start/end` |
| compiler stack-allocation storage lifetime | stack storage marker | may emit `llvm.lifetime.start/end` when exact alloca storage lifetime matches |
| ref capture | infer from body | `captures(none)` only if body analysis proves no address/provenance capture |
| positive extent | target/layout fact | no baseline `dereferenceable(N)` until null-address/ABI policy is owned by target lowering |

## 3. `ref<write,T>` must not lower to parameter `noalias`

NewLang intentionally permits aliasing write references.  Existing source fixture `13_semantic_aliased_actuals_conflict.nl` passes the same write reference as two arguments and is accepted.

LLVM parameter `noalias` is a substantially stronger promise: for memory modified during the function, conflicting accesses through pointers not based on the noalias argument make the IR behavior undefined.

M7.3's destructive probe passes the same pointer to two LLVM functions:

```text
ordinary pointers:
    O0 result component = 2
    O2 result component = 2

incorrect `noalias` parameters:
    O0 result component = 2 (optimizer did not exploit the invalid promise)
    O2 result component = 1 (optimizer validly exploits `noalias`)
```

The combined process exit changes from `202` at `-O0` to `201` at `-O2`, and optimized IR reduces the incorrectly annotated function to `ret i32 1`.

This is not an LLVM miscompile.  The frontend would have produced IR whose `noalias` precondition is false for a NewLang-defined program.  Therefore the lowering itself would be wrong.

## 4. `ref<read,T>` may use `readonly`, but not `noalias`

LLVM `readonly` only says the function does not write *through that pointer argument*; it does not say other aliases cannot modify the same memory.

The M7.3 probe uses one `readonly` pointer and one ordinary writer pointer that alias.  At `-O2` the load correctly observes the value written through the other pointer (`2`).

This is a good one-way lowering fact for a NewLang read ref: NewLang promises at least that code cannot write through the read ref.  NewLang's stronger stability semantics remain a checker fact and do not require a stronger LLVM alias promise.

## 5. `exclusive ref` and LLVM `noalias`

`exclusive` in NewLang is an authority/resource property.  LLVM `noalias` is an access-set promise over a dynamic execution extent.

M7.3 therefore requires a separate checked-MIR fact such as conceptually:

```text
AccessExclusive(range R, dynamic extent E)
```

before emitting LLVM `noalias` or equivalent `alias.scope`/`noalias` metadata.

The source spelling `exclusive ref<...>` alone is insufficient.  This keeps lifetime-ending authority, aliasing locators, and memory-access exclusivity as distinct axes.

## 6. source ref nonescape does not imply LLVM nocapture

NewLang refs themselves are scoped/nonescaping, but a persistent locator may be derived from a ref:

```text
fn save_locator(value: ref<read,Box>) -> ptr<Box> {
    ptr_from_ref(value)
}
```

M7.3 fixture `241_ref_locator_capture_ok.nl` is accepted.  Therefore a ref parameter can cause pointer provenance to escape even though the ref capability itself does not.

Do not emit LLVM `captures(none)` from the source type alone.  Capture attributes are body-sensitive optimization facts.

## 7. `dereferenceable` / `nonnull`

A NewLang ref denotes valid access in the source semantics, but LLVM `dereferenceable(N)` has target-level consequences.  In default address space it normally implies non-null unless `null_pointer_is_valid` is present.

Because NewLang targets embedded/bare-metal code and should not accidentally rule out a platform where address zero is usable storage, M7.3 does not emit `dereferenceable` or `nonnull` from ref type alone.

A target-aware lowering phase may add them after it owns:

- concrete positive extent;
- address-space rules;
- target null-address policy;
- the relevant dynamic program point.

## 8. NewLang lifetime versus `llvm.lifetime.*`

Current LLVM LangRef restricts `llvm.lifetime.start/end` operands to stack objects defined by `alloca` or `llvm.structured.alloca`.

Therefore:

```text
NewLang initialize(slot<T> on heap/raw Storage)
NewLang take/destroy of typed object
CurrentValueVersion reset
```

must **not** be lowered as general `llvm.lifetime.start/end` operations.

The intrinsics may be used when the compiler has an actual stack allocation and the intrinsic describes that stack storage lifetime exactly.  This is an optimization/storage-lifetime mapping, not the normative representation of a NewLang typed-object incarnation.

## 9. alias-scope metadata

`!alias.scope` / `!noalias` metadata can also introduce undefined behavior if the promised access sets alias.  They are not a workaround for the ordinary-ref rule.

They may be generated only from a separate proven disjoint-access fact in checked MIR, for example one derived from genuinely disjoint BackingRegions/ranges and valid for the exact instruction scope.

## 10. Deferred optimizations

M7.3 intentionally does not rely on:

- `llvm.invariant.start/end` for read stability;
- `nofree` for stability/lifetime loans;
- `writable` for write refs;
- automatic `dereferenceable`/`nonnull`;
- TBAA as a representation of NewLang ownership;
- automatic alias scopes from source ref kinds.

These may be revisited as performance optimizations after a production Checked MIR exists.  Omitting them is safe; emitting an unjustified one can make a valid NewLang program LLVM-UB.

## 11. Production compiler consequence

The future compiler should preserve at least these independent backend facts until Checked MIR:

```text
access mode
proven access exclusivity (optional)
capture behavior
known extent/alignment
target null-address policy
storage kind (stack allocation vs heap/external/subobject)
NewLang semantic lifetime state
```

Only the proven LLVM-relevant subset is emitted.  This supports the planned C-written production compiler without forcing LLVM's memory model back into the NewLang source semantics.

## 12. References used for M7.3

- LLVM Language Reference Manual, `noalias`, pointer capture, `readonly`, object lifetime, and memory-use markers: https://llvm.org/docs/LangRef.html
- NewLang Draft 17.3 and the M7.2 prototype/test corpus.

---

# M7.4 addendum — C ABI / calling convention / by-value aggregate boundary

## A. Native aggregate layout is not a C ABI representation

NewLang ordinary/native aggregate layout remains opaque.  Crossing an `extern C`-style boundary does not make a native aggregate layout-compatible with a C `struct` or `union`.

Conceptually:

```text
NewLang native value
    -> semantic field/variant marshalling
explicit C compatibility representation
    -> target C ABI classification
target machine call/return
```

The exact source spelling of the compatibility representation is not fixed by M7.4.  It may initially be produced by a compatibility frontend or generated C shim.

A raw/native bitcopy is not the default marshalling rule.  Padding bytes are representation details, not NewLang semantic value.

## B. ABI classification is a backend result

The following are not source-language ownership/lifetime properties:

```text
LLVM sret
LLVM byval
LLVM inreg
register coercion/splitting
hidden result pointer
caller-created aggregate copy
```

They arise from the selected target ABI and calling convention.

The same source-level C aggregate may have materially different LLVM signatures on x86-64 SysV, Windows x64, AArch64, and RISC-V.  Checked MIR therefore preserves an explicit foreign ABI identity/profile, while the target backend or generated C shim owns classification.

## C. ABI-originated alias facts remain distinct from NewLang refs

A target C ABI may impose a strong hidden-result-storage contract.  Clang may therefore represent an ABI-lowered hidden result as an `sret ... noalias` pointer.

This does not weaken M7.3:

```text
NewLang ref/exclusive spelling
    !=
LLVM noalias
```

Instead the `noalias` fact has a different proof origin:

```text
foreign ABI hidden-result rule
    -> backend ABI fact
    -> LLVM noalias where valid
```

Proof origin must be retained in Checked MIR/backend planning; ABI facts must not be reflected back into NewLang source permission semantics.

## D. v0 boundary policy

Baseline policy:

```text
C scalar / explicit C pointer
    -> direct C ABI lowering is permitted

explicit C record/union
    -> direct only when a target ABI classifier is available
    -> otherwise generated C shim

native NewLang aggregate/sum
    -> no direct by-value ABI identity
    -> explicit C representation + semantic marshalling

NewLang semantic-resource-bearing value
    -> no automatic aggregate-byte ABI conversion
    -> dedicated privileged FFI contract required

by-value aggregate varargs
    -> generated C shim in v0 baseline
```

A native sum is not automatically a C union: active-variant semantics and representation must be mapped explicitly.

## E. Initial production compiler strategy

The first production compiler need not reimplement every platform aggregate classifier.

A conservative path is:

```text
NewLang frontend / Checked MIR
    -> generate narrow C ABI shim
    -> host/target C compiler performs exact C aggregate ABI lowering
    -> link with NewLang-generated objects
```

This is especially attractive for the planned C implementation of the production compiler.  Direct ABI classification can be added target-by-target later and differential-tested against the C shim/Clang oracle.

## F. Calling convention contract

A foreign declaration records its ABI/calling-convention identity explicitly in semantic/backend state.  LLVM declaration and call-site calling conventions and all ABI-impacting attributes must match the target contract.

NewLang native calling convention is independent and may evolve without changing the C ABI compatibility representation.

## G. M7.4 executable evidence

M7.4 cross-target Clang probes observe at least three different LLVM signatures for the same C `PairD { double, double }` by-value identity across:

```text
x86_64 SysV
Windows x64
AArch64
RISC-V 64
```

A 20,000-case randomized layout pressure test reorders native fields independently from the C declaration and explicitly marshals semantic field values.  Result:

```text
roundtrip mismatch: 0
native bitcopy not equivalent: 17,187 cases
```

A separately compiled host C API plus generated shim also passes while the simulated native record deliberately has a different size and field order from the C record.
