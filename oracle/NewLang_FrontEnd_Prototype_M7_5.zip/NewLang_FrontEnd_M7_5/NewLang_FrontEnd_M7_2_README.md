# NewLang Front-End Prototype M7.2

M7.2 is the over-aligned-storage / zero-sized-type policy milestone in the C-substitutability/backend phase.

Main result:

```text
positive-size over-aligned Storage
    -> supported with allocation alignment + subrange coordinate checks

Layout<ZST> knowledge
    -> allowed

raw Storage -> slot<ZST> dynamic lifetime bridge
    -> v0 rejected (E_ZST_DYNAMIC_STORAGE)
```

Why the ZST restriction exists:

```text
byte range [0,0) carries no multiplicity
```

so full dynamic ZST support needs an additional logical responsibility axis rather than a relaxation of byte-range overlap.

The production lifecycle lowerer now tracks Storage/slot/root geometry so alignment checks match the exact lifecycle bridge.

Validation:

```text
428 / 428 front-end tests PASS
independent Draft17.2: 110 / 110 PASS
closure vectors: 12 / 12 PASS
100,000 closure differential cases: 0 mismatch / false accept / false reject
M7.2 generated pressure: 20,000 cases
max tested alignment: 4096
```

See `NewLang_FrontEnd_M7_2_REPORT.md` for the design reasoning and backend probe.
