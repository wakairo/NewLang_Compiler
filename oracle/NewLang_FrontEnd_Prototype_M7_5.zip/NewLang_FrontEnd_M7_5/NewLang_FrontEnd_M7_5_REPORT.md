# NewLang Front-End Prototype M7.5 Report

## 1. Scope

M7.5 is the **FFI / external backing / opaque-call summary boundary** milestone and the final planned M7 backend/interop pressure point after M7.4's C ABI work.

The question is not whether NewLang v0 should expose a complete FFI syntax now. The question is whether future foreign calls, external backing, out construction, callbacks, and opaque indirect behavior force a redesign of the Draft 17.3 semantic core or an immediate general effect system.

The answer from this pressure pass is **no**.

The smallest stable boundary is:

```text
explicit narrow foreign facts
    -> existing NewLang effect/dependency machinery
    -> independent backend facts
    -> LLVM attributes only when separately justified

missing foreign fact
    -> Unknown on that axis
    -> conservative rejection when a live NewLang obligation could be invalidated
```

M7.5 adds no normative surface syntax.

## 2. Prior evidence incorporated

The earlier combined Draft-17 foreign-boundary experiment already established four important facts:

1. safe external backing can be imported only when the ordinary-safe non-alias invariant is guaranteed;
2. aliased/shared/device-style external views can remain opaque instead of weakening that invariant;
3. a foreign call with an explicit narrow `Change / Reset / EndRoot` summary composes with the existing dependency checker, while no summary can fall back to `Unknown`;
4. representation bytes alone do not create a complete NewLang semantic `ValuePackage`.

M7.5 does not reopen those decisions. It pressure-tests how they interact with the backend contract and optimization boundary.

## 3. Foreign summary is multi-axis, not `pure/impure`

A single purity bit loses distinctions that matter to both safety and code generation. M7.5 therefore keeps at least these facts independent in compiler state:

```text
semantic effect:
    none / Change(P) / Reset(P) / EndRoot(P) / Unknown

LLVM-relevant memory access:
    none / read / readwrite / Unknown

retention:
    no-retain / may-retain / Unknown

callback behavior:
    none / synchronous / retained-or-escaping / Unknown

control transfer:
    checked return / foreign unwind / longjmp-or-other nonlocal transfer / Unknown

construction:
    complete representation?
    complete semantic ValuePackage?

external backing:
    liveness / range / alignment / access / non-alias proof
```

This preserves the same principle as M7.3: proof origins are kept separate until backend lowering.

## 4. Opaque call policy

An opaque call is not automatically forbidden. Unknown behavior matters only when it can invalidate something the checked NewLang state still relies on.

Examples:

```text
only scalars + opaque foreign handle
    -> unknown mutation of the foreign object need not become a NewLang place effect

safe NewLang place exposed while Value(P) is live
    -> unknown Change/EndRoot behavior is not acceptable

scoped ref or raw out location exposed
    -> no-retain must be established

nonescaping callable exposed
    -> synchronous/non-retained callback behavior must be established
```

The M7.5 finite checker models these rules and is differential-tested against an enumerating concrete oracle.

## 5. Differential semantic pressure

The checker varies:

- live current-value dependency;
- root-liveness requirement;
- borrowed/raw-location exposure;
- nonescaping callback exposure;
- semantic effect summary;
- retention summary;
- callback summary;
- control-transfer summary;
- independent backend memory-access summary.

Result with seed `20261004`:

```text
cases:         100,000
mismatch:      0
false accept:  0
false reject:  0
```

The finite model is deliberately small; its purpose is to falsify the boundary algebra, not to claim a complete FFI implementation.

## 6. Destructive optimizer probe

A separately compiled C implementation is:

```c
int mutate(int *p) {
    *p += 5;
    return 7;
}
```

The truthful/opaque caller merely declares:

```c
extern int mutate(int *p);
```

At `-O2`, Clang 17 keeps a load before and after the call and the program produces:

```text
x=15 r=12
exit 0
```

The destructive probe then lies to the optimizer:

```c
extern int mutate(int *p) __attribute__((pure));
```

Observed result:

```text
-O0: x=15 r=12, exit 0
-O2: x=15 r=7,  exit 1
```

The optimized IR carries `memory(read)` and removes both caller loads around the call. The declaration is intentionally false and therefore outside the valid C/LLVM contract; the point is precisely that **an unjustified foreign summary changes optimizer-visible semantics**.

This is the M7.5 analogue of the M7.3 invalid-`noalias` destructive probe.

## 7. LLVM contract check

Current LLVM LangRef makes omission conservative for memory effects: without a `memory(...)` attribute, `memory(readwrite)` is implied. It also has independent pointer-capture, callback, and unwind attributes.

M7.5 therefore adopts:

```text
NewLang semantic no-effect
    does not imply memory(none)

foreign no-retain proof
    may justify LLVM capture restriction for the exact covered pointer

foreign no-exception-unwind proof
    may justify nounwind

foreign no-callback/reentry proof
    may justify nocallback where its LLVM contract matches
```

The checked continuation/no-nonlocal-transfer fact remains a NewLang boundary fact because LLVM `nounwind` only covers exception unwind, while `nocallback` has its own module-level semantics and includes callback/nonlocal-reentry constraints.

The local Clang 17 `__attribute__((noescape))` probe lowers to the then-current `nocapture` spelling. Current LLVM documentation spells the more expressive contract as `captures(...)`; this is a backend-version spelling issue, not a NewLang semantic distinction.

## 8. External backing probe

M7.5 maps the same shared file backing twice using `mmap`.

Observed:

```text
aliases=1
 distinct_virtual_addresses=1
```

Thus two different virtual/numeric addresses can denote the same abstract external bytes. Safe backing identity cannot be derived from address inequality.

The boundary remains:

```text
can prove liveness/range/alignment/access/nonalias
    -> ordinary-safe BackingRegion + Storage

cannot prove it / shared alias exists
    -> opaque external view
```

No rule allowing overlapping ordinary-safe `BackingRegion` identities is needed.

## 9. Foreign out construction

M7.5 keeps the already-tested future extension point:

```text
slot<T>
  -> raw FFI destination location   // not ptr<T>
  -> complete foreign write
  -> representation witness
  -> complete semantic ValuePackage<T>
  -> privileged lifetime start
  -> fresh root + first safe ptr<T>
```

The pressure model rejects:

- partial representation;
- resource-bearing value without a complete semantic package;
- retained raw destination location.

A semantically trivial FFI representation may have an empty/trivial package; that is not the same as manufacturing hidden NewLang authority from bytes.

## 10. Callback and control-flow boundary

The v0 callable remains nonescaping and synchronous. Passing it across FFI is safe only under a synchronous/non-retained callback contract.

Retained callbacks remain outside the v0 checked boundary.

Likewise, M7.5 does not attempt to make foreign exceptions, `longjmp`, or arbitrary nonlocal transfer interact with scope-exit obligations. The checked boundary requires an adequate ordinary-return contract or rejects conservatively.

This is intentionally not collapsed into LLVM `nounwind`.

## 11. Production compiler implication

The planned C-written production compiler can represent the foreign boundary with a small internal contract record rather than a source-visible general effect language.

A reasonable initial Checked MIR record contains optional facts for:

```text
foreign ABI identity
semantic effects
memory access
capture/retention
callback behavior
control transfer
construction certification
external-backing proof origin
```

Generated C shims can continue to own difficult ABI classification, but C/Clang attributes should be emitted *from* checked facts, not imported back as unquestioned NewLang semantics.

## 12. Validation on the canonical M7.4 tree

M7.5 was applied to the uploaded canonical M7.4 archive whose 426-entry SHA-256 inventory first verified with zero mismatch.

Full front-end regression after integration:

```text
pytest:      466 / 466 PASS
pytest time: 7.21 s
wall time:   8.70 s
peak RSS:    134,856 KiB
compileall:  PASS
```

The 466 tests consist of the previous 443-test M7.4 tree plus 23 M7.5 boundary tests.

Generated M7.5 differential:

```text
100,000 cases
accepted:      9,420
mismatch:      0
false accept:  0
false reject:  0
```

Backend probes with Clang 17:

```text
unknown external call -O2:         x=15 r=12, exit 0
false pure summary -O0:            x=15 r=12, exit 0
false pure summary -O2:            x=15 r=7,  exit 1
external shared-backing alias:     aliases=1, distinct_virtual_addresses=1
noescape probe:                    LLVM nocapture emitted by Clang 17
```

## 13. Regression against prior M7 evidence

The following M7-family experiment outputs were rerun from the integrated M7.5 tree and their published JSON results matched byte-for-byte / SHA-256-for-SHA-256 with the M7.4 archive:

```text
M7 intrusive owner recovery          MATCH
M7.1 address stability               MATCH
M7.1 backend probe                   MATCH
M7.2 storage/layout pressure         MATCH
M7.2 backend probe                   MATCH
M7.3 backend contract                MATCH
M7.4 C ABI pressure                  MATCH
```

The supplied Draft 17.3 bundle was also inventory-checked: all seven manifest entries matched their SHA-256 values. It remains the semantic baseline; M7.5 does not require a Draft 17.4/18 semantic-core revision.

The independent Draft17.2 110/110 result remains part of the already-validated M7.4/Draft17.3 baseline; M7.5 did not modify that independent checker bundle.

## 14. Judgment

M7.5 is a **PASS**, including full-tree integration.

The closure is:

```text
FFI remains localized
+
external aliasing does not weaken ordinary-safe backing
+
narrow explicit summaries compose with existing semantic effects
+
missing facts remain Unknown
+
retention / callback / control / memory facts remain independent
+
foreign representation bytes do not manufacture semantic authority
+
LLVM promises are emitted only from matching backend proofs
```

No Draft-18 semantic redesign or general source-visible effect system is required by M7.5.

This completes the planned M7 backend/interop pressure sequence. The next step should be an M7 consolidation/adjudication pass: decide which M7.3–M7.5 backend/FFI conclusions belong in normative Draft 17.x wording, which remain backend contracts, and which remain explicitly Deferred before starting the next milestone family.


## 15. References

- LLVM Language Reference Manual: https://llvm.org/docs/LangRef.html
- Clang Attribute Reference (`noescape`, `callback`, `nothrow`): https://clang.llvm.org/docs/AttributeReference.html
- NewLang Draft 17 combined foreign-boundary experiment and Draft 17.3 semantic baseline from the project archive.
