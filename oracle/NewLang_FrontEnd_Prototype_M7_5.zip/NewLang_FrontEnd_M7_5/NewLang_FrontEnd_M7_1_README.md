# NewLang Front-End Prototype M7.1

M7.1 pressures self-reference and address-sensitive values after M7 intrusive owner recovery.

Key result:

```text
ordinary value movement remains ordinary
address-stable abstractions use stable backing + movable handles
```

No core `Pin`, runtime pin flag, or permanent `!Relocatable` nominal property was required by the tested workloads.

Important files:

- `NewLang_FrontEnd_M7_1_REPORT.md`
- `newlang_frontend/address_stability_pressure.py`
- `tests/test_m7_1_address_stability.py`
- `tests/programs/234_relocation_stales_external_observer_error.nl`
- `tests/programs/235_swap_keeps_location_observer_live_ok.nl`
- `tests/programs/236_stable_owner_handle_move_ok.nl`
- `tests/programs/237_stable_owner_hides_pointee_error.nl`
- `run_m7_1_address_stability_experiment.py`
- `m7_1_address_stability_results.json`
- `backend_probe/m7_1_address_move.c`
- `backend_probe/m7_1_address_move.ll`
- `run_m7_1_backend_probe.py`
- `m7_1_backend_probe_results.json`

Semantic baseline remains Draft 17.3. Exact anchored/unanchored library source spelling remains Provisional.
