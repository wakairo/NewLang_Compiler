# NewLang Front-End Prototype M6.4 — Focus / Re-entry / Multiple-Claim Closure

> Status: **completed experimental M6.4 implementation**
>
> Normative baseline: `NewLang_v0_spec_Draft17_3.md`
>
> Executable starting point: Front-End Prototype M6.3
>
> Prior-art pressure: `netresearch_002_reinvention.md`, especially Vault/Mezzo focus/nesting and the re-entry / multiple-claim counterexamples.

## 1. Question

M6.4 tests whether Draft 17.3's rooted responsibility model can close the first two prior-art failure modes without adding a general permission calculus or symbolic range solver:

1. a scoped claim is open and code re-enters the same root;
2. an operation needs two or more dynamic claims from the same root.

The existing rule remains:

```text
metadata describes occupancy
authority comes from rooted responsibility
claim extraction transfers responsibility; it does not reconstruct it
```

M6.4 adds the missing **focus discipline**:

```text
root closed
    -> ordinary claim extraction may open one focus

root focused
    -> independent root operation / observation / claim extraction is blocked
    -> only operations on already-extracted claims may continue

need multiple dynamic claims
    -> present all candidates at one atomic boundary
    -> validate concrete non-overlap before transferring any authority
```

## 2. Important result

The workload closed without adding:

```text
general permission language
general guarded-type system
symbolic inequality/range solver
source-visible focus syntax
new source-level lifetime/effect annotation
runtime focus token/version counter
```

The new receipts are prototype ghost/authority objects, not required runtime representation.

## 3. Ordinary focus rule

Previously, `SealedRegion` prevented extracting the *same index* twice because the first responsibility became `claimed_*`, but a second independent claim at another index could still be opened directly.

M6.4 strengthens this:

```text
any open claim on root R
    => R is focused
    => another independent claim extraction from R rejects E_REGION_FOCUSED
```

The same focused root also rejects:

- public invariant observation;
- starting another container transition;
- starting a new stable borrow;
- safe closure/API re-entry that tries to open the root again.

Returning one claim from a multi-focus does not close the root while another extracted responsibility remains outside the owner.

A `take` that turns a live claim into a vacant claim also does not accidentally close the focus: the replacement vacant claim remains open responsibility.

## 4. Transition-local authority

Draft 17.3 already distinguishes steady-state metadata from transition-local responsibility. M6.4 makes that discipline executable.

`begin_transition()` now returns a scoped `TransitionReceipt`.

While the container invariant is unpublished:

```text
claim extraction without active receipt
    -> E_REGION_TRANSITION

claim extraction with the active receipt
    -> allowed for the internal transition path

stale receipt after publication
    -> E_REGION_STALE_TRANSITION
```

This matters because merely blocking *observation* was insufficient: an untrusted/safe helper must not enter an unpublished root through a claim API either.

The receipt is an implementation experiment, not a proposed source-visible syntax.

## 5. Multiple dynamic claims

M6.4 deliberately does not make ordinary `claim_live(i)` recursively composable.

Instead an operation that needs several claims uses one boundary:

```text
claim_many([
    (live, i, T),
    (live, j, T),
])
```

All candidates are validated before authority transfer.

For the current whole-element region model:

```text
i == j           -> E_REGION_OVERLAPPING_CLAIMS
distinct slots   -> accepted after concrete byte-range non-overlap check
```

`claim_many_ranges` additionally tests concrete element ranges:

```text
[0,2) and [1,3)  -> reject overlap
[0,2) and [2,4)  -> accept adjacency
```

The safe M6.4 prototype is intentionally **whole-element granular**. Arbitrary sub-element byte-range focus is not generalized in v0 by this milestone.

This is the central complexity result:

> NewLang does not need a symbolic solver merely because two runtime indices exist. A library/compiler boundary can receive the concrete candidates together, perform a runtime non-overlap check, and transfer the already-owned responsibilities atomically.

## 6. Closure re-entry break test

M6.3's nonescaping closure sugar was retested adversarially.

Conceptually:

```text
with_live(root, i) { claim_i ->
    with_live(root, j) { ... }
}
```

The nested open rejects `E_REGION_FOCUSED`; the outer `finally` path returns the original claim and restores the root.

Likewise, a safe closure cannot enter a root that is currently in an unpublished transition even if no element claim happens to be open at that instant; it rejects `E_REGION_TRANSITION`.

Thus closure sugar remains viable without acquiring independent authority semantics.

## 7. Atomicity / responsibility conservation

`claim_many` prevalidates:

- root state;
- type/state suitability;
- bounds/alignment;
- stable-borrow conflicts;
- pairwise concrete byte-range non-overlap.

Only after successful validation are responsibilities transferred out of the region ledger.

Break tests verify that a duplicate index, overlapping range, or type prevalidation error leaves:

```text
open_claims == empty
all non-Discardable token owners == original region
```

No metadata value is used to mint a replacement claim.

## 8. Generated pressure

Seed `20261004`, 300 traces × 64 operations:

```text
operations            19,200
re-entry rejects        3,899
duplicate rejects       3,809
partial-overlap rejects 3,824
disjoint multi success  3,781
adjacent-range success  3,887
mismatches                  0
```

Every generated step checks that:

- no unexpected open claim leaks after the operation;
- each non-Discardable token has exactly one owner;
- successful multi-focus returns all authority;
- rejected operations do not transfer authority.

## 9. Front-end validation

Final M6.4 tree:

```text
pytest:      365 / 365 PASS
compileall:  PASS
```

M6.4 adds no source syntax and does not alter generic/lifetime/dependency semantics outside the dynamic-region prototype.

## 10. Independent Draft 17.2 closure regression

Fresh independent closure checker rerun:

```text
pytest:      110 / 110 PASS
compileall:  PASS
closure executable vectors: 12 / 12 PASS
```

Generated Draft 17.2 differential:

```text
100,000 cases
mismatches:     0
false accepts:  0
false rejects:  0
```

## 11. Prior-art interpretation

The result should **not** be read as “Vault/Mezzo focus was unnecessary”. Their failure cases identified the missing rule.

M6.4's narrower answer is possible because v0 deliberately restricts the interaction set:

- claim source is one rooted region;
- safe refs do not escape;
- ordinary independent nested focus is rejected;
- multiple dynamic claims must be requested together;
- current prototype focuses whole element slots;
- unsupported general relation reasoning is not inferred silently.

This is exactly the project-level hypothesis now being tested: prior systems' powerful mechanisms may be avoidable when the language permits fewer interactions.

## 12. Draft 17.3 impact

No Draft 18-style redesign is indicated.

Draft 17.3 already normatively requires:

- no overlapping claim regeneration;
- outstanding claims to block whole-root return;
- inconsistent transition state not to be exposed to reentrant callbacks;
- transition-local responsibility to remain owned.

M6.4 suggests one future clarification when normative consolidation is next performed:

> While a rooted responsibility is focused/open, operations that can observe, redistribute, end, move, or reopen the same hidden responsibility must be blocked unless they are part of the same authorized focus/transition or their disjoint claims were established together by a sound boundary.

The exact `TransitionReceipt`, `claim_many`, and `claim_many_ranges` spellings remain **Provisional implementation vehicles**.

## 13. Decision

M6.4 **passes** the first convergence-closure milestone.

Current judgment:

```text
general permission calculus required?  no evidence yet
symbolic dynamic-range solver required? no
re-entry discipline required?           yes
multi-claim atomic boundary required?   yes for operations needing >1 claim
source-visible focus syntax required?   no evidence yet
```

The next planned milestone should remain M6.5: `CurrentValueVersion` closure under replace, swap, alias-mediated write, A→B→A, aggregate field update, and unrelated-update positive cases.
