from __future__ import annotations

import json

from newlang_frontend.dynamic_container_pressure import (
    differential_prefix_trace,
    differential_trace,
    run_generated_differential,
    run_generated_prefix_differential,
)


def main() -> None:
    result = {
        "scattered_representative": differential_trace(seed=20261003, capacity=16, steps=1000),
        "scattered_generated": run_generated_differential(seed=20261003, traces=500, steps=64),
        "prefix_representative": differential_prefix_trace(seed=20261003, capacity=64, steps=2000),
        "prefix_generated": run_generated_prefix_differential(seed=20261003, traces=500, steps=64),
    }
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
