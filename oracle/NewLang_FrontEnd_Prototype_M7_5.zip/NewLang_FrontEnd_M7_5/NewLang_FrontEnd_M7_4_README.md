# NewLang Front-End M7.4

M7.4 closes the **C ABI / calling convention / by-value aggregate** pressure point.

Main rule:

```text
native NewLang aggregate layout != C ABI representation
```

C aggregate interoperability is modeled as:

```text
native value
  -> semantic field/variant marshalling
explicit C compatibility representation
  -> target ABI classifier or generated C shim
```

Cross-target Clang probes demonstrate target-specific aggregate classification across x86-64 SysV, Windows x64, AArch64, and RISC-V 64.  A 20,000-case randomized layout pressure test preserves all semantic values through explicit marshalling while raw native bitcopy is non-equivalent in 17,187 cases.

Validation:

```text
443 / 443 front-end tests PASS
independent Draft17.2: 110 / 110 PASS
100,000 closure differential cases: 0 mismatch / false accept / false reject
M7.3 / M7.2 / M7.1 / M7 published results reproduced exactly
```

See:

- `NewLang_Backend_Contract_v0_2.md`
- `NewLang_FrontEnd_M7_4_REPORT.md`
- `m7_4_c_abi_results.json`
