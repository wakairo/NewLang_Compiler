# NewLang Front-End Prototype M7.4 Report

## 1. Scope

M7.4 is the **C ABI / calling convention / by-value aggregate boundary** milestone of the C-substitutability/backend phase.

It asks whether NewLang can interoperate with ordinary C aggregate-by-value interfaces while preserving the Draft 17.3 rule:

```text
native aggregate layout is opaque
native layout != C aggregate layout
```

No new native NewLang layout guarantee or source-visible `offsetof`/packed-layout mechanism is introduced.

The tested boundary covers:

- scalar/pointer versus aggregate ABI lowering;
- by-value C records and unions;
- target-specific register/memory classification;
- hidden result pointers (`sret`-like lowering);
- pointer-to-copy (`byval`-like lowering);
- field-wise native <-> C compatibility marshalling;
- padding non-semantics;
- generated C shims as the initial production fallback;
- aggregate varargs being kept behind a shim in the v0 baseline.

## 2. Cross-target ABI pressure

The same C source was compiled to LLVM IR with Clang 17 for:

```text
x86_64-unknown-linux-gnu
x86_64-pc-windows-msvc
aarch64-unknown-linux-gnu
riscv64-unknown-linux-gnu
```

For:

```c
struct PairD { double a; double b; };
struct PairD paird_id(struct PairD x) { return x; }
```

observed LLVM signatures include three materially different forms:

```text
x86_64 SysV:
    { double, double } @paird_id(double, double)

Windows x64:
    void @paird_id(ptr sret(%struct.PairD), ptr)

AArch64:
    %struct.PairD @paird_id([2 x double])

RISC-V 64:
    { double, double } @paird_id(double, double)
```

For a 24-byte `Big` record, all tested targets return indirectly in the emitted LLVM IR, but parameter lowering still differs: x86-64 SysV uses `byval(%struct.Big)` while Windows/AArch64/RISC-V Clang IR uses different pointer forms.

Therefore:

```text
C aggregate type
    != fixed LLVM function signature
```

The function signature is a target ABI lowering result.

## 3. Design closure: explicit C representation

M7.4 models a distinct compatibility representation.

Conceptually:

```text
native NewLang aggregate
    -> semantic field/variant marshalling
explicit C record/union representation
    -> target ABI classifier or C shim
actual call/return
```

A native aggregate is never directly declared C-layout-compatible merely because it is passed to foreign code.

The source spelling of an explicit C representation is deliberately not fixed in M7.4.  It may initially be internal to a compatibility frontend or generated shim.

## 4. Randomized native-layout versus C-layout pressure

`c_abi_pressure.py` generates records containing 2..6 `i32`, `i64`, and `f64` fields.

The C compatibility layout follows declaration order.  The simulated NewLang native layout is independently reordered, reflecting the native opaque-layout freedom.

For each case the test:

1. encodes a semantic value in native layout;
2. reads semantic fields and writes a C representation;
3. reads the C representation and reconstructs native layout;
4. compares semantic field values;
5. separately tests whether raw native bytes could have been interpreted as the C record.

Seed `20261004`, 20,000 cases:

```text
roundtrip mismatch:                     0
reordered native-layout cases:     17,187
padding cases:                     13,585
raw native bitcopy not equivalent: 17,187
```

Thus explicit semantic marshalling survives arbitrary tested native field reorder, while direct native-byte reuse commonly changes meaning.

## 5. Real separately-compiled C shim probe

M7.4 also compiles two translation units independently.

The C API uses:

```c
struct CPair {
    int x;
    double y;
};
```

The simulated NewLang-native representation is deliberately different:

```c
struct NativePair {
    double y;
    long long private_cookie;
    int x;
};
```

The shim marshals `x`/`y` field-wise in both directions.  The probe checks that:

- native and C field offsets differ;
- native and C sizes differ;
- a by-value C call receives correct values;
- a by-value C return reconstructs correct native values;
- the private native field remains unchanged.

Host result:

```text
exit = 0
PASS
```

This demonstrates the intended compatibility architecture without making native layout C-compatible.

## 6. `sret` / `byval` are not NewLang ownership facts

LLVM documents `sret`, `byval`, `inreg`, `inalloca`, and related attributes as ABI-impacting parameter attributes.

M7.4 therefore records them as backend/target facts.

In particular, Clang often emits a hidden result pointer as:

```text
sret(...) noalias writable
```

for C aggregate returns.  This does not mean a NewLang source `exclusive ref` maps to `noalias`.

The proof origin is distinct:

```text
C ABI hidden result contract
    -> ABI backend fact
    -> LLVM noalias if required/valid
```

M7.3 remains unchanged:

```text
ordinary ref / exclusive spelling alone
    -> never enough for LLVM noalias
```

## 7. Padding is representation, not semantic value

A C compatibility record can contain padding required by the target C implementation/ABI.

Those bytes are not part of the native NewLang semantic value and need not be preserved when converting native <-> C representations unless a specific foreign byte-level contract says otherwise.

Automatic native aggregate bitcopy is therefore not the FFI marshalling rule.

## 8. Native sum versus C union

A native NewLang sum is not automatically a C union.

The active variant, payload representation, and any semantic dependency/occurrence state are not represented merely by union bytes.  A wrapper must explicitly map the foreign discriminator/protocol to the native sum.

M7.4 therefore treats automatic native-sum -> C-union by-value conversion as unavailable.

## 9. Resource-bearing values

`Storage`, `LifetimeDomain`, scoped `ref`, hidden responsibility, semantic dependencies, and similar NewLang state are not encoded by C aggregate bytes.

An aggregate containing such semantic resources cannot be made C ABI-safe by selecting a C field layout.  It needs a dedicated privileged FFI contract or opaque handle representation.

This is consistent with Draft 17.3's rule that foreign bytes do not automatically create a semantic `ValuePackage`.

## 10. Aggregate varargs

C varargs have target/language-specific default promotions and calling rules.  M7.4 keeps by-value aggregate varargs behind a generated C shim in the v0 baseline rather than adding another source-visible ABI subsystem.

This can be relaxed later target-by-target if real workload pressure justifies it.

## 11. Initial production compiler implication

M7.4 produces a useful simplification for the planned C production compiler.

The initial compiler does **not** need a complete reimplementation of SysV AMD64, Windows x64, AAPCS64, RISC-V, and other aggregate classifiers.

It can start with:

```text
simple scalar/pointer C ABI lowering
+
generated C shim for complex aggregate boundaries
```

and let the target C compiler/Clang perform exact aggregate ABI lowering.

Later, direct target-specific lowering can replace individual shims and be differential-tested against the C compiler oracle.

This is a production strategy, not a semantic dependency on C layout in native NewLang.

## 12. Validation

M7.4 front-end tree:

```text
pytest:      443 / 443 PASS
compileall:  PASS
full pytest elapsed: ~9.2 s
peak RSS:            ~138 MB
```

Independent Draft 17.2 closure, fresh extraction:

```text
pytest:       110 / 110 PASS
compileall:   PASS
generated:    100,000 cases
mismatches:   0
false accepts:0
false rejects:0
```

M7.3, M7.2, M7.1, and M7 published experiment outputs were rerun and matched exactly.

## 13. M7.4 conclusion

M7.4 is a **PASS**.

No evidence requires changing the native aggregate layout policy.

The closure is:

```text
native layout stays opaque
+
C compatibility representation is explicit/separate
+
semantic field/variant marshalling
+
target ABI classification is backend-owned
+
generated C shim is an acceptable initial fallback
```

No Draft 17.4 semantic-core revision is required solely by M7.4.

The remaining planned M7 pressure is M7.5:

```text
FFI / external backing / opaque-call summary boundary
```

After M7.5, consolidate the M7 backend/interop phase and decide whether any Draft 17.x wording should be promoted from experimental evidence into the normative text.
