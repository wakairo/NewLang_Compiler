# NewLang Front-End Prototype M7.2 Report

## 1. Scope

M7.2 is the third **C-substitutability / backend pressure** milestone.

It targets two layout/storage boundaries before backend alias lowering:

1. **over-aligned storage** — can NewLang preserve target alignment requirements through allocation, split Storage claims, typed slot materialization, and backend lowering without exposing native field layout or adding runtime tags?
2. **zero-sized types (ZST)** — can the existing byte-range `Storage -> slot<T> -> live T` algebra represent a finite multiplicity of zero-byte object lifetimes without adding a second authority dimension?

Draft 17.3 remains the semantic baseline.  M7.2 does not add source-visible alignment attributes, pointer arithmetic, `offsetof`, or a new ZST container primitive.

## 2. Result

**PASS.**

The experiment supports this v0 decomposition:

```text
layout knowledge
    !=
storage authority

positive-size addressable dynamic storage
    = byte-range authority + alignment fact

zero-size value layout knowledge
    is allowed

zero-size dynamic object-lifetime multiplicity
    is not represented by the v0 byte-range Storage algebra
```

Consequently:

- `Layout<unit>` is now a valid compiler layout witness with `(size=0, align=1, stride=0)` in the prototype;
- querying its layout facts is accepted;
- `allocate_layout(Layout<unit>, N)` is rejected with `E_ZST_DYNAMIC_STORAGE`;
- the v0 raw `Storage -> slot<T>` bridge remains restricted to positive-size typed lifetimes;
- over-aligned positive-size storage works without a new runtime alignment token.

## 3. Important implementation correction: production bridge alignment

Before M7.2, the exact lifecycle runner validated both:

```text
backing_alignment >= alignof(T)
subrange_start % alignof(T) == 0
```

before `storage_into_slot_layout`.

The production lifecycle bridge did not preserve enough lowering-time Storage geometry to perform the same check.  Its byte-range production checker validates exact extent but has no target-alignment model, so a same-size misaligned subrange could escape the bridge-level check.

M7.2 adds finite lowering-time geometry:

```text
Storage -> (BackingRegion, start, end)
slot    -> (BackingRegion, start, end)
root    -> (BackingRegion, start, end)
Allocation -> base alignment
```

and threads it across:

```text
allocate
split / merge
Storage -> slot
initialize
root -> slot (take/destroy)
erase_slot
```

This is compiler bookkeeping, not runtime metadata.

A synthetic target layout `(size=64, align=64, stride=64)` now behaves identically in exact and production bridges:

```text
64-aligned whole Storage, start 0   -> accept
64-byte subrange starting at 32     -> E_SLOT_ALIGNMENT
backing aligned only to 32          -> E_SLOT_ALIGNMENT
```

## 4. Over-alignment pressure

`newlang_frontend/storage_layout_pressure.py` exercises alignments:

```text
16, 32, 64, 128, 256, 512, 1024, 2048, 4096
```

For each generated case it checks:

1. sufficiently aligned backing + aligned subrange -> accepted;
2. insufficient backing alignment -> rejected;
3. sufficiently aligned backing + misaligned subrange start -> rejected.

20,000-case result:

```text
over-aligned materialization success     20,000
under-aligned backing rejection          20,000
misaligned subrange rejection            20,000
mismatch                                      0
```

The experiment does not require a per-object runtime alignment tag.  Alignment is a property of the allocation/backing plus the subrange coordinate known to the compiler/library boundary.

## 5. ZST: layout fact is not object-lifetime authority

M6.3 rejected even asking for `Layout<unit>` because dynamic-region ZST multiplicity had not been defined.

M7.2 narrows that restriction.

A compiler is allowed to know:

```text
sizeof(unit)  = 0
alignof(unit) = 1
stride(unit)  = 0
```

without claiming that raw byte Storage can represent `N` independent `unit` object lifetimes.

This directly applies the Draft 17.3 principle:

```text
layout knowledge != authority
```

The historical M6.3 `205_layout_zst_policy_error.nl` fixture is therefore now accepted as a layout-query-only program.

## 6. Why the existing Storage algebra cannot simply “allow size 0”

The current occupancy authority is fundamentally byte-range based.

For positive-size objects, disjoint half-open ranges provide a useful conservation/non-overlap invariant.

For zero extent:

```text
[0,0)
[0,0)
[0,0)
...
```

all such ranges are pairwise non-overlapping under ordinary byte-range overlap.

Therefore byte non-overlap cannot answer:

```text
How many logical ZST slots exist?
Which one is live?
Which one is vacant?
Did split/merge preserve the finite multiplicity?
Did we duplicate a logical object-lifetime responsibility?
```

M7.2 contains a comparison `LogicalZstArena` whose authority is indexed by logical slot identity rather than bytes.  It works and conserves responsibility, but it demonstrates the cost: **full ZST dynamic-storage support requires an additional logical multiplicity/claim axis** (or an equivalent mechanism).

That mechanism is not needed merely to substitute for standard C object storage.

## 7. v0 ZST policy after M7.2

The pressure result supports the following provisional-v0 boundary:

### Allowed

- zero-sized semantic values such as `unit`;
- compiler layout knowledge for zero-sized values;
- ordinary value-flow uses that do not ask the raw byte-storage bridge to host a finite set of independent zero-byte lifetimes.

### Not admitted by the raw dynamic storage bridge

- `allocate_layout(Layout<ZST>, count)`;
- `Storage -> slot<ZST>` materialization;
- dynamic container occupancy whose element-lifetime multiplicity is inferred only from zero-byte ranges.

Error:

```text
E_ZST_DYNAMIC_STORAGE
```

This is a v0 scope restriction, not a claim that zero-sized addressable/logical objects are impossible to support later.

If real workloads need them, the next design question is a separate logical-slot authority carrier — not a fake one-byte size or unconstrained duplicate empty ranges.

## 8. C / backend probe

A C2x probe defines types with 64-byte and 4096-byte alignment and compiles them with the available Clang 17.

Observed LLVM IR:

```text
alloca %struct.Wide64,   align 64
alloca %struct.Wide4096, align 4096
```

For heap allocation:

```text
aligned_alloc(64, 64)
```

is lowered with a return alignment fact, and the declaration carries LLVM's `allocalign` parameter attribute.

Probe result:

```text
stack align 64 preserved       true
stack align 4096 preserved     true
heap return align 64           true
aligned_alloc allocalign       true
```

Thus no backend obstacle was found for preserving large NewLang target alignment requirements.

The same probe compiles an empty C struct under:

```text
clang -std=c2x -pedantic-errors
```

and Clang rejects it as a GNU empty-struct extension.

This matches the relevant C23 object-representation direction: standard complete objects are not required to support zero-byte object extent.  Therefore deferring NewLang's *dynamic ZST object-lifetime multiplicity* does not by itself reduce the standard-C storage domain NewLang aims to substitute for.

## 9. Generated M7.2 pressure

Seed: `20261004`.

```text
20,000 cases

over-aligned materializations                20,000
under-aligned backing rejections              20,000
misaligned subrange rejections                20,000
ZST dynamic-storage rejections                20,000
logical-ZST comparison conservation           20,000

maximum alignment tested                        4096
naive empty ranges pairwise nonconflicting       true
runtime alignment tag required                   false
ZST layout query allowed                         true
ZST raw Storage bridge allowed                   false
```

## 10. Front-end validation

Final M7.2 tree:

```text
pytest:      428 / 428 PASS
compileall:  PASS
```

Measured in this prototype environment:

```text
full pytest elapsed:  ~8.1 s
peak RSS:              ~131 MB
```

These remain regression baselines, not compiler-performance claims.

## 11. Prior milestone regressions

Fresh reruns:

```text
M7.1 address-stability pressure: MATCH
M7 intrusive pressure:          MATCH
```

The M7.2 production-geometry addition did not change their outcomes.

## 12. Independent Draft 17.2 closure regression

Fresh extraction of the independent closure prototype:

```text
pytest:      110 / 110 PASS
compileall:  PASS
executable vectors: 12 / 12 PASS
```

Generated closure differential:

```text
100,000 cases
mismatches:     0
false accepts:  0
false rejects:  0
```

## 13. What M7.2 does not claim

M7.2 deliberately does **not** add or settle:

- source-visible `alignas` / alignment attributes;
- C aggregate ABI layout;
- MMIO/device-specific alignment contracts;
- a general ZST address identity model;
- ZST dynamic containers;
- allocation-failure ABI for extreme alignments;
- concurrency;
- backend alias/noalias lowering.

The result is narrower:

> positive-size over-aligned storage fits the existing authority model, while zero-byte dynamic object multiplicity does not.

## 14. Semantic judgment

M7.2 does not justify a large core change.

The strongest conclusions are:

```text
Fix/strongly preserve:
  alignment is part of target layout/storage validity
  layout facts do not mint authority
  Storage subrange coordinates participate in alignment validity

Provisional v0 restriction:
  raw Storage/slot dynamic lifetime bridge requires positive object extent

Deferred:
  general logical ZST multiplicity / address identity for dynamic containers
```

This is preferable to either:

```text
pretend each ZST consumes one byte
```

or:

```text
let arbitrary duplicate empty byte ranges stand for distinct ownership claims
```

because both would blur the existing separation between physical bytes and semantic responsibility.

## 15. Next phase

The next backend pressure should now be the previously identified critical rule:

```text
ref<write,T> != LLVM noalias
```

M7/M7.1/M7.2 have shown that provenance, address stability, and alignment can remain explicit semantic axes without importing C pointer/layout policy into the core.

M7.3 should test whether LLVM alias/lifetime metadata can preserve NewLang's more unusual access decomposition:

```text
write permission
    != exclusive aliasing
    != lifetime-ending authority
```

The failure mode to avoid is a sound NewLang source program being miscompiled because the backend was given stronger `noalias`, `alias.scope`, lifetime, or dereferenceability facts than the language semantics guarantee.
