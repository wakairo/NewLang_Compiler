extern int mutate(int *p);

int probe_unknown(int *p) {
    int before = *p;
    int r = mutate(p);
    return (*p - before) + r;
}
