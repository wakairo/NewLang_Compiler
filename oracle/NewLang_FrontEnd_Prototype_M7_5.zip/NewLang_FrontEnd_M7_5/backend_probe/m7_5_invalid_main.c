#include <stdio.h>
int probe_invalid_summary(int *p);
int main(void) {
    int x = 10;
    int r = probe_invalid_summary(&x);
    printf("x=%d r=%d\n", x, r);
    /* This is the source-level result if the foreign summary were truthful. */
    return !(x == 15 && r == 12);
}
