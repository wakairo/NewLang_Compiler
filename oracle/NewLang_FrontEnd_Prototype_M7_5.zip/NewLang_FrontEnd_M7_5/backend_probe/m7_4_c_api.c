struct CPair {
    int x;
    double y;
};

double cpair_score(struct CPair p) {
    return ((double)p.x * 1000.0) + p.y;
}

struct CPair cpair_make(int x, double y) {
    struct CPair out = {x, y};
    return out;
}
