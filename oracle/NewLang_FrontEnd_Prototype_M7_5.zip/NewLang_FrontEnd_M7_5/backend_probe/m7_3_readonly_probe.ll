source_filename = "m7_3_readonly_probe"

define i32 @readonly_does_not_mean_noalias(ptr readonly %view, ptr %writer) {
entry:
  store i32 2, ptr %writer, align 4
  %x = load i32, ptr %view, align 4
  ret i32 %x
}

define i32 @main() {
entry:
  %x = alloca i32, align 4
  store i32 1, ptr %x, align 4
  %r = call i32 @readonly_does_not_mean_noalias(ptr %x, ptr %x)
  ret i32 %r
}
