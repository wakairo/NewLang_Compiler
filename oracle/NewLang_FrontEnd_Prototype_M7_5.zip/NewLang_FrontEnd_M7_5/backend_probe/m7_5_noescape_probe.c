extern int inspect(__attribute__((noescape)) int *p);
int wrap_noescape(int *p) { return inspect(p); }
