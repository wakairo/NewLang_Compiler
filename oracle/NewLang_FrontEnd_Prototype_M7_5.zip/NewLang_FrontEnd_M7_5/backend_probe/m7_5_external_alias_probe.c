#define _GNU_SOURCE
#include <sys/mman.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>

int main(void) {
    FILE *f = tmpfile();
    if (!f) return 10;
    int fd = fileno(f);
    if (ftruncate(fd, 4096) != 0) return 11;

    unsigned char *a = mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    unsigned char *b = mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (a == MAP_FAILED || b == MAP_FAILED) return 12;

    a[123] = 77;
    int aliases = (b[123] == 77);
    int distinct_virtual_addresses = (a != b);
    printf("aliases=%d distinct_virtual_addresses=%d\n", aliases, distinct_virtual_addresses);

    munmap(a, 4096);
    munmap(b, 4096);
    fclose(f);
    return !(aliases && distinct_virtual_addresses);
}
