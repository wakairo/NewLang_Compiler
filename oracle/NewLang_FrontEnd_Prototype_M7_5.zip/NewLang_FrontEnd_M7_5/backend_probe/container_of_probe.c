#include <stddef.h>
struct Link { int tag; };
struct Node { char small; struct Link first; long word; struct Link second; };
struct Node *from_first(struct Link *p) {
  return (struct Node *)((char *)p - offsetof(struct Node, first));
}
struct Node *from_second(struct Link *p) {
  return (struct Node *)((char *)p - offsetof(struct Node, second));
}
