int mutate(int *p) {
    *p += 5;
    return 7;
}
