#include <stdio.h>
int probe_unknown(int *p);
int main(void) {
    int x = 10;
    int r = probe_unknown(&x);
    printf("x=%d r=%d\n", x, r);
    return !(x == 15 && r == 12);
}
