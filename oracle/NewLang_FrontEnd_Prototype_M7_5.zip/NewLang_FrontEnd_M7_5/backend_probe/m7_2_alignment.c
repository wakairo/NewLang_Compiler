#include <stdlib.h>

extern void escape(void *);

struct Wide64 {
    _Alignas(64) unsigned char data[64];
};

struct Wide4096 {
    _Alignas(4096) unsigned char data[4096];
};

void stack64(void) {
    struct Wide64 value;
    escape(&value);
}

void stack4096(void) {
    struct Wide4096 value;
    escape(&value);
}

void *heap64(void) {
    return aligned_alloc(_Alignof(struct Wide64), sizeof(struct Wide64));
}
