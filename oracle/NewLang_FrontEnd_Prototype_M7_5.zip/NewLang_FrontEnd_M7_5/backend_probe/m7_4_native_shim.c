#include <stddef.h>

struct CPair {
    int x;
    double y;
};

/* Deliberately not CPair-compatible: reordered plus private payload/padding. */
struct NativePair {
    double y;
    long long private_cookie;
    int x;
};

double cpair_score(struct CPair p);
struct CPair cpair_make(int x, double y);

static struct CPair marshal_to_c(const struct NativePair *n) {
    struct CPair c;
    c.x = n->x;
    c.y = n->y;
    return c;
}

static void marshal_from_c(struct NativePair *n, struct CPair c) {
    n->x = c.x;
    n->y = c.y;
}

double nl_score(const struct NativePair *n) {
    return cpair_score(marshal_to_c(n));
}

void nl_make(struct NativePair *out, int x, double y) {
    struct CPair c = cpair_make(x, y);
    marshal_from_c(out, c);
}

int main(void) {
    struct NativePair a = {2.5, 0x1122334455667788LL, 7};
    if (offsetof(struct NativePair, x) == offsetof(struct CPair, x)) return 10;
    if (sizeof(struct NativePair) == sizeof(struct CPair)) return 11;
    if (nl_score(&a) != 7002.5) return 12;
    if (a.private_cookie != 0x1122334455667788LL) return 13;

    struct NativePair b = {-1.0, 0x7766554433221100LL, -1};
    nl_make(&b, 9, 4.5);
    if (b.x != 9 || b.y != 4.5) return 14;
    if (b.private_cookie != 0x7766554433221100LL) return 15;
    return 0;
}
