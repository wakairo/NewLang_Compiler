struct Empty {};
int main(void) {
    struct Empty x;
    return (int)sizeof x;
}
