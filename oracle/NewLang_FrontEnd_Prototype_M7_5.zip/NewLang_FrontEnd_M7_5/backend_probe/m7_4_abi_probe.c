struct PairI { int a; int b; };
struct PairD { double a; double b; };
struct Mixed { double d; int i; };
struct Big { long long a; long long b; long long c; };
union U64D { long long i; double d; };

struct PairI pairi_id(struct PairI x) { return x; }
struct PairD paird_id(struct PairD x) { return x; }
struct Mixed mixed_id(struct Mixed x) { return x; }
struct Big big_id(struct Big x) { return x; }
union U64D union_id(union U64D x) { return x; }

int pairi_sum(struct PairI x) { return x.a + x.b; }
double paird_sum(struct PairD x) { return x.a + x.b; }
long long big_sum(struct Big x) { return x.a + x.b + x.c; }
