source_filename = "m7_3_noalias_probe"

define i32 @ordinary_write_refs(ptr %a, ptr %b) {
entry:
  store i32 1, ptr %a, align 4
  store i32 2, ptr %b, align 4
  %x = load i32, ptr %a, align 4
  ret i32 %x
}

define i32 @incorrectly_claimed_noalias(ptr noalias %a, ptr noalias %b) {
entry:
  store i32 1, ptr %a, align 4
  store i32 2, ptr %b, align 4
  %x = load i32, ptr %a, align 4
  ret i32 %x
}

define i32 @main() {
entry:
  %x = alloca i32, align 4
  store i32 0, ptr %x, align 4
  %ordinary = call i32 @ordinary_write_refs(ptr %x, ptr %x)
  store i32 0, ptr %x, align 4
  ; Passing the same pointer to two noalias parameters violates the IR contract.
  ; We do it deliberately to show what an unsound frontend lowering lets LLVM
  ; optimize under its valid assumptions.
  %claimed = call i32 @incorrectly_claimed_noalias(ptr %x, ptr %x)
  %scaled = mul i32 %ordinary, 100
  %result = add i32 %scaled, %claimed
  ret i32 %result
}
