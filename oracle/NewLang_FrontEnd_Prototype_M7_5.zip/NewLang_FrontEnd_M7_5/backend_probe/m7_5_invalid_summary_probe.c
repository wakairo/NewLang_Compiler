/* Deliberately false declaration used only as a destructive optimizer probe. */
extern int mutate(int *p) __attribute__((pure));

int probe_invalid_summary(int *p) {
    int before = *p;
    int r = mutate(p);
    return (*p - before) + r;
}
