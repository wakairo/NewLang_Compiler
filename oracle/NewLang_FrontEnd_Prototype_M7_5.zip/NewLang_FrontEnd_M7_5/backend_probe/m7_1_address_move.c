typedef struct Node Node;
struct Node { Node *self; long value; };

void move_node(Node *dst, Node *src) {
  *dst = *src;
}

void fix_self(Node *p) {
  p->self = p;
}
