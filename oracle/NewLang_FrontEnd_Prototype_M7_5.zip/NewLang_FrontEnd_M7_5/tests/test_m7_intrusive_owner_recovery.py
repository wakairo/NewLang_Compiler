from __future__ import annotations

from pathlib import Path

import pytest

from newlang_frontend.driver import check_source
from newlang_frontend.lexer import lex
from newlang_frontend.lifecycle import run_lifecycle_detailed
from newlang_frontend.parser import parse
from newlang_frontend.production_lifecycle import run_production_lifecycle_detailed
from newlang_frontend.source import SourceFile
from newlang_frontend.symbols import SymbolBuilder
from newlang_frontend.typecheck import TypeChecker

ROOT = Path(__file__).parent / "programs"


def typed(name: str):
    path = ROOT / name
    source = SourceFile(str(path), path.read_text(encoding="utf-8"))
    symbols = SymbolBuilder(parse(lex(source))).build()
    return TypeChecker(symbols).check_program()


@pytest.mark.parametrize(
    ("name", "accepted", "code"),
    [
        ("223_owner_recovery_intrusive_ok.nl", True, None),
        ("224_owner_recovery_wrong_provenance_error.nl", False, "E_OWNER_PROJECTION"),
        ("225_owner_recovery_private_error.nl", False, "E_PRIVATE_OWNER_RECOVERY"),
        ("226_owner_recovery_same_type_fields_ok.nl", True, None),
        ("227_owner_recovery_nested_ok.nl", True, None),
        ("228_owner_recovery_dangling_token_ok.nl", True, None),
        ("229_owner_recovery_dangling_access_error.nl", False, "E_STALE_PTR"),
        ("230_dangling_ptr_field_projection_ok.nl", True, None),
        ("231_nested_owner_not_lifetime_root_error.nl", False, "E_NOT_LIFETIME_ROOT"),
        ("232_owner_recovery_ref_ptr_roundtrip_ok.nl", True, None),
        ("233_owner_recovery_stored_ptr_ok.nl", True, None),
    ],
)
def test_owner_recovery_source_workloads(name: str, accepted: bool, code: str | None) -> None:
    path = ROOT / name
    result = check_source(path.read_text(encoding="utf-8"), str(path))
    assert result.accepted is accepted, result.diagnostic
    if code is not None:
        assert result.diagnostic is not None
        assert result.diagnostic.code == code


def test_owner_recovery_exact_and_production_agree_on_core_cases() -> None:
    for name, accepted in [
        ("223_owner_recovery_intrusive_ok.nl", True),
        ("224_owner_recovery_wrong_provenance_error.nl", False),
        ("226_owner_recovery_same_type_fields_ok.nl", True),
        ("227_owner_recovery_nested_ok.nl", True),
        ("228_owner_recovery_dangling_token_ok.nl", True),
        ("229_owner_recovery_dangling_access_error.nl", False),
        ("230_dangling_ptr_field_projection_ok.nl", True),
        ("231_nested_owner_not_lifetime_root_error.nl", False),
        ("232_owner_recovery_ref_ptr_roundtrip_ok.nl", True),
        ("233_owner_recovery_stored_ptr_ok.nl", True),
    ]:
        program = typed(name)
        exact = run_lifecycle_detailed(program)
        production = run_production_lifecycle_detailed(program)
        assert exact.accepted is accepted, (name, exact)
        assert production.accepted is accepted, (name, production)
        assert not production.precision_loss


def test_wrong_provenance_is_not_repaired_by_expected_owner_type() -> None:
    program = typed("224_owner_recovery_wrong_provenance_error.nl")
    exact = run_lifecycle_detailed(program)
    production = run_production_lifecycle_detailed(program)
    assert exact.code == "E_OWNER_PROJECTION"
    assert production.code == "E_OWNER_PROJECTION"


def test_dangling_owner_derivation_does_not_revive_access() -> None:
    ok = run_lifecycle_detailed(typed("228_owner_recovery_dangling_token_ok.nl"))
    bad = run_lifecycle_detailed(typed("229_owner_recovery_dangling_access_error.nl"))
    assert ok.accepted
    assert not bad.accepted
    assert bad.code == "E_STALE_PTR"

from newlang_frontend.intrusive_pressure import run_intrusive_pressure


def test_generated_intrusive_owner_recovery_pressure() -> None:
    result = run_intrusive_pressure(seed=20261004, cases=4_000)
    assert result["recovered"] == 4_000
    assert result["same_type_field_recoveries"] == 4_000
    assert result["nested_recoveries"] == 4_000
    assert result["forged_address_rejections"] == 4_000
    assert result["stale_locator_recoveries"] == 4_000
    assert result["stale_access_rejections"] == 4_000
    assert result["backend_lowering_mismatches"] == 0
    assert result["field_offsets_exposed_to_source"] is False
    assert result["integer_pointer_roundtrip_required"] is False
