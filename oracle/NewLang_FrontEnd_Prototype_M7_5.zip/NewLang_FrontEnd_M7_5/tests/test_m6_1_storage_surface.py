from pathlib import Path
import pytest
from newlang_frontend.driver import check_source
from newlang_frontend.lexer import lex
from newlang_frontend.lifecycle import run_lifecycle_detailed
from newlang_frontend.production_lifecycle import run_production_lifecycle_detailed
from newlang_frontend.parser import parse
from newlang_frontend.source import SourceFile
from newlang_frontend.symbols import SymbolBuilder
from newlang_frontend.typecheck import TypeChecker

ROOT = Path(__file__).parent / "programs"

def check(name: str):
    p = ROOT / name
    return check_source(p.read_text(), str(p))

def typed(name: str):
    p = ROOT / name
    src = SourceFile(str(p), p.read_text())
    syms = SymbolBuilder(parse(lex(src))).build()
    return TypeChecker(syms).check_program()

@pytest.mark.parametrize(("name","ok","code"), [
    ("193_storage_split_slot_roundtrip_ok.nl", True, None),
    ("194_dynamic_materialize_u32_ok.nl", False, "E_M62_LEGACY_DYNAMIC_BRIDGE"),
    ("195_dynamic_materialize_alignment_error.nl", False, "E_M62_LEGACY_DYNAMIC_BRIDGE"),
    ("196_dynamic_recover_live_root_error.nl", False, "E_M62_LEGACY_DYNAMIC_BRIDGE"),
    ("197_dynamic_overlap_claim_error.nl", False, "E_M62_LEGACY_DYNAMIC_BRIDGE"),
    ("198_storage_into_slot_size_error.nl", False, "E_SLOT_SIZE"),
    ("199_reallocate_typed_transfer_ok.nl", True, None),
    ("200_reallocate_live_ref_error.nl", False, "E_LOAN_CONFLICT"),
    ("201_opaque_nominal_storage_layout_error.nl", False, "E_OPAQUE_LAYOUT"),
])
def test_m61_programs(name, ok, code):
    r=check(name)
    assert r.accepted is ok, r.diagnostic
    if code:
        assert r.diagnostic and r.diagnostic.code == code

def test_safe_storage_roundtrip_exact_lifecycle():
    r=run_lifecycle_detailed(typed("193_storage_split_slot_roundtrip_ok.nl"))
    assert r.accepted, r

def test_m61_dynamic_authority_reconstruction_surface_is_retired_in_m62():
    r=check("194_dynamic_materialize_u32_ok.nl")
    assert not r.accepted and r.diagnostic and r.diagnostic.code == "E_M62_LEGACY_DYNAMIC_BRIDGE"


def test_safe_storage_roundtrip_production_lifecycle():
    r=run_production_lifecycle_detailed(typed("193_storage_split_slot_roundtrip_ok.nl"))
    assert r.accepted, r
    assert not r.precision_loss

def test_retired_dynamic_bridge_never_reaches_production_lifecycle():
    r=check("194_dynamic_materialize_u32_ok.nl")
    assert not r.accepted and r.diagnostic and r.diagnostic.code == "E_M62_LEGACY_DYNAMIC_BRIDGE"


def test_reallocation_typed_transfer_runs_through_both_bridges():
    p=typed("199_reallocate_typed_transfer_ok.nl")
    exact=run_lifecycle_detailed(p)
    prod=run_production_lifecycle_detailed(p)
    assert exact.accepted, exact
    assert prod.accepted, prod
    assert not prod.precision_loss
