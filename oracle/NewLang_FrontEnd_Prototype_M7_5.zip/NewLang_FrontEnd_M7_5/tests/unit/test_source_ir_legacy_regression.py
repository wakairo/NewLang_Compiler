from newlang_checker.callbacks import CallbackSummary
from newlang_checker.ir import Effect
from newlang_checker.source_ir import (
    AddDepStmt,
    BoundedSourceAnalyzer,
    CallbackStmt,
    EffectStmt,
    ExactSourceRunner,
    FunctionDef,
    GenericCallStmt,
    KillDepStmt,
    SourceProgram,
)


def test_legacy_live_dependency_invalidated_rejects_both_layers():
    p = SourceProgram({"f": FunctionDef("f", (AddDepStmt("P"), EffectStmt(Effect("Reset", "P"))))})
    assert not ExactSourceRunner(p).run("f").exact_accepts
    assert not BoundedSourceAnalyzer(p, 8).analyze("f").result.accepted


def test_legacy_kill_before_invalidation_accepts():
    p = SourceProgram(
        {"f": FunctionDef("f", (AddDepStmt("P"), KillDepStmt("P"), EffectStmt(Effect("Reset", "P"))))}
    )
    assert ExactSourceRunner(p).run("f").exact_accepts
    assert BoundedSourceAnalyzer(p, 8).analyze("f").result.accepted


def test_legacy_unresolved_generic_remains_unknown():
    p = SourceProgram({"f": FunctionDef("f", (GenericCallStmt("hash<K>"),))})
    assert not ExactSourceRunner(p).run("f").exact_accepts
    assert not BoundedSourceAnalyzer(p, 8).analyze("f").result.accepted


def test_legacy_escaping_callback_remains_rejected():
    cb = CallbackSummary(frozenset(), nonescaping=False)
    p = SourceProgram({"f": FunctionDef("f", (CallbackStmt("cb"),))}, callbacks={"cb": cb})
    assert not ExactSourceRunner(p).run("f").exact_accepts
    assert not BoundedSourceAnalyzer(p, 8).analyze("f").result.accepted
