from __future__ import annotations

import random
from pathlib import Path

import pytest

from newlang_checker.language_ir import (
    ClonePtr,
    DestroyRoot,
    FinalizeDomain,
    Initialize,
    TakeRoot,
    UFunction,
    UProgram,
    ValidatePtrDomain,
)
from newlang_checker.model import BackingRegion, ByteRange, SemanticError, SemanticState, SlotClaim, ValuePackage
from newlang_checker.production_analysis import ProductionChecker
from newlang_checker.semantics import (
    apply_step,
    derive_ptr_token,
    finalize_lifetime_domain,
    require_stability_domain,
)
from newlang_frontend.lexer import lex
from newlang_frontend.lifecycle import run_lifecycle_detailed
from newlang_frontend.parser import parse
from newlang_frontend.production_lifecycle import run_production_lifecycle_detailed
from newlang_frontend.source import SourceFile
from newlang_frontend.symbols import SymbolBuilder
from newlang_frontend.typecheck import TypeChecker

ROOT = Path(__file__).parents[1] / "programs"

SOURCE_CASES = [
    ("15_lifecycle_initialize_destroy_ok.nl", True),
    ("16_lifecycle_take_ok.nl", True),
    ("17_lifecycle_wrong_domain_error.nl", False),
    ("21_stale_ptr_after_destroy_error.nl", False),
    ("22_finalize_live_domain_error.nl", False),
    ("23_projected_ptr_not_root_error.nl", False),
    ("27_lifecycle_wrapper_destroy_ok.nl", True),
    ("28_lifecycle_wrapper_wrong_domain_error.nl", False),
    ("32_ref_from_ptr_read_ok.nl", True),
    ("33_ref_from_ptr_write_ok.nl", True),
    ("34_ref_from_ptr_wrong_domain_error.nl", False),
    ("35_ref_from_ptr_stale_error.nl", False),
    ("36_ref_from_ptr_escape_error.nl", False),
    ("37_ptr_from_ref_escape_ok.nl", True),
    ("38_projected_ptr_ref_roundtrip_ok.nl", True),
    ("42_ref_escape_through_wrapper_error.nl", False),
    ("43_ptr_escape_through_wrapper_ok.nl", True),
    ("44_ref_from_ptr_wrong_domain_wrapper_error.nl", False),
    ("45_ptr_from_local_ref_ok.nl", True),
]


def _typed(path: Path):
    source = SourceFile(str(path), path.read_text(encoding="utf-8"))
    tree = parse(lex(source))
    symbols = SymbolBuilder(tree).build()
    return TypeChecker(symbols).check_program()


@pytest.mark.parametrize(("filename", "expected"), SOURCE_CASES)
def test_source_exact_and_production_lifecycle_agree(filename: str, expected: bool) -> None:
    typed = _typed(ROOT / filename)
    exact = run_lifecycle_detailed(typed)
    production = run_production_lifecycle_detailed(typed)
    assert exact.accepted is expected, (filename, exact)
    assert production.accepted is expected, (filename, production)
    if production.accepted:
        assert not production.precision_loss


def _initial() -> tuple[SemanticState, dict[str, object]]:
    exact = SemanticState()
    exact.backings["R"] = BackingRegion("R", "B")
    exact.slots["slot"] = SlotClaim("T", "R", ByteRange(0, 8))
    exact.values["value"] = ValuePackage("v")
    exact.live_domains.update({"D0", "D1"})
    abstract: dict[str, object] = {
        "backings": {"R": {"abstract_bytes": "B", "live": True}},
        "slots": {"slot": {"type": "T", "backing_region": "R", "range": [0, 8]}},
        "values": {"value": {"local": "v"}},
        "lifetime_domains": ["D0", "D1"],
    }
    return exact, abstract


def _exact_family(family: int) -> bool:
    st, _ = _initial()
    try:
        apply_step(st, {
            "op": "initialize", "slot": "slot", "value": "value", "domain": "D0",
            "result_root": "root", "result_location_token": "p",
        })
        if family == 0:  # destroy correct domain
            apply_step(st, {"op": "destroy", "root": "root", "ending_domain": "D0", "result_slot": "out"})
        elif family == 1:  # take correct domain
            apply_step(st, {"op": "take", "root": "root", "ending_domain": "D0", "result_value": "outv", "result_slot": "out"})
        elif family == 2:  # destroy wrong domain
            apply_step(st, {"op": "destroy", "root": "root", "ending_domain": "D1", "result_slot": "out"})
        elif family == 3:  # ref acquisition correct
            require_stability_domain(st, "p", "D0")
        elif family == 4:  # ref acquisition wrong domain
            require_stability_domain(st, "p", "D1")
        elif family == 5:  # clone ptr and acquire
            derive_ptr_token(st, "p", "q")
            require_stability_domain(st, "q", "D0")
        elif family == 6:  # stale ptr after destroy
            apply_step(st, {"op": "destroy", "root": "root", "ending_domain": "D0", "result_slot": "out"})
            require_stability_domain(st, "p", "D0")
        elif family == 7:  # finalize while root live
            finalize_lifetime_domain(st, "D0")
        elif family == 8:  # finalize after destroy
            apply_step(st, {"op": "destroy", "root": "root", "ending_domain": "D0", "result_slot": "out"})
            finalize_lifetime_domain(st, "D0")
        elif family == 9:  # cloned ptr also becomes stale
            derive_ptr_token(st, "p", "q")
            apply_step(st, {"op": "destroy", "root": "root", "ending_domain": "D0", "result_slot": "out"})
            require_stability_domain(st, "q", "D0")
        else:
            raise AssertionError(family)
        return True
    except (SemanticError, KeyError):
        return False


def _production_family(family: int) -> bool:
    _, initial = _initial()
    body = [Initialize("slot", "value", "D0", "root", "p")]
    if family == 0:
        body += [DestroyRoot("root", "out", "D0")]
    elif family == 1:
        body += [TakeRoot("root", "outv", "out", "D0")]
    elif family == 2:
        body += [DestroyRoot("root", "out", "D1")]
    elif family == 3:
        body += [ValidatePtrDomain("p", "D0")]
    elif family == 4:
        body += [ValidatePtrDomain("p", "D1")]
    elif family == 5:
        body += [ClonePtr("p", "q"), ValidatePtrDomain("q", "D0")]
    elif family == 6:
        body += [DestroyRoot("root", "out", "D0"), ValidatePtrDomain("p", "D0")]
    elif family == 7:
        body += [FinalizeDomain("D0")]
    elif family == 8:
        body += [DestroyRoot("root", "out", "D0"), FinalizeDomain("D0")]
    elif family == 9:
        body += [ClonePtr("p", "q"), DestroyRoot("root", "out", "D0"), ValidatePtrDomain("q", "D0")]
    else:
        raise AssertionError(family)
    program = UProgram({"main": UFunction("main", tuple(body))})
    return ProductionChecker(program, path_budget=4, value_budget=8).analyze("main", initial).accepted


def test_generated_exact_vs_production_lifecycle_differential() -> None:
    rng = random.Random(20261003)
    mismatches: list[tuple[int, bool, bool]] = []
    for _ in range(10_000):
        family = rng.randrange(10)
        exact = _exact_family(family)
        production = _production_family(family)
        if exact != production:
            mismatches.append((family, exact, production))
            if len(mismatches) >= 5:
                break
    assert mismatches == []
