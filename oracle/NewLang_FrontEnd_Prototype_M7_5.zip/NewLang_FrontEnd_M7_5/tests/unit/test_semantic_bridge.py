from newlang_frontend.driver import check_source
from newlang_frontend.lower import lower_program
from newlang_checker.source_ir import EffectStmt


def test_store_lowers_to_existing_change_effect_relative_to_formal():
    src = r'''
module Box
  struct { value: u32 }
  fn set_value(self: ref<write, Self>, value: u32) -> unit {
    store(self@value, value)
  }
  fn make(value: u32) -> Self { Self { value: value } }
end
fn main() -> unit {
  let b = Box::make(u32(1))
  loan write b as w { w.set_value(u32(2)) }
}
'''
    result = check_source(src)
    assert result.accepted
    assert result.typed is not None
    program = lower_program(result.typed)
    set_fn = program.functions["Box::set_value"]
    effects = [s for s in set_fn.body if isinstance(s, EffectStmt)]
    assert len(effects) == 1
    assert effects[0].effect.kind == "Change"
    assert effects[0].effect.place == "self.value"
    assert set_fn.params == ("self", "value")
