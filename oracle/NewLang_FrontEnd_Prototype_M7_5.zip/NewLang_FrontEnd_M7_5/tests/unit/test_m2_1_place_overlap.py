from newlang_checker.ir import Effect
from newlang_checker.source_ir import BoundedSourceAnalyzer, EffectStmt, ExactSourceRunner, FunctionDef, SourceProgram


def run(effect_place: str, dep: str):
    program = SourceProgram({"main": FunctionDef("main", (EffectStmt(Effect("Change", effect_place)),))})
    exact = ExactSourceRunner(program).run("main", (dep,))
    bounded = BoundedSourceAnalyzer(program, alternative_budget=8).analyze("main", (dep,))
    return exact, bounded


def test_dynamic_index_wildcard_overlaps_specific_index() -> None:
    exact, bounded = run("values.$index:*", "values.$index:2")
    assert not exact.exact_accepts
    assert not bounded.result.accepted


def test_parent_change_overlaps_descendant_dependency() -> None:
    exact, bounded = run("box", "box.value")
    assert not exact.exact_accepts
    assert not bounded.result.accepted


def test_distinct_specific_indices_remain_distinct() -> None:
    exact, bounded = run("values.$index:0", "values.$index:1")
    assert exact.exact_accepts
    assert bounded.result.accepted
