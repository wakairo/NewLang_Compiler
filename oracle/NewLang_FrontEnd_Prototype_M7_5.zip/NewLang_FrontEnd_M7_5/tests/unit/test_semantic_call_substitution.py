from newlang_frontend.driver import check_source
from newlang_frontend.lower import lower_program
from newlang_checker.ir import Effect
from newlang_checker.source_ir import AddDepStmt, CallStmt, EffectStmt, ExactSourceRunner, FunctionDef, SourceProgram


def test_shared_ir_substitutes_dependency_and_effect_places():
    program = SourceProgram(
        {
            "mutate": FunctionDef(
                "mutate",
                (
                    AddDepStmt("self.value"),
                    EffectStmt(Effect("Change", "self.value")),
                ),
                ("self",),
            ),
            "main": FunctionDef("main", (CallStmt("mutate", ("box",)),)),
        }
    )
    result = ExactSourceRunner(program).run("main")
    assert not result.exact_accepts
    rejected = next(path for path in result.paths if path.rejected)
    assert rejected.reason == "semantic conflict at box.value"
    assert rejected.deps == frozenset({"box.value"})
    assert rejected.effects[-1] == Effect("Change", "box.value")


def test_direct_receiver_ref_call_preserves_loan_alias():
    src = r'''
module Box
  struct { value: u32 }
  fn set_value(self: ref<write, Self>, value: u32) -> unit {
    store(self@value, value)
  }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn main() -> unit {
  let b = Box::make(u32(1))
  loan write b as w {
    w.set_value(u32(2))
  }
}
'''
    result = check_source(src, semantic_initial_deps=("b.value",))
    assert not result.accepted
    assert result.diagnostic is not None
    assert result.diagnostic.code == "E_SEMANTIC_CONFLICT"
    assert result.semantic_reason == "semantic conflict at b.value"
    # The primary diagnostic points at the callee store, not the first declaration.
    line, _ = result.diagnostic.span.start_line_col
    assert line == 5


def test_nested_receiver_wrapper_substitutes_actual_place_twice():
    src = r'''
module Box
  struct { value: u32 }
  fn set_value(self: ref<write, Self>, value: u32) -> unit {
    store(self@value, value)
  }
  fn update(self: ref<write, Self>, value: u32) -> unit {
    self.set_value(value)
  }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn main() -> unit {
  let b = Box::make(u32(1))
  loan write b as w {
    w.update(u32(2))
  }
}
'''
    result = check_source(src, semantic_initial_deps=("b.value",))
    assert not result.accepted
    assert result.diagnostic is not None
    assert result.diagnostic.code == "E_SEMANTIC_CONFLICT"
    assert result.semantic_reason == "semantic conflict at b.value"
    line, _ = result.diagnostic.span.start_line_col
    assert line == 5


def test_aliased_actuals_remain_aliased_across_call_boundary():
    src = r'''
module Box
  struct { value: u32 }
  fn set_other(self: ref<write, Self>, other: ref<write, Self>, value: u32) -> unit {
    store(other@value, value)
  }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn main() -> unit {
  let b = Box::make(u32(1))
  loan write b as w {
    w.set_other(w, u32(2))
  }
}
'''
    result = check_source(src, semantic_initial_deps=("b.value",))
    assert not result.accepted
    assert result.semantic_reason == "semantic conflict at b.value"
    assert result.typed is not None
    lowered = lower_program(result.typed)
    main_calls = [stmt for stmt in lowered.functions["main"].body if isinstance(stmt, CallStmt)]
    update = next(stmt for stmt in main_calls if stmt.function == "Box::set_other")
    assert update.actual_places[:2] == ("b", "b")


def test_by_value_parameter_is_fresh_place_not_caller_alias():
    src = r'''
module Box
  struct { value: u32 }
  fn touch_copy(self: Self) -> unit {
    loan write self as w {
      store(w@value, u32(9))
    }
  }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn main() -> unit {
  let b = Box::make(u32(1))
  b.touch_copy()
}
'''
    result = check_source(src, semantic_initial_deps=("b.value",))
    assert result.accepted
    assert result.typed is not None
    lowered = lower_program(result.typed)
    call = next(stmt for stmt in lowered.functions["main"].body if isinstance(stmt, CallStmt) and stmt.function == "Box::touch_copy")
    assert call.actual_places == (None,)
    exact = ExactSourceRunner(lowered).run("main", ("b.value",))
    assert exact.exact_accepts
    effects = [e for path in exact.paths for e in path.effects if e.kind == "Change"]
    assert effects
    assert all(e.place != "b.value" for e in effects)
    assert any(e.place.endswith(".value") and e.place.startswith("@frame") for e in effects)


def test_receiver_and_ordinary_calls_have_same_semantic_actual_substitution():
    prefix = r'''
module Box
  struct { value: u32 }
  fn set_value(self: ref<write, Self>, value: u32) -> unit {
    store(self@value, value)
  }
  fn make(value: u32) -> Self { Self { value: value } }
end
'''
    receiver = prefix + r'''
fn main() -> unit {
  let b = Box::make(u32(1))
  loan write b as w { w.set_value(u32(2)) }
}
'''
    ordinary = prefix + r'''
fn main() -> unit {
  let b = Box::make(u32(1))
  loan write b as w { set_value(w, u32(2)) }
}
'''
    rr = check_source(receiver, semantic_initial_deps=("b.value",))
    ro = check_source(ordinary, semantic_initial_deps=("b.value",))
    assert not rr.accepted and not ro.accepted
    assert rr.semantic_reason == ro.semantic_reason == "semantic conflict at b.value"
