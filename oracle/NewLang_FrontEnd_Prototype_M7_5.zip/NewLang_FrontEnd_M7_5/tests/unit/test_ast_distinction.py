from newlang_frontend import ast
from newlang_frontend.lexer import lex
from newlang_frontend.parser import parse
from newlang_frontend.source import SourceFile


def test_receiver_qualified_and_field_are_distinct_nodes():
    src = SourceFile("x.nl", r'''
module Box
  struct { value: u32 }
  fn f(self: Self) -> u32 { self@value }
  fn make(value: u32) -> Self { Self { value: value } }
end
fn main() -> u32 { Box::make(u32(1)).f() }
''')
    tree = parse(lex(src))
    module = tree.declarations[0]
    assert isinstance(module, ast.ModuleDecl)
    f = module.functions[0]
    assert isinstance(f.body.tail, ast.FieldProjectionExpr)
    main = tree.declarations[1]
    assert isinstance(main, ast.FunctionDecl)
    assert isinstance(main.body.tail, ast.ReceiverCallExpr)
    assert isinstance(main.body.tail.receiver, ast.QualifiedCallExpr)
