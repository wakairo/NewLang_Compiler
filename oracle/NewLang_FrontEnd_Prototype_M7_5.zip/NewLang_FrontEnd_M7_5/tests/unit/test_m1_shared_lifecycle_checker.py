import pytest

from newlang_checker.model import BackingRegion, ByteRange, SemanticError, SemanticState, SlotClaim, ValuePackage
from newlang_checker.semantics import (
    apply_step,
    create_lifetime_domain,
    finalize_lifetime_domain,
    require_ending_domain,
    resolve_live_ptr_root,
)


def _initialized_state() -> SemanticState:
    st = SemanticState()
    st.backings["R"] = BackingRegion("R", "B")
    st.slots["slot"] = SlotClaim("T", "R", ByteRange(0, 8))
    st.values["value"] = ValuePackage("v")
    create_lifetime_domain(st, "D")
    apply_step(st, {
        "op": "initialize",
        "slot": "slot",
        "value": "value",
        "domain": "D",
        "result_root": "root",
        "result_location_token": "ptr",
    })
    return st


def test_destroy_marks_all_ptrs_to_ended_incarnation_stale() -> None:
    st = _initialized_state()
    apply_step(st, {"op": "destroy", "root": "root", "ending_domain": "D", "result_slot": "empty"})
    assert st.ptrs["ptr"].stale
    with pytest.raises(SemanticError, match="ended object incarnation"):
        resolve_live_ptr_root(st, "ptr")


def test_ending_domain_must_match_root_domain() -> None:
    st = _initialized_state()
    create_lifetime_domain(st, "OTHER")
    with pytest.raises(SemanticError) as exc:
        require_ending_domain(st, "ptr", "OTHER")
    assert exc.value.kind == "lifetime_domain_mismatch"


def test_domain_cannot_finalize_while_it_governs_live_root() -> None:
    st = _initialized_state()
    with pytest.raises(SemanticError) as exc:
        finalize_lifetime_domain(st, "D")
    assert exc.value.kind == "domain_still_governs_live_root"


def test_domain_can_finalize_after_take() -> None:
    st = _initialized_state()
    apply_step(st, {
        "op": "take",
        "root": "root",
        "ending_domain": "D",
        "result_value": "out",
        "result_slot": "empty",
    })
    finalize_lifetime_domain(st, "D")
    assert "D" not in st.live_domains
