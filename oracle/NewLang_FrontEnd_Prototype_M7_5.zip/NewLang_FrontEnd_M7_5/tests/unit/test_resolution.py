from newlang_frontend.driver import check_source
from newlang_frontend.typed_ir import TCall, TLoan


def calls(result):
    assert result.typed is not None
    out = []
    def walk_expr(expr):
        if isinstance(expr, TCall):
            out.append(expr)
            for a in expr.args:
                walk_expr(a)
        elif isinstance(expr, TLoan):
            walk_expr(expr.source)
            walk_block(expr.body)
        else:
            for name in ("base",):
                child = getattr(expr, name, None)
                if child is not None:
                    walk_expr(child)
            for _, child in getattr(expr, "fields", ()): 
                walk_expr(child)
            for child in getattr(expr, "args", ()):
                walk_expr(child)
    def walk_block(block):
        for stmt in block.statements:
            value = getattr(stmt, "value", None) or getattr(stmt, "expr", None)
            if value is not None:
                walk_expr(value)
        if block.tail is not None:
            walk_expr(block.tail)
    for fn in result.typed.functions:
        walk_block(fn.body)
    return out


def test_receiver_and_ordinary_call_resolve_same_function_id():
    src = r'''
module Box
  struct { value: u32 }
  fn inspect(self: Self) -> unit { unit }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn main() -> unit {
  let b = Box::make(u32(1))
  inspect(b)
  b.inspect()
}
'''
    result = check_source(src)
    assert result.accepted
    selected = [c for c in calls(result) if c.function.name == "inspect"]
    assert len(selected) == 2
    assert selected[0].function.function_id == selected[1].function.function_id
    assert selected[0].receiver_syntax is False
    assert selected[1].receiver_syntax is True


def test_write_to_read_weakening_happens_after_selection():
    src = r'''
module Box
  struct { value: u32 }
  fn inspect(self: ref<read, Self>) -> unit { unit }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn main() -> unit {
  let b = Box::make(u32(1))
  loan write b as w {
    w.inspect()
  }
}
'''
    result = check_source(src)
    assert result.accepted
    selected = [c for c in calls(result) if c.function.name == "inspect"]
    assert len(selected) == 1
    assert selected[0].weakenings == (0,)


def test_lexical_selection_does_not_fall_back_after_type_mismatch():
    src = r'''
module Box
  struct { value: u32 }
  fn inspect(self: Self) -> unit { unit }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn inspect(self: u32) -> unit { unit }

fn main() -> unit {
  let b = Box::make(u32(1))
  b.inspect()
}
'''
    result = check_source(src)
    assert not result.accepted
    assert result.diagnostic is not None
    assert result.diagnostic.code == "E_ARGUMENT_TYPE"
