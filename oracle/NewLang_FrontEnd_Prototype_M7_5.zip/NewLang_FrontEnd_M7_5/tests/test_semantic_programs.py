from pathlib import Path

import pytest

from newlang_frontend.driver import check_source

ROOT = Path(__file__).parent / "programs"

CASES = [
    ("11_semantic_direct_ref_conflict.nl", False, "E_SEMANTIC_CONFLICT", "semantic conflict at b.value", 4),
    ("12_semantic_nested_wrapper_conflict.nl", False, "E_SEMANTIC_CONFLICT", "semantic conflict at b.value", 4),
    ("13_semantic_aliased_actuals_conflict.nl", False, "E_SEMANTIC_CONFLICT", "semantic conflict at b.value", 4),
    ("14_semantic_by_value_isolation.nl", True, None, "", None),
]


@pytest.mark.parametrize(("filename", "accepted", "code", "reason", "line"), CASES)
def test_semantic_actual_place_programs(
    filename: str,
    accepted: bool,
    code: str | None,
    reason: str,
    line: int | None,
) -> None:
    path = ROOT / filename
    result = check_source(
        path.read_text(encoding="utf-8"),
        str(path),
        semantic_initial_deps=("b.value",),
    )
    assert result.accepted is accepted
    if accepted:
        return
    assert result.diagnostic is not None
    assert result.diagnostic.code == code
    assert result.semantic_reason == reason
    assert result.diagnostic.span.start_line_col[0] == line
