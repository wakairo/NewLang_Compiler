from pathlib import Path

from newlang_checker.ir import Effect
from newlang_checker.source_ir import AddDepStmt, CallStmt, EffectStmt, FunctionDef
from newlang_frontend.driver import check_source
from newlang_frontend.lexer import lex
from newlang_frontend.lifecycle import run_lifecycle_detailed
from newlang_frontend.parser import parse
from newlang_frontend.production_lifecycle import run_production_lifecycle_detailed
from newlang_frontend.recursive_summary import infer_semantic_effect_summaries
from newlang_frontend.source import SourceFile
from newlang_frontend.symbols import SymbolBuilder
from newlang_frontend.typecheck import TypeChecker

ROOT = Path(__file__).parent / "programs"


def typed(name: str):
    path = ROOT / name
    source = SourceFile(str(path), path.read_text())
    symbols = SymbolBuilder(parse(lex(source))).build()
    return TypeChecker(symbols).check_program()


def test_ordinary_direct_recursion_closes_end_to_end() -> None:
    path = ROOT / "109_ordinary_direct_recursion_ok.nl"
    result = check_source(path.read_text(), str(path))
    assert result.accepted, result.diagnostic


def test_ordinary_mutual_recursion_closes_end_to_end() -> None:
    path = ROOT / "110_ordinary_mutual_recursion_ok.nl"
    result = check_source(path.read_text(), str(path))
    assert result.accepted, result.diagnostic


def test_generic_recursive_programs_now_close_beyond_monomorphization() -> None:
    for name in ("95_generic_direct_recursion_monomorph.nl", "96_generic_mutual_recursion_monomorph.nl"):
        path = ROOT / name
        result = check_source(path.read_text(), str(path))
        assert result.accepted, result.diagnostic


def test_recursive_may_effect_summary_preserves_caller_conflict() -> None:
    path = ROOT / "111_recursive_effect_summary_ok.nl"
    ok = check_source(path.read_text(), str(path))
    assert ok.accepted, ok.diagnostic
    conflict = check_source(path.read_text(), str(path), semantic_initial_deps=("box.value",))
    assert not conflict.accepted
    assert conflict.diagnostic is not None
    assert conflict.diagnostic.code == "E_SEMANTIC_CONFLICT"


def test_exact_and_production_lifecycle_accept_neutral_recursive_sccs() -> None:
    for name in (
        "95_generic_direct_recursion_monomorph.nl",
        "96_generic_mutual_recursion_monomorph.nl",
        "108_generic_effectful_recursion_ok.nl",
        "109_ordinary_direct_recursion_ok.nl",
        "110_ordinary_mutual_recursion_ok.nl",
        "111_recursive_effect_summary_ok.nl",
    ):
        program = typed(name)
        exact = run_lifecycle_detailed(program)
        production = run_production_lifecycle_detailed(program)
        assert exact.accepted, (name, exact)
        assert production.accepted, (name, production)
        assert not production.precision_loss, name


def test_resource_transforming_recursive_scc_stays_explicit_precision_boundary() -> None:
    program = typed("112_recursive_lifecycle_transform_error.nl")
    exact = run_lifecycle_detailed(program)
    production = run_production_lifecycle_detailed(program)
    assert not exact.accepted
    assert exact.code == "E_LIFETIME_RECURSIVE_SUMMARY"
    assert not production.accepted
    assert production.code == "E_LIFETIME_RECURSIVE_SUMMARY"


def test_identity_bearing_recursive_result_requires_richer_transformer() -> None:
    program = typed("113_recursive_identity_result_error.nl")
    exact = run_lifecycle_detailed(program)
    production = run_production_lifecycle_detailed(program)
    assert not exact.accepted
    assert exact.code == "E_LIFETIME_RECURSIVE_RESULT"
    assert not production.accepted
    assert production.code == "E_LIFETIME_RECURSIVE_RESULT"


def test_semantic_scc_fixpoint_unions_mutual_recursive_effects() -> None:
    functions = {
        "a": FunctionDef(
            "a",
            (
                EffectStmt(Effect("Change", "x.left")),
                CallStmt("b", ("x",)),
            ),
            ("x",),
        ),
        "b": FunctionDef(
            "b",
            (
                EffectStmt(Effect("Reset", "x.right")),
                CallStmt("a", ("x",)),
            ),
            ("x",),
        ),
    }
    summaries, stats = infer_semantic_effect_summaries(functions)
    expected = frozenset({Effect("Change", "x.left"), Effect("Reset", "x.right")})
    assert summaries["a"].effects == expected
    assert summaries["b"].effects == expected
    assert not summaries["a"].unknown
    assert not summaries["b"].unknown
    assert stats.recursive_scc_count == 1


def test_projection_growing_recursive_effect_summary_widens_instead_of_diverging() -> None:
    functions = {
        "grow": FunctionDef(
            "grow",
            (
                EffectStmt(Effect("Change", "x.value")),
                CallStmt("grow", ("x.next",)),
            ),
            ("x",),
        )
    }
    summaries, stats = infer_semantic_effect_summaries(functions, max_effects_per_function=4)
    assert summaries["grow"].unknown
    assert stats.widened_sccs == 1


def test_recursive_dependency_post_state_is_not_assumed_empty() -> None:
    functions = {
        "dep": FunctionDef(
            "dep",
            (
                AddDepStmt("x.value"),
                CallStmt("dep", ("x",)),
            ),
            ("x",),
        )
    }
    summaries, _ = infer_semantic_effect_summaries(functions)
    assert summaries["dep"].unknown


def test_source_recursive_occurrence_dependency_remains_precision_boundary() -> None:
    path = ROOT / "114_recursive_dependency_poststate_error.nl"
    result = check_source(path.read_text(), str(path))
    assert not result.accepted
    assert result.diagnostic is not None
    assert result.diagnostic.code == "E_SEMANTIC"
    assert "Unknown effect" in result.diagnostic.message
