from pathlib import Path

from newlang_checker.source_ir import BoundedSourceAnalyzer, ExactSourceRunner

from newlang_frontend.lexer import lex
from newlang_frontend.lower import lower_program
from newlang_frontend.parser import parse
from newlang_frontend.source import SourceFile
from newlang_frontend.symbols import SymbolBuilder
from newlang_frontend.typecheck import TypeChecker

ROOT = Path(__file__).parent / "programs"


def lowered(name: str):
    path = ROOT / name
    source = SourceFile(str(path), path.read_text())
    tree = parse(lex(source))
    symbols = SymbolBuilder(tree).build()
    typed = TypeChecker(symbols).check_program()
    return lower_program(typed)


def test_sum_occurrence_conflict_is_seen_by_exact_and_bounded_source_analysis() -> None:
    program = lowered("48_sum_occurrence_reset_error.nl")
    exact = ExactSourceRunner(program).run("main")
    bounded = BoundedSourceAnalyzer(program, alternative_budget=8).analyze("main")
    assert not exact.exact_accepts
    assert not bounded.result.accepted


def test_callback_capture_effect_is_visible_after_specialized_block_substitution() -> None:
    program = lowered("62_block_capture_effect.nl")
    deps = ("box.value",)
    exact = ExactSourceRunner(program).run("main", deps)
    bounded = BoundedSourceAnalyzer(program, alternative_budget=8).analyze("main", deps)
    assert not exact.exact_accepts
    assert not bounded.result.accepted


def test_structured_array_index_place_is_visible_after_function_substitution() -> None:
    program = lowered("69_array_index_effect.nl")
    exact = ExactSourceRunner(program).run("main", ("values.$index:0",))
    assert not exact.exact_accepts
    exact_other = ExactSourceRunner(program).run("main", ("values.$index:1",))
    bounded_other = BoundedSourceAnalyzer(program, alternative_budget=8).analyze("main", ("values.$index:1",))
    assert exact_other.exact_accepts
    assert bounded_other.result.accepted
