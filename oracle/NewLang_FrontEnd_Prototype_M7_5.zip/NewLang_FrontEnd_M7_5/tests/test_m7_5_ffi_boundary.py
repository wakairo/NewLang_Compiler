from __future__ import annotations

import random

import pytest

from newlang_frontend.ffi_boundary_pressure import (
    BackendProofs,
    Exposure,
    ExternalBackingRegistry,
    ForeignInitEvidence,
    ForeignSummary,
    can_start_foreign_initialized_root,
    checked_accept,
    llvm_lowering_attributes,
    oracle_accept,
)


def test_known_no_effect_call_preserves_value_dependency() -> None:
    exposure = Exposure(value_dependency=True)
    summary = ForeignSummary(
        semantic_effect="none", retention="no", callback="none", control="return", memory_access="readwrite"
    )
    assert checked_accept(exposure, summary)


def test_known_change_conflicts_with_current_value_dependency() -> None:
    exposure = Exposure(value_dependency=True)
    summary = ForeignSummary(semantic_effect="change", retention="no", callback="none", control="return")
    assert not checked_accept(exposure, summary)


def test_unknown_effect_rejects_when_value_dependency_is_live() -> None:
    exposure = Exposure(value_dependency=True)
    summary = ForeignSummary(retention="no", callback="none", control="return")
    assert not checked_accept(exposure, summary)


def test_endroot_rejects_when_root_must_remain_live() -> None:
    exposure = Exposure(root_must_remain_live=True)
    summary = ForeignSummary(semantic_effect="endroot", retention="no", callback="none", control="return")
    assert not checked_accept(exposure, summary)


def test_unknown_effect_is_irrelevant_when_no_safe_state_depends_on_exposed_place() -> None:
    exposure = Exposure()
    summary = ForeignSummary(semantic_effect="unknown", retention="no", callback="none", control="return")
    assert checked_accept(exposure, summary)


def test_unknown_retention_rejects_borrowed_location() -> None:
    exposure = Exposure(borrowed_location=True)
    summary = ForeignSummary(semantic_effect="none", retention="unknown", callback="none", control="return")
    assert not checked_accept(exposure, summary)


def test_proven_no_retain_allows_borrowed_location() -> None:
    exposure = Exposure(borrowed_location=True)
    summary = ForeignSummary(semantic_effect="none", retention="no", callback="none", control="return")
    assert checked_accept(exposure, summary)


def test_retained_callback_rejects_nonescaping_callable() -> None:
    exposure = Exposure(nonescaping_callback=True)
    summary = ForeignSummary(semantic_effect="none", retention="no", callback="retain", control="return")
    assert not checked_accept(exposure, summary)


def test_synchronous_callback_can_use_nonescaping_callable() -> None:
    exposure = Exposure(nonescaping_callback=True)
    summary = ForeignSummary(semantic_effect="none", retention="no", callback="sync", control="return")
    assert checked_accept(exposure, summary)


def test_unknown_callback_mode_rejects_nonescaping_callable() -> None:
    exposure = Exposure(nonescaping_callback=True)
    summary = ForeignSummary(semantic_effect="none", retention="no", callback="unknown", control="return")
    assert not checked_accept(exposure, summary)


def test_nonlocal_exit_is_outside_checked_v0_boundary() -> None:
    assert not checked_accept(
        Exposure(),
        ForeignSummary(semantic_effect="none", retention="no", callback="none", control="nonlocal"),
    )
    assert not checked_accept(
        Exposure(),
        ForeignSummary(semantic_effect="none", retention="no", callback="none", control="unknown"),
    )


def test_semantic_no_effect_does_not_imply_llvm_memory_none() -> None:
    summary = ForeignSummary(
        semantic_effect="none", retention="no", callback="none", control="return", memory_access="readwrite"
    )
    assert "memory(none)" not in llvm_lowering_attributes(summary, BackendProofs())


def test_llvm_memory_read_requires_independent_memory_fact() -> None:
    summary = ForeignSummary(memory_access="read")
    assert llvm_lowering_attributes(summary, BackendProofs()) == ("memory(read)",)


def test_capture_nounwind_nocallback_require_separate_backend_proofs() -> None:
    summary = ForeignSummary(memory_access="unknown")
    assert llvm_lowering_attributes(summary, BackendProofs()) == ()
    assert llvm_lowering_attributes(
        summary,
        BackendProofs(
            pointer_no_provenance_capture=True,
            no_exception_unwind=True,
            no_callback_into_module=True,
        ),
    ) == ("captures(none)", "nounwind", "nocallback")


def test_safe_external_backing_requires_all_boundary_proofs() -> None:
    r = ExternalBackingRegistry()
    with pytest.raises(ValueError, match="proof obligation"):
        r.import_safe(
            name="bad",
            abstract_backing="device0",
            start=0,
            size=64,
            liveness_proven=True,
            alignment_proven=True,
            access_proven=True,
            nonalias_proven=False,
        )


def test_distinct_safe_regions_may_not_overlap_same_abstract_backing() -> None:
    r = ExternalBackingRegistry()
    r.import_safe(
        name="a", abstract_backing="map0", start=0, size=64,
        liveness_proven=True, alignment_proven=True, access_proven=True, nonalias_proven=True,
    )
    with pytest.raises(ValueError, match="overlap"):
        r.import_safe(
            name="b", abstract_backing="map0", start=32, size=64,
            liveness_proven=True, alignment_proven=True, access_proven=True, nonalias_proven=True,
        )


def test_disjoint_safe_regions_on_same_external_backing_are_allowed() -> None:
    r = ExternalBackingRegistry()
    r.import_safe(
        name="a", abstract_backing="map0", start=0, size=64,
        liveness_proven=True, alignment_proven=True, access_proven=True, nonalias_proven=True,
    )
    r.import_safe(
        name="b", abstract_backing="map0", start=64, size=64,
        liveness_proven=True, alignment_proven=True, access_proven=True, nonalias_proven=True,
    )
    assert len(r.safe_regions) == 2


def test_opaque_views_can_overlap_without_claiming_safe_backing_identity() -> None:
    r = ExternalBackingRegistry()
    r.import_opaque(name="a", abstract_backing="device0", start=0, size=64)
    r.import_opaque(name="b", abstract_backing="device0", start=0, size=64)
    assert len(r.safe_regions) == 0
    assert len(r.opaque_views) == 2


def test_complete_trivial_foreign_value_can_start_root() -> None:
    assert can_start_foreign_initialized_root(
        ForeignInitEvidence(True, False, True, False)
    )


def test_resource_bearing_foreign_value_requires_complete_semantic_package() -> None:
    assert not can_start_foreign_initialized_root(
        ForeignInitEvidence(True, False, False, False)
    )
    assert can_start_foreign_initialized_root(
        ForeignInitEvidence(True, True, False, False)
    )


def test_partial_foreign_write_does_not_start_typed_lifetime() -> None:
    assert not can_start_foreign_initialized_root(
        ForeignInitEvidence(False, True, False, False)
    )


def test_retained_raw_location_blocks_safe_lifetime_start() -> None:
    assert not can_start_foreign_initialized_root(
        ForeignInitEvidence(True, True, False, True)
    )


def test_randomized_symbolic_checker_matches_exact_refinement_oracle() -> None:
    rng = random.Random(20261004)
    effects = ("none", "change", "endroot", "unknown")
    retentions = ("no", "yes", "unknown")
    callbacks = ("none", "sync", "retain", "unknown")
    controls = ("return", "nonlocal", "unknown")
    memory = ("none", "read", "readwrite", "unknown")

    for _ in range(100_000):
        exposure = Exposure(
            value_dependency=bool(rng.getrandbits(1)),
            root_must_remain_live=bool(rng.getrandbits(1)),
            borrowed_location=bool(rng.getrandbits(1)),
            nonescaping_callback=bool(rng.getrandbits(1)),
        )
        summary = ForeignSummary(
            semantic_effect=rng.choice(effects),
            retention=rng.choice(retentions),
            callback=rng.choice(callbacks),
            control=rng.choice(controls),
            memory_access=rng.choice(memory),
        )
        assert checked_accept(exposure, summary) == oracle_accept(exposure, summary)
