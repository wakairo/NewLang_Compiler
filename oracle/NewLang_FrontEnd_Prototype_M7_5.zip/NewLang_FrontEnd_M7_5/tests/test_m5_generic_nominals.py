from pathlib import Path

import pytest

from newlang_frontend.driver import check_source
from newlang_frontend.lexer import lex
from newlang_frontend.lifecycle import run_lifecycle_detailed
from newlang_frontend.parser import parse
from newlang_frontend.production_lifecycle import run_production_lifecycle_detailed
from newlang_frontend.source import SourceFile
from newlang_frontend.symbols import SymbolBuilder
from newlang_frontend.typecheck import TypeChecker
from newlang_frontend.typesys import BuiltinType, NominalType, SumType, display_type

ROOT = Path(__file__).parent / "programs"


def check(name: str):
    p = ROOT / name
    return check_source(p.read_text(), str(p))


def typed(name: str):
    p = ROOT / name
    src = SourceFile(str(p), p.read_text())
    symbols = SymbolBuilder(parse(lex(src))).build()
    checker = TypeChecker(symbols)
    return symbols, checker, checker.check_program()


@pytest.mark.parametrize(
    ("name", "accepted", "code"),
    [
        ("132_generic_nominal_basic_ok.nl", True, None),
        ("133_generic_nominal_two_instantiations_ok.nl", True, None),
        ("134_generic_nominal_arity_error.nl", False, "E_GENERIC_TYPE_ARITY"),
        ("135_generic_nominal_args_required_error.nl", False, "E_GENERIC_TYPE_ARGUMENTS_REQUIRED"),
        ("136_generic_sum_some_match_ok.nl", True, None),
        ("137_generic_sum_none_expected_ok.nl", True, None),
        ("138_generic_sum_none_unbound_error.nl", False, "E_GENERIC_SUM_INFERENCE"),
        ("139_generic_sum_nondiscardable_payload_ok.nl", True, None),
        ("140_generic_nominal_associated_lookup_ok.nl", True, None),
        ("141_generic_recursive_ptr_ok.nl", True, None),
        ("142_generic_recursive_value_error.nl", False, "E_RECURSIVE_VALUE_TYPE"),
        ("143_generic_container_nondiscardable_drain_ok.nl", True, None),
        ("144_generic_container_loop_find_ok.nl", True, None),
        ("145_generic_nominal_nondiscardable_store_error.nl", False, "E_STORE_NONDISCARDABLE"),
        ("146_generic_nominal_discardable_store_ok.nl", True, None),
        ("147_generic_sum_nondiscardable_store_error.nl", False, "E_STORE_NONDISCARDABLE"),
        ("148_generic_sum_discardable_store_ok.nl", True, None),
        ("149_generic_recursive_sum_ptr_ok.nl", True, None),
        ("150_generic_recursive_sum_value_error.nl", False, "E_RECURSIVE_VALUE_TYPE"),
        ("151_generic_nominal_generic_associated_target_ok.nl", True, None),
        ("152_generic_nominal_two_type_params_ok.nl", True, None),
        ("153_generic_recursive_through_sum_error.nl", False, "E_RECURSIVE_VALUE_TYPE"),
        ("154_generic_nominal_param_shadow_error.nl", False, "E_DUP_TYPE_PARAM"),
        ("155_generic_nominal_static_unbound_error.nl", False, "E_GENERIC_INFERENCE"),
    ],
)
def test_m5_programs(name: str, accepted: bool, code: str | None) -> None:
    result = check(name)
    assert result.accepted is accepted, result.diagnostic
    if code is not None:
        assert result.diagnostic is not None
        assert result.diagnostic.code == code


def test_generic_nominal_instances_share_owner_identity_but_keep_type_arguments() -> None:
    symbols, checker, program = typed("133_generic_nominal_two_instantiations_ok.nl")
    box = symbols.modules["Box"]
    instances = [f.symbol for f in program.functions if f.symbol.template_function_id == box.functions["make"].function_id]
    names = sorted(f.qualified_name for f in instances)
    assert names == ["Box::make<Key>", "Box::make<u32>"]
    assert all(f.owner_module_id == box.module_id for f in instances)
    assert len(checker.monomorph_cache) == 2


def test_generic_sum_constructor_uses_expected_type_for_payloadless_variant() -> None:
    symbols, _, program = typed("137_generic_sum_none_expected_ok.nl")
    maybe = symbols.sums["Maybe"]
    none_fn = next(f for f in program.functions if f.symbol.qualified_name == "none_u32")
    assert isinstance(none_fn.symbol.return_type, SumType)
    assert none_fn.symbol.return_type.type_id == maybe.type.type_id
    assert none_fn.symbol.return_type.args == (BuiltinType("u32"),)


def test_generic_associated_lookup_keeps_one_nominal_owner_and_instantiates_target() -> None:
    symbols, checker, program = typed("140_generic_nominal_associated_lookup_ok.nl")
    reqs = checker.generic_requirements[symbols.top_functions["generic_hash"].function_id]
    assert len(reqs) == 1 and reqs[0].name == "hash"
    names = sorted(f.symbol.qualified_name for f in program.functions if f.symbol.template_function_id is not None)
    assert "Box::hash<u32>" in names
    assert "generic_hash<Box<u32>>" in names


def test_nondiscardable_generic_container_runs_through_exact_and_production_lifecycle() -> None:
    _, _, program = typed("143_generic_container_nondiscardable_drain_ok.nl")
    exact = run_lifecycle_detailed(program)
    production = run_production_lifecycle_detailed(program)
    assert exact.accepted, exact
    assert production.accepted, production
    assert not production.precision_loss


def test_generic_container_loop_composes_nominal_instantiation_and_dependent_requirement() -> None:
    symbols, checker, program = typed("144_generic_container_loop_find_ok.nl")
    find = symbols.modules["Fixed2"].functions["find"]
    reqs = checker.generic_requirements[find.function_id]
    assert len(reqs) == 1 and reqs[0].name == "equal"
    assert any(f.symbol.qualified_name == "Fixed2::find<Key>" for f in program.functions)
    assert any(f.symbol.qualified_name == "Fixed2::make<Key>" for f in program.functions)


def test_generic_nominal_display_preserves_arguments() -> None:
    symbols, _, _ = typed("132_generic_nominal_basic_ok.nl")
    box = symbols.modules["Box"]
    concrete = NominalType(box.nominal.type_id, "Box", (BuiltinType("u32"),))
    assert display_type(concrete) == "Box<u32>"


def test_generic_nominal_associated_target_can_have_nominal_and_function_type_parameters() -> None:
    _, checker, program = typed("151_generic_nominal_generic_associated_target_ok.nl")
    names = sorted(f.symbol.qualified_name for f in program.functions if f.symbol.template_function_id is not None)
    assert "Box::echo<u32,u32>" in names
    assert "generic_echo<Box<u32>,u32>" in names
    assert len(checker.monomorph_cache) >= 3


def test_generic_nominal_multiple_type_parameters_infer_independently() -> None:
    _, _, program = typed("152_generic_nominal_two_type_params_ok.nl")
    names = [f.symbol.qualified_name for f in program.functions if f.symbol.template_function_id is not None]
    assert "Pair::make<u32,Key>" in names


def test_generic_container_loop_runs_through_both_lifecycle_bridges() -> None:
    _, _, program = typed("144_generic_container_loop_find_ok.nl")
    exact = run_lifecycle_detailed(program)
    production = run_production_lifecycle_detailed(program)
    assert exact.accepted, exact
    assert production.accepted, production
    assert not production.precision_loss
