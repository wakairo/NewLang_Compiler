from pathlib import Path

import pytest

from newlang_frontend.driver import check_source
from newlang_frontend.lexer import lex
from newlang_frontend.lifecycle import run_lifecycle_detailed
from newlang_frontend.parser import parse
from newlang_frontend.production_lifecycle import run_production_lifecycle_detailed
from newlang_frontend.source import SourceFile
from newlang_frontend.symbols import SymbolBuilder
from newlang_frontend.typecheck import TypeChecker
from newlang_frontend.typesys import NominalType

ROOT = Path(__file__).parent / "programs"


def check(name: str):
    p = ROOT / name
    return check_source(p.read_text(), str(p))


def typed(name: str):
    p = ROOT / name
    src = SourceFile(str(p), p.read_text())
    syms = SymbolBuilder(parse(lex(src))).build()
    return TypeChecker(syms).check_program()


@pytest.mark.parametrize(("name", "ok", "code"), [
    ("202_layout_opaque_nominal_ok.nl", True, None),
    ("203_layout_allocate_generic_ok.nl", True, None),
    ("204_layout_expected_type_required_error.nl", False, "E_LAYOUT_RESULT_REQUIRED"),
    ("205_layout_zst_policy_error.nl", True, None),
    ("206_layout_allocate_zero_error.nl", False, "E_ALLOCATION_LAYOUT"),
    ("207_layout_sum_ok.nl", True, None),
    ("208_layout_nondiscardable_ok.nl", True, None),
    ("213_layout_generic_monomorph_ok.nl", True, None),
])
def test_m63_layout_programs(name, ok, code):
    result = check(name)
    assert result.accepted is ok, result.diagnostic
    if code:
        assert result.diagnostic and result.diagnostic.code == code


def test_opaque_nominal_layout_witness_contains_only_target_extent_alignment_stride():
    program = typed("202_layout_opaque_nominal_ok.nl")
    box_layouts = [x for x in program.layouts if isinstance(x.type, NominalType) and x.type.name == "Box"]
    assert len(box_layouts) == 1
    info = box_layouts[0]
    assert (info.size, info.align, info.stride) == (4, 4, 4)
    # There is intentionally no field-offset map in the witness IR.
    assert not hasattr(info, "fields")
    assert not hasattr(info, "offsets")


def test_layout_opaque_nominal_runs_through_both_lifecycle_bridges():
    program = typed("202_layout_opaque_nominal_ok.nl")
    exact = run_lifecycle_detailed(program)
    production = run_production_lifecycle_detailed(program)
    assert exact.accepted, exact
    assert production.accepted, production
    assert not production.precision_loss


def test_generic_layout_allocation_runs_through_both_lifecycle_bridges():
    program = typed("203_layout_allocate_generic_ok.nl")
    exact = run_lifecycle_detailed(program)
    production = run_production_lifecycle_detailed(program)
    assert exact.accepted, exact
    assert production.accepted, production
    assert not production.precision_loss


def test_layout_witness_from_generic_body_is_not_loan_dependent():
    program = typed("213_layout_generic_monomorph_ok.nl")
    infos = [x for x in program.layouts if isinstance(x.type, NominalType) and x.type.name == "Padded"]
    assert len(infos) == 1
    assert (infos[0].size, infos[0].align, infos[0].stride) == (16, 8, 16)
    exact = run_lifecycle_detailed(program)
    production = run_production_lifecycle_detailed(program)
    assert exact.accepted, exact
    assert production.accepted, production
    assert not production.precision_loss
