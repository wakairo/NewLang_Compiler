from pathlib import Path

import pytest

from newlang_frontend.driver import check_source

ROOT = Path(__file__).parent / "programs"


@pytest.mark.parametrize(
    ("name", "accepted", "code"),
    [
        ("46_sum_match_value_ok.nl", True, None),
        ("47_sum_match_ref_ok.nl", True, None),
        ("48_sum_occurrence_reset_error.nl", False, "E_SEMANTIC_CONFLICT"),
        ("49_sum_nonexhaustive_error.nl", False, "E_NONEXHAUSTIVE_MATCH"),
        ("50_sum_payload_ref_escape_error.nl", False, "E_OCCURRENCE_ESCAPE"),
        ("51_span_index_len_ok.nl", True, None),
        ("52_span_write_to_read_weakening_ok.nl", True, None),
        ("53_array_value_index_error.nl", False, "E_ARRAY_VALUE_INDEX"),
        ("54_subspan_bounds_error.nl", False, "E_BOUNDS"),
        ("55_consume_array_copy_preserves_binding_ok.nl", True, None),
        ("56_consume_array_nondiscardable_ok.nl", True, None),
        ("57_consume_array_nondiscardable_reuse_error.nl", False, "E_USE_AFTER_CONSUME"),
        ("58_consume_array_zero_ok.nl", True, None),
        ("59_callback_capture_noncopy_error.nl", False, "E_CALLBACK_CAPTURE_CONSUME"),
        ("60_span_index_out_of_bounds_error.nl", False, "E_BOUNDS"),
    ],
)
def test_m2_programs(name: str, accepted: bool, code: str | None) -> None:
    path = ROOT / name
    result = check_source(path.read_text(), str(path))
    assert result.accepted is accepted, result.diagnostic
    if code is not None:
        assert result.diagnostic is not None
        assert result.diagnostic.code == code
