from pathlib import Path

import pytest

from newlang_frontend.authority_region_pressure import RegionReject, ResponsibilityOracle, SealedRegion
from newlang_frontend.driver import check_source
from newlang_frontend.region_surface_pressure import (
    ClosureSurface,
    PrivilegedHookSurface,
    ReceiptSurface,
    assess_surfaces,
    run_surface_experiment,
)

ROOT = Path(__file__).parent / "programs"


def check(name: str):
    p = ROOT / name
    return check_source(p.read_text(), str(p))


def token(oracle: ResponsibilityOracle, name: str) -> None:
    oracle.create_external(name)


def region(oracle: ResponsibilityOracle, name: str = "surface") -> SealedRegion:
    r = SealedRegion(1, elem_size=8, elem_align=8, oracle=oracle, name=name)
    r.register_type("Token", size=8, align=8)
    return r


def test_receipt_surface_rejects_token_reuse_and_conserves_authority():
    oracle = ResponsibilityOracle(); token(oracle, "x")
    r = region(oracle)
    api = ReceiptSurface(r)
    vacant = api.vacant(0, "Token")
    api.initialize(vacant, "x")
    with pytest.raises(RegionReject) as exc:
        api.return_vacant(vacant)
    assert exc.value.code == "E_M63_CLAIM_TOKEN_CONSUMED"
    live = api.live(0)
    value, vacant2 = api.take(live)
    assert value == "x"
    api.return_vacant(vacant2)
    assert oracle.owner("x") == "external"
    r.unseal()


def test_closure_surface_is_sugar_over_receipt_and_closes_unused_scope():
    oracle = ResponsibilityOracle(); token(oracle, "x")
    r = region(oracle)
    api = ClosureSurface(r)
    api.with_vacant(0, "Token", lambda claim: None)
    assert r.responsibility(0).kind == "vacant"
    assert not r.open_claims
    api.with_vacant(0, "Token", lambda claim: claim.initialize("x"))
    got = api.with_live(0, lambda claim: claim.take())
    assert got == "x"
    assert oracle.owner("x") == "external"
    r.unseal()


def test_privileged_hook_is_safe_but_trusted_surface_grows_per_operation():
    oracle = ResponsibilityOracle(); token(oracle, "x")
    r = region(oracle)
    hook = PrivilegedHookSurface(r)
    hook.install(0, "Token", "x")
    assert hook.remove(0) == "x"
    assert hook.trusted_operations == 2
    assert oracle.owner("x") == "external"
    r.unseal()


def test_surface_assessment_prefers_receipt_as_base_and_closure_as_sugar():
    items = {x.candidate: x for x in assess_surfaces()}
    assert items["receipt"].verdict.startswith("best semantic base")
    assert not items["closure"].needs_new_callable_semantics
    assert items["hook"].trusted_operation_growth == "per-operation"


def test_surface_experiment_closes_all_authority():
    result = run_surface_experiment()
    assert result["receipt"]["double_use_rejected"]
    assert result["closure"]["new_exactly_once_callable_kind_required"] is False
    assert result["hook"]["authority_conserved"]


@pytest.mark.parametrize(("name", "ok", "code"), [
    ("209_claim_token_block_thread_ok.nl", True, None),
    ("210_claim_token_block_double_use_error.nl", False, "E_USE_AFTER_CONSUME"),
    ("211_claim_token_block_zero_invoke_ok.nl", True, None),
    ("212_claim_token_block_drop_error.nl", False, "E_SLOT_NOT_CONSUMED"),
])
def test_existing_nonescaping_block_can_thread_linear_claim_tokens(name, ok, code):
    result = check(name)
    assert result.accepted is ok, result.diagnostic
    if code:
        assert result.diagnostic and result.diagnostic.code == code
