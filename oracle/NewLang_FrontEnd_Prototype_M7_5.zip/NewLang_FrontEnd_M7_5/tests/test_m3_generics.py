from pathlib import Path

import pytest

from newlang_frontend.driver import check_source
from newlang_frontend.lexer import lex
from newlang_frontend.parser import parse
from newlang_frontend.source import SourceFile
from newlang_frontend.symbols import SymbolBuilder
from newlang_frontend.typecheck import TypeChecker
from newlang_frontend.typesys import RefType, TypeParamType, U32

ROOT = Path(__file__).parent / "programs"


@pytest.mark.parametrize(
    ("name", "accepted", "code"),
    [
        ("75_generic_dependent_hash_ok.nl", True, None),
        ("76_generic_receiver_hash_ok.nl", True, None),
        ("77_generic_missing_requirement_error.nl", False, "E_GENERIC_REQUIREMENT_UNSATISFIED"),
        ("78_dependent_result_required_error.nl", False, "E_DEPENDENT_RESULT_REQUIRED"),
        ("79_dependent_annotated_let_ok.nl", True, None),
        ("80_generic_identity_ok.nl", True, None),
        ("81_generic_memoization_ok.nl", True, None),
        ("82_generic_lexical_priority_error.nl", False, "E_ARGUMENT_TYPE"),
        ("83_generic_field_duck_error.nl", False, "E_FIELD_BASE"),
        ("84_generic_result_mismatch_error.nl", False, "E_GENERIC_REQUIREMENT_RESULT"),
        ("85_generic_store_property_error.nl", False, "E_STORE_NONDISCARDABLE"),
        ("86_generic_write_to_read_inference_ok.nl", True, None),
        ("87_generic_two_instantiations_ok.nl", True, None),
    ],
)
def test_m3_programs(name: str, accepted: bool, code: str | None) -> None:
    p = ROOT / name
    result = check_source(p.read_text(), str(p))
    assert result.accepted is accepted, result.diagnostic
    if code is not None:
        assert result.diagnostic is not None
        assert result.diagnostic.code == code


def typed(name: str):
    p = ROOT / name
    source = SourceFile(str(p), p.read_text())
    symbols = SymbolBuilder(parse(lex(source))).build()
    checker = TypeChecker(symbols)
    program = checker.check_program()
    return symbols, checker, program


def test_dependent_requirement_is_visible_on_generic_contract() -> None:
    symbols, checker, program = typed("75_generic_dependent_hash_ok.nl")
    fn = symbols.top_functions["generic_hash"]
    reqs = checker.generic_requirements[fn.function_id]
    assert len(reqs) == 1
    req = reqs[0]
    assert req.name == "hash"
    assert req.result_type == U32
    assert isinstance(req.argument_types[0], RefType)
    assert isinstance(req.argument_types[0].inner, TypeParamType)
    assert program.generic_requirements[0][0] == "generic_hash"


def test_same_concrete_instantiation_is_memoized() -> None:
    _, checker, program = typed("81_generic_memoization_ok.nl")
    instances = [f for f in program.functions if f.symbol.template_function_id is not None]
    assert len(instances) == 1
    assert instances[0].symbol.qualified_name == "identity<u32>"
    assert len(checker.monomorph_cache) == 1


def test_distinct_type_arguments_make_distinct_monomorphs() -> None:
    _, checker, program = typed("87_generic_two_instantiations_ok.nl")
    instances = [f.symbol.qualified_name for f in program.functions if f.symbol.template_function_id is not None]
    assert sorted(instances) == ["identity<Key>", "identity<u32>"]
    assert len(checker.monomorph_cache) == 2


def test_monomorphized_dependent_associated_call_preserves_semantic_effects() -> None:
    p = ROOT / "88_generic_associated_effect.nl"
    ok = check_source(p.read_text(), str(p))
    assert ok.accepted, ok.diagnostic
    conflict = check_source(p.read_text(), str(p), semantic_initial_deps=("box.value",))
    assert not conflict.accepted
    assert conflict.diagnostic is not None
    assert conflict.diagnostic.code == "E_SEMANTIC_CONFLICT"


def test_generic_to_generic_symbolic_definition_then_concrete_instantiation() -> None:
    p = ROOT / "89_generic_to_generic_ok.nl"
    result = check_source(p.read_text(), str(p))
    assert result.accepted, result.diagnostic
    _, checker, program = typed("89_generic_to_generic_ok.nl")
    names = sorted(f.symbol.qualified_name for f in program.functions if f.symbol.template_function_id is not None)
    assert names == ["identity<u32>", "wrapper<u32>"]
    assert len(checker.monomorph_cache) == 2


def test_generic_known_array_operations_are_definition_time_checked() -> None:
    p = ROOT / "90_generic_known_array_ops_ok.nl"
    result = check_source(p.read_text(), str(p))
    assert result.accepted, result.diagnostic


def test_repeated_type_parameter_requires_one_consistent_type() -> None:
    p = ROOT / "91_generic_repeated_parameter_mismatch_error.nl"
    result = check_source(p.read_text(), str(p))
    assert not result.accepted
    assert result.diagnostic is not None
    assert result.diagnostic.code == "E_GENERIC_INFERENCE"


def test_multiple_type_parameters_infer_independently() -> None:
    p = ROOT / "92_generic_two_params_ok.nl"
    result = check_source(p.read_text(), str(p))
    assert result.accepted, result.diagnostic
    _, checker, program = typed("92_generic_two_params_ok.nl")
    names = [f.symbol.qualified_name for f in program.functions if f.symbol.template_function_id is not None]
    assert names == ["first<u32,Key>"]


def test_generic_lifecycle_wrapper_runs_through_exact_and_production_bridges() -> None:
    from newlang_frontend.production_lifecycle import run_production_lifecycle_detailed

    p = ROOT / "93_generic_take_lifecycle_ok.nl"
    result = check_source(p.read_text(), str(p))
    assert result.accepted, result.diagnostic
    _, _, program = typed("93_generic_take_lifecycle_ok.nl")
    production = run_production_lifecycle_detailed(program)
    assert production.accepted, production
    assert not production.precision_loss


def test_dependent_lookup_can_resolve_to_generic_associated_target() -> None:
    p = ROOT / "94_dependent_generic_associated_target_ok.nl"
    result = check_source(p.read_text(), str(p))
    assert result.accepted, result.diagnostic
    _, checker, program = typed("94_dependent_generic_associated_target_ok.nl")
    names = sorted(f.symbol.qualified_name for f in program.functions if f.symbol.template_function_id is not None)
    assert names == ["Box::echo<u32>", "generic_echo<Box,u32>"]
    assert len(checker.monomorph_cache) == 2
