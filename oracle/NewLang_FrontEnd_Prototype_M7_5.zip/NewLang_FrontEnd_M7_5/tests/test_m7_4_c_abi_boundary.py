from __future__ import annotations

from newlang_frontend.c_abi_boundary import (
    baseline_c_abi_matrix,
    llvm_c_abi_attribute_contract,
    plan_c_abi_boundary,
)
from newlang_frontend.c_abi_pressure import run_pressure


def test_native_aggregate_never_becomes_c_by_value_by_layout_accident() -> None:
    plan = plan_c_abi_boundary("native_aggregate", direction="parameter")
    assert plan.direct_c_abi_eligible is False
    assert plan.requires_explicit_c_representation is True
    assert plan.requires_field_marshalling is True
    assert plan.native_layout_exposed is False


def test_explicit_c_record_abi_classification_belongs_to_backend_or_shim() -> None:
    shim = plan_c_abi_boundary("explicit_c_record", direction="parameter")
    direct = plan_c_abi_boundary(
        "explicit_c_record", direction="parameter", target_abi_profile_known=True
    )
    assert shim.lowering_owner == "generated-c-shim"
    assert direct.lowering_owner == "target-abi-classifier"
    assert direct.direct_c_abi_eligible is True


def test_sret_and_byval_are_not_source_semantic_properties() -> None:
    attrs = llvm_c_abi_attribute_contract()
    assert "target ABI lowering result" in str(attrs["sret"])
    assert "target ABI lowering result" in str(attrs["byval"])
    assert attrs["native_bitcopy_to_c_record"] is False


def test_resource_state_cannot_be_encoded_by_foreign_aggregate_bytes() -> None:
    plan = plan_c_abi_boundary("semantic_resource", direction="parameter")
    assert plan.lowering_owner == "forbidden"
    assert plan.direct_c_abi_eligible is False


def test_by_value_aggregate_varargs_stay_behind_shim_in_v0() -> None:
    plan = plan_c_abi_boundary(
        "explicit_c_record", direction="parameter", variadic_position=True
    )
    assert plan.lowering_owner == "generated-c-shim"
    assert plan.direct_c_abi_eligible is False


def test_randomized_native_vs_c_layout_requires_semantic_marshalling() -> None:
    result = run_pressure(cases=2_000)
    assert result["roundtrip_mismatch"] == 0
    assert result["direct_native_bitcopy_not_equivalent"] > 0


def test_baseline_matrix_does_not_expose_native_layout() -> None:
    matrix = baseline_c_abi_matrix()
    assert matrix["native_aggregate_parameter"]["native_layout_exposed"] is False
    assert matrix["native_aggregate_return"]["direct_c_abi_eligible"] is False
