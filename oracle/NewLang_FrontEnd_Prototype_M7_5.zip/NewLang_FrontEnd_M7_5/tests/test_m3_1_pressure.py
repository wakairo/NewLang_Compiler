from pathlib import Path

import pytest

from newlang_frontend.diagnostics import FrontendError
from newlang_frontend.driver import check_source
from newlang_frontend.lexer import lex
from newlang_frontend.parser import parse
from newlang_frontend.source import SourceFile
from newlang_frontend.symbols import SymbolBuilder
from newlang_frontend.typecheck import TypeChecker
from newlang_frontend.typesys import RefType, TypeParamType, U32

ROOT = Path(__file__).parent / "programs"


def typed(name: str, **checker_options):
    path = ROOT / name
    source = SourceFile(str(path), path.read_text())
    symbols = SymbolBuilder(parse(lex(source))).build()
    checker = TypeChecker(symbols, **checker_options)
    program = checker.check_program()
    return symbols, checker, program


def semantic_requirement_shape(req):
    return req.name, req.argument_types, req.result_type


def test_exact_recursive_generic_key_reuses_provisional_monomorph() -> None:
    _, checker, program = typed("95_generic_direct_recursion_monomorph.nl")
    names = [f.symbol.qualified_name for f in program.functions if f.symbol.template_function_id is not None]
    assert names == ["loop<u32>"]
    assert checker.monomorph_cycle_hits == 1
    assert len(checker.monomorph_cache) == 1


def test_mutually_recursive_generic_keys_close_without_expansion() -> None:
    _, checker, program = typed("96_generic_mutual_recursion_monomorph.nl")
    names = sorted(f.symbol.qualified_name for f in program.functions if f.symbol.template_function_id is not None)
    assert names == ["a<u32>", "b<u32>"]
    assert checker.monomorph_cycle_hits == 1
    assert len(checker.monomorph_cache) == 2


def test_type_growing_recursion_hits_graceful_depth_budget() -> None:
    path = ROOT / "97_generic_growth_depth_error.nl"
    result = check_source(path.read_text(), str(path))
    assert not result.accepted
    assert result.diagnostic is not None
    assert result.diagnostic.code == "E_GENERIC_MONOMORPH_DEPTH"


def test_total_monomorph_budget_is_independent_of_depth_budget() -> None:
    with pytest.raises(FrontendError) as caught:
        typed(
            "103_generic_total_budget_source.nl",
            max_monomorph_depth=32,
            max_monomorphs=2,
        )
    assert caught.value.diagnostic.code == "E_GENERIC_MONOMORPH_BUDGET"


def test_wrapper_requirements_propagate_transitively() -> None:
    symbols, checker, _ = typed("98_generic_wrapper_requirement_ok.nl")
    for name in ("need_hash", "wrapper", "outer"):
        fn = symbols.top_functions[name]
        reqs = checker.generic_requirements[fn.function_id]
        assert len(reqs) == 1
        req = reqs[0]
        assert req.name == "hash"
        assert req.result_type == U32
        assert isinstance(req.argument_types[0], RefType)
        assert isinstance(req.argument_types[0].inner, TypeParamType)
        assert req.argument_types[0].inner.function_id == fn.function_id


def test_requirement_scc_reaches_fixpoint_without_growth() -> None:
    symbols, checker, _ = typed("99_generic_requirement_scc_ok.nl")
    a = checker.generic_requirements[symbols.top_functions["a"].function_id]
    b = checker.generic_requirements[symbols.top_functions["b"].function_id]
    assert len(a) == len(b) == 1
    assert a[0].name == b[0].name == "hash"


def test_same_semantic_requirement_is_deduplicated_across_source_spans() -> None:
    symbols, checker, _ = typed("100_generic_requirement_dedup_ok.nl")
    reqs = checker.generic_requirements[symbols.top_functions["twice"].function_id]
    assert len(reqs) == 1
    assert reqs[0].name == "hash"


def test_requirement_budget_fails_gracefully() -> None:
    with pytest.raises(FrontendError) as caught:
        typed("104_generic_requirement_budget_source.nl", max_requirements_per_generic=1)
    assert caught.value.diagnostic.code == "E_GENERIC_REQUIREMENT_BUDGET"


def test_current_strict_coherence_rejects_same_name_associated_definitions() -> None:
    path = ROOT / "101_associated_duplicate_coherence_error.nl"
    result = check_source(path.read_text(), str(path))
    assert not result.accepted
    assert result.diagnostic is not None
    assert result.diagnostic.code == "E_DUP_FUNCTION"


def test_wrapper_monomorphization_does_not_launder_semantic_effects() -> None:
    path = ROOT / "102_generic_wrapper_effect.nl"
    ok = check_source(path.read_text(), str(path))
    assert ok.accepted, ok.diagnostic
    conflict = check_source(path.read_text(), str(path), semantic_initial_deps=("box.value",))
    assert not conflict.accepted
    assert conflict.diagnostic is not None
    assert conflict.diagnostic.code == "E_SEMANTIC_CONFLICT"


def test_recursive_generic_typecheck_pressure_remains_closed_after_recursive_summary_work() -> None:
    # M3.2 closes the semantic/lifecycle recursion boundary that M3.1 deliberately
    # left visible. Keep the original monomorph pressure program as a regression.
    path = ROOT / "95_generic_direct_recursion_monomorph.nl"
    result = check_source(path.read_text(), str(path))
    assert result.accepted, result.diagnostic


def test_type_transforming_requirement_cycle_hits_graph_budget() -> None:
    with pytest.raises(FrontendError) as caught:
        typed(
            "105_generic_requirement_growth_source.nl",
            max_requirements_per_generic=4,
        )
    assert caught.value.diagnostic.code == "E_GENERIC_REQUIREMENT_BUDGET"


def test_same_associated_name_in_distinct_nominal_owners_does_not_overlap() -> None:
    path = ROOT / "106_associated_same_name_distinct_owners_ok.nl"
    result = check_source(path.read_text(), str(path))
    assert result.accepted, result.diagnostic
    _, checker, program = typed("106_associated_same_name_distinct_owners_ok.nl")
    names = sorted(
        f.symbol.qualified_name
        for f in program.functions
        if f.symbol.template_function_id is not None
    )
    assert names == ["generic_hash<KeyA>", "generic_hash<KeyB>"]
    assert len(checker.monomorph_cache) == 2


def test_larger_requirement_chain_propagates_normalized_contract() -> None:
    symbols, checker, _ = typed("107_generic_requirement_chain_pressure_ok.nl")
    for name in ("need_ops", "wrap1", "wrap2", "wrap3", "wrap4", "wrap5", "wrap6", "wrap7", "wrap8"):
        reqs = checker.generic_requirements[symbols.top_functions[name].function_id]
        assert [r.name for r in reqs] == ["op_a", "op_b", "op_c"]


def test_effectful_recursive_generic_uses_summary_without_laundering_effect() -> None:
    path = ROOT / "108_generic_effectful_recursion_ok.nl"
    result = check_source(path.read_text(), str(path))
    assert result.accepted, result.diagnostic
    conflict = check_source(path.read_text(), str(path), semantic_initial_deps=("box.value",))
    assert not conflict.accepted
    assert conflict.diagnostic is not None
    assert conflict.diagnostic.code == "E_SEMANTIC_CONFLICT"
