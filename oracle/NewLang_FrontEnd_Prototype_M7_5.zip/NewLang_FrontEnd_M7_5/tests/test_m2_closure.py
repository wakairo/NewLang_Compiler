from pathlib import Path

import pytest

from newlang_frontend.driver import check_source

ROOT = Path(__file__).parent / "programs"


@pytest.mark.parametrize(
    ("name", "accepted", "code"),
    [
        ("63_sum_nondiscardable_payload_ok.nl", True, None),
        ("64_sum_nondiscardable_discard_error.nl", False, "E_NONDDiscardable_PATTERN"),
        ("65_consume_array_zero_capture_error.nl", False, "E_CALLBACK_CAPTURE_CONSUME"),
        ("66_callback_param_not_consumed_error.nl", False, "E_BLOCK_PARAM_NOT_CONSUMED"),
        ("67_block_return_type_error.nl", False, "E_BLOCK_ESCAPE_TYPE"),
        ("68_store_nondiscardable_sum_error.nl", False, "E_STORE_NONDISCARDABLE"),
        ("70_sum_payload_not_consumed_error.nl", False, "E_MATCH_PAYLOAD_NOT_CONSUMED"),
    ],
)
def test_m2_closure_programs(name: str, accepted: bool, code: str | None) -> None:
    path = ROOT / name
    result = check_source(path.read_text(), str(path))
    assert result.accepted is accepted, result.diagnostic
    if code is not None:
        assert result.diagnostic is not None
        assert result.diagnostic.code == code


def test_structured_array_element_place_conflicts_through_wrapper() -> None:
    path = ROOT / "69_array_index_effect.nl"
    result = check_source(
        path.read_text(),
        str(path),
        semantic_initial_deps=("values.$index:0",),
    )
    assert not result.accepted
    assert result.diagnostic is not None
    assert result.diagnostic.code == "E_SEMANTIC_CONFLICT"
    assert "values.$index:0" in result.diagnostic.message


def test_structured_array_element_place_keeps_other_index_distinct() -> None:
    path = ROOT / "69_array_index_effect.nl"
    result = check_source(
        path.read_text(),
        str(path),
        semantic_initial_deps=("values.$index:1",),
    )
    assert result.accepted, result.diagnostic
