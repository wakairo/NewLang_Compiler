from __future__ import annotations

from pathlib import Path

from newlang_frontend.backend_contract import (
    alias_metadata_contract,
    baseline_contract_matrix,
    lifetime_intrinsic_contract,
    ref_contract,
)
from newlang_frontend.driver import check_source

ROOT = Path(__file__).parent / "programs"


def test_write_refs_may_alias_so_type_does_not_imply_noalias() -> None:
    p = ROOT / "13_semantic_aliased_actuals_conflict.nl"
    result = check_source(p.read_text(encoding="utf-8"), str(p))
    assert result.accepted, result.diagnostic
    contract = ref_contract("write")
    assert contract.noalias is False
    assert contract.writeonly is False


def test_read_ref_may_lower_readonly_but_not_noalias() -> None:
    contract = ref_contract("read")
    assert contract.readonly is True
    assert contract.noalias is False
    assert contract.writeonly is False


def test_source_exclusive_spelling_is_not_enough_for_llvm_noalias() -> None:
    assert ref_contract("read", exclusive_spelling=True).noalias is False
    assert ref_contract("write", exclusive_spelling=True).noalias is False
    assert ref_contract("write", exclusive_spelling=True, proven_access_exclusive=True).noalias is True


def test_nonescaping_ref_does_not_imply_nocapture_of_pointer_provenance() -> None:
    p = ROOT / "241_ref_locator_capture_ok.nl"
    result = check_source(p.read_text(encoding="utf-8"), str(p))
    assert result.accepted, result.diagnostic
    assert ref_contract("read").captures == "unknown"
    assert ref_contract("read", capture="provenance").captures == "provenance"


def test_dereferenceable_requires_target_policy_in_baseline_contract() -> None:
    assert ref_contract("read", positive_extent=8).dereferenceable_bytes is None
    assert ref_contract("read", positive_extent=8, target_null_address_policy_known=True).dereferenceable_bytes == 8


def test_newlang_typed_heap_lifetime_does_not_map_to_llvm_lifetime_intrinsics() -> None:
    assert lifetime_intrinsic_contract("heap_or_external", exact_storage_lifetime=True)["emit_llvm_lifetime"] is False
    assert lifetime_intrinsic_contract("subobject_or_slot", exact_storage_lifetime=True)["emit_llvm_lifetime"] is False
    assert lifetime_intrinsic_contract("stack_alloca", exact_storage_lifetime=True)["emit_llvm_lifetime"] is True


def test_alias_scope_metadata_also_requires_separate_disjoint_access_proof() -> None:
    assert alias_metadata_contract(proven_disjoint_access_sets=False)["emit_alias_scope_or_noalias_metadata"] is False
    assert alias_metadata_contract(proven_disjoint_access_sets=True)["emit_alias_scope_or_noalias_metadata"] is True


def test_baseline_matrix_keeps_all_ordinary_refs_non_noalias() -> None:
    matrix = baseline_contract_matrix()
    assert matrix["ref_read"]["noalias"] is False
    assert matrix["ref_write"]["noalias"] is False
    assert matrix["exclusive_ref_read_without_access_proof"]["noalias"] is False
    assert matrix["backend_proven_exclusive_write"]["noalias"] is True
