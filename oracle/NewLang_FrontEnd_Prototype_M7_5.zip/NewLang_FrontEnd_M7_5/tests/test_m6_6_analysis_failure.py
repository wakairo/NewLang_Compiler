from __future__ import annotations

from newlang_checker.ir import Effect
from newlang_checker.source_ir import AddDepStmt, CallStmt, ExactSourceRunner, FunctionDef, SourceProgram
from newlang_frontend.analysis_failure_pressure import run_analysis_pressure, run_failure_pressure
from newlang_frontend.recursive_summary import infer_semantic_effect_summaries


def test_recursive_unknown_keeps_finite_reason_provenance() -> None:
    functions = {
        "dep": FunctionDef(
            "dep",
            (
                AddDepStmt("x.value", origin="dep-site"),
                CallStmt("dep", ("x",), origin="call-site"),
            ),
            ("x",),
        )
    }
    summaries, stats = infer_semantic_effect_summaries(functions)
    summary = summaries["dep"]
    assert summary.unknown
    assert "dependency-post-state" in summary.unknown_reasons
    assert "recursive-scc:dep" in summary.unknown_reasons
    assert stats.recursive_scc_count == 1


def test_recursive_unknown_diagnostic_points_to_call_and_explains_cause() -> None:
    functions = {
        "dep": FunctionDef(
            "dep",
            (
                AddDepStmt("x.value", origin="dep-site"),
                CallStmt("dep", ("x",), origin="call-site"),
            ),
            ("x",),
        )
    }
    summaries, _ = infer_semantic_effect_summaries(functions)
    result = ExactSourceRunner(SourceProgram(functions, function_summaries=summaries)).run("dep")
    rejected = next(p for p in result.paths if p.rejected)
    assert rejected.precision_loss
    assert "Unknown effect" in rejected.reason
    assert "dependency-post-state" in rejected.reason
    assert "recursive-scc:dep" in rejected.reason
    assert rejected.rejection_origin == "call-site"


def test_projection_growing_summary_terminates_by_widening() -> None:
    from newlang_checker.source_ir import EffectStmt

    functions = {
        "grow": FunctionDef(
            "grow",
            (
                EffectStmt(Effect("Change", "x.value")),
                CallStmt("grow", ("x.next",), origin="grow-call"),
            ),
            ("x",),
        )
    }
    summaries, stats = infer_semantic_effect_summaries(
        functions,
        max_effects_per_function=4,
        max_scc_iterations=32,
    )
    assert summaries["grow"].unknown
    assert stats.widened_sccs == 1
    assert stats.iterations <= 32
    assert any(
        reason.startswith("effect-budget-exceeded:") or reason.startswith("scc-fixpoint-nonconvergent:")
        for reason in summaries["grow"].unknown_reasons
    )


def test_analysis_generated_pressure_has_no_false_accept() -> None:
    result = run_analysis_pressure(seed=20261004, cases=4000)
    assert result.false_accepts == 0
    assert result.exact_accepts > 0
    assert result.exact_rejections > 0
    assert result.false_rejects >= 0
    assert result.precision_rejections > 0
    assert result.unknown_summary_cases >= 2
    assert result.diagnostic_provenance_cases >= 2


def test_normal_error_failure_pressure_preserves_all_responsibility() -> None:
    result = run_failure_pressure(seed=20261004, traces=80, steps=48)
    assert result["mismatches"] == 0
    assert result["push_failures"] > 0
    assert result["pop_failures"] > 0
    assert result["growth_failures"] > 0


def test_frontend_unknown_diagnostic_reports_precision_loss_at_recursive_call() -> None:
    from pathlib import Path
    from newlang_frontend.driver import check_source

    path = Path(__file__).parent / "programs" / "114_recursive_dependency_poststate_error.nl"
    result = check_source(path.read_text(), str(path))
    assert not result.accepted
    assert result.diagnostic is not None
    assert result.diagnostic.code == "E_SEMANTIC"
    assert "dependency-post-state" in result.diagnostic.message
    assert "recursive-scc:recurse" in result.diagnostic.message
    rendered = result.diagnostic.render()
    assert "recurse(value)" in rendered


def test_all_normal_error_injection_points_restore_vec_state() -> None:
    from newlang_frontend.authority_region_pressure import DenseVecModel, ResponsibilityOracle

    for point in ("after_claim", "after_initialize", "after_publish"):
        oracle = ResponsibilityOracle()
        vec = DenseVecModel(2, oracle=oracle, name=f"push-{point}")
        oracle.create_external("x")
        assert not vec.push("x", fail_at=point)
        assert vec.logical_contents() == ()
        assert oracle.owner("x") == "external"
        assert not vec.region.open_claims
        assert not vec.region.transition_active

    for point in ("after_claim", "after_take", "after_publish", "after_return"):
        oracle = ResponsibilityOracle()
        vec = DenseVecModel(2, oracle=oracle, name=f"pop-{point}")
        oracle.create_external("x")
        assert vec.push("x")
        ok, value = vec.try_pop(fail_at=point)
        assert not ok and value is None
        assert vec.logical_contents() == ("x",)
        assert oracle.owner("x") == vec.region.region_id
        assert not vec.region.open_claims
        assert not vec.region.transition_active


def test_call_depth_budget_rejects_with_precise_call_site_reason() -> None:
    functions = {}
    depth = 12
    for i in range(depth):
        name = f"f{i}"
        if i + 1 < depth:
            body = (CallStmt(f"f{i+1}", origin=f"call-f{i+1}"),)
        else:
            body = ()
        functions[name] = FunctionDef(name, body)
    result = ExactSourceRunner(SourceProgram(functions), max_call_depth=5).run("f0")
    rejected = next(p for p in result.paths if p.rejected)
    assert rejected.precision_loss
    assert "call-depth budget 5 exceeded" in rejected.reason
    assert rejected.rejection_origin == "call-f6"


def test_zero_or_more_callback_conflict_is_not_laundered() -> None:
    from newlang_checker.callbacks import CallbackSummary
    from newlang_checker.source_ir import CallbackStmt

    program = SourceProgram(
        {"main": FunctionDef("main", (CallbackStmt("cb"),))},
        callbacks={
            "cb": CallbackSummary(
                frozenset({Effect("Change", "x.value")}),
                nonescaping=True,
                min_calls=0,
            )
        },
    )
    result = ExactSourceRunner(program).run("main", initial_deps=("x.value",))
    assert not result.exact_accepts
    assert any(p.rejected and "semantic conflict" in p.reason for p in result.paths)


def test_recursive_callback_poststate_widens_to_unknown_not_empty_summary() -> None:
    from newlang_checker.source_ir import CallbackStmt

    functions = {
        "f": FunctionDef(
            "f",
            (
                CallbackStmt("cb"),
                CallStmt("f", origin="recur"),
            ),
        )
    }
    summaries, _ = infer_semantic_effect_summaries(functions)
    assert summaries["f"].unknown
    assert "callback-post-state" in summaries["f"].unknown_reasons
