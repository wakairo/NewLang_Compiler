from __future__ import annotations

import pytest

from newlang_frontend.dynamic_container_pressure import (
    DenseMetadataBuffer,
    DynamicContainerReject,
    TaggedOccupancyBuffer,
    differential_trace,
    run_generated_differential,
)


def test_tagged_and_dense_scattered_occupancy_are_logically_equivalent() -> None:
    result = differential_trace(seed=20261003, capacity=8, steps=200)
    assert result["tagged_initial_roots"] == 8
    assert result["dense_initial_roots"] == 0
    assert result["tagged_tag_slots"] == 8
    assert result["dense_materializations"] > 0
    assert result["dense_absorptions"] > 0


def test_dense_runtime_capacity_does_not_require_per_slot_typed_roots() -> None:
    dense = DenseMetadataBuffer(257)
    assert len(dense.state.roots) == 0
    dense.insert(256, "last")
    assert len(dense.state.roots) == 1
    assert dense.remove(256) == "last"
    assert len(dense.state.roots) == 0
    dense.deallocate()


def test_dense_materialize_rejects_occupied_or_duplicate_claim() -> None:
    dense = DenseMetadataBuffer(4)
    slot = dense.materialize_slot(2)
    with pytest.raises(DynamicContainerReject, match="outstanding empty claim"):
        dense.materialize_slot(2)
    dense._absorb_empty_slot(2, slot)
    dense.insert(2, "x")
    with pytest.raises(DynamicContainerReject, match="occupied element"):
        dense.materialize_slot(2)


def test_dense_whole_recovery_requires_empty_metadata_and_no_outstanding_claims() -> None:
    dense = DenseMetadataBuffer(3)
    dense.insert(1, "x")
    with pytest.raises(DynamicContainerReject, match="metadata is live"):
        dense.recover_whole_storage()
    assert dense.remove(1) == "x"
    slot = dense.materialize_slot(2)
    with pytest.raises(DynamicContainerReject, match="outstanding claims"):
        dense.recover_whole_storage()
    dense._absorb_empty_slot(2, slot)
    whole = dense.recover_whole_storage()
    assert dense.state.storages[whole].byte_range.length == 3


def test_dense_metadata_corruption_is_detected() -> None:
    dense = DenseMetadataBuffer(2)
    dense.insert(0, "x")
    dense.metadata[0] = None
    with pytest.raises(DynamicContainerReject, match="metadata says empty"):
        dense.validate_metadata_invariant()


def test_dense_untracked_live_root_blocks_whole_storage_recovery() -> None:
    dense = DenseMetadataBuffer(2)
    dense.insert(0, "x")
    root = dense.roots.pop(0)
    dense.metadata[0] = None
    assert root in dense.state.roots
    with pytest.raises(DynamicContainerReject, match="untracked live root"):
        dense.recover_whole_storage()


def test_tagged_teardown_requires_every_payload_removed() -> None:
    tagged = TaggedOccupancyBuffer(2)
    tagged.insert(0, "x")
    with pytest.raises(DynamicContainerReject, match="payloads remain live"):
        tagged.recover_whole_storage()
    assert tagged.remove(0) == "x"
    tagged.deallocate()


def test_generated_representation_differential() -> None:
    result = run_generated_differential(seed=20261003, traces=200, steps=48)
    assert result == {"traces": 200, "steps": 9600, "max_capacity": 32, "mismatches": 0}

from newlang_frontend.dynamic_container_pressure import DensePrefixBuffer, differential_prefix_trace, run_generated_prefix_differential


def test_dense_prefix_uses_len_not_per_slot_occupancy_metadata() -> None:
    dense = DensePrefixBuffer(1024)
    assert dense.length == 0
    assert not hasattr(dense, "metadata")
    dense.push("a")
    dense.push("b")
    assert dense.length == 2
    assert dense.logical_contents()[:3] == ("a", "b", None)
    assert dense.pop() == "b"
    assert dense.pop() == "a"
    dense.deallocate()


def test_prefix_tagged_vs_dense_differential() -> None:
    result = differential_prefix_trace(seed=7, capacity=17, steps=500)
    assert result["tagged_tag_slots"] == 17
    assert result["tagged_initial_roots"] == 17
    assert result["dense_initial_roots"] == 0
    assert result["dense_metadata_scalars"] == 1


def test_generated_prefix_differential() -> None:
    result = run_generated_prefix_differential(seed=20261003, traces=200, steps=48)
    assert result == {"traces": 200, "steps": 9600, "max_capacity": 64, "mismatches": 0}


def test_dense_prefix_recovery_rejects_live_prefix() -> None:
    dense = DensePrefixBuffer(4)
    dense.push("x")
    with pytest.raises(DynamicContainerReject, match="len is nonzero"):
        dense.recover_whole_storage()
    assert dense.pop() == "x"
    dense.deallocate()
