from pathlib import Path

import pytest

from newlang_frontend.driver import check_source

ROOT = Path(__file__).parent / "programs"

CASES = [
    ("01_qualified_make_ok.nl", True, None),
    ("02_receiver_chain_ok.nl", True, None),
    ("03_read_receiver_ok.nl", True, None),
    ("04_write_to_read_weakening_ok.nl", True, None),
    ("05_field_function_same_name_ok.nl", True, None),
    ("06_private_field_outside_error.nl", False, "E_PRIVATE_FIELD"),
    ("07_private_construct_outside_error.nl", False, "E_PRIVATE_CONSTRUCTION"),
    ("08_private_destructure_outside_error.nl", False, "E_PRIVATE_DESTRUCTURE"),
    ("09_receiver_no_auto_borrow_error.nl", False, "E_ARGUMENT_TYPE"),
    ("10_bound_method_error.nl", False, "E_BOUND_METHOD_UNSUPPORTED"),
]


@pytest.mark.parametrize(("filename", "accepted", "code"), CASES)
def test_program(filename: str, accepted: bool, code: str | None) -> None:
    path = ROOT / filename
    result = check_source(path.read_text(encoding="utf-8"), str(path))
    assert result.accepted is accepted
    if code is not None:
        assert result.diagnostic is not None
        assert result.diagnostic.code == code
        line, col = result.diagnostic.span.start_line_col
        assert line >= 1 and col >= 1
