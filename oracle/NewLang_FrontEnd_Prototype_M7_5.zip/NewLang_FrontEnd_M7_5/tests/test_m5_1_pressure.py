from pathlib import Path

import pytest

from newlang_frontend.diagnostics import FrontendError
from newlang_frontend.driver import check_source
from newlang_frontend.lexer import lex
from newlang_frontend.lifecycle import run_lifecycle_detailed
from newlang_frontend.parser import parse
from newlang_frontend.production_lifecycle import run_production_lifecycle_detailed
from newlang_frontend.source import SourceFile
from newlang_frontend.symbols import SymbolBuilder
from newlang_frontend.typecheck import TypeChecker

ROOT = Path(__file__).parent / "programs"


def check(name: str):
    path = ROOT / name
    return check_source(path.read_text(encoding="utf-8"), str(path))


def typed(name: str):
    path = ROOT / name
    source = SourceFile(str(path), path.read_text(encoding="utf-8"))
    symbols = SymbolBuilder(parse(lex(source))).build()
    checker = TypeChecker(symbols)
    return symbols, checker, checker.check_program()


@pytest.mark.parametrize(
    ("name", "accepted", "code"),
    [
        ("156_nested_nominal_copy_discardable_ok.nl", True, None),
        ("157_nested_nominal_nondiscardable_store_error.nl", False, "E_STORE_NONDISCARDABLE"),
        ("158_repeated_generic_field_capability_ok.nl", True, None),
        ("159_nested_generic_sum_copy_discardable_ok.nl", True, None),
        ("160_nested_generic_sum_nondiscardable_store_error.nl", False, "E_STORE_NONDISCARDABLE"),
        ("161_generic_nominal_block_storage_error.nl", False, "E_BLOCK_ESCAPE_TYPE"),
        ("162_generic_sum_block_storage_error.nl", False, "E_BLOCK_ESCAPE_TYPE"),
        ("163_mutual_generic_nominal_ptr_ok.nl", True, None),
        ("164_mutual_generic_nominal_value_error.nl", False, "E_RECURSIVE_VALUE_TYPE"),
        ("165_mutual_generic_sum_ptr_ok.nl", True, None),
        ("166_mutual_generic_sum_value_error.nl", False, "E_RECURSIVE_VALUE_TYPE"),
        ("167_nested_resource_generic_drain_ok.nl", True, None),
        ("168_generic_cell_whole_replace_ok.nl", True, None),
        ("169_generic_slots_store_nondiscardable_error.nl", False, "E_STORE_NONDISCARDABLE"),
        ("170_discardable_slots_store_ok.nl", True, None),
        ("171_generic_nominal_growth_budget_error.nl", False, "E_GENERIC_MONOMORPH_DEPTH"),
        ("172_nested_generic_associated_owner_ok.nl", True, None),
        ("173_generic_nominal_sum_mutual_ptr_ok.nl", True, None),
        ("174_generic_nominal_sum_mutual_value_error.nl", False, "E_RECURSIVE_VALUE_TYPE"),
        ("175_nested_generic_block_storage_error.nl", False, "E_BLOCK_ESCAPE_TYPE"),
        ("176_generic_optional_slots_functional_ok.nl", True, None),
        ("177_generic_payloadless_field_expected_ok.nl", True, None),
        ("178_generic_block_noncopy_transfer_ok.nl", True, None),
        ("179_generic_constructor_block_storage_error.nl", False, "E_BLOCK_ESCAPE_TYPE"),
        ("180_generic_sum_constructor_block_storage_error.nl", False, "E_BLOCK_ESCAPE_TYPE"),
        ("181_nested_generic_sum_block_storage_error.nl", False, "E_BLOCK_ESCAPE_TYPE"),
        ("182_generic_optional_slots_inplace_store_error.nl", False, "E_STORE_NONDISCARDABLE"),
    ],
)
def test_m5_1_programs(name: str, accepted: bool, code: str | None) -> None:
    result = check(name)
    assert result.accepted is accepted, result.diagnostic
    if code is not None:
        assert result.diagnostic is not None
        assert result.diagnostic.code == code


@pytest.mark.parametrize(
    "name",
    [
        "167_nested_resource_generic_drain_ok.nl",
        "168_generic_cell_whole_replace_ok.nl",
        "176_generic_optional_slots_functional_ok.nl",
        "178_generic_block_noncopy_transfer_ok.nl",
    ],
)
def test_resource_pressure_runs_through_both_lifecycle_bridges(name: str) -> None:
    _, _, program = typed(name)
    exact = run_lifecycle_detailed(program)
    production = run_production_lifecycle_detailed(program)
    assert exact.accepted, exact
    assert production.accepted, production
    assert not production.precision_loss


def test_nested_associated_instantiation_keeps_single_nominal_owner() -> None:
    symbols, checker, program = typed("172_nested_generic_associated_owner_ok.nl")
    box = symbols.modules["Box"]
    tags = [
        fn.symbol
        for fn in program.functions
        if fn.symbol.template_function_id == box.functions["tag"].function_id
    ]
    assert [fn.qualified_name for fn in tags] == ["Box::tag<Box<u32>>"]
    assert tags[0].owner_module_id == box.module_id
    assert len(checker.monomorph_cache) >= 3


def test_wide_nominal_instantiation_uses_existing_total_monomorph_budget() -> None:
    lets = ["  let b0 = Box::make(u32(0))"]
    for i in range(1, 7):
        lets.append(f"  let b{i} = Box::make(b{i - 1})")
    source_text = """
module Box<T>
  struct { value: T }
  fn make(value: T) -> Self { Self { value: value } }
end
fn main() -> unit {
""" + "\n".join(lets) + "\n  unit\n}\n"
    source = SourceFile("wide_nominal_budget.nl", source_text)
    symbols = SymbolBuilder(parse(lex(source))).build()
    checker = TypeChecker(symbols, max_monomorphs=4)
    with pytest.raises(FrontendError) as exc:
        checker.check_program()
    assert exc.value.diagnostic.code == "E_GENERIC_MONOMORPH_BUDGET"


def test_functional_optional_slots_do_not_require_partial_initialization() -> None:
    symbols, checker, program = typed("176_generic_optional_slots_functional_ok.nl")
    slots = symbols.modules["Slots2"]
    names = {
        fn.symbol.qualified_name
        for fn in program.functions
        if fn.symbol.template_function_id is not None
    }
    assert "Slots2::singleton<LifetimeDomain>" in names
    assert "Slots2::put_second_then<LifetimeDomain>" in names
    assert "Slots2::drain<LifetimeDomain>" in names
    assert checker.monomorph_cache


def test_payloadless_generic_sum_uses_field_expected_type() -> None:
    _, _, program = typed("177_generic_payloadless_field_expected_ok.nl")
    names = {
        fn.symbol.qualified_name
        for fn in program.functions
        if fn.symbol.template_function_id is not None
    }
    assert "Slot::from<u32>" in names
