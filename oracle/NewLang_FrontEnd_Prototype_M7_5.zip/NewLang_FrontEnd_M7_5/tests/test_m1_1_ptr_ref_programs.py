from pathlib import Path

import pytest

from newlang_frontend.driver import check_source

ROOT = Path(__file__).parent / "programs"

CASES = [
    ("32_ref_from_ptr_read_ok.nl", True, None),
    ("33_ref_from_ptr_write_ok.nl", True, None),
    ("34_ref_from_ptr_wrong_domain_error.nl", False, "E_LIFETIME_DOMAIN_MISMATCH"),
    ("35_ref_from_ptr_stale_error.nl", False, "E_STALE_PTR"),
    ("36_ref_from_ptr_escape_error.nl", False, "E_SCOPE_ESCAPE"),
    ("37_ptr_from_ref_escape_ok.nl", True, None),
    ("38_projected_ptr_ref_roundtrip_ok.nl", True, None),
    ("39_ref_from_ptr_requires_ordinary_stable_error.nl", False, "E_ARGUMENT_TYPE"),
    ("40_ref_from_ptr_bad_mode_error.nl", False, "E_REF_FROM_PTR_MODE"),
    ("41_ptr_from_exclusive_ref_error.nl", False, "E_PTR_FROM_REF"),
    ("42_ref_escape_through_wrapper_error.nl", False, "E_SCOPE_ESCAPE"),
    ("43_ptr_escape_through_wrapper_ok.nl", True, None),
    ("44_ref_from_ptr_wrong_domain_wrapper_error.nl", False, "E_LIFETIME_DOMAIN_MISMATCH"),
    ("45_ptr_from_local_ref_ok.nl", True, None),
]


@pytest.mark.parametrize(("filename", "accepted", "code"), CASES)
def test_m1_1_ptr_ref_programs(filename: str, accepted: bool, code: str | None) -> None:
    path = ROOT / filename
    result = check_source(path.read_text(encoding="utf-8"), str(path))
    assert result.accepted is accepted, (filename, result.diagnostic)
    if code is not None:
        assert result.diagnostic is not None
        assert result.diagnostic.code == code, (filename, result.diagnostic)
