from __future__ import annotations

import pytest

from newlang_frontend.authority_region_pressure import (
    DenseVecModel,
    ResponsibilityOracle,
    Ring3Model,
    SealedRegion,
    Slab8Model,
    RegionReject,
    exhaustive_ring_sequences,
)


def token(oracle: ResponsibilityOracle, name: str, *, address_sensitive: bool = False) -> str:
    oracle.create_external(name, address_sensitive=address_sensitive)
    return name


def test_region_claim_is_transfer_not_authority_reconstruction() -> None:
    oracle = ResponsibilityOracle()
    region = SealedRegion(2, elem_size=8, elem_align=8, oracle=oracle)
    region.register_type("Token", size=8, align=8)
    c = region.claim_vacant(0, "Token")
    assert region.responsibility(0).kind == "claimed_vacant"
    with pytest.raises(RegionReject) as exc:
        region.claim_vacant(0, "Token")
    assert exc.value.code == "E_REGION_FOCUSED"
    region.return_vacant(c)
    assert region.responsibility(0).kind == "vacant"


def test_metadata_corruption_cannot_forge_whole_storage() -> None:
    oracle = ResponsibilityOracle()
    vec = DenseVecModel(3, oracle=oracle)
    token(oracle, "d0")
    vec.push("d0")
    # Simulate corrupt operational metadata. Authority is still held by the region.
    vec.length = 0
    with pytest.raises(RegionReject) as exc:
        vec.region.unseal()
    assert exc.value.code == "E_REGION_LIVE_RESPONSIBILITY"
    assert oracle.owner("d0") == vec.region.region_id


def test_dense_vec_non_discardable_failure_guards_preserve_responsibility() -> None:
    oracle = ResponsibilityOracle()
    vec = DenseVecModel(3, oracle=oracle)
    token(oracle, "a")
    assert not vec.push("a", fail_at="after_claim")
    assert oracle.owner("a") == "external"
    assert vec.logical_contents() == ()
    assert not vec.push("a", fail_at="after_initialize")
    assert oracle.owner("a") == "external"
    assert vec.logical_contents() == ()
    vec.push("a")
    assert oracle.owner("a") == vec.region.region_id
    assert vec.pop() == "a"
    assert oracle.owner("a") == "external"
    vec.teardown()
    oracle.assert_conserved()


def test_dense_vec_reentry_during_unpublished_transition_is_blocked_and_rolled_back() -> None:
    oracle = ResponsibilityOracle()
    vec = DenseVecModel(2, oracle=oracle)
    token(oracle, "x")
    with pytest.raises(RegionReject) as exc:
        vec.push("x", reenter=True)
    assert exc.value.code == "E_REGION_TRANSITION"
    assert vec.logical_contents() == ()
    assert oracle.owner("x") == "external"


def test_growth_failure_preserves_old_allocation_and_values() -> None:
    oracle = ResponsibilityOracle()
    vec = DenseVecModel(2, oracle=oracle)
    token(oracle, "x"); token(oracle, "y")
    vec.push("x"); vec.push("y")
    old_region = vec.region.region_id
    assert not vec.grow(4, allocation_fails=True)
    assert vec.region.region_id == old_region
    assert vec.logical_contents() == ("x", "y")
    assert oracle.owner("x") == old_region and oracle.owner("y") == old_region


def test_growth_rejects_live_borrow() -> None:
    oracle = ResponsibilityOracle()
    vec = DenseVecModel(2, oracle=oracle)
    token(oracle, "x")
    vec.push("x")
    b = vec.borrow(0)
    with pytest.raises(RegionReject) as exc:
        vec.grow(4)
    assert exc.value.code == "E_REGION_BORROWED"
    vec.region.end_borrow(b)
    assert vec.grow(4)
    assert vec.logical_contents() == ("x",)


def test_growth_does_not_assume_address_sensitive_value_is_relocatable() -> None:
    oracle = ResponsibilityOracle()
    vec = DenseVecModel(1, oracle=oracle)
    token(oracle, "selfptr", address_sensitive=True)
    vec.push("selfptr")
    with pytest.raises(RegionReject) as exc:
        vec.grow(2)
    assert exc.value.code == "E_ADDRESS_SENSITIVE_RELOCATION"
    assert vec.logical_contents() == ("selfptr",)


def test_non_discardable_teardown_requires_returning_elements() -> None:
    oracle = ResponsibilityOracle()
    vec = DenseVecModel(2, oracle=oracle)
    token(oracle, "x")
    vec.push("x")
    with pytest.raises(RegionReject) as exc:
        vec.teardown()
    assert exc.value.code == "E_REGION_LIVE_RESPONSIBILITY"
    assert vec.pop() == "x"
    vec.teardown()


def test_ring_capacity_three_exhaustive_sequences() -> None:
    result = exhaustive_ring_sequences(depth=7)
    assert result["explored"] > 0
    assert result["expected_boundary_rejects"] > 0


def test_ring_reentry_cannot_observe_half_published_state() -> None:
    oracle = ResponsibilityOracle()
    ring = Ring3Model(oracle=oracle)
    token(oracle, "x")
    with pytest.raises(RegionReject) as exc:
        ring.push("x", reenter_after_initialize=True)
    assert exc.value.code == "E_REGION_TRANSITION"
    assert ring.observe() == ()
    assert oracle.owner("x") == "external"


def test_logically_free_slab_slot_is_not_vacant_storage() -> None:
    slab = Slab8Model()
    assert slab.free[0]
    # A live FreeNode owns this range; logical free != raw vacant.
    with pytest.raises(RegionReject) as exc:
        slab.region.claim_vacant(0, "Token")
    assert exc.value.code == "E_REGION_NOT_VACANT"


def test_slab_ends_inline_freenode_before_installing_token() -> None:
    oracle = ResponsibilityOracle()
    slab = Slab8Model(oracle=oracle)
    token(oracle, "user")
    slab.allocate_at(3, "user")
    assert slab.region.responsibility(3).type_name == "Token"
    assert oracle.owner("user") == slab.region.region_id
    assert slab.free_at(3) == "user"
    assert oracle.owner("user") == "external"
    assert slab.region.responsibility(3).type_name == "FreeNode"
    slab.teardown()


def test_wrong_root_claim_return_is_rejected() -> None:
    a = SealedRegion(1, elem_size=8, elem_align=8, name="a")
    b = SealedRegion(1, elem_size=8, elem_align=8, name="b")
    a.register_type("Token", size=8, align=8)
    b.register_type("Token", size=8, align=8)
    claim = a.claim_vacant(0, "Token")
    with pytest.raises(RegionReject) as exc:
        b.return_vacant(claim)
    assert exc.value.code == "E_REGION_WRONG_ROOT"
    a.return_vacant(claim)


def test_outstanding_claim_blocks_region_unseal() -> None:
    r = SealedRegion(1, elem_size=8, elem_align=8)
    r.register_type("Token", size=8, align=8)
    claim = r.claim_vacant(0, "Token")
    with pytest.raises(RegionReject) as exc:
        r.unseal()
    assert exc.value.code == "E_REGION_OUTSTANDING_CLAIM"
    r.return_vacant(claim)
    storage = r.unseal()
    assert storage.byte_range.length == 8


def test_stale_live_receipt_cannot_be_reused_after_lifetime_transition() -> None:
    oracle = ResponsibilityOracle()
    r = SealedRegion(1, elem_size=8, elem_align=8, oracle=oracle)
    r.register_type("Token", size=8, align=8)
    token(oracle, "x")
    vc = r.claim_vacant(0, "Token")
    r.initialize_vacant(vc, "x")
    live = r.claim_live(0)
    got, vacant = r.take_live(live)
    assert got == "x"
    with pytest.raises(RegionReject) as exc:
        r.return_live(live)
    assert exc.value.code == "E_REGION_STALE_CLAIM"
    r.return_vacant(vacant)


def test_overaligned_region_layout_is_checked() -> None:
    r = SealedRegion(2, elem_size=16, elem_align=16, base_align=16)
    r.register_type("Wide", size=16, align=16)
    c = r.claim_vacant(1, "Wide")
    assert r.state.slots[c.resource].byte_range.start == 16
    r.return_vacant(c)


def test_zst_policy_is_explicit_in_m62_byte_range_prototype() -> None:
    with pytest.raises(RegionReject) as exc:
        SealedRegion(4, elem_size=0, elem_align=1)
    assert exc.value.code == "E_M62_ZST_POLICY"

from newlang_frontend.authority_region_pressure import (
    run_generated_slab_authority_pressure,
    run_generated_vec_authority_pressure,
)


def test_generated_vec_authority_pressure() -> None:
    result = run_generated_vec_authority_pressure(seed=20261004, traces=120, steps=48)
    assert result["mismatches"] == 0
    assert result["rolled_back_transitions"] > 0
    assert result["growth_failures"] > 0
    assert result["successful_growths"] > 0


def test_generated_slab_authority_pressure() -> None:
    result = run_generated_slab_authority_pressure(seed=20261004, traces=80, steps=48)
    assert result == {"traces": 80, "operations": 3840, "mismatches": 0}


def test_live_claim_receipt_temporarily_owns_non_discardable_responsibility() -> None:
    oracle = ResponsibilityOracle()
    r = SealedRegion(1, elem_size=8, elem_align=8, oracle=oracle)
    r.register_type("Token", size=8, align=8)
    token(oracle, "x")
    vc = r.claim_vacant(0, "Token")
    r.initialize_vacant(vc, "x")
    live = r.claim_live(0)
    assert oracle.owner("x") == live.claim_id
    r.return_live(live)
    assert oracle.owner("x") == r.region_id
