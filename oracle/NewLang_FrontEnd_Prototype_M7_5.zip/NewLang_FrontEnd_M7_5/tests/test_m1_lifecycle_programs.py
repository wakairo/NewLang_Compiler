from pathlib import Path

import pytest

from newlang_frontend.driver import check_source

ROOT = Path(__file__).parent / "programs"

CASES = [
    ("15_lifecycle_initialize_destroy_ok.nl", True, None),
    ("16_lifecycle_take_ok.nl", True, None),
    ("17_lifecycle_wrong_domain_error.nl", False, "E_LIFETIME_DOMAIN_MISMATCH"),
    ("18_lifecycle_stability_blocks_exclusive_error.nl", False, "E_LOAN_CONFLICT"),
    ("19_initialize_requires_stable_ref_error.nl", False, "E_ARGUMENT_TYPE"),
    ("20_take_requires_exclusive_error.nl", False, "E_ARGUMENT_TYPE"),
    ("21_stale_ptr_after_destroy_error.nl", False, "E_STALE_PTR"),
    ("22_finalize_live_domain_error.nl", False, "E_DOMAIN_STILL_GOVERNS_ROOT"),
    ("23_projected_ptr_not_root_error.nl", False, "E_NOT_LIFETIME_ROOT"),
    ("24_slot_double_initialize_error.nl", False, "E_USE_AFTER_CONSUME"),
    ("25_finalize_while_stability_loan_error.nl", False, "E_LOAN_CONFLICT"),
    ("26_use_finalized_domain_error.nl", False, "E_USE_AFTER_CONSUME"),
    ("27_lifecycle_wrapper_destroy_ok.nl", True, None),
    ("28_lifecycle_wrapper_wrong_domain_error.nl", False, "E_LIFETIME_DOMAIN_MISMATCH"),
    ("29_domain_double_transfer_error.nl", False, "E_USE_AFTER_CONSUME"),
    ("30_unfinalized_domain_error.nl", False, "E_DOMAIN_NOT_FINALIZED"),
    ("31_unreturned_slot_error.nl", False, "E_SLOT_NOT_CONSUMED"),
]


@pytest.mark.parametrize(("filename", "accepted", "code"), CASES)
def test_m1_lifecycle_programs(filename: str, accepted: bool, code: str | None) -> None:
    path = ROOT / filename
    result = check_source(path.read_text(encoding="utf-8"), str(path))
    assert result.accepted is accepted
    if code is not None:
        assert result.diagnostic is not None
        assert result.diagnostic.code == code
        line, col = result.diagnostic.span.start_line_col
        assert line >= 1 and col >= 1
