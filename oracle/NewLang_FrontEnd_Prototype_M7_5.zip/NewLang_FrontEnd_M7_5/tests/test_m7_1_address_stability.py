from __future__ import annotations

import pytest

from newlang_frontend.address_stability_pressure import (
    AddressInvariant,
    AddressStabilityReject,
    PlaceObject,
    StablePlaceOwner,
    ordinary_relocate,
    ordinary_swap,
    privileged_self_fixup_relocate,
    run_address_stability_pressure,
)
from newlang_frontend.intrusive_pressure import CompilerProjectionModel, layout_variants


def roots():
    model = CompilerProjectionModel(layout_variants()[0])
    return model.root_ptr("a", "Node", 0x1000), model.root_ptr("b", "Node", 0x2000)


def test_ordinary_relocation_stales_old_locator_instead_of_fixing_it() -> None:
    a, _ = roots()
    moved, stale = ordinary_relocate(PlaceObject("A", a), new_root_id="a2", new_address=0x3000)
    assert stale.stale
    assert stale.address == 0x1000
    assert moved.ptr.address == 0x3000


def test_ordinary_swap_changes_semantic_identity_at_observed_place() -> None:
    a, b = roots()
    left = PlaceObject("A", a)
    right = PlaceObject("B", b)
    ordinary_swap(left, right)
    assert left.ptr.address == 0x1000 and left.semantic_id == "B"
    assert right.ptr.address == 0x2000 and right.semantic_id == "A"


def test_stable_owner_handle_may_move_without_moving_pointee() -> None:
    a, _ = roots()
    owner = StablePlaceOwner(PlaceObject("A", a), AddressInvariant())
    owner.install_self_reference()
    moved = owner.move_handle()
    assert moved.handle_generation == 1
    assert moved.obj.ptr.address == 0x1000
    assert moved.invariant.self_ptr is not None
    assert moved.invariant.self_ptr.address == 0x1000


def test_address_sensitive_state_blocks_whole_value_operations_but_not_payload_update() -> None:
    a, b = roots()
    owner = StablePlaceOwner(PlaceObject("A", a), AddressInvariant())
    peer = StablePlaceOwner(PlaceObject("B", b), AddressInvariant())
    owner.install_self_reference()
    owner.mutate_payload(99)
    assert owner.obj.payload == 99
    for action in (
        lambda: owner.whole_replace("X"),
        lambda: owner.swap_with(peer),
        owner.take_for_relocation,
    ):
        with pytest.raises(AddressStabilityReject) as exc:
            action()
        assert exc.value.code == "E_ADDRESS_STABILITY"


def test_address_sensitivity_is_state_dependent_not_nominal_forever_property() -> None:
    a, _ = roots()
    owner = StablePlaceOwner(PlaceObject("A", a), AddressInvariant())
    owner.install_self_reference()
    with pytest.raises(AddressStabilityReject):
        owner.take_for_relocation()
    owner.clear_self_reference()
    assert owner.take_for_relocation() == "A"


def test_localized_self_fixup_does_not_pretend_to_fix_external_intrusive_observers() -> None:
    a, _ = roots()
    owner = StablePlaceOwner(PlaceObject("A", a), AddressInvariant())
    owner.install_self_reference()
    moved = privileged_self_fixup_relocate(owner, new_root_id="a2", new_address=0x4000)
    assert moved.invariant.self_ptr is not None
    assert moved.invariant.self_ptr.address == 0x4000

    other = StablePlaceOwner(PlaceObject("B", a), AddressInvariant())
    other.install_self_reference()
    other.add_external_observer()
    with pytest.raises(AddressStabilityReject) as exc:
        privileged_self_fixup_relocate(other, new_root_id="b2", new_address=0x5000)
    assert exc.value.code == "E_NONLOCAL_RELOCATION_FIXUP"


def test_generated_address_stability_pressure() -> None:
    result = run_address_stability_pressure(seed=20261004, cases=4_000)
    for key in (
        "ordinary_relocation_stale_old_locator",
        "ordinary_swap_location_identity_mismatch",
        "stable_owner_handle_moves",
        "anchored_replace_rejections",
        "anchored_swap_rejections",
        "anchored_take_rejections",
        "same_place_payload_updates",
        "unanchor_then_move",
        "privileged_self_fixup_relocations",
        "nonlocal_fixup_rejections",
    ):
        assert result[key] == 4_000
    assert result["runtime_pin_flag_required"] is False
    assert result["core_pin_type_required_by_experiment"] is False
    assert result["nominal_forever_nonrelocatable_required"] is False
    assert result["general_relocation_fixup_safe"] is False

from pathlib import Path
from newlang_frontend.driver import check_source
from newlang_frontend.lexer import lex
from newlang_frontend.lifecycle import run_lifecycle_detailed
from newlang_frontend.parser import parse
from newlang_frontend.production_lifecycle import run_production_lifecycle_detailed
from newlang_frontend.source import SourceFile
from newlang_frontend.symbols import SymbolBuilder
from newlang_frontend.typecheck import TypeChecker

PROGRAM_ROOT = Path(__file__).parent / "programs"


def _typed_program(name: str):
    path = PROGRAM_ROOT / name
    source = SourceFile(str(path), path.read_text(encoding="utf-8"))
    symbols = SymbolBuilder(parse(lex(source))).build()
    return TypeChecker(symbols).check_program()


def test_source_relocation_stales_external_observer() -> None:
    name = "234_relocation_stales_external_observer_error.nl"
    result = check_source((PROGRAM_ROOT / name).read_text(), str(PROGRAM_ROOT / name))
    assert not result.accepted
    assert result.diagnostic is not None and result.diagnostic.code == "E_STALE_PTR"
    exact = run_lifecycle_detailed(_typed_program(name))
    production = run_production_lifecycle_detailed(_typed_program(name))
    assert not exact.accepted and exact.code == "E_STALE_PTR"
    assert not production.accepted and not production.precision_loss


def test_source_swap_keeps_location_observer_live() -> None:
    name = "235_swap_keeps_location_observer_live_ok.nl"
    assert check_source((PROGRAM_ROOT / name).read_text(), str(PROGRAM_ROOT / name)).accepted
    assert run_lifecycle_detailed(_typed_program(name)).accepted
    production = run_production_lifecycle_detailed(_typed_program(name))
    assert production.accepted and not production.precision_loss


def test_source_stable_owner_handle_moves_without_moving_pointee() -> None:
    name = "236_stable_owner_handle_move_ok.nl"
    assert check_source((PROGRAM_ROOT / name).read_text(), str(PROGRAM_ROOT / name)).accepted
    assert run_lifecycle_detailed(_typed_program(name)).accepted
    production = run_production_lifecycle_detailed(_typed_program(name))
    assert production.accepted and not production.precision_loss


def test_source_stable_owner_hides_pointee_location() -> None:
    name = "237_stable_owner_hides_pointee_error.nl"
    result = check_source((PROGRAM_ROOT / name).read_text(), str(PROGRAM_ROOT / name))
    assert not result.accepted
    assert result.diagnostic is not None and result.diagnostic.code == "E_PRIVATE_FIELD"
