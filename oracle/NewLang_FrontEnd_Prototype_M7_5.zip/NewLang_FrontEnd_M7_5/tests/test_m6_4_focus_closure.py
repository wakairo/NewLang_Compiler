import pytest

from newlang_frontend.authority_region_pressure import RegionReject, ResponsibilityOracle, SealedRegion
from newlang_frontend.focus_pressure import run_focus_pressure
from newlang_frontend.region_surface_pressure import ClosureSurface


def live_region(capacity: int = 4, *, name: str = "m64"):
    oracle = ResponsibilityOracle()
    region = SealedRegion(capacity, elem_size=8, elem_align=8, oracle=oracle, name=name)
    region.register_type("Token", size=8, align=8)
    tokens = []
    for i in range(capacity):
        token = f"{name}:t{i}"
        tokens.append(token)
        oracle.create_external(token)
        vacant = region.claim_vacant(i, "Token")
        region.initialize_vacant(vacant, token)
    return region, oracle, tokens


def drain(region: SealedRegion, tokens: list[str]) -> None:
    for i, expected in enumerate(tokens):
        live = region.claim_live(i, expected_type="Token")
        got, vacant = region.take_live(live)
        assert got == expected
        region.return_vacant(vacant)
    region.unseal()


def test_independent_second_claim_is_blocked_while_root_is_focused():
    region, oracle, tokens = live_region()
    first = region.claim_live(0, expected_type="Token")
    with pytest.raises(RegionReject) as exc:
        region.claim_live(1, expected_type="Token")
    assert exc.value.code == "E_REGION_FOCUSED"
    assert oracle.owner(tokens[0]) == first.claim_id
    assert oracle.owner(tokens[1]) == region.region_id
    region.return_live(first)
    drain(region, tokens)


def test_public_observation_and_root_transition_are_blocked_during_focus():
    region, _, tokens = live_region()
    first = region.claim_live(0, expected_type="Token")
    with pytest.raises(RegionReject) as exc:
        region.require_public_observation()
    assert exc.value.code == "E_REGION_FOCUSED"
    with pytest.raises(RegionReject) as exc:
        region.begin_transition()
    assert exc.value.code == "E_REGION_FOCUSED"
    region.return_live(first)
    drain(region, tokens)


def test_closure_callback_cannot_reenter_same_root_and_scope_is_restored():
    region, oracle, tokens = live_region()
    api = ClosureSurface(region)

    def callback(_claim):
        with pytest.raises(RegionReject) as exc:
            api.with_live(1, lambda _: None, expected_type="Token")
        assert exc.value.code == "E_REGION_FOCUSED"
        with pytest.raises(RegionReject) as exc:
            region.begin_transition()
        assert exc.value.code == "E_REGION_FOCUSED"

    api.with_live(0, callback, expected_type="Token")
    assert not region.open_claims
    for token in tokens:
        assert oracle.owner(token) == region.region_id
    drain(region, tokens)


def test_multi_claim_boundary_accepts_two_disjoint_dynamic_indices():
    region, oracle, tokens = live_region()
    claims = region.claim_many([
        ("live", 0, "Token"),
        ("live", 3, "Token"),
    ])
    assert len(claims) == 2
    assert oracle.owner(tokens[0]) == claims[0].claim_id
    assert oracle.owner(tokens[3]) == claims[1].claim_id
    with pytest.raises(RegionReject) as exc:
        region.claim_live(1, expected_type="Token")
    assert exc.value.code == "E_REGION_FOCUSED"
    for claim in claims:
        region.return_live(claim)
    drain(region, tokens)


def test_multi_focus_remains_open_until_every_extracted_claim_is_restored():
    region, oracle, tokens = live_region()
    first, second = region.claim_many([
        ("live", 0, "Token"),
        ("live", 1, "Token"),
    ])
    region.return_live(first)
    assert oracle.owner(tokens[0]) == region.region_id
    assert oracle.owner(tokens[1]) == second.claim_id
    with pytest.raises(RegionReject) as exc:
        region.require_public_observation()
    assert exc.value.code == "E_REGION_FOCUSED"
    region.return_live(second)
    region.require_public_observation()
    drain(region, tokens)


def test_take_inside_multi_focus_preserves_focus_via_replacement_vacant_claim():
    region, oracle, tokens = live_region()
    first, second = region.claim_many([
        ("live", 0, "Token"),
        ("live", 1, "Token"),
    ])
    got, vacant = region.take_live(first)
    assert got == tokens[0]
    assert oracle.owner(tokens[0]) == "external"
    assert vacant.claim_id in region.open_claims
    assert second.claim_id in region.open_claims
    with pytest.raises(RegionReject) as exc:
        region.begin_transition()
    assert exc.value.code == "E_REGION_FOCUSED"
    region.return_vacant(vacant)
    region.return_live(second)
    # Reinstall the externally returned token so the common drain helper can close the region.
    reinstall = region.claim_vacant(0, "Token")
    region.initialize_vacant(reinstall, tokens[0])
    drain(region, tokens)


def test_duplicate_dynamic_index_is_rejected_atomically():
    region, oracle, tokens = live_region()
    with pytest.raises(RegionReject) as exc:
        region.claim_many([
            ("live", 2, "Token"),
            ("live", 2, "Token"),
        ])
    assert exc.value.code == "E_REGION_OVERLAPPING_CLAIMS"
    assert not region.open_claims
    for token in tokens:
        assert oracle.owner(token) == region.region_id
    drain(region, tokens)


def test_multi_claim_prevalidation_failure_does_not_transfer_any_authority():
    region, oracle, tokens = live_region()
    with pytest.raises(RegionReject) as exc:
        region.claim_many([
            ("live", 0, "Token"),
            ("live", 1, "WrongType"),
        ])
    assert exc.value.code == "E_REGION_TYPE"
    assert not region.open_claims
    for token in tokens:
        assert oracle.owner(token) == region.region_id
    drain(region, tokens)


def test_partially_overlapping_element_ranges_are_rejected_before_opening():
    region, oracle, tokens = live_region()
    with pytest.raises(RegionReject) as exc:
        region.claim_many_ranges([
            ("live", 0, 2, "Token"),
            ("live", 1, 2, "Token"),
        ])
    assert exc.value.code == "E_REGION_OVERLAPPING_CLAIMS"
    assert not region.open_claims
    for token in tokens:
        assert oracle.owner(token) == region.region_id
    drain(region, tokens)


def test_adjacent_element_ranges_can_be_focused_together():
    region, oracle, tokens = live_region()
    claims = region.claim_many_ranges([
        ("live", 0, 2, "Token"),
        ("live", 2, 2, "Token"),
    ])
    assert len(claims) == 4
    assert {claim.index for claim in claims} == {0, 1, 2, 3}
    for claim in claims:
        region.return_live(claim)
    for token in tokens:
        assert oracle.owner(token) == region.region_id
    drain(region, tokens)


def test_sub_element_range_focus_is_not_silently_generalized():
    region, _, tokens = live_region()
    with pytest.raises(RegionReject) as exc:
        region.claim_many_ranges([("live", 0, 0, "Token")])
    assert exc.value.code == "E_M64_RANGE_GRANULARITY"
    drain(region, tokens)



def test_active_transition_receipt_is_required_to_open_new_claims():
    region, oracle, tokens = live_region()
    transition = region.begin_transition()
    with pytest.raises(RegionReject) as exc:
        region.claim_live(0, expected_type="Token")
    assert exc.value.code == "E_REGION_TRANSITION"
    claim = region.claim_live(0, expected_type="Token", transition=transition)
    assert oracle.owner(tokens[0]) == claim.claim_id
    region.return_live(claim)
    region.end_transition(transition)
    with pytest.raises(RegionReject) as exc:
        region.claim_live(0, expected_type="Token", transition=transition)
    assert exc.value.code == "E_REGION_STALE_TRANSITION"
    drain(region, tokens)


def test_safe_closure_surface_cannot_enter_unpublished_transition_even_without_open_claim():
    region, _, tokens = live_region()
    api = ClosureSurface(region)
    transition = region.begin_transition()
    with pytest.raises(RegionReject) as exc:
        api.with_live(0, lambda _: None, expected_type="Token")
    assert exc.value.code == "E_REGION_TRANSITION"
    region.end_transition(transition)
    drain(region, tokens)

def test_generated_focus_pressure():
    result = run_focus_pressure(seed=20261004, traces=100, steps=40)
    assert result["mismatches"] == 0
    assert result["reentry_rejects"] > 0
    assert result["duplicate_rejects"] > 0
    assert result["overlap_rejects"] > 0
    assert result["multi_success"] > 0
    assert result["range_success"] > 0
