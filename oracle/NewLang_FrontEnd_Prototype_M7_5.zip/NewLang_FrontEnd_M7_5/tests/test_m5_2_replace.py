from pathlib import Path

import pytest

from newlang_frontend.driver import check_source
from newlang_frontend.lexer import lex
from newlang_frontend.lifecycle import run_lifecycle_detailed
from newlang_frontend.parser import parse
from newlang_frontend.production_lifecycle import run_production_lifecycle_detailed
from newlang_frontend.source import SourceFile
from newlang_frontend.symbols import SymbolBuilder
from newlang_frontend.typecheck import TypeChecker

ROOT = Path(__file__).parent / "programs"


def check(name: str, *, deps=()):
    path = ROOT / name
    return check_source(path.read_text(encoding="utf-8"), str(path), semantic_initial_deps=deps)


def typed(name: str):
    path = ROOT / name
    source = SourceFile(str(path), path.read_text(encoding="utf-8"))
    symbols = SymbolBuilder(parse(lex(source))).build()
    checker = TypeChecker(symbols)
    return symbols, checker, checker.check_program()


@pytest.mark.parametrize(
    ("name", "accepted", "code"),
    [
        ("183_generic_slot_replace_nondiscardable_ok.nl", True, None),
        ("184_array_maybe_static_replace_ok.nl", True, None),
        ("185_array_maybe_dynamic_replace_precision.nl", False, "E_REPLACE_DYNAMIC_PRECISION"),
        ("186_replace_nondiscardable_result_error.nl", False, "E_NONDDiscardable_EXPR"),
        ("187_replace_read_ref_error.nl", False, "E_REPLACE_DEST"),
        ("188_replace_type_mismatch_error.nl", False, "E_ARGUMENT_TYPE"),
        ("190_replace_sum_occurrence_conflict.nl", False, "E_SEMANTIC_CONFLICT"),
        ("191_generic_array_maybe_replace_ok.nl", True, None),
        ("192_generic_replace_unconstrained_ok.nl", True, None),
    ],
)
def test_m5_2_programs(name: str, accepted: bool, code: str | None) -> None:
    result = check(name)
    assert result.accepted is accepted, result.diagnostic
    if code is not None:
        assert result.diagnostic is not None
        assert result.diagnostic.code == code


def test_replace_has_same_current_value_conflict_surface_as_store() -> None:
    result = check("189_replace_semantic_effect.nl", deps=("b.value",))
    assert not result.accepted
    assert result.diagnostic is not None
    assert result.diagnostic.code == "E_SEMANTIC_CONFLICT"
    assert result.semantic_reason == "semantic conflict at b.value"


@pytest.mark.parametrize(
    "name",
    [
        "183_generic_slot_replace_nondiscardable_ok.nl",
        "184_array_maybe_static_replace_ok.nl",
        "191_generic_array_maybe_replace_ok.nl",
        "192_generic_replace_unconstrained_ok.nl",
    ],
)
def test_replace_workloads_run_through_both_lifecycle_bridges(name: str) -> None:
    _, _, program = typed(name)
    exact = run_lifecycle_detailed(program)
    production = run_production_lifecycle_detailed(program)
    assert exact.accepted, exact
    assert production.accepted, production
    assert not production.precision_loss


def test_dynamic_index_replace_is_an_explicit_lifecycle_precision_boundary() -> None:
    _, _, program = typed("185_array_maybe_dynamic_replace_precision.nl")
    exact = run_lifecycle_detailed(program)
    production = run_production_lifecycle_detailed(program)
    assert not exact.accepted and exact.code == "E_REPLACE_DYNAMIC_PRECISION"
    assert not production.accepted and production.code == "E_REPLACE_DYNAMIC_PRECISION"


def test_unconstrained_generic_replace_adds_no_discardable_requirement() -> None:
    symbols, checker, program = typed("192_generic_replace_unconstrained_ok.nl")
    template = symbols.top_functions["replace_any"]
    assert checker.generic_requirements[template.function_id] == ()
    assert any(fn.symbol.qualified_name == "replace_any<LifetimeDomain>" for fn in program.functions)


def test_generic_array_occupancy_replace_instantiates_for_nondiscardable_element() -> None:
    _, _, program = typed("191_generic_array_maybe_replace_ok.nl")
    names = {fn.symbol.qualified_name for fn in program.functions}
    assert "replace_first<LifetimeDomain>" in names
    assert "Outcome::make<LifetimeDomain>" in names
