from __future__ import annotations

from dataclasses import replace
from pathlib import Path

import pytest

from newlang_frontend.driver import check_source
from newlang_frontend.lexer import lex
from newlang_frontend.lifecycle import run_lifecycle_detailed
from newlang_frontend.parser import parse
from newlang_frontend.production_lifecycle import run_production_lifecycle_detailed
from newlang_frontend.source import SourceFile
from newlang_frontend.storage_layout_pressure import (
    LayoutFacts,
    LogicalZstArena,
    RawAllocation,
    StorageLayoutReject,
    naive_zero_extent_claims_do_not_conflict,
    run_storage_layout_pressure,
)
from newlang_frontend.symbols import SymbolBuilder
from newlang_frontend.typecheck import TypeChecker
from newlang_frontend.typed_ir import TLayoutInfo
from newlang_frontend.typesys import UNIT, NominalType

ROOT = Path(__file__).parent / 'programs'


def typed(name: str):
    p = ROOT / name
    source = SourceFile(str(p), p.read_text(encoding='utf-8'))
    symbols = SymbolBuilder(parse(lex(source))).build()
    return TypeChecker(symbols).check_program()


def with_layout(program, *, type_name: str, size: int, align: int):
    stride = ((size + align - 1) // align) * align if size else 0
    infos = []
    found = False
    for info in program.layouts:
        if isinstance(info.type, NominalType) and info.type.name == type_name:
            infos.append(TLayoutInfo(info.type, size, align, stride)); found = True
        else:
            infos.append(info)
    assert found
    return replace(program, layouts=tuple(infos))


def test_zst_layout_knowledge_is_allowed_but_dynamic_storage_is_not() -> None:
    result = check_source((ROOT/'238_layout_zst_query_ok.nl').read_text(), str(ROOT/'238_layout_zst_query_ok.nl'))
    assert result.accepted, result.diagnostic
    program = typed('238_layout_zst_query_ok.nl')
    infos = [x for x in program.layouts if x.type == UNIT]
    assert len(infos) == 1
    assert (infos[0].size, infos[0].align, infos[0].stride) == (0, 1, 0)

    bad = check_source((ROOT/'239_layout_zst_allocate_error.nl').read_text(), str(ROOT/'239_layout_zst_allocate_error.nl'))
    assert not bad.accepted and bad.diagnostic is not None
    assert bad.diagnostic.code == 'E_ZST_DYNAMIC_STORAGE'


def test_byte_ranges_alone_do_not_encode_zst_logical_multiplicity() -> None:
    assert naive_zero_extent_claims_do_not_conflict(100)
    arena = LogicalZstArena(4)
    for i in range(4): arena.initialize(i)
    assert arena.conserved
    with pytest.raises(StorageLayoutReject) as exc:
        arena.initialize(0)
    assert exc.value.code == 'E_ZST_LOGICAL_OCCUPANCY'
    for i in range(4): arena.destroy(i)
    assert arena.conserved


def test_overaligned_model_accepts_aligned_and_rejects_bad_backing_or_offset() -> None:
    layout = LayoutFacts.make(64, 64)
    assert RawAllocation(256, 64).materialize(128, layout) == (128, 192)
    with pytest.raises(StorageLayoutReject) as exc:
        RawAllocation(256, 32).materialize(0, layout)
    assert exc.value.code == 'E_SLOT_ALIGNMENT'
    with pytest.raises(StorageLayoutReject) as exc:
        RawAllocation(256, 64).materialize(32, layout)
    assert exc.value.code == 'E_SLOT_ALIGNMENT'


def test_overaligned_layout_roundtrip_runs_through_exact_and_production() -> None:
    program = with_layout(typed('202_layout_opaque_nominal_ok.nl'), type_name='Box', size=64, align=64)
    exact = run_lifecycle_detailed(program)
    production = run_production_lifecycle_detailed(program)
    assert exact.accepted, exact
    assert production.accepted, production
    assert not production.precision_loss


def test_overaligned_misaligned_subrange_rejected_by_both_bridges() -> None:
    program = with_layout(typed('240_overaligned_misaligned_subrange.nl'), type_name='Wide', size=64, align=64)
    exact = run_lifecycle_detailed(program)
    production = run_production_lifecycle_detailed(program)
    assert not exact.accepted and exact.code == 'E_SLOT_ALIGNMENT'
    assert not production.accepted and production.code == 'E_SLOT_ALIGNMENT'
    assert not production.precision_loss


def test_generated_storage_layout_pressure() -> None:
    result = run_storage_layout_pressure(seed=20261004, cases=4_000)
    for key in (
        'overaligned_materializations',
        'underaligned_backing_rejections',
        'misaligned_subrange_rejections',
        'zst_dynamic_storage_rejections',
        'logical_zst_comparison_model_conserved',
    ):
        assert result[key] == 4_000
    assert result['naive_zero_extent_claims_nonconflicting'] is True
    assert result['max_alignment_tested'] == 4096
    assert result['runtime_alignment_tag_required'] is False
    assert result['zst_value_layout_query_allowed'] is True
    assert result['zst_raw_storage_bridge_allowed'] is False
