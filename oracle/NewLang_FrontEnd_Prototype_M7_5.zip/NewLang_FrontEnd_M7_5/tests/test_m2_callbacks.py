from pathlib import Path

from newlang_frontend.driver import check_source

ROOT = Path(__file__).parent / "programs"


def test_general_nonescaping_block_parameter_executes_body() -> None:
    path = ROOT / "61_block_parameter_ok.nl"
    result = check_source(path.read_text(), str(path))
    assert result.accepted, result.diagnostic


def test_callback_capture_effect_substitutes_to_caller_place() -> None:
    path = ROOT / "62_block_capture_effect.nl"
    result = check_source(
        path.read_text(),
        str(path),
        semantic_initial_deps=("box.value",),
    )
    assert not result.accepted
    assert result.diagnostic is not None
    assert result.diagnostic.code == "E_SEMANTIC_CONFLICT"
    assert "box.value" in result.diagnostic.message
