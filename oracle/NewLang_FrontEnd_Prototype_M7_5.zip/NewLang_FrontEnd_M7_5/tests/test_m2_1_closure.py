from pathlib import Path

import pytest

from newlang_checker.source_ir import BoundedSourceAnalyzer, ExactSourceRunner
from newlang_frontend.driver import check_source
from newlang_frontend.lexer import lex
from newlang_frontend.lifecycle import run_lifecycle_detailed
from newlang_frontend.lower import lower_program
from newlang_frontend.parser import parse
from newlang_frontend.production_lifecycle import run_production_lifecycle_detailed
from newlang_frontend.source import SourceFile
from newlang_frontend.symbols import SymbolBuilder
from newlang_frontend.typecheck import TypeChecker

ROOT = Path(__file__).parent / "programs"


def typed(name: str):
    path = ROOT / name
    source = SourceFile(str(path), path.read_text())
    tree = parse(lex(source))
    symbols = SymbolBuilder(tree).build()
    return TypeChecker(symbols).check_program()


@pytest.mark.parametrize(
    ("name", "accepted", "code"),
    [
        ("71_dynamic_array_index_ok.nl", True, None),
        ("72_dynamic_subspan_ok.nl", True, None),
        ("73_span_escape_error.nl", False, "E_SCOPE_ESCAPE"),
        ("45_ptr_from_local_ref_ok.nl", True, None),
    ],
)
def test_m2_1_source_closure(name: str, accepted: bool, code: str | None) -> None:
    path = ROOT / name
    result = check_source(path.read_text(), str(path))
    assert result.accepted is accepted, result.diagnostic
    if code is not None:
        assert result.diagnostic is not None
        assert result.diagnostic.code == code


@pytest.mark.parametrize(
    "name",
    [
        "45_ptr_from_local_ref_ok.nl",
        "51_span_index_len_ok.nl",
        "54_subspan_bounds_error.nl",
        "56_consume_array_nondiscardable_ok.nl",
        "58_consume_array_zero_ok.nl",
        "63_sum_nondiscardable_payload_ok.nl",
        "71_dynamic_array_index_ok.nl",
        "72_dynamic_subspan_ok.nl",
        "73_span_escape_error.nl",
    ],
)
def test_m2_exact_and_production_lifecycle_agree(name: str) -> None:
    program = typed(name)
    exact = run_lifecycle_detailed(program)
    production = run_production_lifecycle_detailed(program)
    assert production.accepted is exact.accepted, (name, exact, production)
    if production.accepted:
        assert not production.precision_loss


def test_dynamic_index_effect_conflicts_with_specific_index_dependency() -> None:
    path = ROOT / "74_dynamic_array_index_effect.nl"
    result = check_source(
        path.read_text(), str(path), semantic_initial_deps=("values.$index:0",)
    )
    assert not result.accepted
    assert result.diagnostic is not None
    assert result.diagnostic.code == "E_SEMANTIC_CONFLICT"


def test_dynamic_index_effect_exact_and_bounded_source_analysis_agree() -> None:
    program = typed("74_dynamic_array_index_effect.nl")
    lowered = lower_program(program)
    deps = ("values.$index:2",)
    exact = ExactSourceRunner(lowered).run("main", deps)
    bounded = BoundedSourceAnalyzer(lowered, alternative_budget=8).analyze("main", deps)
    assert not exact.exact_accepts
    assert not bounded.result.accepted
