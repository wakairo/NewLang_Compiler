from __future__ import annotations

from pathlib import Path

import pytest

from newlang_checker.language_ir import ReplaceRoot, SwapRoots, UFunction, UProgram
from newlang_checker.model import SemanticError
from newlang_checker.production_analysis import ProductionChecker
from newlang_checker.semantics import apply_step, load_initial
from newlang_frontend.current_value_pressure import _initial, run_current_value_pressure
from newlang_frontend.driver import check_source
from newlang_frontend.lexer import lex
from newlang_frontend.lower import lower_program
from newlang_frontend.parser import parse
from newlang_frontend.source import SourceFile
from newlang_frontend.symbols import SymbolBuilder
from newlang_frontend.typecheck import TypeChecker
from newlang_frontend.lifecycle import run_lifecycle_detailed
from newlang_frontend.production_lifecycle import run_production_lifecycle_detailed
from newlang_checker.source_ir import EffectStmt

ROOT = Path(__file__).parent / "programs"


def check(name: str, *, deps=()):
    path = ROOT / name
    return check_source(path.read_text(encoding="utf-8"), str(path), semantic_initial_deps=deps)


def typed(name: str):
    path = ROOT / name
    source = SourceFile(str(path), path.read_text(encoding="utf-8"))
    symbols = SymbolBuilder(parse(lex(source))).build()
    checker = TypeChecker(symbols)
    return symbols, checker, checker.check_program()


@pytest.mark.parametrize(
    ("name", "deps", "accepted", "code"),
    [
        ("214_current_value_sibling_update_ok.nl", ("p.a",), True, None),
        ("215_current_value_field_update_conflict.nl", ("p.a",), False, "E_SEMANTIC_CONFLICT"),
        ("216_current_value_whole_update_conflict.nl", ("p.a",), False, "E_SEMANTIC_CONFLICT"),
        ("217_current_value_alias_write_conflict.nl", ("p.a",), False, "E_SEMANTIC_CONFLICT"),
        ("218_current_value_alias_sibling_ok.nl", ("p.a",), True, None),
        ("219_swap_same_place_dependency_ok.nl", ("p.a",), True, None),
        ("220_swap_distinct_dependency_conflict.nl", ("p.a",), False, "E_SEMANTIC_CONFLICT"),
        ("221_swap_disjoint_sibling_dependency_ok.nl", ("p.c",), True, None),
        ("222_generic_swap_unconstrained_ok.nl", (), True, None),
    ],
)
def test_source_current_value_workloads(name, deps, accepted, code):
    result = check(name, deps=deps)
    assert result.accepted is accepted, result.diagnostic
    if code is not None:
        assert result.diagnostic is not None
        assert result.diagnostic.code == code


def test_same_place_swap_lowers_to_no_current_value_effect():
    _, _, program = typed("219_swap_same_place_dependency_ok.nl")
    lowered = lower_program(program)
    fn = lowered.functions["Pair::swap_same"]
    effects = [stmt.effect for stmt in fn.body if isinstance(stmt, EffectStmt)]
    assert effects == []


def test_distinct_swap_lowers_to_change_for_both_places_only():
    _, _, program = typed("220_swap_distinct_dependency_conflict.nl")
    lowered = lower_program(program)
    fn = lowered.functions["Pair::swap_ab"]
    effects = [stmt.effect for stmt in fn.body if isinstance(stmt, EffectStmt)]
    assert [(e.kind, e.place) for e in effects] == [("Change", "self.a"), ("Change", "self.b")]


def test_generic_swap_adds_no_copy_or_discardable_requirement():
    symbols, checker, _ = typed("222_generic_swap_unconstrained_ok.nl")
    template = symbols.top_functions["exchange"]
    assert checker.generic_requirements[template.function_id] == ()


def test_swap_source_runs_through_both_lifecycle_bridges():
    for name in ("219_swap_same_place_dependency_ok.nl", "221_swap_disjoint_sibling_dependency_ok.nl", "222_generic_swap_unconstrained_ok.nl"):
        _, _, program = typed(name)
        exact = run_lifecycle_detailed(program)
        production = run_production_lifecycle_detailed(program)
        assert exact.accepted, (name, exact)
        assert production.accepted, (name, production)
        assert not production.precision_loss


def test_whole_replace_refreshes_fixed_subobject_value_facts_but_not_incarnations():
    st = load_initial(_initial())
    before = st.roots["left"]
    before_root_fact = before.root_value_fact
    before_fixed = {k: (v.incarnation, v.value_fact) for k, v in before.fixed_subobjects.items()}
    apply_step(st, {"op": "replace_root_package", "root": "left", "new_value": "new_left", "result_old": "old"})
    after = st.roots["left"]
    assert after.incarnation == before.incarnation
    assert after.root_value_fact != before_root_fact
    for name, child in after.fixed_subobjects.items():
        old_inc, old_fact = before_fixed[name]
        assert child.incarnation == old_inc
        assert child.value_fact != old_fact
        assert old_fact not in st.live_value_facts
        assert child.value_fact in st.live_value_facts


def test_whole_swap_refreshes_both_places_structural_value_facts_and_preserves_incarnations():
    st = load_initial(_initial())
    left0, right0 = st.roots["left"], st.roots["right"]
    left_fixed0 = {k: (v.incarnation, v.value_fact) for k, v in left0.fixed_subobjects.items()}
    right_fixed0 = {k: (v.incarnation, v.value_fact) for k, v in right0.fixed_subobjects.items()}
    apply_step(st, {"op": "swap_roots", "roots": ["left", "right"]})
    left, right = st.roots["left"], st.roots["right"]
    assert left.incarnation == left0.incarnation
    assert right.incarnation == right0.incarnation
    assert left.value_package.local == "B"
    assert right.value_package.local == "A"
    for name, child in left.fixed_subobjects.items():
        inc, fact = left_fixed0[name]
        assert child.incarnation == inc
        assert child.value_fact != fact
    for name, child in right.fixed_subobjects.items():
        inc, fact = right_fixed0[name]
        assert child.incarnation == inc
        assert child.value_fact != fact


def test_same_place_swap_is_exact_noop_including_value_facts():
    st = load_initial(_initial(cap_dep="LVA"))
    before = st.clone()
    apply_step(st, {"op": "swap_roots", "roots": ["left", "left"]})
    assert st.roots == before.roots
    assert st.live_value_facts == before.live_value_facts
    assert st.values == before.values


def test_aba_value_return_does_not_resurrect_old_current_value_identity():
    st = load_initial(_initial())
    initial = st.roots["left"]
    v0 = initial.root_value_fact
    f0 = {k: v.value_fact for k, v in initial.fixed_subobjects.items()}
    apply_step(st, {"op": "replace_root_package", "root": "left", "new_value": "new_left", "result_old": "old_a"})
    middle = st.roots["left"]
    v1 = middle.root_value_fact
    apply_step(st, {"op": "replace_root_package", "root": "left", "new_value": "old_a", "result_old": "old_c"})
    final = st.roots["left"]
    assert final.value_package.local == "A"  # semantic value returns to A
    assert v0 != v1 != final.root_value_fact
    assert final.root_value_fact != v0
    assert v0 not in st.live_value_facts
    for name, child in final.fixed_subobjects.items():
        assert child.value_fact != f0[name]
        assert f0[name] not in st.live_value_facts


def test_hidden_dependency_on_fixed_subobject_blocks_whole_replace_exact_and_production():
    init = _initial(cap_dep="LVA")
    st = load_initial(init)
    with pytest.raises(SemanticError) as exc:
        apply_step(st, {"op": "replace_root_package", "root": "left", "new_value": "new_left", "result_old": "old"})
    assert exc.value.kind == "DanglingSemanticDependency"

    program = UProgram({"main": UFunction("main", (ReplaceRoot("left", "new_left", "old"),))})
    result = ProductionChecker(program).analyze("main", init)
    assert not result.accepted
    assert "DanglingSemanticDependency" in result.reason


def test_hidden_dependency_on_unrelated_fixed_subobject_survives_other_root_update():
    init = _initial(cap_dep="RVA")
    st = load_initial(init)
    apply_step(st, {"op": "replace_root_package", "root": "left", "new_value": "new_left", "result_old": "old"})
    program = UProgram({"main": UFunction("main", (ReplaceRoot("left", "new_left", "old"),))})
    result = ProductionChecker(program).analyze("main", init)
    assert result.accepted


def test_hidden_fixed_subobject_dependency_blocks_distinct_swap_but_not_same_place_swap():
    init = _initial(cap_dep="LVA")
    distinct = UProgram({"main": UFunction("main", (SwapRoots("left", "right"),))})
    same = UProgram({"main": UFunction("main", (SwapRoots("left", "left"),))})
    assert not ProductionChecker(distinct).analyze("main", init).accepted
    assert ProductionChecker(same).analyze("main", init).accepted


def test_generated_current_value_exact_vs_production_pressure():
    result = run_current_value_pressure(seed=20261004, cases=4_000)
    assert result["mismatches"] == 0
    assert result["accepted"] > 0
    assert result["rejected"] > 0
