module Link
  struct { marker: u32 }
  fn make() -> Self { Self { marker: u32(0) } }
end

module Node
  struct { value: u32, link: Link }
  fn make() -> Self { Self { value: u32(1), link: Link::make() } }
  fn link_ptr(self: ptr<Self>) -> ptr<Link> { self@link }
end

fn main(slot: slot<Node>) -> slot<Node> {
  let life = lifetime_domain()
  let node = loan read life as stable { initialize(slot, Node::make(), stable) }
  let link = Node::link_ptr(node)
  let recovered: ptr<Node> = owner_ptr(link)
  let empty = loan exclusive read life as ending { destroy(node, ending) }
  finalize_domain(life)
  empty
}
