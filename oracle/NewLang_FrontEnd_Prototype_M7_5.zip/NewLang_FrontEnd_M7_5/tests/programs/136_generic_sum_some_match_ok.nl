sum Maybe<T> { None, Some(T) }
fn wrap<T>(x: T) -> Maybe<T> { Maybe::Some(x) }
fn unwrap(x: Maybe<u32>) -> u32 {
  match x {
    None => { u32(0) }
    Some(v) => { v }
  }
}
fn main() -> u32 { unwrap(wrap(u32(7))) }
