module Link
  struct { marker: u32 }
  fn make() -> Self { Self { marker: u32(0) } }
end

module Inner
  struct { link: Link }
  fn make() -> Self { Self { link: Link::make() } }
  fn link_ptr(self: ptr<Self>) -> ptr<Link> { self@link }
  fn owner_from_link(link: ptr<Link>) -> ptr<Self> { owner_ptr(link) }
end

module Outer
  struct { inner: Inner }
  fn make() -> Self { Self { inner: Inner::make() } }
  fn link_ptr(self: ptr<Self>) -> ptr<Link> { Inner::link_ptr(self@inner) }
end

fn main(slot: slot<Outer>) -> slot<Inner> {
  let life = lifetime_domain()
  let outer = loan read life as stable { initialize(slot, Outer::make(), stable) }
  let link = Outer::link_ptr(outer)
  let inner = Inner::owner_from_link(link)
  let empty_inner = loan exclusive read life as ending { destroy(inner, ending) }
  finalize_domain(life)
  empty_inner
}
