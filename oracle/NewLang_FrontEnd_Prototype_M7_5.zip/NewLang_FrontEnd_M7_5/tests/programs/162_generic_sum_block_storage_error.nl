sum Maybe<T> { None, Some(T) }
fn hold(x: Maybe<block() -> unit>) -> unit { unit }
fn main() -> unit { unit }
