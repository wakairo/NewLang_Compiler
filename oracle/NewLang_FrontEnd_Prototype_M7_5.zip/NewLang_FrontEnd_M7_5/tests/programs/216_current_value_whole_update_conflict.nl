module Pair
  struct { a: u32, b: u32 }
  fn make(a: u32, b: u32) -> Self { Self { a: a, b: b } }
end

fn main() -> unit {
  let p = Pair::make(u32(1), u32(2))
  loan write p as w {
    store(w, Pair::make(u32(3), u32(4)))
  }
}
