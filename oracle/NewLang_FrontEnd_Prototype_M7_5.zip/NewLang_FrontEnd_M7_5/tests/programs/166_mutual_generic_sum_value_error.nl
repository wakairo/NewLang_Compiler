sum Left<T> { End, More(Right<T>) }
sum Right<T> { End, More(Left<T>) }
fn main() -> unit { unit }
