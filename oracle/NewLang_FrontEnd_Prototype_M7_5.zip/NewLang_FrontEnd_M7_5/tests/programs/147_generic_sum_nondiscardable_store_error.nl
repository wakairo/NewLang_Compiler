sum Maybe<T> { None, Some(T) }
fn main() -> unit {
  let value = Maybe::Some(lifetime_domain())
  loan write value as w {
    store(w, Maybe::Some(lifetime_domain()))
  }
  unit
}
