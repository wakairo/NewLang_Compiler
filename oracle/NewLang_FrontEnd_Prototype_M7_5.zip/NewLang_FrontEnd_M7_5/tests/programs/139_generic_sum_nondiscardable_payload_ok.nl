sum Maybe<T> { None, Some(T) }
fn main(domain: LifetimeDomain) -> unit {
  let value = Maybe::Some(domain)
  match value {
    None => { unit }
    Some(d) => {
      finalize_domain(d)
      unit
    }
  }
  unit
}
