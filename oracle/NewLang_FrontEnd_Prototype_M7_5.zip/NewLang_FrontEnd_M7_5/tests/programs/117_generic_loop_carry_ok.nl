fn carry<T>(x: T) -> T {
  loop (value: T = x) -> T {
    break(value)
  }
}

fn main() -> u32 {
  carry(u32(7))
}
