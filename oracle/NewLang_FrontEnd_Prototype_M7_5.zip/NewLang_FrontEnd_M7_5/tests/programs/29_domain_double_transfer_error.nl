fn finish(d: LifetimeDomain) -> unit {
  finalize_domain(d)
}

fn main() -> unit {
  let life = lifetime_domain()
  finish(life)
  finish(life)
}
