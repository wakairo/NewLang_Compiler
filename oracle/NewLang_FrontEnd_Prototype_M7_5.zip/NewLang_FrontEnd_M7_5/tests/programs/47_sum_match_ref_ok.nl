sum MaybeU32 {
  None,
  Some(u32),
}

fn inspect(value: ref<read, MaybeU32>) -> u32 {
  match value {
    None => { u32(0) }
    Some(x) => {
      unit
      u32(1)
    }
  }
}

fn main() -> u32 {
  let value = MaybeU32::Some(u32(7))
  loan read value as r {
    inspect(r)
  }
}
