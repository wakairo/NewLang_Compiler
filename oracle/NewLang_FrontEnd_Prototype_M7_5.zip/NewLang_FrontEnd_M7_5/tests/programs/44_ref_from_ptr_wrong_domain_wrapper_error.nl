module Box
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn acquire(p: ptr<Box>, stable: ref<read, LifetimeDomain>) -> unit {
  let r = ref_from_ptr(read, p, stable)
  unit
}

fn main(slot: slot<Box>) -> slot<Box> {
  let first = lifetime_domain()
  let second = lifetime_domain()
  let p = loan read first as stable { initialize(slot, Box::make(u32(1)), stable) }
  loan read second as wrong { acquire(p, wrong) }
  let empty = loan exclusive read first as ending { destroy(p, ending) }
  finalize_domain(first)
  finalize_domain(second)
  empty
}
