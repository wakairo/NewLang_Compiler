module Box<T>
  struct { value: T }
  fn make(value: T) -> Self { Self { value: value } }
end

fn make_slot<T>(raw: Storage, witness: Layout<T>) -> slot<T> {
  storage_into_slot_layout(raw, witness)
}

fn main() -> unit {
  let witness: Layout<Box<u32>> = layout()
  let (alloc, raw) = allocate_storage(layout_size(witness), layout_align(witness))
  let slot = make_slot(raw, witness)
  let box = Box::make(u32(7))
  let life = lifetime_domain()
  let ptr = loan read life as stable { initialize(slot, box, stable) }
  let (value, empty) = loan exclusive read life as ending { take(ptr, ending) }
  finalize_domain(life)
  let raw2 = erase_slot(empty)
  deallocate_storage(alloc, raw2)
  unit
}
