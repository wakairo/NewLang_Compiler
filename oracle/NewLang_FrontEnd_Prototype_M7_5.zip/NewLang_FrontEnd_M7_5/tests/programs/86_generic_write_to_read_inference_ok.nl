module Key
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn generic_read<T>(x: ref<read, T>) -> u32 { u32(1) }

fn main() -> u32 {
  let key = Key::make(u32(1))
  loan write key as w { generic_read(w) }
}
