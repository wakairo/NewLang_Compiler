fn need_ops<T>(x: ref<read,T>) -> u32 {
  let a: u32 = op_a(x)
  let b: u32 = op_b(x)
  let c: u32 = op_c(x)
  a
}

fn wrap1<T>(x: ref<read,T>) -> u32 { need_ops(x) }
fn wrap2<T>(x: ref<read,T>) -> u32 { wrap1(x) }
fn wrap3<T>(x: ref<read,T>) -> u32 { wrap2(x) }
fn wrap4<T>(x: ref<read,T>) -> u32 { wrap3(x) }
fn wrap5<T>(x: ref<read,T>) -> u32 { wrap4(x) }
fn wrap6<T>(x: ref<read,T>) -> u32 { wrap5(x) }
fn wrap7<T>(x: ref<read,T>) -> u32 { wrap6(x) }
fn wrap8<T>(x: ref<read,T>) -> u32 { wrap7(x) }

fn main() -> u32 { u32(0) }
