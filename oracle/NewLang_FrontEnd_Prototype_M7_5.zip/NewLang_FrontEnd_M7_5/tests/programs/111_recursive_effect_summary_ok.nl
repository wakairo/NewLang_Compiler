module Box
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
  fn set(self: ref<write,Self>) -> unit {
    store(self@value, u32(1))
  }
end

fn recursive_set(x: ref<write,Box>) -> unit {
  recursive_set(x)
  Box::set(x)
}

fn main() -> unit {
  let box = Box::make(u32(0))
  loan write box as w {
    recursive_set(w)
  }
}
