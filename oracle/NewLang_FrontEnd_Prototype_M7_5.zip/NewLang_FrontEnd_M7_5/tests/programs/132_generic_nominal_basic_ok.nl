module Box<T>
  struct { value: T }
  fn make(value: T) -> Self { Self { value: value } }
  fn get(self: ref<read,Self>) -> ref<read,T> { self@value }
end

fn main() -> u32 {
  let box = Box::make(u32(7))
  loan read box as r {
    let x = r.get()
    u32(1)
  }
}
