module Box
  struct {
    value: u32
  }

  fn make(value: u32) -> Self {
    Self {
      value: value
    }
  }
end

fn main() -> Box {
  Box::make(u32(42))
}
