module Box<T>
  struct { value: T }
  fn make(value: T) -> Self { Self { value: value } }
end
module Pair<T>
  struct { left: T, right: T }
  fn make(left: T, right: T) -> Self { Self { left: left, right: right } }
end
fn main() -> unit {
  let pair = Pair::make(Box::make(u32(1)), Box::make(u32(2)))
  loan write pair as w {
    store(w, Pair::make(Box::make(u32(3)), Box::make(u32(4))))
  }
  unit
}
