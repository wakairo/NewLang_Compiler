module Empty<T>
  struct { }
  fn make() -> Self { Self { } }
end
fn main() -> unit {
  let value = Empty::make()
  unit
}
