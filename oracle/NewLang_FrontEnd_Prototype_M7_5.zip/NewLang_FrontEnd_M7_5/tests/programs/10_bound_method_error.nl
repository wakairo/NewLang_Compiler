module Box
  struct {
    value: u32
  }

  fn make(value: u32) -> Self {
    Self { value: value }
  }

  fn value(self: Self) -> u32 {
    self@value
  }
end

fn main() -> unit {
  let box = Box::make(u32(42))
  let getter = box.value
  unit
}
