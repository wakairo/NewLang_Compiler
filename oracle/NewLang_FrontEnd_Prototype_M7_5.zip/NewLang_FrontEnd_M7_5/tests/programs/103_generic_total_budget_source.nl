module Key
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

module Box
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn identity<T>(x: T) -> T { x }

fn main() -> u32 {
  let key = Key::make(u32(1))
  let box = Box::make(u32(2))
  let a = identity(key)
  let b = identity(box)
  identity(u32(3))
}
