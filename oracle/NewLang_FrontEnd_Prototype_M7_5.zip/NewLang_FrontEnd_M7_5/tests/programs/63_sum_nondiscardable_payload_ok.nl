sum MaybeDomain {
  None,
  Some(LifetimeDomain),
}

fn main() -> unit {
  let value = MaybeDomain::Some(lifetime_domain())
  match value {
    None => { unit }
    Some(domain) => {
      finalize_domain(domain)
      unit
    }
  }
  unit
}
