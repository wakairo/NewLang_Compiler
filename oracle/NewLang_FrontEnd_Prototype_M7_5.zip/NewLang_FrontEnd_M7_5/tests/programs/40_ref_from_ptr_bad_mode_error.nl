module Box
  struct { value: u32 }
end

fn main(p: ptr<Box>, stable: ref<read, LifetimeDomain>) -> unit {
  let r = ref_from_ptr(foo, p, stable)
  unit
}
