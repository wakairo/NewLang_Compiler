module Node
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

module Holder
  struct { saved: ptr<Node> }
  fn make(saved: ptr<Node>) -> Self { Self { saved: saved } }
  fn get(self: Self) -> ptr<Node> { self@saved }
end

fn main() -> unit {
  let witness: Layout<Node> = layout()
  let (a_alloc, a_raw) = allocate_storage(layout_size(witness), layout_align(witness))
  let a_slot: slot<Node> = storage_into_slot_layout(a_raw, witness)
  let (b_alloc, b_raw) = allocate_storage(layout_size(witness), layout_align(witness))
  let b_slot: slot<Node> = storage_into_slot_layout(b_raw, witness)

  let life_a = lifetime_domain()
  let a = loan read life_a as stable { initialize(a_slot, Node::make(u32(1)), stable) }
  let life_b = lifetime_domain()
  let b = loan read life_b as stable { initialize(b_slot, Node::make(u32(2)), stable) }
  let holder = Holder::make(a)

  loan read life_a as stable_a {
    loan read life_b as stable_b {
      let ar = ref_from_ptr(write, a, stable_a)
      let br = ref_from_ptr(write, b, stable_b)
      swap(ar, br)
    }
  }

  let observed = Holder::get(holder)
  loan read life_a as stable {
    let still_live = ref_from_ptr(read, observed, stable)
    unit
  }

  let a_empty = loan exclusive read life_a as ending { destroy(a, ending) }
  finalize_domain(life_a)
  let b_empty = loan exclusive read life_b as ending { destroy(b, ending) }
  finalize_domain(life_b)
  let a_raw2 = erase_slot(a_empty)
  deallocate_storage(a_alloc, a_raw2)
  let b_raw2 = erase_slot(b_empty)
  deallocate_storage(b_alloc, b_raw2)
  unit
}
