fn main(life: LifetimeDomain) -> LifetimeDomain {
  loan read life as stable {
    finalize_domain(life)
  }
  life
}
