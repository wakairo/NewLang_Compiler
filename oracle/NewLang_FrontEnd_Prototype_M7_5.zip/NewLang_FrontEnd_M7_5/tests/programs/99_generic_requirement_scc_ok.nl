fn a<T>(x: ref<read,T>) -> u32 {
  b(x)
}

fn b<U>(x: ref<read,U>) -> u32 {
  let h: u32 = hash(x)
  a(x)
}

fn main() -> u32 {
  u32(0)
}
