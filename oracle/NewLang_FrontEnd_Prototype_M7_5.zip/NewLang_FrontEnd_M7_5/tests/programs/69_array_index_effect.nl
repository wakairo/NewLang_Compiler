fn set_first(values: ref<write, Array<u32, 2>>) -> unit {
  store(values[usize(0)], u32(9))
}

fn main(values: Array<u32, 2>) -> unit {
  loan write values as w {
    set_first(w)
  }
}
