module Key
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

module Box<T>
  struct { value: T }
  fn make(value: T) -> Self { Self { value: value } }
end

fn main() -> unit {
  let a = Box::make(u32(1))
  let b = Box::make(Key::make(u32(2)))
  unit
}
