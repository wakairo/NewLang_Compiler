fn main(domains: Array<LifetimeDomain, 1>) -> unit {
  consume_array(domains, { |domain: LifetimeDomain|
    unit
  })
  unit
}
