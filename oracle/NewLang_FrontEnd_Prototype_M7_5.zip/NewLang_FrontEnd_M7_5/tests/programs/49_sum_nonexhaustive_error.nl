sum MaybeU32 {
  None,
  Some(u32),
}

fn main() -> u32 {
  let value = MaybeU32::Some(u32(7))
  match value {
    Some(x) => { x }
  }
}
