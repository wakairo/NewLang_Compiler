fn twice<K>(x: ref<read,K>) -> u32 {
  let first: u32 = hash(x)
  hash(x)
}

fn main() -> u32 {
  u32(0)
}
