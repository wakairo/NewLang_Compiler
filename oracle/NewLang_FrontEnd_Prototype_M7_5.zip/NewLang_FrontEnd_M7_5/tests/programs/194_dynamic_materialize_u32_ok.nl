fn main(value: u32) -> unit {
  let (alloc0, whole) = allocate_storage(usize(8), usize(4))
  let alloc1 = unchecked_dematerialize_storage(alloc0, whole)
  let (alloc2, slot): (Allocation, slot<u32>) = unchecked_materialize_slot(alloc1, usize(4))
  let life = lifetime_domain()
  let p = loan read life as stable { initialize(slot, value, stable) }
  let (old, empty) = loan exclusive read life as ending { take(p, ending) }
  finalize_domain(life)
  let raw = erase_slot(empty)
  let alloc3 = unchecked_dematerialize_storage(alloc2, raw)
  let (alloc4, recovered) = unchecked_recover_whole_storage(alloc3)
  deallocate_storage(alloc4, recovered)
  unit
}
