sum Maybe<T> { None, Some(T) }
module Node<T>
  struct { next: Maybe<Self>, value: T }
end
fn main() -> unit { unit }
