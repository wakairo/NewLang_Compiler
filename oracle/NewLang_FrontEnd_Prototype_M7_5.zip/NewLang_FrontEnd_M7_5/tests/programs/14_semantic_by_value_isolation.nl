module Box
  struct { value: u32 }
  fn touch_copy(self: Self) -> unit {
    loan write self as w {
      store(w@value, u32(9))
    }
  }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn main() -> unit {
  let b = Box::make(u32(1))
  b.touch_copy()
}
