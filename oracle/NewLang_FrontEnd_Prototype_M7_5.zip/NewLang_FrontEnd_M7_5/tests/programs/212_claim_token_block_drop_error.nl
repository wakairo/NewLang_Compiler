fn drop_claim<T>(claim: slot<T>, f: block(slot<T>) -> Storage) -> unit {
  unit
}

fn main(claim: slot<u32>) -> unit {
  drop_claim(claim, { |x: slot<u32>| erase_slot(x) })
  unit
}
