fn main(domains: Array<LifetimeDomain, 1>) -> unit {
  consume_array(domains, { |domain: LifetimeDomain|
    finalize_domain(domain)
    unit
  })
  consume_array(domains, { |domain: LifetimeDomain|
    finalize_domain(domain)
    unit
  })
  unit
}
