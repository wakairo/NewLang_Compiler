module Box
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
  fn set(self: ref<write,Self>) -> unit {
    store(self@value, u32(9))
  }
end

fn set_any<T>(x: ref<write,T>) -> unit {
  set(x)
}

fn outer<U>(x: ref<write,U>) -> unit {
  set_any(x)
}

fn main() -> unit {
  let box = Box::make(u32(1))
  loan write box as w {
    outer(w)
  }
}
