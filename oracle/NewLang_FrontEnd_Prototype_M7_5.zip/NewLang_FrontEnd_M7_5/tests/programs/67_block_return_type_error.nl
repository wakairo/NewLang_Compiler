fn bad() -> block(u32) -> unit {
  { |x: u32| unit }
}
