module Box
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn move_out<T>(p: ptr<T>, ending: exclusive ref<read, LifetimeDomain>) -> (T, slot<T>) {
  take(p, ending)
}

fn main(slot: slot<Box>) -> slot<Box> {
  let life = lifetime_domain()
  let p = loan read life as stable {
    initialize(slot, Box::make(u32(42)), stable)
  }
  let (value, empty) = loan exclusive read life as ending {
    move_out(p, ending)
  }
  finalize_domain(life)
  empty
}
