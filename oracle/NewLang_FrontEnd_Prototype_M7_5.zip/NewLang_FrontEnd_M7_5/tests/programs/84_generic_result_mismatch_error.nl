module Key
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
  fn hash(self: ref<read, Self>) -> usize { usize(1) }
end

fn generic_hash<K>(key: ref<read, K>) -> u32 {
  hash(key)
}

fn main() -> u32 {
  let key = Key::make(u32(1))
  loan read key as r { generic_hash(r) }
}
