sum Maybe<T> { Empty, Full(T) }
module Box<T>
  struct { value: Maybe<T> }
end
fn hold(x: Box<block() -> unit>) -> unit { unit }
fn main() -> unit { unit }
