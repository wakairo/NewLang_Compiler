module Box

  struct {
    value: u32
  }

  fn make(value: u32) -> Self {
    Self { value: value }
  }

  fn inspect(self: ref<read, Self>) -> unit {
    unit
  }

end

fn main(slot: slot<Box>) -> slot<Box> {
  let life = lifetime_domain()
  let p = loan read life as stable {
    initialize(slot, Box::make(u32(42)), stable)
  }

  loan read life as stable {
    let r = ref_from_ptr(read, p, stable)
    r.inspect()
  }

  let empty = loan exclusive read life as ending {
    destroy(p, ending)
  }
  finalize_domain(life)
  empty
}
