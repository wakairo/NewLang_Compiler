sum Maybe<T> { None, Some(T) }
fn main() -> unit {
  let value = Maybe::Some(u32(1))
  loan write value as w {
    store(w, Maybe::Some(u32(2)))
  }
  unit
}
