fn main(domains: Array<LifetimeDomain, 0>, life: LifetimeDomain) -> unit {
  consume_array(domains, { |domain: LifetimeDomain|
    finalize_domain(life)
    finalize_domain(domain)
    unit
  })
  unit
}
