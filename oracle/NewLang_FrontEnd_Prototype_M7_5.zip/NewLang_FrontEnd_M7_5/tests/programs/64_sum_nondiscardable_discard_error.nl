sum MaybeDomain {
  None,
  Some(LifetimeDomain),
}

fn main() -> unit {
  let value = MaybeDomain::Some(lifetime_domain())
  match value {
    None => { unit }
    Some(_) => { unit }
  }
  unit
}
