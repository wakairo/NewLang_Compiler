fn loop(x: u32) -> u32 {
  loop(x)
}

fn main() -> u32 {
  loop(u32(1))
}
