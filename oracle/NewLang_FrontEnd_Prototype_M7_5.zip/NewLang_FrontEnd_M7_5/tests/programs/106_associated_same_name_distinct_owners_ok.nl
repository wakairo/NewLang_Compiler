module KeyA
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
  fn hash(self: ref<read,Self>) -> u32 { u32(1) }
end

module KeyB
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
  fn hash(self: ref<read,Self>) -> u32 { u32(2) }
end

fn generic_hash<K>(x: ref<read,K>) -> u32 {
  hash(x)
}

fn instantiate_a() -> u32 {
  let a = KeyA::make(u32(1))
  loan read a as ar { generic_hash(ar) }
}

fn main() -> u32 {
  let b = KeyB::make(u32(2))
  loan read b as br { generic_hash(br) }
}
