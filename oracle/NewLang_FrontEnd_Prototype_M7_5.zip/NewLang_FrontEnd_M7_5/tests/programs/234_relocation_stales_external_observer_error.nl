module Node
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

module Holder
  struct { saved: ptr<Node> }
  fn make(saved: ptr<Node>) -> Self { Self { saved: saved } }
  fn get(self: Self) -> ptr<Node> { self@saved }
end

fn main() -> unit {
  let witness: Layout<Node> = layout()
  let (src_alloc, src_raw) = allocate_storage(layout_size(witness), layout_align(witness))
  let src_slot: slot<Node> = storage_into_slot_layout(src_raw, witness)
  let life1 = lifetime_domain()
  let p1 = loan read life1 as stable {
    initialize(src_slot, Node::make(u32(1)), stable)
  }
  let holder = Holder::make(p1)
  let (value, empty1) = loan exclusive read life1 as ending {
    take(p1, ending)
  }
  finalize_domain(life1)

  let (dst_alloc, dst_raw) = allocate_storage(layout_size(witness), layout_align(witness))
  let dst_slot: slot<Node> = storage_into_slot_layout(dst_raw, witness)
  let life2 = lifetime_domain()
  let p2 = loan read life2 as stable {
    initialize(dst_slot, value, stable)
  }

  let old_place = Holder::get(holder)
  loan read life2 as stable {
    let old_ref = ref_from_ptr(read, old_place, stable)
    unit
  }

  let empty2 = loan exclusive read life2 as ending { destroy(p2, ending) }
  finalize_domain(life2)
  let src_raw2 = erase_slot(empty1)
  deallocate_storage(src_alloc, src_raw2)
  let dst_raw2 = erase_slot(empty2)
  deallocate_storage(dst_alloc, dst_raw2)
  unit
}
