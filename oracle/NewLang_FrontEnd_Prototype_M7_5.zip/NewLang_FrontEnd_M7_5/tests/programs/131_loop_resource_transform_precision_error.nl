fn main() -> unit {
  loop (i: u32 = u32(0)) -> unit {
    let domain = lifetime_domain()
    finalize_domain(domain)
    continue(i)
  }
}
