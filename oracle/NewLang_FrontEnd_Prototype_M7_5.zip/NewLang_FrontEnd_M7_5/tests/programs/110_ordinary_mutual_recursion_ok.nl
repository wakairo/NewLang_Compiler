fn a(x: u32) -> u32 {
  b(x)
}

fn b(x: u32) -> u32 {
  a(x)
}

fn main() -> u32 {
  a(u32(1))
}
