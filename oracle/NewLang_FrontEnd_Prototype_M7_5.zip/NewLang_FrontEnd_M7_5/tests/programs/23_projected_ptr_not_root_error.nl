module Box

  struct {
    value: u32
  }

  fn make(value: u32) -> Self {
    Self { value: value }
  }

  fn destroy_value(
    self: ptr<Self>,
    ending: exclusive ref<read, LifetimeDomain>
  ) -> slot<u32> {
    destroy(self@value, ending)
  }

end

fn main(slot: slot<Box>) -> slot<u32> {
  let life = lifetime_domain()
  let p = loan read life as stable {
    initialize(slot, Box::make(u32(1)), stable)
  }
  let field_slot = loan exclusive read life as ending {
    p.destroy_value(ending)
  }
  finalize_domain(life)
  field_slot
}
