module Link
  struct { marker: u32 }
  fn make() -> Self { Self { marker: u32(0) } }
end

module Node
  struct { link: Link }
  fn make() -> Self { Self { link: Link::make() } }
  fn link_ptr_via_ref(self: ptr<Self>, stable: ref<read, LifetimeDomain>) -> ptr<Link> {
    let node_ref = ref_from_ptr(read, self, stable)
    ptr_from_ref(node_ref@link)
  }
  fn owner(link: ptr<Link>) -> ptr<Self> { owner_ptr(link) }
end

fn main(slot: slot<Node>) -> slot<Node> {
  let life = lifetime_domain()
  let node = loan read life as stable { initialize(slot, Node::make(), stable) }
  let link = loan read life as stable { Node::link_ptr_via_ref(node, stable) }
  let recovered = Node::owner(link)
  let empty = loan exclusive read life as ending { destroy(recovered, ending) }
  finalize_domain(life)
  empty
}
