fn main(domains: Array<LifetimeDomain, 0>) -> unit {
  consume_array(domains, { |domain: LifetimeDomain|
    finalize_domain(domain)
    unit
  })
  unit
}
