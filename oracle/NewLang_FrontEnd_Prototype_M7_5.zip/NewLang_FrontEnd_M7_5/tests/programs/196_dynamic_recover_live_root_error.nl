fn main(value: u32) -> unit {
  let (alloc0, whole) = allocate_storage(usize(8), usize(4))
  let alloc1 = unchecked_dematerialize_storage(alloc0, whole)
  let (alloc2, slot): (Allocation, slot<u32>) = unchecked_materialize_slot(alloc1, usize(0))
  let life = lifetime_domain()
  let p = loan read life as stable { initialize(slot, value, stable) }
  let (alloc3, recovered) = unchecked_recover_whole_storage(alloc2)
  unit
}
