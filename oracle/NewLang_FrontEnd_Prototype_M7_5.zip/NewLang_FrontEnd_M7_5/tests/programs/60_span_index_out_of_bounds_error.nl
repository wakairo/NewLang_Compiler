fn main(values: Array<u32, 2>) -> unit {
  loan read values as a {
    let s = array_span(a)
    let x = s[usize(3)]
    unit
  }
}
