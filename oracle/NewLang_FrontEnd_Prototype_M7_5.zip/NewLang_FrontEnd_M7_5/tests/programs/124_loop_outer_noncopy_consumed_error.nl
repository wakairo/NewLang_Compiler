fn main() -> unit {
  let domain = lifetime_domain()
  let result = loop (current: LifetimeDomain = domain) -> LifetimeDomain {
    break(current)
  }
  finalize_domain(domain)
}
