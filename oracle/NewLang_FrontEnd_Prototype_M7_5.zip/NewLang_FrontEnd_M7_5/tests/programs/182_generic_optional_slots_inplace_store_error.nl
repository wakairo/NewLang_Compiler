sum Maybe<T> { Empty, Full(T) }
module Slots2<T>
  struct { first: Maybe<T>, second: Maybe<T> }
  fn overwrite_first(self: ref<write,Self>, value: T) -> unit {
    store(self@first, Maybe::Full(value))
  }
end
fn main() -> unit { unit }
