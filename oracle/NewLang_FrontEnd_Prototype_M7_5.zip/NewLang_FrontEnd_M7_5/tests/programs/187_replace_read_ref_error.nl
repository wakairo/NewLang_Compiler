fn bad(dst: ref<read,u32>) -> u32 {
  replace(dst, u32(1))
}
