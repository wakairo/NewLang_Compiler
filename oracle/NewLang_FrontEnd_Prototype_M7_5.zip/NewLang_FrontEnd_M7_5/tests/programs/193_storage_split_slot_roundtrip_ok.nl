fn main(a: u32, b: u32) -> unit {
  let (alloc, whole) = allocate_storage(usize(8), usize(4))
  let (left, right) = split_storage(whole, usize(4))
  let s0: slot<u32> = storage_into_slot(left)
  let s1: slot<u32> = storage_into_slot(right)
  let life = lifetime_domain()
  let p0 = loan read life as stable { initialize(s0, a, stable) }
  let p1 = loan read life as stable { initialize(s1, b, stable) }
  let (v0, e0) = loan exclusive read life as ending { take(p0, ending) }
  let (v1, e1) = loan exclusive read life as ending { take(p1, ending) }
  finalize_domain(life)
  let r0 = erase_slot(e0)
  let r1 = erase_slot(e1)
  let merged = merge_storage(r0, r1)
  deallocate_storage(alloc, merged)
  unit
}
