module Box
  struct {
    value: u32
  }

  fn make(value: u32) -> Self {
    Self { value: value }
  }

  fn value(self: Self) -> u32 {
    self@value
  }
end

fn main() -> u32 {
  Box::make(u32(7)).value()
}
