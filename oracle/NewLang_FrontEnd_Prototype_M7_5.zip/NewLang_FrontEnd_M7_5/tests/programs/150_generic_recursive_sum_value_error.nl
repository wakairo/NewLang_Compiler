sum Chain<T> { End, More(Chain<T>) }
fn main() -> unit { unit }
