module NoHash
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn generic_hash<K>(key: ref<read, K>) -> u32 {
  hash(key)
}

fn main() -> u32 {
  let key = NoHash::make(u32(1))
  loan read key as r { generic_hash(r) }
}
