module Key
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn first<A,B>(a: A, b: B) -> A { a }

fn main() -> u32 {
  let key = Key::make(u32(1))
  first(u32(5), key)
}
