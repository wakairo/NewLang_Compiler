module Link
  struct { marker: u32 }
  fn make(value: u32) -> Self { Self { marker: value } }
end

module Node
  struct { first: Link, second: Link }
  fn make() -> Self { Self { first: Link::make(u32(1)), second: Link::make(u32(2)) } }
  fn first_ptr(self: ptr<Self>) -> ptr<Link> { self@first }
  fn second_ptr(self: ptr<Self>) -> ptr<Link> { self@second }
  fn owner(link: ptr<Link>) -> ptr<Self> { owner_ptr(link) }
end

fn main(slot: slot<Node>) -> slot<Node> {
  let life = lifetime_domain()
  let node = loan read life as stable { initialize(slot, Node::make(), stable) }
  let first_owner = Node::owner(Node::first_ptr(node))
  let second_owner = Node::owner(Node::second_ptr(node))
  loan read life as stable {
    let a = ref_from_ptr(read, first_owner, stable)
    let b = ref_from_ptr(read, second_owner, stable)
    unit
  }
  let empty = loan exclusive read life as ending { destroy(first_owner, ending) }
  finalize_domain(life)
  empty
}
