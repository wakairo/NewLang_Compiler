sum Decision {
  Found,
  Next,
}

module Box
  struct { value: u32 }
  fn equal(self: ref<read,Self>, other: ref<read,Self>) -> Decision {
    Decision::Next()
  }
end

fn next(i: usize) -> usize { i }

fn find<K>(items: span<read,K>, key: ref<read,K>) -> usize {
  loop (i: usize = usize(0)) -> usize {
    let decision: Decision = equal(items[i], key)
    match decision {
      Found => { break(i) }
      Next => { continue(next(i)) }
    }
  }
}

fn instantiate(items: span<read,Box>, key: ref<read,Box>) -> usize {
  find(items, key)
}

fn main() -> unit { unit }
