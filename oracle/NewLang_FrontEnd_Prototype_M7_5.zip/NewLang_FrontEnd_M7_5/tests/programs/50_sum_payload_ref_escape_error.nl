sum EitherU32 {
  A(u32),
  B(u32),
}

fn escape(value: ref<read, EitherU32>) -> ref<read, u32> {
  match value {
    A(x) => { x }
    B(x) => { x }
  }
}
