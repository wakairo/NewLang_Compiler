sum Maybe<T> { Empty, Full(T) }
module Slot<T>
  struct { value: Maybe<T> }
  fn from(value: T) -> Self {
    Self { value: Maybe::Empty() }
  }
end
fn main() -> unit {
  let slot = Slot::from(u32(1))
  unit
}
