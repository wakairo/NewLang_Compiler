module Link
  struct { marker: u32 }
  fn make() -> Self { Self { marker: u32(0) } }
end

module Inner
  struct { link: Link }
  fn make() -> Self { Self { link: Link::make() } }
  fn link_ptr(self: ptr<Self>) -> ptr<Link> { self@link }
end

module Outer
  struct { inner: Inner, value: u32 }
  fn make() -> Self { Self { inner: Inner::make(), value: u32(9) } }
  fn link_ptr(self: ptr<Self>) -> ptr<Link> { Inner::link_ptr(self@inner) }
  fn owner_from_link(link: ptr<Link>) -> ptr<Self> { owner_ptr(link) }
end

fn main(slot: slot<Outer>) -> slot<Outer> {
  let life = lifetime_domain()
  let outer = loan read life as stable { initialize(slot, Outer::make(), stable) }
  let link = Outer::link_ptr(outer)
  let recovered = Outer::owner_from_link(link)
  let empty = loan exclusive read life as ending { destroy(recovered, ending) }
  finalize_domain(life)
  empty
}
