module Box<T>
  struct { value: T }
  fn make(value: T) -> Self { Self { value: value } }
end
fn main() -> unit {
  let box = Box::make({ || unit })
  unit
}
