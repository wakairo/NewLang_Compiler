sum Maybe<T> { None, Some(T) }
fn main() -> unit {
  let x = Maybe::None()
  unit
}
