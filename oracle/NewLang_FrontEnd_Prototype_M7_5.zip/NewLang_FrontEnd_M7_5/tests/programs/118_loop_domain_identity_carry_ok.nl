sum Step {
  Again,
  Done,
}

fn main() -> LifetimeDomain {
  loop (
    domain: LifetimeDomain = lifetime_domain(),
    state: Step = Step::Again()
  ) -> LifetimeDomain {
    match state {
      Again => { continue(domain, Step::Done()) }
      Done => { break(domain) }
    }
  }
}
