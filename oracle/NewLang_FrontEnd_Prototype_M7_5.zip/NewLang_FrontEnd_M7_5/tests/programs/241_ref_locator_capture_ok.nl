module Box
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn save_locator(value: ref<read,Box>) -> ptr<Box> {
  ptr_from_ref(value)
}

fn main() -> unit {
  let box = Box::make(u32(1))
  let saved = loan read box as view { save_locator(view) }
  unit
}
