module Box<T>
  struct { value: T }
end
fn bad(x: Box<u32,u32>) -> unit { unit }
fn main() -> unit { unit }
