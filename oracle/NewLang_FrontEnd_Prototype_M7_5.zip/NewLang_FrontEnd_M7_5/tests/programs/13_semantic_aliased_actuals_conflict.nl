module Box
  struct { value: u32 }
  fn set_other(self: ref<write, Self>, other: ref<write, Self>, value: u32) -> unit {
    store(other@value, value)
  }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn main() -> unit {
  let b = Box::make(u32(1))
  loan write b as w {
    w.set_other(w, u32(2))
  }
}
