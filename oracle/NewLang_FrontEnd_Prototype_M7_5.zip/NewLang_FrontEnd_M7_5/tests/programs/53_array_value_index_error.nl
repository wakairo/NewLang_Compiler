fn main(values: Array<u32, 2>) -> ref<read, u32> {
  values[usize(0)]
}
