module Box
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn to_ptr(x: ref<read, Box>) -> ptr<Box> {
  ptr_from_ref(x)
}

fn main(slot: slot<Box>) -> slot<Box> {
  let life = lifetime_domain()
  let p = loan read life as stable { initialize(slot, Box::make(u32(1)), stable) }
  let q = loan read life as stable {
    let r = ref_from_ptr(read, p, stable)
    to_ptr(r)
  }
  let empty = loan exclusive read life as ending { destroy(q, ending) }
  finalize_domain(life)
  empty
}
