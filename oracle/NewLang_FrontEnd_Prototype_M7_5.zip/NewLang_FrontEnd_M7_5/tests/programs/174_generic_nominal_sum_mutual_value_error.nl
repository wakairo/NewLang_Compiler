sum Link<T> { End, More(Node<T>) }
module Node<T>
  struct { next: Link<T>, value: T }
end
fn main() -> unit { unit }
