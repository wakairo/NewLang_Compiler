fn grow<T>(x: T) -> unit {
  loan read x as r {
    grow(ptr_from_ref(r))
  }
}

fn main() -> unit {
  grow(u32(1))
}
