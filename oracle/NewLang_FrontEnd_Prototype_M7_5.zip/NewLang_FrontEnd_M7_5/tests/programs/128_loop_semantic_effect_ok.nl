module Box
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
  fn set(self: ref<write,Self>) -> unit {
    store(self@value, u32(9))
  }
end

fn main() -> unit {
  let box = Box::make(u32(1))
  loan write box as w {
    loop (i: u32 = u32(0)) -> unit {
      Box::set(w)
      break()
    }
  }
}
