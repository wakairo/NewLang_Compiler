fn scan(values: span<read, u32>) -> unit {
  unit
}

fn main(values: Array<u32, 2>) -> unit {
  loan write values as a {
    let s = array_span(a)
    scan(s)
  }
}
