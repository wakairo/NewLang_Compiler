module Box

  struct {
    value: u32
  }

  fn make(value: u32) -> Self {
    Self { value: value }
  }

end

fn main(slot: slot<Box>) -> slot<Box> {
  let life = lifetime_domain()
  let p = loan read life as stable {
    initialize(slot, Box::make(u32(1)), stable)
  }
  let pair = loan read life as stable {
    take(p, stable)
  }
  finalize_domain(life)
  slot
}
