module Box

  struct {
    value: u32
  }

  fn make(value: u32) -> Self {
    Self { value: value }
  }

end

fn main(slot: slot<Box>, life: LifetimeDomain) -> ptr<Box> {
  initialize(slot, Box::make(u32(1)), life)
}
