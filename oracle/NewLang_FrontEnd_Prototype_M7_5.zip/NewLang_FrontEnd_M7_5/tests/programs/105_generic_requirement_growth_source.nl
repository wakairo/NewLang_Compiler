fn grow_requirements<T>(x: T) -> u32 {
  let h: u32 = hash(x)
  loan read x as r {
    grow_requirements(ptr_from_ref(r))
  }
}

fn main() -> u32 { u32(0) }
