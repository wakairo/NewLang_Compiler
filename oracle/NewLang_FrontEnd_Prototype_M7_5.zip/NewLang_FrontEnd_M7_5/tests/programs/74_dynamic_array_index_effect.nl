fn set_at(values: ref<write, Array<u32, 3>>, i: usize) -> unit {
  store(values[i], u32(9))
}

fn main(values: Array<u32, 3>, i: usize) -> unit {
  loan write values as w {
    set_at(w, i)
  }
  unit
}
