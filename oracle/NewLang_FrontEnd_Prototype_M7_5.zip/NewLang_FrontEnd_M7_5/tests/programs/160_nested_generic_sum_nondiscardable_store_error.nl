sum Maybe<T> { None, Some(T) }
fn main() -> unit {
  let value: Maybe<Maybe<LifetimeDomain>> = Maybe::Some(Maybe::Some(lifetime_domain()))
  loan write value as w {
    store(w, Maybe::Some(Maybe::Some(lifetime_domain())))
  }
  unit
}
