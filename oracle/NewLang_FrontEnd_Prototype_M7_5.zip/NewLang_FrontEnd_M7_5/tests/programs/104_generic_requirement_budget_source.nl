fn needs_two<K>(x: ref<read,K>) -> u32 {
  let h: u32 = hash(x)
  let e: u32 = equal_hash(x)
  h
}

fn main() -> u32 { u32(0) }
