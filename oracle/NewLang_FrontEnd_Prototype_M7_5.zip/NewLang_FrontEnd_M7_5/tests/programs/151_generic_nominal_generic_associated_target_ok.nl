module Box<T>
  struct { value: T }
  fn make(value: T) -> Self { Self { value: value } }
  fn echo<U>(self: ref<read,Self>, value: U) -> U { value }
end
fn generic_echo<K,V>(key: ref<read,K>, value: V) -> V { echo(key, value) }
fn main() -> u32 {
  let box = Box::make(u32(1))
  loan read box as r { generic_echo(r, u32(9)) }
}
