sum Maybe<T> { None, Some(T) }

fn main() -> unit {
  let witness: Layout<Maybe<u32>> = layout()
  let (alloc, raw) = allocate_layout(witness, usize(1))
  let slot: slot<Maybe<u32>> = storage_into_slot_layout(raw, witness)
  let raw2 = erase_slot(slot)
  deallocate_storage(alloc, raw2)
  unit
}
