module Box
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn main() -> unit {
  let box = Box::make(u32(1))
  loan read box as r {
    let p = ptr_from_ref(r)
    unit
  }
}
