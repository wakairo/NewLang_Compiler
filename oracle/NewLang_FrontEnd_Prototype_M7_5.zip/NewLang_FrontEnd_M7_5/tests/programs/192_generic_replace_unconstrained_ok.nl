fn replace_any<T>(dst: ref<write,T>, value: T) -> T {
  replace(dst, value)
}

fn main(old: LifetimeDomain, new_value: LifetimeDomain) -> unit {
  let current = old
  let previous = loan write current as w {
    replace_any(w, new_value)
  }
  finalize_domain(previous)
  finalize_domain(current)
  unit
}
