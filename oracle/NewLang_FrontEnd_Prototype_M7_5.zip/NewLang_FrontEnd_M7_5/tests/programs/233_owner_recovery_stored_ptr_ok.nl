module Link
  struct { marker: u32 }
  fn make() -> Self { Self { marker: u32(0) } }
end

module Node
  struct { link: Link }
  fn make() -> Self { Self { link: Link::make() } }
  fn link_ptr(self: ptr<Self>) -> ptr<Link> { self@link }
  fn owner(link: ptr<Link>) -> ptr<Self> { owner_ptr(link) }
end

module Holder
  struct { saved: ptr<Link> }
  fn make(saved: ptr<Link>) -> Self { Self { saved: saved } }
  fn get(self: Self) -> ptr<Link> { self@saved }
end

fn main(slot: slot<Node>) -> slot<Node> {
  let life = lifetime_domain()
  let node = loan read life as stable { initialize(slot, Node::make(), stable) }
  let holder = Holder::make(Node::link_ptr(node))
  let saved = Holder::get(holder)
  let recovered = Node::owner(saved)
  let empty = loan exclusive read life as ending { destroy(recovered, ending) }
  finalize_domain(life)
  empty
}
