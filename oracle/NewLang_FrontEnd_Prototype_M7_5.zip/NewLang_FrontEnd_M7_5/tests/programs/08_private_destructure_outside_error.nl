module Box
  struct {
    value: u32
  }

  fn make(value: u32) -> Self {
    Self { value: value }
  }
end

fn main() -> u32 {
  let box = Box::make(u32(42))
  let Box { value } = box
  value
}
