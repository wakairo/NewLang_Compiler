module A<T>
  struct { next: ptr<B<T>>, value: T }
end
module B<T>
  struct { next: ptr<A<T>>, value: T }
end
fn main() -> unit { unit }
