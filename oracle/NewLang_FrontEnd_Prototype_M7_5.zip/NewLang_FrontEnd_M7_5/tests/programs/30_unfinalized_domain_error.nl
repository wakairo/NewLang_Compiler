fn main() -> unit {
  let life = lifetime_domain()
  unit
}
