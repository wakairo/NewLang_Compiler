fn skip<T>(claim: slot<T>, f: block(slot<T>) -> Storage) -> Storage {
  erase_slot(claim)
}

fn main(claim: slot<u32>) -> Storage {
  skip(claim, { |x: slot<u32>| erase_slot(x) })
}
