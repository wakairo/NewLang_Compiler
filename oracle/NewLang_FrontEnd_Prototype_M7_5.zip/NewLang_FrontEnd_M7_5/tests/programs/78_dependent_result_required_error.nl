fn bad<K>(key: ref<read, K>) -> u32 {
  let h = hash(key)
  u32(0)
}

fn main() -> u32 { u32(0) }
