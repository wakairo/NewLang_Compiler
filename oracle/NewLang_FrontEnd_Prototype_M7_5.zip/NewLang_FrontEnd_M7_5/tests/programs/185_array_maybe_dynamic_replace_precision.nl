sum Maybe<T> { Empty, Full(T) }

fn main(slots: Array<Maybe<u32>,2>, i: usize) -> unit {
  loan write slots as w {
    let old = replace(w[i], Maybe::Full(u32(9)))
    unit
  }
  unit
}
