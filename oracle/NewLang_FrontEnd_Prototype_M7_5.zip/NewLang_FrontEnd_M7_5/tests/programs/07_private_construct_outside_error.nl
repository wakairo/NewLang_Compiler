module Box
  struct {
    value: u32
  }
end

fn main() -> Box {
  Box { value: u32(42) }
}
