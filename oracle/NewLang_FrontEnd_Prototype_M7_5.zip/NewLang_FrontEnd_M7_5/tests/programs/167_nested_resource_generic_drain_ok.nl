module Fixed2<T>
  struct { values: Array<T,2> }
  fn make(values: Array<T,2>) -> Self { Self { values: values } }
  fn drain(self: Self, f: block(T) -> unit) -> unit {
    let Self { values } = self
    consume_array(values, f)
  }
end
module Box<T>
  struct { value: T }
  fn make(value: T) -> Self { Self { value: value } }
  fn drain(self: Self, f: block(T) -> unit) -> unit {
    let Self { value } = self
    f(value)
  }
end
fn main(values: Array<LifetimeDomain,2>) -> unit {
  let bag = Fixed2::make(values)
  let boxed = Box::make(bag)
  Box::drain(boxed, { |inner: Fixed2<LifetimeDomain>|
    Fixed2::drain(inner, { |d: LifetimeDomain| finalize_domain(d) })
  })
  unit
}
