fn identity<T>(x: T) -> T { x }
fn wrapper<U>(x: U) -> U { identity(x) }
fn main() -> u32 { wrapper(u32(11)) }
