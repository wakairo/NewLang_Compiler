sum Maybe<T> { Empty, Full(T) }
module Slots2U32
  struct { slots: Array<Maybe<u32>,2> }
  fn set_first(self: ref<write,Self>, value: u32) -> unit {
    let items = array_span(self@slots)
    store(items[usize(0)], Maybe::Full(value))
  }
end
fn main() -> unit { unit }
