module Node
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

module StableNode
  struct { alloc: Allocation, node: ptr<Node>, life: LifetimeDomain }

  fn make(value: u32) -> Self {
    let witness: Layout<Node> = layout()
    let (alloc, raw) = allocate_storage(layout_size(witness), layout_align(witness))
    let slot: slot<Node> = storage_into_slot_layout(raw, witness)
    let life = lifetime_domain()
    let node = loan read life as stable {
      initialize(slot, Node::make(value), stable)
    }
    Self { alloc: alloc, node: node, life: life }
  }

  fn pass(self: Self) -> Self { self }

  fn close(self: Self) -> unit {
    let Self { alloc, node, life } = self
    let empty = loan exclusive read life as ending { destroy(node, ending) }
    finalize_domain(life)
    let raw = erase_slot(empty)
    deallocate_storage(alloc, raw)
    unit
  }
end

fn main() -> unit {
  let owner = StableNode::make(u32(7))
  let moved_owner = StableNode::pass(owner)
  StableNode::close(moved_owner)
  unit
}
