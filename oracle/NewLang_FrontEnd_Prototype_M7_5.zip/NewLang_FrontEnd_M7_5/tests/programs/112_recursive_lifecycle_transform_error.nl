fn recursive_domain() -> unit {
  let life = lifetime_domain()
  finalize_domain(life)
  recursive_domain()
}

fn main() -> unit {
  recursive_domain()
}
