module Padded
  struct { a: u32, b: usize }
  fn make(a: u32, b: usize) -> Self { Self { a: a, b: b } }
end

fn witness_from_ref<T>(value: ref<read,T>) -> Layout<T> {
  layout()
}

fn main() -> unit {
  let value = Padded::make(u32(1), usize(2))
  let witness = loan read value as r { witness_from_ref(r) }
  let (alloc, whole) = allocate_layout(witness, usize(2))
  let (left, right) = split_storage(whole, layout_stride(witness))
  let s0: slot<Padded> = storage_into_slot_layout(left, witness)
  let s1: slot<Padded> = storage_into_slot_layout(right, witness)
  let r0 = erase_slot(s0)
  let r1 = erase_slot(s1)
  let merged = merge_storage(r0, r1)
  deallocate_storage(alloc, merged)
  unit
}
