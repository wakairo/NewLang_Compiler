fn main() -> unit {
  loop (domain: LifetimeDomain = lifetime_domain()) -> unit {
    break()
  }
}
