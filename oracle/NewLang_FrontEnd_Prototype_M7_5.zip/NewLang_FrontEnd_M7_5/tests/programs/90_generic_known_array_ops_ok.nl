fn count_elements<T>(values: ref<read, Array<T,2>>) -> usize {
  let s = array_span(values)
  len(s)
}

fn main(values: Array<u32,2>) -> usize {
  loan read values as r { count_elements(r) }
}
