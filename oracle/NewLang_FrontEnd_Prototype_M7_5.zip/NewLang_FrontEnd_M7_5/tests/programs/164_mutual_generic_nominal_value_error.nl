module A<T>
  struct { next: B<T>, value: T }
end
module B<T>
  struct { next: A<T>, value: T }
end
fn main() -> unit { unit }
