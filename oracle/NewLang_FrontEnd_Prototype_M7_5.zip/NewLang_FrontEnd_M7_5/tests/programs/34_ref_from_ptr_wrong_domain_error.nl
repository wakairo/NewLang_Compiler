module Box
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn main(slot: slot<Box>) -> slot<Box> {
  let first = lifetime_domain()
  let second = lifetime_domain()
  let p = loan read first as stable {
    initialize(slot, Box::make(u32(1)), stable)
  }

  loan read second as wrong_stable {
    let r = ref_from_ptr(read, p, wrong_stable)
    unit
  }

  let empty = loan exclusive read first as ending { destroy(p, ending) }
  finalize_domain(first)
  finalize_domain(second)
  empty
}
