module Box
  struct {
    value: u32
  }

  fn make(value: u32) -> Self {
    Self { value: value }
  }

  fn set(self: ref<write, Self>, value: u32) -> unit {
    store(self@value, value)
  }
end

fn invoke(f: block() -> unit) -> unit {
  f()
  unit
}

fn main() -> unit {
  let box = Box::make(u32(1))
  loan write box as w {
    invoke({ ||
      w.set(u32(2))
      unit
    })
  }
}
