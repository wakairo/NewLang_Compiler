fn main(value: u32) -> unit {
  let (old_alloc, old_raw) = allocate_storage(usize(4), usize(4))
  let old_slot: slot<u32> = storage_into_slot(old_raw)
  let life = lifetime_domain()
  let old_ptr = loan read life as stable { initialize(old_slot, value, stable) }

  let (new_alloc, new_whole) = allocate_storage(usize(8), usize(4))
  let (new_head, new_tail) = split_storage(new_whole, usize(4))
  let new_slot: slot<u32> = storage_into_slot(new_head)

  let (moved, old_empty) = loan exclusive read life as ending { take(old_ptr, ending) }
  let new_ptr = loan read life as stable { initialize(new_slot, moved, stable) }
  let (final_value, new_empty) = loan exclusive read life as ending { take(new_ptr, ending) }
  finalize_domain(life)

  let old_storage = erase_slot(old_empty)
  deallocate_storage(old_alloc, old_storage)
  let new_head2 = erase_slot(new_empty)
  let new_storage = merge_storage(new_head2, new_tail)
  deallocate_storage(new_alloc, new_storage)
  unit
}
