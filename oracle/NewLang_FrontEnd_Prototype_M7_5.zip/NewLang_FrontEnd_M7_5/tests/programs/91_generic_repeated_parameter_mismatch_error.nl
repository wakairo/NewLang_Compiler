module Key
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn same<T>(a: T, b: T) -> T { a }

fn main() -> u32 {
  let key = Key::make(u32(1))
  same(u32(1), key)
}
