fn main(domains: Array<LifetimeDomain, 2>) -> unit {
  consume_array(domains, { |domain: LifetimeDomain|
    finalize_domain(domain)
    unit
  })
  unit
}
