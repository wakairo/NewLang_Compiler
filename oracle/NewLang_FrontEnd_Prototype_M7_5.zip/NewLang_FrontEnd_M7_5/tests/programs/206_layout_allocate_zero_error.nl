fn main() -> unit {
  let witness: Layout<u32> = layout()
  let (alloc, raw) = allocate_layout(witness, usize(0))
  unit
}
