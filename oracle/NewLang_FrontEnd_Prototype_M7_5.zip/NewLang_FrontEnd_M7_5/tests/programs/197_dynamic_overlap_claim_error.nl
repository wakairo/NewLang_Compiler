fn main() -> unit {
  let (alloc0, whole) = allocate_storage(usize(8), usize(4))
  let alloc1 = unchecked_dematerialize_storage(alloc0, whole)
  let (alloc2, slot0): (Allocation, slot<u32>) = unchecked_materialize_slot(alloc1, usize(0))
  let (alloc3, slot1): (Allocation, slot<u32>) = unchecked_materialize_slot(alloc2, usize(0))
  unit
}
