fn loop<T>(x: T) -> T {
  loop(x)
}

fn main() -> u32 {
  loop(u32(1))
}
