module Box
  struct {
    value: u32
  }

  fn make(value: u32) -> Self {
    Self { value: value }
  }

  fn inspect(self: ref<read, Self>) -> unit {
    unit
  }

  fn set_value(self: ref<write, Self>, value: u32) -> unit {
    store(self@value, value)
  }
end

fn main() -> unit {
  let box = Box::make(u32(1))
  loan write box as w {
    w.set_value(u32(42))
    w.inspect()
  }
}
