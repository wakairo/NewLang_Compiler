module Box
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
  fn echo<T>(self: ref<read, Self>, value: T) -> T { value }
end

fn generic_echo<K,V>(key: ref<read, K>, value: V) -> V {
  echo(key, value)
}

fn main() -> u32 {
  let box = Box::make(u32(1))
  loan read box as r {
    generic_echo(r, u32(12))
  }
}
