fn bad<K>(x: K) -> u32 {
  x@value
}

fn main() -> u32 { u32(0) }
