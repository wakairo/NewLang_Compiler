module Box<T>
  struct { value: T }
  fn make(value: T) -> Self { Self { value: value } }
end
fn grow<T>(x: T) -> unit {
  let boxed = Box::make(x)
  grow(boxed)
}
fn main() -> unit { grow(u32(1)) }
