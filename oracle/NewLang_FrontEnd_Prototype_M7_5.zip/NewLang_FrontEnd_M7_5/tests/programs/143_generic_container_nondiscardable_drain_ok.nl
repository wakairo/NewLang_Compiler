module Fixed2<T>
  struct { values: Array<T,2> }
  fn make(values: Array<T,2>) -> Self { Self { values: values } }
  fn drain(self: Self, f: block(T) -> unit) -> unit {
    let Self { values } = self
    consume_array(values, f)
  }
end
fn main(values: Array<LifetimeDomain,2>) -> unit {
  let bag = Fixed2::make(values)
  Fixed2::drain(bag, { |d: LifetimeDomain| finalize_domain(d) })
  unit
}
