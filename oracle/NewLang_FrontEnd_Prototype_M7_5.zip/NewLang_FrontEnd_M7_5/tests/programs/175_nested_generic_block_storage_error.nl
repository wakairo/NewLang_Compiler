module Box<T>
  struct { value: T }
end
module Outer<T>
  struct { inner: Box<T> }
end
fn hold(x: Outer<block() -> unit>) -> unit { unit }
fn main() -> unit { unit }
