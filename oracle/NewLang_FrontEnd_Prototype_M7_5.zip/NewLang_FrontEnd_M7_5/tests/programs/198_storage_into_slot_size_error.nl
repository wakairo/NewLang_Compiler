fn main() -> unit {
  let (alloc, whole) = allocate_storage(usize(8), usize(4))
  let slot: slot<u32> = storage_into_slot(whole)
  unit
}
