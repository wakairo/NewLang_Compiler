fn choose_other(a: LifetimeDomain, b: LifetimeDomain) -> LifetimeDomain {
  loop (current: LifetimeDomain = a) -> LifetimeDomain {
    continue(b)
  }
}

fn main() -> unit { unit }
