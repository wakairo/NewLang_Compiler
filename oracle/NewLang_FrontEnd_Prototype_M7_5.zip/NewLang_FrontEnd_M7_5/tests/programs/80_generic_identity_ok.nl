fn identity<T>(x: T) -> T { x }
fn main() -> u32 { identity(u32(9)) }
