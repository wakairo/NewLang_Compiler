fn hash(x: u32) -> u32 { x }

fn bad<K>(key: ref<read, K>) -> u32 {
  hash(key)
}

fn main() -> u32 { u32(0) }
