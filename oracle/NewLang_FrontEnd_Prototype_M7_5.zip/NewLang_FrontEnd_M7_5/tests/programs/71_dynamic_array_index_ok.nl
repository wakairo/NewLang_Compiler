fn inspect(value: ref<read, u32>) -> unit {
  unit
}

fn main(values: Array<u32, 3>, i: usize) -> unit {
  loan read values as a {
    inspect(a[i])
  }
  unit
}
