module Link
  struct { marker: u32 }
  fn make() -> Self { Self { marker: u32(0) } }
end

module Node
  struct { link: Link }
  fn make() -> Self { Self { link: Link::make() } }
  fn link_ptr(self: ptr<Self>) -> ptr<Link> { self@link }
  fn owner(link: ptr<Link>) -> ptr<Self> { owner_ptr(link) }
end

fn main(slot: slot<Node>) -> slot<Node> {
  let life = lifetime_domain()
  let node = loan read life as stable { initialize(slot, Node::make(), stable) }
  let link = Node::link_ptr(node)
  let empty = loan exclusive read life as ending { destroy(node, ending) }
  let dangling_owner = Node::owner(link)
  finalize_domain(life)
  empty
}
