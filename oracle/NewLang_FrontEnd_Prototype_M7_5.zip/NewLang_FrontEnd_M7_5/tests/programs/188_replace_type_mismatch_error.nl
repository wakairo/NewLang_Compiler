fn bad(dst: ref<write,u32>) -> u32 {
  replace(dst, usize(1))
}
