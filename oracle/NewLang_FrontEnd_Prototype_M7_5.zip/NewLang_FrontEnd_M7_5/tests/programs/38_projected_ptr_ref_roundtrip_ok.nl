module Box

  struct { value: u32 }

  fn make(value: u32) -> Self { Self { value: value } }

  fn value_ptr(self: ptr<Self>, stable: ref<read, LifetimeDomain>) -> ptr<u32> {
    let r = ref_from_ptr(read, self@value, stable)
    ptr_from_ref(r)
  }

  fn touch_value_ptr(self: ptr<u32>, stable: ref<read, LifetimeDomain>) -> unit {
    let r = ref_from_ptr(read, self, stable)
    unit
  }

end

fn main(slot: slot<Box>) -> slot<Box> {
  let life = lifetime_domain()
  let p = loan read life as stable {
    initialize(slot, Box::make(u32(1)), stable)
  }
  let vp = loan read life as stable {
    Box::value_ptr(p, stable)
  }
  loan read life as stable {
    Box::touch_value_ptr(vp, stable)
  }
  let empty = loan exclusive read life as ending { destroy(p, ending) }
  finalize_domain(life)
  empty
}
