module Link
  struct { marker: u32 }
  fn make() -> Self { Self { marker: u32(0) } }
end

module Node
  struct { value: u32, link: Link }

  fn make(value: u32) -> Self {
    Self { value: value, link: Link::make() }
  }

  fn link_ptr(self: ptr<Self>) -> ptr<Link> {
    self@link
  }

  fn owner_from_link(link: ptr<Link>) -> ptr<Self> {
    owner_ptr(link)
  }
end

fn main(slot: slot<Node>) -> slot<Node> {
  let life = lifetime_domain()
  let node = loan read life as stable {
    initialize(slot, Node::make(u32(7)), stable)
  }
  let link = Node::link_ptr(node)
  let recovered = Node::owner_from_link(link)
  loan read life as stable {
    let r = ref_from_ptr(read, recovered, stable)
    unit
  }
  let empty = loan exclusive read life as ending { destroy(recovered, ending) }
  finalize_domain(life)
  empty
}
