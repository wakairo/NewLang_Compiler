module Box<T>
  struct { value: T }
end
fn bad(x: Box) -> unit { unit }
fn main() -> unit { unit }
