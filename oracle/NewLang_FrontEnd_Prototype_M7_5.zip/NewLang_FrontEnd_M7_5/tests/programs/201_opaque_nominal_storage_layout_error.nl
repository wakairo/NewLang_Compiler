module Box
  struct { value: u32 }
end

fn main() -> unit {
  let (alloc, raw) = allocate_storage(usize(4), usize(4))
  let slot: slot<Box> = storage_into_slot(raw)
  unit
}
