sum Decision { Found, Next }
module Key
  struct { value: u32 }
  fn equal(self: ref<read,Self>, other: ref<read,Self>) -> Decision { Decision::Found() }
end
fn next(i: usize) -> usize { i }
module Fixed2<T>
  struct { values: Array<T,2> }
  fn make(values: Array<T,2>) -> Self { Self { values: values } }
  fn find(self: ref<read,Self>, key: ref<read,T>) -> usize {
    let items = array_span(self@values)
    loop (i: usize = usize(0)) -> usize {
      let d: Decision = equal(items[i], key)
      match d {
        Found => { break(i) }
        Next => { continue(next(i)) }
      }
    }
  }
end
fn main(values: Array<Key,2>, key: Key) -> usize {
  let bag = Fixed2::make(values)
  loan read bag as r {
    loan read key as k { r.find(k) }
  }
}
