module Pair
  struct { a: u32, b: u32 }
  fn set_b(self: ref<write, Self>, value: u32) -> unit {
    store(self@b, value)
  }
  fn make(a: u32, b: u32) -> Self { Self { a: a, b: b } }
end

fn main() -> unit {
  let p = Pair::make(u32(1), u32(2))
  loan write p as w {
    w.set_b(u32(3))
  }
}
