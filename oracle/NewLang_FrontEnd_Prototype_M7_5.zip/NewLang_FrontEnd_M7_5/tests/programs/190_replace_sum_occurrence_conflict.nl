sum MaybeU32 { None, Some(u32) }

fn main(value: MaybeU32) -> unit {
  loan write value as w {
    match w {
      None => { unit }
      Some(x) => {
        replace(w, MaybeU32::None())
        unit
      }
    }
  }
}
