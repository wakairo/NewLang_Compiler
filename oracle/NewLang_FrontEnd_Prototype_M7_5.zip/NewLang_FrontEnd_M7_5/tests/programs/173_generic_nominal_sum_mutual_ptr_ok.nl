sum Link<T> { End, More(ptr<Node<T>>) }
module Node<T>
  struct { next: Link<T>, value: T }
end
fn main() -> unit { unit }
