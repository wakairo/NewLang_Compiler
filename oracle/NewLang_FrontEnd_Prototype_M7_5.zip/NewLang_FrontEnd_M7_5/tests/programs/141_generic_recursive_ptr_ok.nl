module Node<T>
  struct { next: ptr<Self>, value: T }
  fn keep(p: ptr<Self>) -> ptr<Self> { p }
end
fn main() -> unit { unit }
