sum MaybeDomain {
  None,
  Some(LifetimeDomain),
}

fn main() -> unit {
  let value = MaybeDomain::None()
  loan write value as w {
    store(w, MaybeDomain::Some(lifetime_domain()))
  }
}
