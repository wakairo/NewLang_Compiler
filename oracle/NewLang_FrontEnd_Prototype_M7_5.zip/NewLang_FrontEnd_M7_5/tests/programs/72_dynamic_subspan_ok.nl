fn main(values: Array<u32, 3>, start: usize, count: usize) -> usize {
  loan read values as a {
    let s = array_span(a)
    let part = subspan(s, start, count)
    len(part)
  }
}
