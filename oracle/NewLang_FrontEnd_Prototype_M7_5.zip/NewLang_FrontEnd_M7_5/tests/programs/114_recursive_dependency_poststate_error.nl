sum MaybeU32 {
  None,
  Some(u32),
}

fn recurse(value: ref<read, MaybeU32>) -> unit {
  match value {
    None => {
      recurse(value)
    }
    Some(x) => {
      recurse(value)
    }
  }
}

fn main() -> unit {
  let value = MaybeU32::Some(u32(7))
  loan read value as r {
    recurse(r)
  }
}
