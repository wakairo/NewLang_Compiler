module Box<T>
  struct { value: T }
  fn bad<T>(value: T) -> unit { unit }
end
fn main() -> unit { unit }
