fn main() -> u32 {
  loop (outer: u32 = u32(1)) -> u32 {
    let inner: u32 = loop (value: u32 = outer) -> u32 {
      break(value)
    }
    break(inner)
  }
}
