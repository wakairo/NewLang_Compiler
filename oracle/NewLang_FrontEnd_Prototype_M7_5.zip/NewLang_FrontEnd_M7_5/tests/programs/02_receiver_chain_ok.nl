module Box
  struct {
    value: u32
  }

  fn make(value: u32) -> Self {
    Self { value: value }
  }

  fn identity(self: Self) -> Self {
    self
  }

  fn into_value(self: Self) -> u32 {
    self@value
  }
end

fn main() -> u32 {
  Box::make(u32(42)).identity().identity().into_value()
}
