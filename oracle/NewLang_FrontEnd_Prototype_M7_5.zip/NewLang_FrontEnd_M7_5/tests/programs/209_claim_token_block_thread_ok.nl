fn thread<T>(claim: slot<T>, f: block(slot<T>) -> Storage) -> Storage {
  f(claim)
}

fn main(claim: slot<u32>) -> Storage {
  thread(claim, { |x: slot<u32>| erase_slot(x) })
}
