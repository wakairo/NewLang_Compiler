fn identity<T>(x: T) -> T { x }
fn main() -> u32 {
  let a = identity(u32(1))
  let b = identity(u32(2))
  b
}
