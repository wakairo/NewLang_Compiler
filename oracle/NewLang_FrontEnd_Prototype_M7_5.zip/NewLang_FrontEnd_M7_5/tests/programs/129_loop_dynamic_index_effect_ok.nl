fn touch(values: ref<write,Array<u32,2>>) -> unit {
  loop (i: usize = usize(0)) -> unit {
    store(values[i], u32(1))
    break()
  }
}

fn main() -> unit { unit }
