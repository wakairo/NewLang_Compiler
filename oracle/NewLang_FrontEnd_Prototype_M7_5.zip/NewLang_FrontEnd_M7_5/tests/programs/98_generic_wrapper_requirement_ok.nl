fn need_hash<K>(x: ref<read,K>) -> u32 {
  hash(x)
}

fn wrapper<U>(x: ref<read,U>) -> u32 {
  need_hash(x)
}

fn outer<V>(x: ref<read,V>) -> u32 {
  wrapper(x)
}

fn main() -> u32 {
  u32(0)
}
