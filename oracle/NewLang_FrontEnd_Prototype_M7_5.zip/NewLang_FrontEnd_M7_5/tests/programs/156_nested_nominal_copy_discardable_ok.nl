module Box<T>
  struct { value: T }
  fn make(value: T) -> Self { Self { value: value } }
end
fn main() -> unit {
  let box = Box::make(Box::make(u32(1)))
  loan write box as w {
    store(w, Box::make(Box::make(u32(2))))
  }
  unit
}
