fn main() -> unit {
  let (alloc0, whole) = allocate_storage(usize(8), usize(4))
  let alloc1 = unchecked_dematerialize_storage(alloc0, whole)
  let (alloc2, slot): (Allocation, slot<u32>) = unchecked_materialize_slot(alloc1, usize(2))
  unit
}
