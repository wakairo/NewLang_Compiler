sum Maybe<T> { None, Some(T) }
fn none_u32() -> Maybe<u32> { Maybe::None() }
fn main() -> unit {
  let x: Maybe<u32> = Maybe::None()
  match x {
    None => { unit }
    Some(v) => { unit }
  }
}
