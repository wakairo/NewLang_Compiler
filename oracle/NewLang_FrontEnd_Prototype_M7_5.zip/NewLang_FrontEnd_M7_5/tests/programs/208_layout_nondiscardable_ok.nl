module Cell<T>
  struct { value: T }
end

fn main() -> unit {
  let witness: Layout<Cell<LifetimeDomain>> = layout()
  let (alloc, raw) = allocate_layout(witness, usize(1))
  let slot: slot<Cell<LifetimeDomain>> = storage_into_slot_layout(raw, witness)
  let raw2 = erase_slot(slot)
  deallocate_storage(alloc, raw2)
  unit
}
