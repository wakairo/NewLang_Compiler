sum Maybe<T> { Empty, Full(T) }
fn consume_maybe<T>(value: Maybe<T>, f: block(T) -> unit) -> unit {
  match value {
    Empty => { unit }
    Full(x) => { f(x) }
  }
}
module Slots2<T>
  struct { first: Maybe<T>, second: Maybe<T> }
  fn singleton(value: T) -> Self {
    Self { first: Maybe::Full(value), second: Maybe::Empty() }
  }
  fn put_second_then(self: Self, value: T, f: block(Self,Maybe<T>) -> unit) -> unit {
    let Self { first, second } = self
    let updated = Self { first: first, second: Maybe::Full(value) }
    f(updated, second)
  }
  fn drain(self: Self, f: block(T) -> unit) -> unit {
    let Self { first, second } = self
    consume_maybe(first, f)
    consume_maybe(second, f)
  }
end
fn main(old: LifetimeDomain, new_value: LifetimeDomain) -> unit {
  let slots = Slots2::singleton(old)
  Slots2::put_second_then(slots, new_value, { |updated: Slots2<LifetimeDomain>, previous: Maybe<LifetimeDomain>|
    consume_maybe(previous, { |d: LifetimeDomain| finalize_domain(d) })
    Slots2::drain(updated, { |d: LifetimeDomain| finalize_domain(d) })
  })
  unit
}
