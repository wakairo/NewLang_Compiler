sum MaybeU32 {
  None,
  Some(u32),
}

fn rewrite(value: ref<write, MaybeU32>) -> unit {
  match value {
    None => { unit }
    Some(x) => {
      store(value, MaybeU32::None())
      unit
    }
  }
}

fn main() -> unit {
  let value = MaybeU32::Some(u32(7))
  loan write value as w {
    rewrite(w)
  }
}
