module Box<T>
  struct { value: T }
  fn make(value: T) -> Self { Self { value: value } }
end
fn main() -> unit {
  let box = Box::make(Box::make(lifetime_domain()))
  loan write box as w {
    store(w, Box::make(Box::make(lifetime_domain())))
  }
  unit
}
