sum Maybe<T> { Empty, Full(T) }
module Slots2<T>
  struct { slots: Array<Maybe<T>,2> }
  fn set_first(self: ref<write,Self>, value: T) -> unit {
    let items = array_span(self@slots)
    store(items[usize(0)], Maybe::Full(value))
  }
end
fn main() -> unit { unit }
