fn main(values: Array<u32, 3>) -> usize {
  consume_array(values, { |value: u32| unit })
  loan read values as a {
    let s = array_span(a)
    len(s)
  }
}
