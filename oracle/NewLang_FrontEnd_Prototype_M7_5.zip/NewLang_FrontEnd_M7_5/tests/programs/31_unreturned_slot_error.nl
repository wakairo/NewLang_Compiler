module Box
  struct { value: u32 }
end

fn main(slot: slot<Box>) -> unit {
  unit
}
