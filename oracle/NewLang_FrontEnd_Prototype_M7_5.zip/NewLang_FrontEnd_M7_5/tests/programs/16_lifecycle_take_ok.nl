module Box

  struct {
    value: u32
  }

  fn make(value: u32) -> Self {
    Self { value: value }
  }

end

fn main(slot: slot<Box>) -> slot<Box> {
  let life = lifetime_domain()
  let p = loan read life as stable {
    initialize(slot, Box::make(u32(7)), stable)
  }
  let (value, empty) = loan exclusive read life as ending {
    take(p, ending)
  }
  finalize_domain(life)
  empty
}
