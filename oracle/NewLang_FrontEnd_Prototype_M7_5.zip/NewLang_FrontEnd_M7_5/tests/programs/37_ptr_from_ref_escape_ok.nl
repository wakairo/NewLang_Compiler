module Box
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn main(slot: slot<Box>) -> slot<Box> {
  let life = lifetime_domain()
  let p = loan read life as stable {
    initialize(slot, Box::make(u32(1)), stable)
  }
  let q = loan read life as stable {
    let r = ref_from_ptr(read, p, stable)
    ptr_from_ref(r)
  }
  loan read life as stable {
    let r2 = ref_from_ptr(read, q, stable)
    unit
  }
  let empty = loan exclusive read life as ending { destroy(q, ending) }
  finalize_domain(life)
  empty
}
