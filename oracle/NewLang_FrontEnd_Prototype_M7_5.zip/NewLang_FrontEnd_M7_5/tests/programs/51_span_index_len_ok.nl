fn inspect(value: ref<read, u32>) -> unit {
  unit
}

fn main(values: Array<u32, 3>) -> usize {
  loan read values as a {
    let s = array_span(a)
    inspect(s[usize(1)])
    len(s)
  }
}
