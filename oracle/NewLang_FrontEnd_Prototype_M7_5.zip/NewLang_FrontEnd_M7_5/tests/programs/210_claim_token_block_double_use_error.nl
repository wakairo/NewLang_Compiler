fn bad<T>(claim: slot<T>, f: block(slot<T>) -> Storage) -> Storage {
  let first = f(claim)
  f(claim)
}

fn main(claim: slot<u32>) -> Storage {
  bad(claim, { |x: slot<u32>| erase_slot(x) })
}
