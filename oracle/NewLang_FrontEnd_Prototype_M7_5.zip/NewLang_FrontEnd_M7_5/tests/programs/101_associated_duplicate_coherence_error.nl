module Key
  struct { value: u32 }
  fn hash(self: ref<read,Self>) -> u32 { u32(1) }
  fn hash<T>(self: ref<read,Self>, value: T) -> u32 { u32(2) }
end

fn main() -> u32 { u32(0) }
