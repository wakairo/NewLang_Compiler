module Pair<T>
  struct { first: T, second: T }
end

fn alloc_one<T>(witness: Layout<T>) -> (Allocation, Storage) {
  allocate_layout(witness, usize(1))
}

fn main() -> unit {
  let witness: Layout<Pair<u32>> = layout()
  let (alloc, raw) = alloc_one(witness)
  let slot: slot<Pair<u32>> = storage_into_slot_layout(raw, witness)
  let raw2 = erase_slot(slot)
  deallocate_storage(alloc, raw2)
  unit
}
