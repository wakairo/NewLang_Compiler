module Cell<T>
  struct { value: T }
  fn make(value: T) -> Self { Self { value: value } }
  fn replace_then(self: Self, new_value: T, f: block(Self,T) -> unit) -> unit {
    let Self { value } = self
    let rebuilt = Self { value: new_value }
    f(rebuilt, value)
  }
  fn drain(self: Self, f: block(T) -> unit) -> unit {
    let Self { value } = self
    f(value)
  }
end
fn main(old: LifetimeDomain, new_value: LifetimeDomain) -> unit {
  let cell = Cell::make(old)
  Cell::replace_then(cell, new_value, { |updated: Cell<LifetimeDomain>, old_value: LifetimeDomain|
    finalize_domain(old_value)
    Cell::drain(updated, { |current: LifetimeDomain| finalize_domain(current) })
  })
  unit
}
