fn exchange<T>(a: ref<write,T>, b: ref<write,T>) -> unit {
  swap(a, b)
}

fn main() -> unit {
  let a = u32(1)
  let b = u32(2)
  loan write a as wa {
    loan write b as wb {
      exchange(wa, wb)
    }
  }
}
