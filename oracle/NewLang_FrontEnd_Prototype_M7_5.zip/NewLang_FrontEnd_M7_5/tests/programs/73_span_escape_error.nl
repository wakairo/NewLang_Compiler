fn main(values: Array<u32, 3>) -> span<read, u32> {
  loan read values as a {
    array_span(a)
  }
}
