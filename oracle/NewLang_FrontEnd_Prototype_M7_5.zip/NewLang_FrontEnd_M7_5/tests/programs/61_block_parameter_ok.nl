fn apply_twice(f: block(u32) -> unit) -> unit {
  f(u32(1))
  f(u32(2))
  unit
}

fn main() -> unit {
  apply_twice({ |x: u32| unit })
  unit
}
