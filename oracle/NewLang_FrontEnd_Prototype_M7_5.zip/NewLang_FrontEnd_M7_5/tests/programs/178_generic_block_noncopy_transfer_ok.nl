fn apply<T>(value: T, f: block(T) -> unit) -> unit {
  f(value)
}
fn main(domain: LifetimeDomain) -> unit {
  apply(domain, { |d: LifetimeDomain| finalize_domain(d) })
  unit
}
