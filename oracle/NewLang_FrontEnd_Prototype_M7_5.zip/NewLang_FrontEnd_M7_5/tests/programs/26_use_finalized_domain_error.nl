module Box
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn main(slot: slot<Box>) -> ptr<Box> {
  let life = lifetime_domain()
  finalize_domain(life)
  loan read life as stable {
    initialize(slot, Box::make(u32(1)), stable)
  }
}
