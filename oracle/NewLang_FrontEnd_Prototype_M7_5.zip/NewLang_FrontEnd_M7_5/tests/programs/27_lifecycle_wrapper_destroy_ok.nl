module Box
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn destroy_box(
  p: ptr<Box>,
  ending: exclusive ref<read, LifetimeDomain>
) -> slot<Box> {
  destroy(p, ending)
}

fn main(slot: slot<Box>) -> slot<Box> {
  let life = lifetime_domain()
  let p = loan read life as stable {
    initialize(slot, Box::make(u32(1)), stable)
  }
  let empty = loan exclusive read life as ending {
    destroy_box(p, ending)
  }
  finalize_domain(life)
  empty
}
