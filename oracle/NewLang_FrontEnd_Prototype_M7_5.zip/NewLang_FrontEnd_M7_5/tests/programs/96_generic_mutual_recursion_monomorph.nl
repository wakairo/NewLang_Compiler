fn a<T>(x: T) -> T {
  b(x)
}

fn b<U>(x: U) -> U {
  a(x)
}

fn main() -> u32 {
  a(u32(1))
}
