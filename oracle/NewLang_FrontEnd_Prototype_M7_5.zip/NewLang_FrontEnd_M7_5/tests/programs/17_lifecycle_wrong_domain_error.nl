module Box

  struct {
    value: u32
  }

  fn make(value: u32) -> Self {
    Self { value: value }
  }

end

fn main(slot: slot<Box>) -> slot<Box> {
  let first = lifetime_domain()
  let second = lifetime_domain()
  let p = loan read first as stable {
    initialize(slot, Box::make(u32(1)), stable)
  }
  let empty = loan exclusive read second as ending {
    destroy(p, ending)
  }
  finalize_domain(first)
  finalize_domain(second)
  empty
}
