fn main() -> unit {
  let witness: Layout<unit> = layout()
  let pair = allocate_layout(witness, usize(3))
  unit
}
