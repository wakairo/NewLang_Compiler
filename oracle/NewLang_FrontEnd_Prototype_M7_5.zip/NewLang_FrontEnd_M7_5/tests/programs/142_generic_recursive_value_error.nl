module Node<T>
  struct { next: Self, value: T }
end
fn main() -> unit { unit }
