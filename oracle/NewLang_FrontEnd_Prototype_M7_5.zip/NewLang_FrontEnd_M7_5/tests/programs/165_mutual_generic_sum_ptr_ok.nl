sum Left<T> { End, More(ptr<Right<T>>) }
sum Right<T> { End, More(ptr<Left<T>>) }
fn main() -> unit { unit }
