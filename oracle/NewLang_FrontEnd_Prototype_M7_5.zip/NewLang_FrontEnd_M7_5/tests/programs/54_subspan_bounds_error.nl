fn main(values: Array<u32, 3>) -> usize {
  loan read values as a {
    let s = array_span(a)
    let part = subspan(s, usize(2), usize(2))
    len(part)
  }
}
