module Box<T>
  struct { value: T }
  fn make(value: T) -> Self { Self { value: value } }
  fn hash(self: ref<read,Self>) -> u32 { u32(1) }
end
fn generic_hash<K>(x: ref<read,K>) -> u32 { hash(x) }
fn main() -> u32 {
  let box = Box::make(u32(3))
  loan read box as r { generic_hash(r) }
}
