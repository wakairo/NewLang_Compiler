sum Maybe<T> { Empty, Full(T) }

fn main(slots: Array<Maybe<u32>,2>) -> unit {
  loan write slots as w {
    let old = replace(w[usize(0)], Maybe::Full(u32(9)))
    match w[usize(0)] {
      Empty => { unit }
      Full(x) => { unit }
    }
  }
  unit
}
