module Box

  struct {
    value: u32
  }

  fn make(value: u32) -> Self {
    Self { value: value }
  }

  fn set_value(self: ref<write, Self>, value: u32) -> unit {
    store(self@value, value)
  }

end

fn main(slot: slot<Box>) -> slot<Box> {
  let life = lifetime_domain()
  let p = loan read life as stable {
    initialize(slot, Box::make(u32(1)), stable)
  }

  loan read life as stable {
    let r = ref_from_ptr(write, p, stable)
    r.set_value(u32(2))
  }

  let empty = loan exclusive read life as ending {
    destroy(p, ending)
  }
  finalize_domain(life)
  empty
}
