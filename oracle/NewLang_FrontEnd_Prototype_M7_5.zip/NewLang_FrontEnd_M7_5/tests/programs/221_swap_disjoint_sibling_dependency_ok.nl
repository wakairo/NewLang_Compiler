module Triple
  struct { a: u32, b: u32, c: u32 }
  fn swap_ab(self: ref<write, Self>) -> unit {
    swap(self@a, self@b)
  }
  fn make(a: u32, b: u32, c: u32) -> Self { Self { a: a, b: b, c: c } }
end

fn main() -> unit {
  let p = Triple::make(u32(1), u32(2), u32(3))
  loan write p as w {
    w.swap_ab()
  }
}
