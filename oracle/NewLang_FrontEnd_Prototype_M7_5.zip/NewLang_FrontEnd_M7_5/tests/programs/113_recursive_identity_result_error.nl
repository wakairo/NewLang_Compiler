fn recursive_ptr(p: ptr<u32>) -> ptr<u32> {
  recursive_ptr(p)
}

fn main() -> ptr<u32> {
  let value = u32(1)
  loan read value as r {
    let p = ptr_from_ref(r)
    recursive_ptr(p)
  }
}
