fn main() -> unit {
  let witness: Layout<unit> = layout()
  unit
}
