fn main() -> unit {
  let witness: Layout<unit> = layout()
  let size = layout_size(witness)
  let align = layout_align(witness)
  let stride = layout_stride(witness)
  unit
}
