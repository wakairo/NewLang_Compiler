sum Maybe<T> { None, Some(T) }
fn main() -> unit {
  let value: Maybe<Maybe<u32>> = Maybe::Some(Maybe::Some(u32(1)))
  loan write value as w {
    store(w, Maybe::Some(Maybe::Some(u32(2))))
  }
  unit
}
