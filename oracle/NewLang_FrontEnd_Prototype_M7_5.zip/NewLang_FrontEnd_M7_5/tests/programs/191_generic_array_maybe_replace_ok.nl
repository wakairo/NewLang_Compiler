sum Maybe<T> { Empty, Full(T) }

module Outcome<T>
  struct { slots: Array<Maybe<T>,2>, previous: Maybe<T> }
  fn make(slots: Array<Maybe<T>,2>, previous: Maybe<T>) -> Self {
    Self { slots: slots, previous: previous }
  }
end

fn replace_first<T>(slots: ref<write,Array<Maybe<T>,2>>, value: T) -> Maybe<T> {
  replace(slots[usize(0)], Maybe::Full(value))
}

fn main(slots: Array<Maybe<LifetimeDomain>,2>, value: LifetimeDomain) -> Outcome<LifetimeDomain> {
  let previous = loan write slots as w {
    replace_first(w, value)
  }
  Outcome::make(slots, previous)
}
