fn main(life: LifetimeDomain) -> LifetimeDomain {
  loan read life as stable {
    loan exclusive read life as ending {
      unit
    }
  }
  life
}
