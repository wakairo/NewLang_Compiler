module Box
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
  fn set(self: ref<write,Self>) -> unit {
    store(self@value, u32(1))
  }
end

fn recursive_set<T>(x: ref<write,T>) -> unit {
  let ignored: unit = set(x)
  recursive_set(x)
}

fn main() -> unit {
  let box = Box::make(u32(0))
  loan write box as w {
    recursive_set(w)
  }
}
