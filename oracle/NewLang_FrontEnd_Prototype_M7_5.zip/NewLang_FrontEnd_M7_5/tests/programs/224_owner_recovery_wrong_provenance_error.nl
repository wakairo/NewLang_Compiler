module Link
  struct { marker: u32 }
  fn make() -> Self { Self { marker: u32(0) } }
end

module Node
  struct { value: u32, link: Link }
  fn owner_from_link(link: ptr<Link>) -> ptr<Self> { owner_ptr(link) }
end

fn main(slot: slot<Link>) -> slot<Link> {
  let life = lifetime_domain()
  let link_root = loan read life as stable { initialize(slot, Link::make(), stable) }
  let bogus = Node::owner_from_link(link_root)
  let empty = loan exclusive read life as ending { destroy(link_root, ending) }
  finalize_domain(life)
  empty
}
