module Box
  struct {
    value: u32
  }

  fn make(value: u32) -> Self {
    Self { value: value }
  }

  fn inspect(self: ref<read, Self>) -> unit {
    unit
  }
end

fn main() -> unit {
  let box = Box::make(u32(42))
  loan read box as r {
    r.inspect()
  }
}
