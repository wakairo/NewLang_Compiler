module Key
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn identity<T>(x: T) -> T { x }

fn main() -> u32 {
  let key = Key::make(u32(3))
  let key2 = identity(key)
  let n = identity(u32(4))
  n
}
