module Key
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
  fn hash(self: ref<read, Self>) -> u32 { u32(9) }
end

fn generic_hash<K>(key: ref<read, K>) -> u32 {
  let h: u32 = hash(key)
  h
}

fn main() -> u32 {
  let key = Key::make(u32(9))
  loan read key as r { generic_hash(r) }
}
