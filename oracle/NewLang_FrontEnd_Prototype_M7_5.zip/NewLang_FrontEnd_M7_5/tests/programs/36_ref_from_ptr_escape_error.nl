module Box
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn main(slot: slot<Box>) -> slot<Box> {
  let life = lifetime_domain()
  let p = loan read life as stable {
    initialize(slot, Box::make(u32(1)), stable)
  }
  let escaped = loan read life as stable {
    ref_from_ptr(read, p, stable)
  }
  let empty = loan exclusive read life as ending { destroy(p, ending) }
  finalize_domain(life)
  empty
}
