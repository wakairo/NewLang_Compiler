fn overwrite<T>(dst: ref<write, T>, value: T) -> unit {
  store(dst, value)
}

fn main() -> unit { unit }
