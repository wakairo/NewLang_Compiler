sum Chain<T> { End, More(ptr<Chain<T>>) }
fn main() -> unit { unit }
