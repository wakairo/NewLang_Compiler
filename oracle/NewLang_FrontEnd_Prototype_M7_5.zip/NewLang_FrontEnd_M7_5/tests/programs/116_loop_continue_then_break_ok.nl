sum Step {
  Again(u32),
  Done(u32),
}

fn main() -> u32 {
  loop (state: Step = Step::Again(u32(1))) -> u32 {
    match state {
      Again(x) => { continue(Step::Done(x)) }
      Done(x) => { break(x) }
    }
  }
}
