sum Maybe<T> { Empty, Full(T) }
fn main() -> unit {
  let value = Maybe::Full({ || unit })
  unit
}
