module Wide
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn main() -> unit {
  let witness: Layout<Wide> = layout()
  let (alloc, whole) = allocate_storage(usize(128), usize(64))
  let (prefix, rest) = split_storage(whole, usize(32))
  let (middle, suffix) = split_storage(rest, usize(64))
  let bad: slot<Wide> = storage_into_slot_layout(middle, witness)
  unit
}
