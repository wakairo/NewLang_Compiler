module Box
  struct { value: u32 }
  fn set_value(self: ref<write, Self>, value: u32) -> unit {
    store(self@value, value)
  }
  fn make(value: u32) -> Self { Self { value: value } }
end

fn main() -> unit {
  let b = Box::make(u32(1))
  loan write b as w {
    w.set_value(u32(2))
  }
}
