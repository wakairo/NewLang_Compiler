fn main() -> u32 {
  loop (i: u32 = u32(1)) -> u32 {
    break()
  }
}
