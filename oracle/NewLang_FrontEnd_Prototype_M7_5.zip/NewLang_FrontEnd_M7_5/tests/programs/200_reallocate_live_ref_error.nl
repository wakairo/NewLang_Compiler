fn main(value: u32) -> unit {
  let (alloc, raw) = allocate_storage(usize(4), usize(4))
  let slot: slot<u32> = storage_into_slot(raw)
  let life = lifetime_domain()
  let p = loan read life as stable { initialize(slot, value, stable) }
  loan read life as stable {
    let r = ref_from_ptr(read, p, stable)
    loan exclusive read life as ending {
      take(p, ending)
    }
  }
  unit
}
