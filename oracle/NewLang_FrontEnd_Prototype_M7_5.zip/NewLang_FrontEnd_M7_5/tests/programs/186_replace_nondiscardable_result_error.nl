sum Maybe<T> { Empty, Full(T) }

fn bad(dst: ref<write,Maybe<LifetimeDomain>>, value: LifetimeDomain) -> unit {
  replace(dst, Maybe::Full(value))
  unit
}
