module Pair<A,B>
  struct { first: A, second: B }
  fn make(first: A, second: B) -> Self { Self { first: first, second: second } }
end
module Key
  struct { value: u32 }
  fn make(value: u32) -> Self { Self { value: value } }
end
fn main() -> unit {
  let pair = Pair::make(u32(1), Key::make(u32(2)))
  unit
}
