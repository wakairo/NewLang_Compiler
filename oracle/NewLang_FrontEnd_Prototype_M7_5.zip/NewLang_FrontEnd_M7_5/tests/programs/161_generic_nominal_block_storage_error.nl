module Box<T>
  struct { value: T }
end
fn hold(x: Box<block() -> unit>) -> unit { unit }
fn main() -> unit { unit }
