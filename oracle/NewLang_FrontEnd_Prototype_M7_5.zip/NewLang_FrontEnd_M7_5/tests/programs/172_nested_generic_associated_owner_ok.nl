module Box<T>
  struct { value: T }
  fn make(value: T) -> Self { Self { value: value } }
  fn tag(self: ref<read,Self>) -> u32 { u32(1) }
end
fn main() -> u32 {
  let outer = Box::make(Box::make(u32(1)))
  loan read outer as r { r.tag() }
}
