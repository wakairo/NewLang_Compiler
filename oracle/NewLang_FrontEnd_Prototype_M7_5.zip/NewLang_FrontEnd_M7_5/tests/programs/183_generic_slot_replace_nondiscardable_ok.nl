sum Maybe<T> { Empty, Full(T) }

fn consume_maybe<T>(value: Maybe<T>, f: block(T) -> unit) -> unit {
  match value {
    Empty => { unit }
    Full(x) => { f(x) }
  }
}

module Slot<T>
  struct { value: Maybe<T> }

  fn singleton(value: T) -> Self {
    Self { value: Maybe::Full(value) }
  }

  fn put(self: ref<write,Self>, value: T) -> Maybe<T> {
    replace(self@value, Maybe::Full(value))
  }

  fn drain(self: Self, f: block(T) -> unit) -> unit {
    let Self { value } = self
    consume_maybe(value, f)
  }
end

fn main(old: LifetimeDomain, new_value: LifetimeDomain) -> unit {
  let slot = Slot::singleton(old)
  let previous = loan write slot as w {
    Slot::put(w, new_value)
  }
  consume_maybe(previous, { |d: LifetimeDomain| finalize_domain(d) })
  Slot::drain(slot, { |d: LifetimeDomain| finalize_domain(d) })
  unit
}
