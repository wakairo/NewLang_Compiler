from pathlib import Path

from newlang_checker.ir import Effect

from newlang_frontend.driver import check_source
from newlang_frontend.lexer import lex
from newlang_frontend.lifecycle import run_lifecycle_detailed
from newlang_frontend.lower import lower_program
from newlang_frontend.parser import parse
from newlang_frontend.production_lifecycle import run_production_lifecycle_detailed
from newlang_frontend.source import SourceFile
from newlang_frontend.symbols import SymbolBuilder
from newlang_frontend.typecheck import TypeChecker

ROOT = Path(__file__).parent / "programs"


def typed(name: str):
    path = ROOT / name
    source = SourceFile(str(path), path.read_text())
    symbols = SymbolBuilder(parse(lex(source))).build()
    checker = TypeChecker(symbols)
    return symbols, checker, checker.check_program()


def check(name: str):
    path = ROOT / name
    return check_source(path.read_text(), str(path))


def test_basic_value_producing_loop_breaks() -> None:
    result = check("115_loop_break_ok.nl")
    assert result.accepted, result.diagnostic


def test_continue_rebinds_fresh_iteration_parameter_then_breaks() -> None:
    result = check("116_loop_continue_then_break_ok.nl")
    assert result.accepted, result.diagnostic


def test_unconstrained_generic_value_can_be_loop_carried_without_copy_assumption() -> None:
    result = check("117_generic_loop_carry_ok.nl")
    assert result.accepted, result.diagnostic
    _, checker, program = typed("117_generic_loop_carry_ok.nl")
    assert any(fn.symbol.qualified_name == "carry<u32>" for fn in program.functions)
    assert len(checker.monomorph_cache) == 1


def test_lifetime_domain_identity_can_move_across_fresh_iteration_bindings() -> None:
    _, _, program = typed("118_loop_domain_identity_carry_ok.nl")
    exact = run_lifecycle_detailed(program)
    production = run_production_lifecycle_detailed(program)
    assert exact.accepted, exact
    assert production.accepted, production
    assert not production.precision_loss


def test_loop_control_cannot_drop_nondiscardable_iteration_binding() -> None:
    result = check("119_loop_nondiscardable_drop_error.nl")
    assert not result.accepted
    assert result.diagnostic is not None
    assert result.diagnostic.code == "E_LOOP_NONDDiscardable_EXIT"


def test_continue_arity_and_type_are_loop_parameter_contract() -> None:
    arity = check("120_loop_continue_arity_error.nl")
    assert not arity.accepted and arity.diagnostic is not None
    assert arity.diagnostic.code == "E_LOOP_CONTINUE_ARITY"
    ty = check("121_loop_continue_type_error.nl")
    assert not ty.accepted and ty.diagnostic is not None
    assert ty.diagnostic.code == "E_ARGUMENT_TYPE"


def test_break_result_must_match_declared_loop_result() -> None:
    result = check("122_loop_break_type_error.nl")
    assert not result.accepted and result.diagnostic is not None
    assert result.diagnostic.code == "E_LOOP_BREAK_TYPE"


def test_loop_body_normal_fallthrough_is_rejected() -> None:
    result = check("123_loop_fallthrough_error.nl")
    assert not result.accepted and result.diagnostic is not None
    assert result.diagnostic.code == "E_LOOP_FALLTHROUGH"


def test_loop_initializer_moves_outer_noncopy_binding() -> None:
    result = check("124_loop_outer_noncopy_consumed_error.nl")
    assert not result.accepted and result.diagnostic is not None
    assert result.diagnostic.code == "E_USE_AFTER_CONSUME"


def test_identity_bearing_carry_requires_stable_identity_in_m4_bridge() -> None:
    result = check("125_loop_identity_change_precision_error.nl")
    assert not result.accepted and result.diagnostic is not None
    assert result.diagnostic.code == "E_LOOP_CARRY_PRECISION"


def test_nested_value_producing_loops_compose() -> None:
    result = check("126_nested_loop_ok.nl")
    assert result.accepted, result.diagnostic


def test_generic_linear_search_shape_composes_loop_index_and_dependent_lookup() -> None:
    symbols, checker, program = typed("127_generic_linear_search_ok.nl")
    result = check("127_generic_linear_search_ok.nl")
    assert result.accepted, result.diagnostic
    reqs = checker.generic_requirements[symbols.top_functions["find"].function_id]
    assert len(reqs) == 1
    assert reqs[0].name == "equal"
    assert any(fn.symbol.qualified_name == "find<Box>" for fn in program.functions)


def test_loop_does_not_launder_captured_semantic_effect() -> None:
    path = ROOT / "128_loop_semantic_effect_ok.nl"
    ok = check_source(path.read_text(), str(path))
    assert ok.accepted, ok.diagnostic
    conflict = check_source(path.read_text(), str(path), semantic_initial_deps=("box.value",))
    assert not conflict.accepted
    assert conflict.diagnostic is not None
    assert conflict.diagnostic.code == "E_SEMANTIC_CONFLICT"


def test_dynamic_index_loop_summary_widens_place_to_index_wildcard() -> None:
    _, _, program = typed("129_loop_dynamic_index_effect_ok.nl")
    lowered = lower_program(program)
    summary = lowered.function_summaries["touch"]
    assert summary.effects == frozenset({Effect("Change", "values.$index:*")})
    assert not summary.unknown


def test_lifecycle_neutral_no_break_loop_is_valid_divergence_not_budget_error() -> None:
    _, _, program = typed("130_loop_neutral_diverges_ok.nl")
    exact = run_lifecycle_detailed(program)
    production = run_production_lifecycle_detailed(program)
    assert exact.accepted, exact
    assert "diverging loop" in exact.reason
    assert production.accepted, production
    assert not production.precision_loss


def test_loop_is_contextual_and_does_not_break_existing_function_named_loop() -> None:
    result = check("109_ordinary_direct_recursion_ok.nl")
    assert result.accepted, result.diagnostic


def test_break_cannot_cross_nonescaping_block_literal_boundary() -> None:
    source = """
fn main() -> u32 {
  loop (i: u32 = u32(0)) -> u32 {
    let callback = { || break(i) }
    break(i)
  }
}
"""
    result = check_source(source)
    assert not result.accepted
    assert result.diagnostic is not None
    assert result.diagnostic.code == "E_BREAK_OUTSIDE_LOOP"


def test_break_and_continue_remain_ordinary_names_outside_loop_context() -> None:
    source = """
fn break(x: u32) -> u32 { x }
fn continue(x: u32) -> u32 { x }
fn main() -> u32 { continue(break(u32(3))) }
"""
    result = check_source(source)
    assert result.accepted, result.diagnostic


def test_resource_transforming_no_break_loop_remains_explicit_lifecycle_precision_boundary() -> None:
    _, _, program = typed("131_loop_resource_transform_precision_error.nl")
    exact = run_lifecycle_detailed(program)
    production = run_production_lifecycle_detailed(program)
    assert not exact.accepted
    assert exact.code == "E_LOOP_LIFECYCLE_BUDGET"
    assert not production.accepted
    assert production.code == "E_LOOP_LIFECYCLE_BUDGET"
