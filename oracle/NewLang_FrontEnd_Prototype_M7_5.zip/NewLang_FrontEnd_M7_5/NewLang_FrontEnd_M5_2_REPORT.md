# NewLang Front-End Prototype M5.2 Report

## 1. Scope

M5.2 is the **replace-and-occupancy closure** after M5.1.

The semantic baseline remains **NewLang v0 Draft 17.2**. M5.2 does not introduce a new ownership/lifetime primitive. Instead it wires the already-specified core operation:

```text
replace(ref<write,T>, new: T) -> T
```

through the real-source type checker, semantic/effect bridge, exact lifecycle bridge, and production lifecycle bridge.

The main questions were:

```text
Can non-Discardable T be updated in place without losing the old value?
Can Maybe<T>-style occupancy support an in-place fixed-capacity container?
Does indexed Array<Maybe<T>,N> force raw vacant storage / partial initialization?
What additional compiler precision is actually required?
```

---

## 2. Main result

M5.2 closes the real-source `replace` path without changing Draft 17.2.

The key result is that:

```text
store(ref<write,T>, new)
    requires Discardable(T)

replace(ref<write,T>, new) -> old
    does not require Discardable(T)
```

works end-to-end for `T = LifetimeDomain` and for generic `Maybe<T>` occupancy.

A concrete resource-bearing workload now succeeds:

```text
Slot<LifetimeDomain>
    current = Maybe::Full(old_domain)

replace(slot.value, Maybe::Full(new_domain))
    -> Maybe::Full(old_domain)

old_domain finalized from returned old value
new_domain finalized later by draining updated Slot
```

Both exact and production lifecycle bridges accept this workload without precision loss.

M5.2 therefore adds further negative evidence against introducing dynamic partial initialization merely to support a fixed-capacity non-Copy container.

---

## 3. Source typing for `replace`

The type checker now recognizes:

```text
replace(dst, value)
```

with the applicability rule:

```text
dst   : ref<write,T>
value : T
result: T
```

The new value is consumed according to ordinary non-Copy transfer rules.

Unlike `store`, `replace` does **not** require:

```text
Discardable(T)
```

because the old value is returned to the caller.

This permits the generic definition:

```text
fn replace_any<T>(dst: ref<write,T>, value: T) -> T {
    replace(dst, value)
}
```

without inferred `Copy`, `Discardable`, trait, or other source-visible constraints.

`replace_any<LifetimeDomain>` is instantiated and accepted end-to-end.

New diagnostics include:

```text
E_REPLACE_ARITY
E_REPLACE_DEST
```

while ordinary argument mismatch continues to use the existing `E_ARGUMENT_TYPE` path.

---

## 4. The old value must remain an ownership obligation

Returning the old value is not optional bookkeeping.

For:

```text
Maybe<LifetimeDomain>
```

this is rejected:

```text
replace(dst, Maybe::Full(value))
```

when used as a discarded expression, because the result is non-Discardable:

```text
E_NONDDiscardable_EXPR
```

The caller must consume, transfer, return, or otherwise discharge the old value normally.

Thus `replace` does not become a hidden destruction primitive.

---

## 5. Semantic effect lowering

`replace` lowers to the same current-value invalidation surface as `store`:

```text
Change(destination)
```

and, when the destination is a sum value:

```text
Reset(destination)
```

Consequently a generic or ordinary `replace` cannot launder a caller-visible semantic conflict.

For example, with a live dependency on:

```text
b.value
```

an associated function containing:

```text
replace(self@value, value)
```

still rejects with:

```text
E_SEMANTIC_CONFLICT
```

Likewise, replacing a sum while an occurrence-sensitive payload ref is live is rejected by the existing conflict algebra.

No new effect language or source-visible post-state annotation was needed.

---

## 6. Exact lifecycle location update

M5.1 could model whole structural values, but ordinary projected refs were effectively read-only snapshots for lifecycle execution. That was sufficient for earlier `store` tests because lifecycle did not need to observe the new current value.

`replace` forces the bridge to represent the distinction:

```text
location identity
    vs
current value stored at that location
```

more explicitly.

M5.2 adds compiler-internal writable-location metadata to projected ordinary refs:

```text
RefHandle {
    target
    parent structural handle
    field/index selector
}
```

For a deterministic structural place, replacing the current value updates the owning structural handle while returning the previous handle.

Supported M5.2 writable locations include:

```text
direct write-loan root
struct field through ref<write,...>
fixed Array element through ref<write,Array<...>>
fixed Span element backed by a writable Array ref
```

This is an implementation representation only. It does not add source-visible pointer arithmetic, provenance, or a new object identity rule.

---

## 7. Write-loan post-state is written back to the source place

A write loan such as:

```text
loan write slot as w {
    ... replace(w@value, ...) ...
}
```

must leave `slot` denoting the same place with its new current value after the lexical loan ends.

M5.2 therefore writes the root ref's post-current-value state back to a direct local source binding at loan exit.

This is required for the representative sequence:

```text
let slot = Slot::singleton(old)

let previous = loan write slot as w {
    Slot::put(w, new_value)
}

consume(previous)
drain(slot)
```

where `drain(slot)` must observe `new_value`, not the pre-loan `old` value.

The same rule is implemented in exact and production lifecycle bridges.

---

## 8. Current-value observation after `replace`

M5.2 does not merely type-check replacement.

The static-index Array workload performs:

```text
replace(w[usize(0)], Maybe::Full(u32(9)))
```

and then immediately matches the same element through the write ref.

The lifecycle bridge observes the replacement result as the current sum value. This closes the previous snapshot-only behavior for the supported deterministic structural locations.

---

## 9. Generic `Array<Maybe<T>,N>` occupancy

M5.2 adds the generic operation:

```text
fn replace_first<T>(
    slots: ref<write,Array<Maybe<T>,2>>,
    value: T
) -> Maybe<T> {
    replace(slots[usize(0)], Maybe::Full(value))
}
```

and instantiates it for:

```text
T = LifetimeDomain
```

without a `Discardable(T)` requirement.

A representative entry workload returns both:

```text
updated Array<Maybe<LifetimeDomain>,2>
previous Maybe<LifetimeDomain>
```

inside an aggregate result so that all live resource ownership remains explicit.

Both lifecycle bridges accept this concrete static-index path.

This establishes that an indexed fully-initialized occupancy representation can perform non-Copy in-place replacement without raw vacant storage.

---

## 10. Dynamic index pressure: a different problem

M5.2 also tests:

```text
replace(w[i], Maybe::Full(value))
```

where `i` is a dynamic `usize` over a fixed Array.

The source type checker and semantic place/effect model can represent this operation. The effect side already uses wildcard/index abstraction where needed.

However, the current lifecycle prototype represents dynamic indexing as a `ChoiceHandle` of possible element refs. Updating one unknown alternative requires **branch-correlated post-state**:

```text
if i == 0:
    slot0 = new, slot1 = old1, result = old0
else:
    slot0 = old0, slot1 = new, result = old1
```

The bridge deliberately does not approximate this as "all slots changed" or silently pick one alternative.

It therefore rejects execution with:

```text
E_REPLACE_DYNAMIC_PRECISION
```

in both exact and production lifecycle bridges.

This is an implementation-analysis precision boundary, not evidence that the language needs uninitialized typed storage.

---

## 11. Why the dynamic-index result does not justify partial initialization

The failure above is about preserving correlation between:

```text
selected index
returned old value
updated aggregate post-state
```

It is not about representing an empty raw slot.

Even if every slot is always a fully initialized:

```text
Maybe<T>
```

branch correlation is still required for a dynamic index update.

Therefore adding dynamic partial initialization would not solve this M5.2 precision boundary.

The smaller future compiler improvement, if demanded by workload, is a finite branch-state / relational update abstraction for bounded index alternatives.

---

## 12. Generic `LifetimeDomain` replacement

M5.2 separately tests:

```text
fn replace_any<T>(dst: ref<write,T>, value: T) -> T
```

with:

```text
T = LifetimeDomain
```

The sequence:

```text
current place contains old domain identity
replace with new domain identity
return old domain identity
finalize old
finalize new through updated place
```

passes both lifecycle bridges.

This is useful because it confirms that `replace` is not secretly relying on `T` being an ordinary scalar or discardable aggregate.

It also preserves the Draft 17 distinction:

```text
same place incarnation
new current semantic value
old value transferred out
```

rather than treating replacement as place lifetime end/recreation.

---

## 13. New real-source corpus

M5.2 adds programs `183` through `192`:

```text
183 generic non-Discardable Slot<T> replacement + drain
184 static Array<Maybe<u32>,2> replacement and immediate observation
185 dynamic Array index replacement precision boundary
186 non-Discardable old replacement result cannot be discarded
187 replace requires ref<write,T>
188 replace new-value type mismatch
189 replace caller-visible Change conflict
190 sum occurrence dependency blocks replace/Reset
191 generic Array<Maybe<T>,2> replacement instantiated with LifetimeDomain
192 unconstrained generic replace instantiated with LifetimeDomain
```

A dedicated `tests/test_m5_2_replace.py` validates typing, semantic effects, generic instantiation, exact lifecycle, production lifecycle, and the explicit dynamic-index precision boundary.

---

## 14. Validation

Final M5.2 front-end suite:

```text
284 tests collected
284 passed
compileall PASS
```

The independent Draft 17.2 closure tree was rerun fresh:

```text
110 tests collected
110 passed
compileall PASS
```

Executable closure vectors:

```text
12 / 12 PASS
```

Generated closure differential, seed `20261003`:

```text
alignment_padding   25,000  mismatch 0
mixed_width_add     25,000  mismatch 0
operation_matrix    25,000  mismatch 0
split_coordinate    25,000  mismatch 0
-------------------------------------
total              100,000  mismatch 0
false accept                 0
false reject                 0
```

`ruff`, `mypy`, and `pyright` were not installed in the execution environment.

---

## 15. Architecture judgment

M5.2 strengthens an existing Draft 17 mechanism rather than expanding the semantic kernel:

```text
real source replace
    -> ordinary generic type checking
    -> consume new value
    -> return old value
    -> Change / Reset effect lowering
    -> deterministic structural location update
    -> lexical write-loan post-state write-back
    -> existing ownership/lifecycle checks
```

The experiment did **not** require:

```text
Discardable constraints on generic T
partial-move aggregate state
raw vacant typed slots
pre-lifetime field projection
destructors
source-visible effect/post-state annotations
traits/interfaces
overload ranking
```

---

## 16. Remaining boundaries after M5.2

Still intentionally open:

```text
dynamic-index branch-correlated lifecycle post-state
swap real-source bridge
explicit generic call-site type arguments
runtime-sized / allocator-backed containers
dense partial occupancy without per-slot Maybe-like tags
safe pre-lifetime field construction
Array value construction/rebuilding surface beyond incoming Array values
escaping callbacks
separate compilation artifacts
resource-mutating loop/recursive relational post-state transformers
```

---

## 17. M5.2 judgment

**Front-End Prototype M5.2 passes.**

The central design result is:

> `replace` is sufficient to make fully initialized `Maybe<T>` occupancy support non-Discardable in-place replacement at deterministic locations. Dynamic partial initialization is still not forced by correctness.

The remaining dynamic-index failure is a correlation/abstract-state precision problem and would remain even with raw vacant storage.

The highest-information next milestone is therefore **not** "add partial initialization now". A useful M6 should pressure a genuinely runtime-sized / allocator-backed dense container (or equivalent low-level workload) and compare:

```text
per-slot tagged fully initialized occupancy
vs
raw vacant storage + explicit object lifetime construction
```

Only that workload can establish whether partial initialization is justified by representation/runtime requirements rather than by a problem already solved by `replace`.
