# NewLang Front-End Prototype M2 — Sum / Array / Span / Callback Vertical Slice Report

> Status: **completed experimental M2 implementation**
>
> Semantic baseline: `NewLang_v0_spec_Draft17_2.md`
>
> Starting point: Front-End Prototype M1.1
>
> Purpose: broaden the real `.nl` front-end vertical slice to closed sums, fixed arrays, spans, and nonescaping block callbacks while preserving the existing Draft 17.2 semantic kernel.

## 1. M2 scope

M2 adds:

```text
closed sum declarations
type-qualified sum constructors
match expressions
Array<T,N>
fixed-array/span indexing
span<read/write,T>
array_span(...)
len(...)
subspan(...)
block(...) -> R
block literals
block invocation
consume_array(Array<T,N>, block(T)->unit)
```

M2 keeps the following deliberately out of scope:

```text
generic sum parameters
general generic functions
Storage / Allocation source construction
escaping closures
persistent callable values in aggregates
concurrency
code generation
```

The existing experimental module/private-field/receiver-call surface remains unchanged.

---

## 2. Closed sums and match

M2 accepts concrete closed sums such as:

```text
sum MaybeU32 {
  None,
  Some(u32),
}
```

M2 uses the current qualification punctuation:

```text
MaybeU32::None()
MaybeU32::Some(u32(42))
```

The exact no-payload constructor spelling remains surface-provisional; the semantic distinction is what is tested.

Match:

```text
match value {
  None => { ... }
  Some(payload) => { ... }
}
```

M2 enforces:

```text
known variant names
no duplicate arms
exhaustive arms
payload/no-payload pattern agreement
all arm result types agree
```

By-value matching a non-Copy sum consumes the whole sum binding. No source-visible partially-moved sum state is introduced.

---

## 3. Non-Discardable sum payload closure

M2 found and closed an important source-level obligation.

For a by-value sum:

```text
sum MaybeDomain {
  None,
  Some(LifetimeDomain),
}
```

this is accepted:

```text
match value {
  None => { unit }
  Some(domain) => {
    finalize_domain(domain)
    unit
  }
}
```

but:

```text
Some(_) => { unit }
```

is rejected because it would discard a non-Discardable payload.

Likewise a named non-Discardable payload binding must be consumed on normal arm exit.

New diagnostics include:

```text
E_NONDDiscardable_PATTERN
E_MATCH_PAYLOAD_NOT_CONSUMED
```

This is a source-checker completion, not a Draft 17.2 semantic change.

---

## 4. Ref match and occurrence stability

When matching an ordinary ref to a sum:

```text
value: ref<read/write, MaybeU32>
```

a payload binding receives a ref with the same ordinary access mode:

```text
Some(x)
    -> x: ref<mode,u32>
```

The arm is treated as dependent on the current variant occurrence of the parent sum.

The M2 effect/dependency lowering uses an arm-scoped occurrence dependency on the parent sum place.

Whole-sum `store(...)` emits:

```text
Change(parent)
Reset(parent)
```

so this pattern is rejected:

```text
match value {
  Some(x) => {
    store(value, MaybeU32::None())
  }
  ...
}
```

The real-source regression confirms the rejection through the shared source semantic checker.

Payload refs are not permitted to escape the match-arm occurrence scope in the M2 front end.

---

## 5. Structured Place / Projection representation

M0.1 explicitly left string-form place paths as an implementation issue to revisit before arrays/index projections became substantial.

M2 addresses that boundary.

The front end now has a small compiler-internal representation:

```text
Place(root, projections...)

FieldProjection(name)
IndexProjection(key)
```

Only the final bridge to the older source semantic checker renders this to a string path.

Examples:

```text
values
values.$index:0
node.field.$index:1
```

This avoids constructing semantic places by ad-hoc string concatenation throughout the front end.

A wrapper regression verifies:

```text
set_first(ref<write,Array<u32,2>>)
    -> store(values[0], ...)
```

substitutes back to:

```text
values.$index:0
```

at the caller.

A dependency on index 0 conflicts, while a dependency on index 1 remains distinct.

---

## 6. Arrays

M2 adds:

```text
Array<T,N>
```

where `N` is a compile-time integer in the M2 parser/type system.

Indexing follows the existing surface direction:

```text
ref<mode,Array<T,N>>[i]
    -> ref<mode,T>

ptr<Array<T,N>>[i]
    -> ptr<T>

span<mode,T>[i]
    -> ref<mode,T>
```

By-value Array indexing remains rejected:

```text
Array<T,N>[i]
```

because it would reintroduce ordinary partial-move/extraction questions for non-Copy arrays.

---

## 7. Spans

M2 adds:

```text
span<read,T>
span<write,T>
```

and:

```text
array_span(ref<mode,Array<T,N>>)
    -> span<mode,T>

len(span)
    -> usize

subspan(span,start,count)
    -> span<mode,T>
```

`span<write,T> -> span<read,T>` participates in the same post-selection contextual weakening rule as ordinary refs.

No exclusive span is introduced.

The exact lifecycle simulator represents spans as scoped access views over an Array handle. Bounds are checked for the constant-index/range source cases exercised in M2.

---

## 8. Nonescaping block type and literal

M2 adds:

```text
block(A, B) -> R
```

and block literals:

```text
{ |x: T|
    ...
}
```

including zero-parameter blocks:

```text
{ ||
    ...
}
```

Blocks are synchronous/nonescaping in this prototype.

M2 rejects direct storage of block values in:

```text
struct fields
sum payloads
function return types
```

so introducing the syntax does not accidentally create escaping closures.

---

## 9. Callback capture invariant

M2 enforces the existing 0..N callback capture rule conservatively at block-literal checking time:

> an outer captured non-Copy binding must have the same availability at each normal invocation exit as at invocation entry.

Therefore a block cannot permanently consume a captured `LifetimeDomain`, even when passed to a concrete `consume_array` whose `N` is 0 or 1.

This deliberately avoids a cardinality-based ownership exception.

A non-Discardable callback parameter itself must be consumed on normal block exit.

Diagnostics include:

```text
E_CALLBACK_CAPTURE_CONSUME
E_BLOCK_PARAM_NOT_CONSUMED
```

---

## 10. `consume_array`

M2 implements the Draft 17.2 whole-value decomposition surface:

```text
consume_array(
    Array<T,N>,
    block(T)->unit
) -> unit
```

Type-level behavior:

```text
Copy(Array<T,N>) == Copy(T)

Copy Array:
    caller binding remains available

non-Copy Array:
    caller binding is consumed
```

The lifecycle simulator invokes the block exactly `N` times in index order.

For:

```text
Array<LifetimeDomain,2>
```

the entry harness seeds two distinct domain identities and verifies that a callback which finalizes each fresh parameter discharges both obligations.

For:

```text
N == 0
```

the block is invoked zero times, while the received non-Copy Array is still consumed at the call boundary.

---

## 11. General block parameters

M2 also permits ordinary functions to receive a nonescaping block parameter:

```text
fn apply_twice(f: block(u32)->unit) -> unit {
  f(u32(1))
  f(u32(2))
  unit
}
```

The lifecycle bridge captures the lexical environment in a `BlockHandle` and executes the typed block body synchronously.

For the source effect/dependency bridge, calls with concrete block-literal actuals are specialized/inlined at lowering time so callback capture effects are mapped to caller places.

A regression verifies that:

```text
captured w -> Box::set -> store(self@value,...)
```

inside a block passed through another function is still seen as:

```text
Change(box.value)
```

at the original caller.

This closes the main M2 callback-function-boundary hole without introducing a source-visible effect language.

---

## 12. Store closure exposed by M2

The broader resource/sum corpus exposed a pre-existing front-end omission in `store`.

M2 now enforces:

```text
store(ref<write,T>, new:T)
    requires Discardable(T)
```

and the new value is treated as a consuming by-value argument when non-Copy.

This matches the already-adopted semantic interpretation:

```text
store = replace + discard old value
```

A `store` of a sum whose possible payload includes `LifetimeDomain` is therefore rejected.

This is a front-end correction, not a semantic revision.

---

## 13. Lifecycle bridge additions

The exact M2 lifecycle bridge adds prototype handles for:

```text
SumHandle
ArrayHandle
SpanHandle
BlockHandle
```

It can execute:

```text
sum construction
runtime sum arm selection
array entry seeding
array/span constant indexing
subspan constant bounds
block invocation
consume_array iteration
```

For ref-matched sum payloads, the runtime handle carries an arm-local scope anchor; a payload ref cannot escape the active occurrence.

Fixed-array ptr indexing remains a typed projection and does not gain independent root-ending authority.

---

## 14. Source semantic exact/bounded regressions

M2 adds direct comparison against the existing bounded source semantic analyzer for representative new cases:

```text
sum occurrence conflict
callback capture effect through block-parameter specialization
structured array-index place through wrapper substitution
```

The bounded layer agrees with the exact source semantic result on these regressions.

The production lifecycle checker itself is not yet extended with the M2 Sum/Array/Span handle layer; that remains an implementation-quality follow-up rather than a semantic blocker.

---

## 15. Real `.nl` corpus added

M2 adds programs `46` through `70`, covering:

```text
by-value sum match
ref sum match
occurrence reset conflict
non-exhaustive match
payload-ref escape
span index/len
span write->read weakening
by-value Array index rejection
subspan bounds
Copy consume_array preserving caller binding
non-Discardable consume_array
consume_array use-after-consume
N==0 consume_array
callback capture restriction
span out-of-bounds
general block parameter
callback effect through function boundary
non-Discardable sum payload consumption
non-Discardable payload discard rejection
N==0 callback capture still rejected
callback parameter consumption obligation
block return escape rejection
store non-Discardable rejection
structured array-index semantic place
```

---

## 16. Validation

Final M2 front-end suite:

```text
113 tests collected
113 passed
compileall PASS
```

The independent Draft 17.2 closure prototype was rerun unchanged:

```text
110 tests passed
compileall PASS
```

No upstream Draft 17.2 regression was observed.

`ruff`, `mypy`, and `pyright` were not available in the execution environment, so this report does not claim those checks passed.

---

## 17. Remaining implementation limits

### 17.1 Generic sums/functions

M2 uses concrete closed sums. Generic sum parameters and general generic-function front-end instantiation remain for a later milestone.

### 17.2 Dynamic lifecycle index precision

The type checker accepts general `usize` index expressions.

The exact M2 lifecycle simulator currently requires a compile-time integer when it must choose a concrete Array/Span element for bounds/resource simulation.

This is an implementation precision limit, not proposed language semantics.

### 17.3 Production lifecycle bridge

The M1.1 production lifecycle bridge is not yet widened to the new M2 sum/array/span/callback handle layer.

The source effect/dependency layer does have exact/bounded M2 regressions.

### 17.4 Local-root `ptr_from_ref`

The M1.1 explicit diagnostic for:

```text
ptr_from_ref(ref-to-ordinary-lexical-local)
```

remains. Ordinary local-root unification should be solved as a place/incarnation representation task rather than faked inside the conversion builtin.

---

## 18. Architecture judgment

The M0 -> M1.1 architecture survives M2.

The real-source vertical slice now includes:

```text
module/private representation/receiver calls
ordinary + exclusive refs
ptr/lifetime-domain lifecycle
ptr/ref stability conversion
closed sums + occurrence-sensitive match
Array/span projections
nonescaping block callbacks
consume_array whole-value decomposition
```

Three particularly useful corrections came from M2 pressure:

```text
string-only place building -> structured Place/Projection

store now enforces Discardable(T) and consuming new-value use

non-Discardable sum/callback payload obligations are checked at source scope exits
```

None requires widening the Draft 17.2 semantic kernel.

---

## 19. M2 judgment

**Front-End Prototype M2 passes.**

The new source surface composes with the existing semantic distinctions without introducing:

```text
partial-move Array state
independent element lifetime roots
escaping closures
cardinality-sensitive callback ownership
public struct representation
general effect annotations
```

No Draft-18-level semantic change is indicated.

The strongest next step is **not immediately M3 feature expansion**. A small M2.1 implementation-quality closure would have good information value around:

```text
dynamic index/range abstract handling
production lifecycle support for Sum/Array/Span
ordinary lexical-local root unification
match payload-result dependency precision
```

After that, M3 can concentrate on the generic dependent-call / associated lookup path with a substantially more complete real-source front end.
