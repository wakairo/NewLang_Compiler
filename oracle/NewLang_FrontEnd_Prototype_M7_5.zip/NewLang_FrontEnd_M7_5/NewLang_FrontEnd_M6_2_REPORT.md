# NewLang Front-End Prototype M6.2 — Authority-Preserving Dynamic Region Closure

> Status: completed experimental M6.2 implementation
>
> Semantic baseline: NewLang v0 Draft 17.2
>
> Starting point: Front-End Prototype M6.1
>
> Research input: `netresearch_001_dynamic_lifetime_bridge.md` (external web research supplied by the user)
>
> Purpose: replace the M6.1 metadata-driven authority-reconstruction experiment with an authority-preserving region/claim model, then break it with DenseVec, Ring, Slab, non-Discardable responsibility, transition failure/reentry, wrong-root claims, ZST policy, over-alignment, live borrows, and address-sensitive values.

## 1. Why M6.2 changed direction

M6/M6.1 established two useful facts:

```text
dense runtime containers need raw-vacant <-> typed-live transitions

safe Allocation / Storage / slot algebra works through real source
```

The external research then identified a stronger invariant that M6.1 had not modeled explicitly:

```text
metadata describes occupancy
!=
metadata creates authority
```

The M6.1 experimental surface:

```text
unchecked_dematerialize_storage
unchecked_materialize_slot
unchecked_recover_whole_storage
```

allowed a conceptual implementation in which metadata correctness justified reconstruction of claims. That is too broad for NewLang's non-Copy/non-Discardable responsibility model: corrupt or incomplete metadata must not erase a live semantic responsibility or mint a duplicate vacant authority.

M6.2 therefore changes the dynamic-container model from **authority reconstruction** to **authority conservation and scoped transfer**.

## 2. What remains unchanged

M6.2 keeps the M6.1 safe raw-storage algebra:

```text
Allocation
Storage

allocate_storage
split_storage
merge_storage
storage_into_slot
erase_slot
deallocate_storage
```

These values remain non-Copy/non-Discardable resource authorities. Typed reallocation through ordinary `take -> semantic value -> initialize` also remains valid.

No dynamic initialized-index set is added to the compiler core.

No source-visible lifetime/effect parameter system is added.

Ordinary nominal layout remains opaque.

## 3. M6.1 general dynamic bridge is retired

The three M6.1 experimental source builtins:

```text
unchecked_dematerialize_storage
unchecked_materialize_slot
unchecked_recover_whole_storage
```

now reject with:

```text
E_M62_LEGACY_DYNAMIC_BRIDGE
```

The exact lifecycle bridge also rejects them even if a typed IR is synthesized directly; the old behavior is not left as a hidden bypass.

This is intentional. M6.2 does **not** immediately replace them with a new frozen source spelling.

The research result indicates that the semantic mechanism should be tested before choosing between:

```text
sealed region value
scoped closure
receipt/token
requires fn
library-facing privileged compiler hook
```

The concrete source surface therefore remains Provisional.

## 4. Internal authority-preserving region model

M6.2 adds `newlang_frontend.authority_region_pressure`.

The central experimental object is `SealedRegion`.

Conceptually:

```text
SealedRegion
    owns one backing/root origin
    + hidden responsibility partition
    + no externally duplicated Storage authority
```

Each element range is in exactly one responsibility state:

```text
vacant
live
claimed_vacant
claimed_live
```

Claim extraction is a transfer:

```text
region owns vacant responsibility
    -> claim_vacant
claim owns slot<T> responsibility
```

or:

```text
region owns live T responsibility
    -> claim_live
claim receipt owns live T responsibility
```

Returning the claim transfers the responsibility back.

For non-Discardable test values, a separate debug/proof `ResponsibilityOracle` records exactly one owner:

```text
external
region-id
claim-id
discharged
```

This oracle is test instrumentation, not production occupancy metadata.

## 5. Whole Storage is returned, not reconstructed

`SealedRegion` is created with one retained origin/backing responsibility.

`unseal()` succeeds only if:

```text
all element responsibilities are vacant
no scoped claim is outstanding
no stable borrow is outstanding
no live root remains
no slot/raw subclaim remains
no transition is active
```

Then the region is consumed and whole Storage is returned.

The important difference from M6.1 is:

```text
metadata says empty
    !=
permission to create whole Storage
```

A test deliberately corrupts `DenseVec.length` to zero while a Token is still live. Whole Storage recovery remains rejected with:

```text
E_REGION_LIVE_RESPONSIBILITY
```

and the Token responsibility remains owned by the region.

## 6. DenseVec pressure

`DenseVecModel` uses:

```text
operational metadata: len
hidden authority state: SealedRegion responsibility ledger
```

The ledger is not derived from `len`.

### push transition

```text
claim vacant tail
initialize Token
publish len += 1
```

Failure is injected at two points:

```text
after vacant claim
    -> claim returned, input Token still external

after initialize but before len publication
    -> live Token taken back, vacant claim returned,
       input Token restored to external ownership
```

No responsibility disappears.

### unpublished transition / callback reentry

While object state and public metadata temporarily disagree, public observation is blocked with:

```text
E_REGION_TRANSITION
```

The prototype therefore distinguishes:

```text
steady-state operational metadata
transition-local responsibility guard
```

without making both authoritative occupancy maps.

### growth

Growth tests:

```text
allocation failure before transfer
    -> old region and all Token responsibilities unchanged

stable borrow live
    -> E_REGION_BORROWED

ordinary movable Token
    -> take from old region, initialize in new region, old region unseals

address-sensitive Token
    -> E_ADDRESS_SENSITIVE_RELOCATION
```

This prevents M6.1's successful `u32` reallocation from being generalized to self-referential/address-sensitive values.

## 7. Capacity-3 Ring pressure

`Ring3Model` uses only:

```text
head
len
```

as operational metadata.

The physical live set is checked against the hidden authority ledger.

All push/pop choice sequences up to depth 8 were replayed from scratch. Boundary attempts on full/empty states are expected rejects; all valid traces preserve logical FIFO state and responsibility conservation.

A reentrant observation between object initialization and metadata publication is rejected with `E_REGION_TRANSITION`, then the transition is rolled back.

This demonstrates that metadata SSOT does not imply that every instruction boundary exposes a valid steady-state invariant.

## 8. 8-slot Slab with inline free metadata

`Slab8Model` makes the strongest free-list distinction explicit:

```text
logical free slot:
    live FreeNode

allocated slot:
    live Token
```

Therefore:

```text
logical free
!=
raw vacant
```

Calling `claim_vacant` on a logically free slot is rejected with:

```text
E_REGION_NOT_VACANT
```

Allocation performs:

```text
claim live FreeNode
-> take/end FreeNode lifetime
-> vacant responsibility
-> initialize Token
-> publish allocated metadata
```

Freeing reverses the process and installs a new live `FreeNode`.

Teardown must explicitly end all `FreeNode` objects before the sealed region can return whole Storage.

This directly exercises the external-research counterexample that allocator/free-list metadata may itself be a live object.

## 9. Wrong-root, double-claim, stale receipt

The region prototype fixes the following authority properties:

```text
same vacant responsibility claimed twice
    -> reject

claim returned to another region/root
    -> E_REGION_WRONG_ROOT

claim reused after take/lifetime transition
    -> E_REGION_STALE_CLAIM

outstanding claim during unseal
    -> E_REGION_OUTSTANDING_CLAIM

stable borrow during lifetime-ending extraction/growth
    -> E_REGION_BORROWED
```

Live Token ownership also transfers to the live claim receipt while the claim is outside the region. It is not still recorded as region-owned in the responsibility oracle.

## 10. ZST and over-alignment

The research identified zero-sized types as a place where byte-range algebra alone is insufficient: multiple logical objects can have zero byte extent.

M6.2 does not invent a solution. The byte-range `SealedRegion` prototype explicitly rejects `elem_size == 0` with:

```text
E_M62_ZST_POLICY
```

This is an experimental boundary, not yet a proposal that NewLang v0 must globally ban ZST.

Over-aligned fixed-size slots are exercised separately; a 16-byte / align-16 element at the second slot begins at offset 16 and produces a correctly aligned typed claim.

## 11. Generated pressure

`run_m6_2_authority_region_experiment.py` produces `m6_2_authority_region_results.json`.

Fresh result:

```text
DenseVec generated pressure
    500 traces
    32,000 operations
    1,415 rolled-back transitions
    2,452 injected growth failures
    2,400 successful growths
    responsibility/logical mismatch: 0

Slab generated pressure
    300 traces
    19,200 operations
    mismatch: 0

Ring exhaustive
    depth 8
    88 valid explored traces
    21 expected full/empty boundary rejects
```

Counterexample diagnostics:

```text
metadata empty with hidden live responsibility
    -> E_REGION_LIVE_RESPONSIBILITY

logical free with live FreeNode
    -> E_REGION_NOT_VACANT

wrong-root return
    -> E_REGION_WRONG_ROOT

ZST byte-range model
    -> E_M62_ZST_POLICY
```

## 12. Validation

Fresh front-end validation:

```text
330 tests collected
330 passed
compileall PASS
```

Independent Draft 17.2 closure rerun:

```text
110 tests collected
110 passed
compileall PASS
executable closure vectors: covered by the 110-test suite; recorded baseline 12 / 12 PASS
generated differential: 100,000 cases
mismatch: 0
false accept: 0
false reject: 0
```

`ruff`, `mypy`, and `pyright` were not installed in the execution environment.

## 13. Semantic judgment

M6.2 changes the dynamic-container conclusion from:

```text
safe claim algebra
+
metadata-driven localized authority reconstruction
```

to:

```text
safe claim algebra
+
rooted/sealed responsibility owner
+
scoped claim extraction and return
+
metadata only describes operational occupancy
```

This is a meaningful correction, but it does not require a Draft-18-level object-model redesign.

The existing distinctions remain useful:

```text
raw storage
slot<T>
live T
BackingRegion identity
non-Copy/non-Discardable responsibility
LifetimeDomain stability
```

The new small general rule is:

> **metadata may describe responsibility, but may not create, duplicate, or erase it.**

## 14. Fix / Provisional / Deferred after M6.2

### Fix candidate

```text
occupancy metadata != authority
responsibility is conserved across dynamic lifetime transitions
claim origin/backing identity is preserved
outstanding claims/borrows block reuse/unseal
dynamic initialized-index set is not mandatory compiler core state
raw bytes do not imply valid T
```

### Provisional

```text
SealedRegion-like packaging
scoped claim receipt vs closure API
vacant/live claim extraction spelling
prefix/two-range safe helper
Layout<T> witness surface
whole Storage return by consuming region
ZST policy
in-place destruction vs take+discard for address-sensitive values
```

### Deferred

```text
general authority reconstruction from pointer + metadata
implicit object creation
transparent pointer rebinding
arbitrary bytes -> arbitrary T
general relocation trait / Pin framework
full concurrent reclamation API
```

## 15. Recommended next step

The next implementation should **not** broaden dynamic-container semantics again.

The highest-value continuation is an M6.3 API/representation closure around two remaining Provisional questions:

1. compiler-provided `Layout<T>` / extent/alignment witness for opaque generic `T`, without exposing field layout;
2. the smallest source form for consuming a rooted/sealed region and temporarily extracting/returning a claim.

That pass should keep DenseVec/Ring/Slab as regression oracles and compare:

```text
receipt/token API
nonescaping closure API
requires fn / privileged library hook
```

before any spelling is frozen into Draft 17.x.
