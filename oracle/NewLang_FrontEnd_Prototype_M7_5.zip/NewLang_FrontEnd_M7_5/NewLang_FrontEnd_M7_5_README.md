# NewLang Front-End Prototype M7.5

M7.5 is the FFI / external backing / opaque-call summary boundary milestone and closes the planned M7 C-substitutability/backend pressure phase.

Core closure:

```text
foreign signature != foreign semantic summary
foreign summary facts stay independent by axis
missing facts remain conservative Unknown
external aliases that cannot satisfy safe BackingRegion obligations remain opaque foreign views
LLVM attributes are emitted only from matching independently proved backend facts
```

M7.5 adds no normative FFI syntax and no general source-visible effect system.

Validation:

```text
466 / 466 front-end tests PASS
compileall PASS
100,000 foreign-summary differential cases: 0 mismatch / false accept / false reject
M7.4 / M7.3 / M7.2 / M7.1 / M7 published experiment outputs reproduced exactly
```

Backend destructive probe with Clang 17 demonstrates that a false `pure` foreign summary changes optimized behavior (`r=12` at `-O0`, `r=7` at `-O2`). An external-backing probe also demonstrates two distinct virtual addresses aliasing the same shared backing bytes.

See:

- `NewLang_Backend_Contract_v0_3.md`
- `NewLang_FrontEnd_M7_5_REPORT.md`
- `m7_5_ffi_boundary_results.json`
- `m7_5_backend_probe_results.json`
