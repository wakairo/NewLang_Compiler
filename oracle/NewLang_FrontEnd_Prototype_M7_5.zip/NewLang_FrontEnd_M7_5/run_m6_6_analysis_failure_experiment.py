from __future__ import annotations

import json
from dataclasses import asdict
from pathlib import Path

from newlang_frontend.analysis_failure_pressure import run_analysis_pressure, run_failure_pressure


def main() -> None:
    analysis = run_analysis_pressure(seed=20261004, cases=20_000)
    failure = run_failure_pressure(seed=20261004, traces=300, steps=64)
    result = {
        "milestone": "M6.6 Analysis / Unknown / Failure Closure",
        "analysis": asdict(analysis),
        "failure": failure,
    }
    out = Path("m6_6_analysis_failure_results.json")
    out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == "__main__":
    main()
