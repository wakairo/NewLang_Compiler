from __future__ import annotations

import json
import sys
from pathlib import Path

_VENDOR = Path(__file__).resolve().parent / "vendor"
if str(_VENDOR) not in sys.path:
    sys.path.insert(0, str(_VENDOR))

from newlang_checker.model import SemanticError
from newlang_checker.semantics import apply_step, load_initial
from newlang_frontend.current_value_pressure import _initial, run_current_value_pressure
from newlang_frontend.driver import check_source


def source_case(name: str, deps: tuple[str, ...]) -> dict[str, object]:
    path = Path("tests/programs") / name
    result = check_source(path.read_text(encoding="utf-8"), str(path), semantic_initial_deps=deps)
    return {
        "accepted": result.accepted,
        "diagnostic": result.diagnostic.code if result.diagnostic else None,
        "semantic_reason": result.semantic_reason,
    }


def structural_targeted() -> dict[str, object]:
    st = load_initial(_initial())
    before = st.roots["left"]
    before_root = before.root_value_fact
    before_fields = {k: {"incarnation": v.incarnation, "fact": v.value_fact} for k, v in before.fixed_subobjects.items()}
    apply_step(st, {"op": "replace_root_package", "root": "left", "new_value": "new_left", "result_old": "old_a"})
    middle = st.roots["left"]
    apply_step(st, {"op": "replace_root_package", "root": "left", "new_value": "old_a", "result_old": "old_c"})
    final = st.roots["left"]

    stale_code = None
    stale = load_initial(_initial(cap_dep="LVA"))
    try:
        apply_step(stale, {"op": "replace_root_package", "root": "left", "new_value": "new_left", "result_old": "old"})
    except SemanticError as exc:
        stale_code = exc.kind

    same = load_initial(_initial(cap_dep="LVA"))
    same_before = same.clone()
    apply_step(same, {"op": "swap_roots", "roots": ["left", "left"]})

    return {
        "whole_replace_preserves_root_incarnation": final.incarnation == before.incarnation,
        "whole_replace_preserves_fixed_incarnations": all(
            final.fixed_subobjects[k].incarnation == before_fields[k]["incarnation"] for k in before_fields
        ),
        "whole_replace_refreshes_fixed_value_facts": all(
            final.fixed_subobjects[k].value_fact != before_fields[k]["fact"] for k in before_fields
        ),
        "aba_semantic_value_returns": final.value_package.local == "A",
        "aba_root_fact_not_resurrected": final.root_value_fact not in {before_root, middle.root_value_fact},
        "aba_old_fixed_facts_not_live": all(before_fields[k]["fact"] not in st.live_value_facts for k in before_fields),
        "hidden_fixed_dependency_reject": stale_code,
        "same_place_swap_complete_noop": same.roots == same_before.roots and same.live_value_facts == same_before.live_value_facts,
    }


def main() -> None:
    result = {
        "schema": "newlang.m6_5_current_value_version/v1",
        "seed": 20261004,
        "source": {
            "sibling_update": source_case("214_current_value_sibling_update_ok.nl", ("p.a",)),
            "field_conflict": source_case("215_current_value_field_update_conflict.nl", ("p.a",)),
            "whole_conflict": source_case("216_current_value_whole_update_conflict.nl", ("p.a",)),
            "alias_conflict": source_case("217_current_value_alias_write_conflict.nl", ("p.a",)),
            "alias_sibling": source_case("218_current_value_alias_sibling_ok.nl", ("p.a",)),
            "swap_same": source_case("219_swap_same_place_dependency_ok.nl", ("p.a",)),
            "swap_distinct_conflict": source_case("220_swap_distinct_dependency_conflict.nl", ("p.a",)),
            "swap_disjoint_sibling": source_case("221_swap_disjoint_sibling_dependency_ok.nl", ("p.c",)),
            "generic_swap": source_case("222_generic_swap_unconstrained_ok.nl", ()),
        },
        "structural": structural_targeted(),
        "generated": run_current_value_pressure(seed=20261004, cases=20_000),
        "judgment": {
            "runtime_version_counter_required": False,
            "general_state_dependent_permission_language_required": False,
            "structural_rule": "subplace update changes that place and ancestors; known-disjoint siblings preserve current-value facts",
            "whole_value_rule": "root and fixed-descendant current-value facts refresh while incarnations remain stable",
            "same_place_swap": "semantic no-op",
            "distinct_swap": "both target current-value fact families refresh simultaneously",
            "aba_rule": "semantic equality does not resurrect an old current-value fact",
        },
    }
    out = Path("m6_5_current_value_version_results.json")
    out.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(out.read_text(encoding="utf-8"), end="")


if __name__ == "__main__":
    main()
