import json
from pathlib import Path
from newlang_frontend.storage_layout_pressure import run_storage_layout_pressure

result = run_storage_layout_pressure(seed=20261004, cases=20_000)
Path('m7_2_storage_layout_results.json').write_text(json.dumps(result, indent=2, sort_keys=True) + '\n', encoding='utf-8')
print(json.dumps(result, indent=2, sort_keys=True))
