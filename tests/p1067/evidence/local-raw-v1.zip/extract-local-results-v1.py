from pathlib import Path
from collections import Counter
import hashlib
import json
import re
import subprocess

art = Path('/workspace/p1067-artifacts')
source = Path('/tmp/p1067-clean')
profiles = []
reference = None
all_physical = []
for name in ['gcc', 'clang', 'asan', 'ubsan']:
    results = []
    logs = []
    for phase, count in [('semantic', 64), ('remaining', 528)]:
        label = name + '-' + phase + '-FIRST'
        meta = json.loads((art / (label + '.json')).read_bytes())
        assert meta['exit'] == 0, label
        text = (art / (label + '.stdout')).read_text()
        rows = re.findall(r'^\s*\d+/\d+ Test\s+#\d+:\s+(\S+)\s+\.{2,}\s*(Passed|\*\*\*[A-Za-z]+)\s+([\d.]+) sec', text, re.M)
        assert len(rows) == count and all(state == 'Passed' for _, state, _ in rows)
        results += [dict(name=n, result=s, seconds=float(t)) for n, s, t in rows]
        logs.append((art / (label + '.LastTest.log')).read_text(errors='replace'))
    names = {r['name'] for r in results}
    assert len(results) == len(names) == 592 and 'llvm.c_api' in names
    if reference is None:
        reference = names
    assert names == reference
    semantic, native = logs
    owner_cases = len(re.findall(r'^P965 parent=.*exactly-once PASS$', semantic, re.M))
    ledger_positions = sum(map(int, re.findall(r'^P965 reached OOM positions=(\d+);', semantic, re.M)))
    assert owner_cases == 494 and ledger_positions == 502
    physical = []
    for line in native.splitlines():
        if line.startswith('{'):
            try:
                row = json.loads(line)
            except ValueError:
                continue
            if row.get('P1062') == 'physical':
                physical.append(row)
    assert len(physical) == 36 and len({r['source'] for r in physical}) == 6
    assert {r['opt'] for r in physical} == {'-O0', '-O2'}
    assert {r['guest_successes'] for r in physical} == {0, 1, 2}
    for row in physical:
        assert 'all_H_closed_before_T=YES actual_caller_returns=YES' in row['observations']
    reached = sum(map(int, re.findall(r'^P1062 OOM SUMMARY reached=(\d+)$', native, re.M)))
    statuses = Counter(map(int, re.findall(r'^P1062 OOM index=\d+ .*status=(\d+)', native, re.M)))
    # Public NLNodeCStatus: unsupported=1, out-of-memory=2.
    assert reached == 2750 and statuses == {2: 2634, 1: 116}
    assert native.count('P1062 original C byte identities PASS 44') == 1
    assert len(re.findall(r'^P1062 SOURCE REJECT ', native, re.M)) == 13
    diagnostics = [line for line in (semantic + native).splitlines()
                   if re.search(r'ERROR: (AddressSanitizer|LeakSanitizer)|runtime error:|SUMMARY: (UndefinedBehaviorSanitizer|AddressSanitizer|LeakSanitizer)', line)]
    assert not diagnostics, (name, diagnostics[:3])
    profiles.append(dict(name=name, tests_PASS=592, tests_FAIL=0,
                         ownership_trials=owner_cases, ledger_OOM_reached=ledger_positions,
                         emitter_reached=reached, emitter_status_counts=dict(statuses),
                         emitter_OOM=statuses[2], emitter_unsupported=statuses[1],
                         physical_traces=len(physical), original_C_byte_identities=44,
                         frozen_source_negatives=13, tests=results))
    all_physical += [dict(profile=name, **row) for row in physical]

assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'])
value = dict(release='C156 P1067 full local verification, finite P sources only',
             tested_HEAD=subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD']).decode().strip(),
             tree=subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD^{tree}']).decode().strip(),
             profiles=profiles, full_named_sets_identical=True,
             semantic_and_remaining_disjoint=True, physical_traces=all_physical,
             total_physical_traces=len(all_physical), runtime_sanitizer_diagnostics=[],
             first_build_RED='gcc-build-FIRST exit2 missing host -lxml2 development link; unchanged candidate then built after task-local link to existing runtime',
             whitespace_diagnostic='inherited frozen raw plus two pre-frozen non-C EOF blanks; original console truncated, full reproduction labelled REPRODUCED, no normalization',
             previous_FIRST_RED='all old Git blobs unchanged; original failed C150 CI and original R findings not regraded',
             new_CI_so_far=0, new_R_F_execution=False,
             unverified=['new F disposition', 'independent R on integrated tree', 'universal source-to-C soundness', 'comparative author+caller human audit/re-audit cost', 'performance', 'R raw Git custody'])
target = art / 'local-results-v1.json'
assert not target.exists()
target.write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps(dict(tested_HEAD=value['tested_HEAD'], tree=value['tree'],
                      profiles=[{k:v for k,v in p.items() if k != 'tests'} for p in profiles],
                      total_physical_traces=len(all_physical),
                      summary_SHA256=hashlib.sha256(target.read_bytes()).hexdigest()), indent=2))
