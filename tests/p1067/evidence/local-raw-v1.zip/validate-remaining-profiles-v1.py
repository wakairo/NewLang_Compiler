from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys

source = Path('/tmp/p1067-clean')
art = Path('/workspace/p1067-artifacts')
cmake = '/workspace/p965-build-tools/cmake/data/bin/cmake'
ctest = '/workspace/p965-build-tools/cmake/data/bin/ctest'
clang = os.environ['NEWLANG_SDK_ROOT'] + '/bin/clang-23'
selected = art / 'semantic-preflight-names-v1.txt'
reference = {t['name'] for t in json.loads((art / 'gcc-inventory-FIRST.json').read_bytes())['tests']}


def run(label, command):
    result = subprocess.run([sys.executable, str(art / 'capture.py'), label,
                             'env', 'PYTHONDONTWRITEBYTECODE=1',
                             'LIBRARY_PATH=/tmp/p1067-system-libs', *command], cwd=source)
    if result.returncode:
        raise SystemExit(result.returncode)


for name, sanitizer, workers in [('clang', 'none', 2), ('asan', 'address', 1),
                                  ('ubsan', 'undefined', 1)]:
    build = Path('/tmp/p1067-' + name)
    run(name + '-configure-FIRST', [cmake, '-S', str(source), '-B', str(build),
        '-DCMAKE_C_COMPILER=' + clang, '-DCMAKE_BUILD_TYPE=Debug',
        '-DCMAKE_C_FLAGS=-Wno-error=gcc-install-dir-libstdcxx',
        '-DNEWLANG_SANITIZER=' + sanitizer,
        '-DCMAKE_PROJECT_INCLUDE=' + str(source / 'cmake/independent-r-tests-hook.cmake')])
    run(name + '-build-FIRST', [cmake, '--build', str(build), '--parallel', '2'])
    result = subprocess.run([ctest, '--test-dir', str(build), '--show-only=json-v1'],
                            cwd=source, capture_output=True)
    assert result.returncode == 0, result.stderr
    target = art / (name + '-inventory-FIRST.json')
    assert not target.exists()
    target.write_bytes(result.stdout)
    tests = [t['name'] for t in json.loads(result.stdout)['tests']]
    assert len(tests) == len(set(tests)) == 592 and set(tests) == reference
    for phase, selector in [('semantic', '--tests-from-file'),
                             ('remaining', '--exclude-from-file')]:
        run(name + '-' + phase + '-FIRST', [ctest, '--test-dir', str(build),
            selector, str(selected), '--output-on-failure', '--stop-on-failure',
            '--parallel', str(workers)])
        saved = art / (name + '-' + phase + '-FIRST.LastTest.log')
        assert not saved.exists()
        shutil.copyfile(build / 'Testing/Temporary/LastTest.log', saved)
    assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'])
    print('P1067 completed full local profile', name, '592 disjoint PASS', flush=True)

print('P1067 remaining Clang / ASan-LSan / UBSan local profiles complete', flush=True)
