from pathlib import Path
import hashlib
import json
import zipfile

art = Path('/workspace/p1067-artifacts')
dest = Path('/tmp/p1067-integrate/tests/p1067/evidence')
dest.mkdir(exist_ok=True)
labels = ['merge-FIRST', 'audit-clean-FIRST', 'v12-clean-FIRST', 'history-clean-FIRST',
          'gcc-configure-FIRST', 'gcc-build-FIRST', 'gcc-build-AFTER-LINK-PREPARATION',
          'pinned-format-FIRST', 'local-analysis-FIRST']
for profile in ['gcc', 'clang', 'asan', 'ubsan']:
    if profile != 'gcc':
        labels += [profile + '-configure-FIRST', profile + '-build-FIRST']
    labels += [profile + '-semantic-FIRST', profile + '-remaining-FIRST']
names = [label + suffix for label in labels for suffix in ['.json', '.stdout', '.stderr']]
for profile in ['gcc', 'clang', 'asan', 'ubsan']:
    names += [profile + '-inventory-FIRST.json', profile + '-semantic-FIRST.LastTest.log',
              profile + '-remaining-FIRST.LastTest.log']
names += ['capture.py', 'validate-remaining-profiles-v1.py', 'extract-local-results-v1.py',
          'pack-local-v1.py', 'semantic-preflight-names-v1.txt',
          'semantic-preflight-plan-v1.json', 'production-identity-v1.json',
          'snapshot-cost-v1.json', 'local-link-preparation-v1.json',
          'whitespace-diagnostic.json', 'whitespace-inherited-diagnostic-REPRODUCED.stdout',
          'whitespace-tip-delta-diagnostic-REPRODUCED.stdout', 'local-results-v1.json']
assert len(names) == len(set(names))
assert all((art / name).is_file() for name in names)
sha = lambda data: hashlib.sha256(data).hexdigest()
archive_path = dest / 'local-raw-v1.zip'
assert not archive_path.exists()
with zipfile.ZipFile(archive_path, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
    hashes = {}
    for name in sorted(names):
        data = (art / name).read_bytes()
        hashes[name] = sha(data)
        archive.writestr(name, data)
    archive.writestr('MANIFEST-SHA256.json', json.dumps(hashes, indent=2) + '\n')
with zipfile.ZipFile(archive_path) as archive:
    assert archive.testzip() is None
    for name, digest in hashes.items():
        assert sha(archive.read(name)) == digest
catalog = dict(release='C156 P1067 local raw v1',
               archive='tests/p1067/evidence/local-raw-v1.zip',
               bytes=archive_path.stat().st_size,
               entries=len(names) + 1, SHA256=sha(archive_path.read_bytes()),
               summary_SHA256=sha((art / 'local-results-v1.json').read_bytes()),
               scope='explicit owned raw list; all original failure logs retained, no ambient cache inputs',
               first_console_whitespace='truncated; separate full immutable-tree reproduction is labelled REPRODUCED')
target = dest / 'local-raw-v1.json'
assert not target.exists()
target.write_text(json.dumps(catalog, indent=2) + '\n')
target = dest / 'local-results-v1.json'
assert not target.exists()
target.write_bytes((art / 'local-results-v1.json').read_bytes())
print(json.dumps(catalog, indent=2))
