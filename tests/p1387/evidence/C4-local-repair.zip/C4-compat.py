from pathlib import Path
import hashlib
import json
import os
import subprocess

r = Path('/workspace/p1387-c768')
repo = r / 'repo'
out = r / 'C4-compat'
out.mkdir()
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def run(label, command):
    (out / (label + '.attempt.json')).write_text(json.dumps(command) + '\n')
    p = subprocess.run(command, capture_output=True, env=dict(os.environ,
        ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',
        UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1'))
    (out / (label + '.stdout')).write_bytes(p.stdout)
    (out / (label + '.stderr')).write_bytes(p.stderr)
    assert p.returncode == 0 and not p.stderr, (label, p.returncode, p.stderr)
    return p.stdout
assert not subprocess.check_output(['git', 'diff', 'd8129e061b7cf66bf0ca9d970fdb3ea35ca85005', '--',
    'tests/p605', 'tests/p603', 'tests/p634'], cwd=repo)
cases = json.loads((repo / 'tests/p605/composition-frozen.json').read_text())['cases']
rows = []
for name, case in cases.items():
    source = repo / 'tests/p605' / name
    assert sha(source) == case['sha256']
    baseline = run(name + '-baseline', [str(r / 'baseline/newlangc'), str(source)])
    for host in ['gcc', 'asan', 'ubsan']:
        label = name + '-' + host
        compiler = r / 'builds' / host / 'newlangc'
        assert not run(label + '-check', [str(compiler), '--check', str(source)])
        emitted = run(label + '-emit', [str(compiler), str(source)])
        assert emitted == baseline
        proof = run(label + '-owned', [str(r / 'builds' / host / 'p605_public_probe'), str(source)])
        value = json.loads(proof.splitlines()[0])
        assert (value['add'], value['sub'], value['bool'], value['authority']) == (
            case['add'], case['subtract'], case['bool'], 0)
        rows.append({'host': host, 'source': name, 'source_SHA256': sha(source),
            'C_SHA256': hashlib.sha256(emitted).hexdigest(), 'baseline_C_byte_identical': True,
            'public': value, 'native': 'NOT_RERUN: identical C/helper/source/oracle to successful adopted-main inputs'})
print(json.dumps({'guest_new': 0, 'guest_total': 26, 'checks': rows}, indent=2))
