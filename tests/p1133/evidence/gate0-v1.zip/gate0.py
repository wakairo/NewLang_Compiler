from pathlib import Path
import hashlib,json,subprocess,sys
p=Path(__file__).resolve().parent;binary=Path(sys.argv[1]);raw=p/'raw';raw.mkdir(exist_ok=False)
freeze=json.loads((p/'freeze.json').read_bytes())
for name,sha in freeze['files'].items():assert hashlib.sha256((p/name).read_bytes()).hexdigest()==sha,name
assert hashlib.sha256(binary.read_bytes()).hexdigest()==freeze['compiler_sha256']
rows=[]
for case in json.loads((p/'oracle.json').read_bytes())['baseline_runs']:
    source=p/'sources'/(case+'.nl');named=raw/(case+'.c');sentinel=b'C222 original named bytes\x00\xff\n';named.write_bytes(sentinel);before=named.stat()
    for mode,args in [('check',['--check',source]),('emit',[source]),('named',['--emit-c17-to',named,source])]:
        r=subprocess.run([str(binary),*map(str,args)],capture_output=True,timeout=60)
        label=case+'-'+mode;(raw/(label+'.out')).write_bytes(r.stdout);(raw/(label+'.err')).write_bytes(r.stderr)
        rows.append(dict(case=case,mode=mode,status=r.returncode,stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest(),stderr=r.stderr.decode()))
        (raw/'observations.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,r.returncode,r.stderr.decode(),flush=True)
        if mode=='named' and r.returncode:
            assert named.read_bytes()==sentinel and before.st_ino==named.stat().st_ino and before.st_mtime_ns==named.stat().st_mtime_ns
