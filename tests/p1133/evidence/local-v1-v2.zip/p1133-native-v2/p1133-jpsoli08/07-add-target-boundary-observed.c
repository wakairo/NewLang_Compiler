/* North Star V0/V1/AVS Checked-C reference output. */
#include <stdint.h>

#include <limits.h>
_Static_assert(CHAR_BIT == 8, "NewLang C17 requires 8-bit bytes");
_Static_assert(UINT8_MAX == 255 && sizeof(uint8_t) == 1 && ((uint8_t)-1) == 255, "NewLang C17 requires exact 8-bit uint8_t");
#include <stddef.h>
_Static_assert(SIZE_MAX == UINTMAX_C(18446744073709551615), "NewLang usize target mismatch");

typedef struct { uint8_t f0; uint8_t f1; } nl_type_10;

#ifdef NEWLANG_LOOP_OBSERVER
#include NEWLANG_LOOP_OBSERVER
#endif
#ifndef NL_LOOP_BIND
#define NL_LOOP_BIND(...) ((void)0)
#endif
#ifndef NL_LOOP_READ
#define NL_LOOP_READ(...) ((void)0)
#endif
#ifndef NL_LOOP_BEFORE
#define NL_LOOP_BEFORE(...) ((void)0)
#endif
#ifndef NL_LOOP_AFTER
#define NL_LOOP_AFTER(...) ((void)0)
#endif

#ifndef NL_LOOP_PHASE
#define NL_LOOP_PHASE(...) ((void)0)
#endif
#ifndef NL_LOOP_CONTINUE
#define NL_LOOP_CONTINUE(...) ((void)0)
#endif

static void nl_fn_11(void);
static uint8_t nl_fn_10(uint8_t *nl_local_4, uint8_t nl_local_5);

static void nl_fn_11(void)
{
    nl_type_10 nl_local_1 = { .f0 = 60, .f1 = 219, };
    (void)nl_local_1;
    NL_LOOP_BIND(&nl_local_1.f0, &nl_local_1.f1);
    const nl_type_10 nl_local_2 = { .f0 = 97, .f1 = 148, };
    (void)nl_local_2;
    NL_LOOP_BIND(&nl_local_2.f0, &nl_local_2.f1);
    uint8_t nl_local_8;
    size_t nl_loop_carry_17 = (size_t)UINTMAX_C(18446744073709551613);
    for (;;) {
        const size_t nl_loop_phase_17 = nl_loop_carry_17;
        NL_LOOP_PHASE(nl_loop_phase_17, &nl_local_1.f0, &nl_local_1.f1);
        if (nl_loop_phase_17 < (size_t)UINTMAX_C(18446744073709551615)) {
            nl_loop_carry_17 = nl_loop_phase_17 + (size_t)UINTMAX_C(1);
            NL_LOOP_CONTINUE(nl_loop_phase_17, nl_loop_carry_17, &nl_local_1.f0, &nl_local_1.f1);
            continue;
        }
        NL_LOOP_BEFORE(&nl_local_1.f0, &nl_local_1.f1, 0);
        nl_local_8 = nl_fn_10(&nl_local_1.f0, 171);
        NL_LOOP_AFTER(&nl_local_1.f0, &nl_local_1.f1, 0, nl_local_8);
        break;
    }
    (void)nl_local_8;
    uint8_t nl_loan_result_2;
    {
        uint8_t *const nl_local_9 = &nl_local_1.f1;
        (void)nl_local_9;
        const uint8_t nl_replace_old_22 = *nl_local_9;
        *nl_local_9 = nl_local_8;
        p1133_outer_store(nl_local_9);
        nl_loan_result_2 = nl_replace_old_22;
    }
    (void)nl_loan_result_2;
    const uint8_t nl_local_10 = nl_loan_result_2;
    (void)nl_local_10;
    const uint8_t nl_local_11 = nl_local_1.f0;
    (void)nl_local_11;
    NL_LOOP_READ(&nl_local_1.f0, nl_local_11);
    const uint8_t nl_local_12 = nl_local_1.f1;
    (void)nl_local_12;
    NL_LOOP_READ(&nl_local_1.f1, nl_local_12);
    const uint8_t nl_local_13 = nl_local_2.f0;
    (void)nl_local_13;
    NL_LOOP_READ(&nl_local_2.f0, nl_local_13);
    const uint8_t nl_local_14 = nl_local_2.f1;
    (void)nl_local_14;
    NL_LOOP_READ(&nl_local_2.f1, nl_local_14);
    (void)0;
    return;
}

static uint8_t nl_fn_10(uint8_t *nl_local_4, uint8_t nl_local_5)
{
    p1133_helper(nl_local_4, nl_local_5);
    (void)nl_local_5;
    (void)nl_local_4;
    const uint8_t nl_replace_old_2 = *nl_local_4;
    *nl_local_4 = nl_local_5;
    p1133_changed(nl_local_4);
    const uint8_t nl_local_6 = nl_replace_old_2;
    (void)nl_local_6;
    return nl_local_6;
}

int main(void)
{
    nl_fn_11();
    return 0;
}
