#define main c226_cli_main
#include "main.c"
#undef main
#include <assert.h>

int main(int argc, char **argv)
{
    assert(argc == 2);
    NLSource *source = NULL, *entry = NULL;
    NLParser *parser = NULL, *ep = NULL;
    NLSyntaxTree *tree = NULL, *et = NULL;
    NLSemanticContext *c = NULL;
    NLCheckedFragment *root = NULL;
    assert(nl_source_load(argv[1], &source) == NL_SOURCE_OK);
    assert(nl_parser_create(source, &parser) == NL_PARSE_OK);
    assert(nl_parser_parse_function_unit(parser, &tree, NULL) == NL_PARSE_OK);
    assert(nl_semantic_create(&c) == NL_CHECK_OK);
    const NLSyntaxTree *units[] = {tree};
    assert(nl_semantic_register_function_unit(c, units, 1, NULL) == NL_CHECK_OK);
    assert(nl_source_create("main()", 6, "C226 actual call", &entry) == NL_SOURCE_OK);
    assert(nl_parser_create(entry, &ep) == NL_PARSE_OK);
    assert(nl_parser_parse_expression_fragment(ep, &et, NULL) == NL_PARSE_OK);
    assert(nl_semantic_check_expression(c, et, &root, NULL) == NL_CHECK_OK);
    const NLCheckedFragment *f = nl_checked_call_body(root, nl_checked_root(root));
    assert(f);
    printf("actual main owner validate=%d\n", nl_linear_break_owner_validate(f));
    for (size_t id = 1; id <= nl_checked_node_count(f); ++id) {
        const NLCheckedNodeView *n = nl_checked_node_view(f, id);
        if (n->kind == NL_CHECKED_LOOP) {
            NLLinearBreakView v = {0};
            const NLCheckStatus status = nl_linear_break_validate(f, id, &v);
            printf("loop=%zu status=%d scalar=%d result=%zu/%zu\n", id,
                   status, v.scalar_loop, v.result.type, v.result.value);
        }
    }
    V0Program full = {.unit = nl_semantic_unit_type(c),
                      .u8 = nl_semantic_core_type(c, NL_TYPE_U8)};
    printf("actual driver root validate=%d\n",
           v0_validate_call(root, nl_checked_root(root), &full));
    V0Program p = {.unit = nl_semantic_unit_type(c),
                   .u8 = nl_semantic_core_type(c, NL_TYPE_U8)};
    const NLCheckedNodeView *block = nl_checked_node_view(f, nl_checked_root(f));
    assert(block && block->kind == NL_CHECKED_BLOCK);
    for (NLCheckedNodeId id = block->first_item; id;) {
        const NLCheckedNodeView *n = nl_checked_node_view(f, id);
        assert(n);
        const bool ok = v0_validate_node(f, id, &p);
        printf("source-ordered item=%zu kind=%d initializer=%zu valid=%d "
               "aggregate=%zu scalar_loop=%d\n",
               id, n->kind, n->initializer, ok, p.aggregate, p.scalar_loop);
        if (!ok) {
            const NLCheckedNodeView *init = nl_checked_node_view(f, n->initializer);
            if (init && init->kind == NL_CHECKED_REGISTERED_CALL) {
                NLSymbolId formal = 0;
                const bool parameters = v1_call_parameter_kind(f, n->initializer,
                                                              &p, &formal, true);
                const NLCheckedFragment *body = nl_checked_call_body(f, n->initializer);
                printf("call=%zu custody=%d actual/formal=%d formal=%zu pure_body=%d "
                       "aggregate_guard=%d\n", n->initializer,
                       nl_h_custody_result_valid(f, n->initializer), parameters,
                       formal, body && parameters && predicate_body(body, formal, &p),
                       p.aggregate != 0);
            }
            break;
        }
        id = n->next_item;
    }

    const NLCheckedNodeView *original = nl_checked_node_view(f, block->first_item);
    const NLCheckedNodeView *change = NULL;
    const NLCheckedFragment *graph = NULL;
    for (size_t i = 1; i <= nl_checked_node_count(f); ++i) {
        const NLCheckedNodeView *n = nl_checked_node_view(f, i);
        if (n->kind == NL_CHECKED_LOOP) graph=nl_checked_loop_body(f,i);
        if (n->kind == NL_CHECKED_REPLACE) change=n;
    }
    assert(graph && change && original);
    const NLSemanticContext *worlds[] = {nl_checked_context(f),nl_checked_context(graph)};
    for(size_t i=0;i<2;++i){
        NLSemanticBindingView b={0};NLSemanticPlaceView place={0},child={0},other={0};
        assert(nl_semantic_binding_view(worlds[i],original->symbol,&b));
        assert(nl_semantic_place_view(worlds[i],b.place,&place));
        printf("epoch=%s availability=%d live=%d fixed_count=%zu incarnation=%zu fact=%zu\n",
               i?"owned-loop":"post-function",b.availability,place.live,place.fixed_field_count,place.incarnation,place.current_fact);
        if(place.fixed_field_count==2){
            assert(nl_semantic_place_view(worlds[i],place.fixed_fields[change->field.index],&child));
            assert(nl_semantic_place_view(worlds[i],place.fixed_fields[1-change->field.index],&other));
            printf("selected fact=%zu sibling fact=%zu\n",child.current_fact,other.current_fact);
        }
    }
    printf("Change before=%zu/%zu after=%zu/%zu\n",change->field.parent_fact,change->field.child_fact,change->field.parent_post_fact,change->field.child_post_fact);
    for(size_t i=1;i<=nl_checked_node_count(f);++i){
        const NLCheckedNodeView *n=nl_checked_node_view(f,i);
        if(n->kind==NL_CHECKED_FIELD_READ)
            printf("read index=%zu fact=%zu/%zu\n",n->field.index,n->field.parent_fact,n->field.child_fact);
    }

    nl_checked_destroy(root);
    nl_semantic_destroy(c);
    nl_syntax_tree_destroy(et);
    nl_parser_destroy(ep);
    nl_source_destroy(entry);
    nl_syntax_tree_destroy(tree);
    nl_parser_destroy(parser);
    nl_source_destroy(source);
    return 0;
}
