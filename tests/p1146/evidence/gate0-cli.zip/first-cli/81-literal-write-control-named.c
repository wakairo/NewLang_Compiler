/* North Star V0/V1/AVS Checked-C reference output. */
#include <stdint.h>

#include <limits.h>
_Static_assert(CHAR_BIT == 8, "NewLang C17 requires 8-bit bytes");
_Static_assert(UINT8_MAX == 255 && sizeof(uint8_t) == 1 && ((uint8_t)-1) == 255, "NewLang C17 requires exact 8-bit uint8_t");
typedef struct { uint8_t f0; uint8_t f1; } nl_type_10;

static void nl_fn_10(void);

static void nl_fn_10(void)
{
    nl_type_10 nl_local_1 = { .f0 = 72, .f1 = 203, };
    (void)nl_local_1;
    uint8_t nl_loan_result_1;
    {
        uint8_t *const nl_local_2 = &nl_local_1.f0;
        (void)nl_local_2;
        const uint8_t nl_replace_old_11 = *nl_local_2;
        *nl_local_2 = 119;
        nl_loan_result_1 = nl_replace_old_11;
    }
    (void)nl_loan_result_1;
    const uint8_t nl_local_3 = nl_loan_result_1;
    (void)nl_local_3;
    const uint8_t nl_local_4 = nl_local_1.f0;
    (void)nl_local_4;
    const uint8_t nl_local_5 = nl_local_1.f1;
    (void)nl_local_5;
    const uint8_t nl_local_6 = nl_local_3;
    (void)nl_local_6;
    (void)0;
    return;
}

int main(void)
{
    nl_fn_10();
    return 0;
}
