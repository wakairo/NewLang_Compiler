C226 initial named output must survive rejection
