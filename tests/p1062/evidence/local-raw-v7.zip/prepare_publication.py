from pathlib import Path
import hashlib,json,re,shutil,zipfile
r=Path('/workspace/p1062-gate0');d=r/'tests/p1062';a=Path('/workspace/p1062-artifacts')
passed=lambda n:set(re.findall(r'Test\s+#\d+:\s+(\S+)\s+\.{2,}\s+Passed',(a/n).read_text()))
inv={t['name'] for t in json.loads((a/'v6-gcc-inventory-FIRST.stdout').read_bytes())['tests']}
assert len(inv)==591 and passed('v7-gcc-all-FIRST.stdout')==inv
assert passed('v7-clang-all-FIRST.stdout')|passed('v7-clang-p738-FIRST.stdout')==inv
expected={n for n in inv if re.match(r'^p(633|817|785|790|965|974|961|990|982|1045|1055|1058)_',n)}
assert len(expected)==122 and passed('v7-ubsan-old-safety-FIRST.stdout')==expected
asan_sets=[passed(n) for n in ['v7-asan-old-safety-FIRST.stdout','v7-asan-p633-timeout-recovery-FIRST.stdout','v7-asan-unrun82-FIRST.stdout']]
assert list(map(len,asan_sets))==[39,1,82] and set.union(*asan_sets)==expected
assert not any(asan_sets[i]&asan_sets[j] for i in range(3) for j in range(i))
measurements={}
for k in ['gcc','clang','asan','ubsan']:
 raw=a/('v7-'+k+'-complete-LAST.log') if k in ['gcc','clang'] else a/('v7-'+k+'-target-FIRST.stdout')
 text=raw.read_text();rows=[json.loads(x) for x in text.splitlines() if x.startswith('{"P1062": "physical"')]
 assert len(rows)==36,(k,len(rows))
 reached=list(map(int,re.findall(r'P1062 OOM SUMMARY reached=(\d+)',text)));assert sorted(reached)==sorted([459,459,455,463,455,459])
 own='\n'.join(x for x in text.splitlines() if x.startswith('P1062 '))
 assert own.count('P1062 ACTUAL REJECT')==84 and own.count('P1062 H REJECT')==24 and own.count('P1062 WORLD REJECT')==42
 assert own.count('P1062 VIEW REJECT')==12 and own.count('P1062 OWNER A_destroyed_unrestored=YES B_current_exact_C_destroy=YES')==6 and own.count('P1062 H_OWNER foreign_arm_A_destroyed_unrestored=YES B_exact_C_destroy=YES')==6
 measurements[k]=dict(physical=rows,OOM_positions=reached,total_reached=sum(reached),OOM_status2=len(re.findall('status=2 ',own)),conservative_unsupported_status1=len(re.findall('status=1 ',own)),host_actual_current_faults=84,supplied_view_faults=36,H_owner_faults=24,world_faults=42,foreign_B_unrestored_A_destroy=12)
 assert measurements[k]['OOM_status2']==2634 and measurements[k]['conservative_unsupported_status1']==116
old={}
for k in ['gcc','clang','ubsan']:
 text=(a/('v7-'+k+'-complete-LAST.log')).read_text();old[k]=dict(owner_attempts=text.count('B-live exactly-once PASS'),CHECK_ledger_OOM=sum(map(int,re.findall(r'P965 reached OOM positions=(\d+)',text))))
 assert old[k]==dict(owner_attempts=494,CHECK_ledger_OOM=502)
s='\n'.join((a/n).read_text() for n in ['v7-asan-timeout-FIRST/LastTest.log','v7-asan-p633-recovered-LAST.log','v7-asan-unrun82-LAST.log'])
old['asan']=dict(owner_attempts=s.count('B-live exactly-once PASS'),CHECK_ledger_OOM=sum(map(int,re.findall(r'P965 reached OOM positions=(\d+)',s))));assert old['asan']==old['gcc']
for n in ['v7-gcc-all-FIRST','v7-clang-all-FIRST','v7-clang-p738-FIRST','v7-asan-target-FIRST','v7-ubsan-target-FIRST','v7-ubsan-old-safety-FIRST','v7-asan-p633-timeout-recovery-FIRST','v7-asan-unrun82-FIRST','v7-format-FIRST']:
 assert json.loads((a/(n+'.json')).read_bytes())['exit']==0,n
v=dict(release='C150 local mandatory verification complete; DRAFT HOLD only, pre-publication CI0',tested=json.loads((a/'tested-v7.json').read_bytes()),parent_HEAD='4c039095455e0df32eebf538b0f9db1db1e089cc',parent_tree='6c8dd17e7921becc3f02d66aefaf1c9c6130d87d',canonical='CURRENT_SPEC Draft17.34',positive_profiles=6,parent_first_backend_holes=['terminal_explicit_return','producer_direct_result','failure_scope_read'],negative_profiles=dict(CHECK0_current0_backend4=7,CHECK3=6,no_clobber=True),local_full=dict(gcc=591,clang=591,clang_parts=[1,590],asan_related=122,asan_parts=[39,1,82],ubsan_related=122,LLVM_infrastructure_smoke='not locally run; sole natural FULL5 may cover'),measurements=measurements,original_P965=old,old_generated_C_identities=44,source_freeze_SHA256=hashlib.sha256((d/'source-freeze-v1.json').read_bytes()).hexdigest(),original_v11=dict(SHA256='e78dc38e5dabc83fd7b619c43479ed293871fc67d830aeb98ddac26cac5b6bd4',Git_blob='e3b51f0cdd971418477aed4a5744b8a16789f073',inherited_keys=2307),first_RED_and_repairs='Parent initial3holes; v1 terminating unit body type0; v2 observer optional function unused; v4 old counter lane regression; v5 new history negative filename; v6 P738 old finite profile boundary; formatter-only; ENOSPC safe own build relocation; ASan P633 timeout90 recovered11.10sec after load relief. All originals/raw preserved; no source/oracle/timeout edits.',independence='No R1016/R1051/R1057/R1060 original source/oracle/runner/raw and no B1061 R details accessed/reused; no R/F launch/request. F90 only fixed-parent conditional static A read after independent freeze, no claim of new-candidate F proof.',limits='Only finite P six-source family tested, not original blind R POS-B or all lawful H variants, third helper/escaping reference/general CFG. No Product GO/formal soundness/comparative cost or performance claim.',VALUE_ALIGNMENT_RISK='B net63 private C lines/two borrowed Env pointers/no new heap object or issuer vs A honest NOCHANGE support matrix; broader audit/observer/history dependency and repeat cost real, human UB audit/re-audit closure advantage vs factored C and performance UNMEASURED. KEEP17.34 / REPLACE NONE / faithful4.2 N/A.',aggregation_note='An initial results-only aggregation assertion mixed legacy same-text owner/OOM records from full CTest logs; corrected by exact P1062 line prefix. No compiler/test/oracle/input/result bytes changed.')
(d/'evidence/local-results-v7.json').write_text(json.dumps(v,indent=2)+'\n')
zip_path=d/'evidence/local-raw-v7.zip';entries={}
with zipfile.ZipFile(zip_path,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in sorted(a.rglob('*')):
  if not p.is_file() or p.is_symlink() or 'parent' in p.relative_to(a).parts or p.name=='STATE.md':continue
  raw=p.read_bytes()
  if raw.startswith((b'\x7fELF',b'!<arch>')):continue
  n=str(p.relative_to(a));entries[n]=hashlib.sha256(raw).hexdigest();info=zipfile.ZipInfo(n,(2026,10,30,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED;info.external_attr=0o100644<<16;z.writestr(info,raw)
 z.writestr('SHA256-MANIFEST.json',json.dumps(entries,indent=2)+'\n')
(d/'evidence/local-raw-v7.json').write_text(json.dumps(dict(archive='tests/p1062/evidence/local-raw-v7.zip',SHA256=hashlib.sha256(zip_path.read_bytes()).hexdigest(),bytes=zip_path.stat().st_size,entries=len(entries),meaning='Exact UTF8 stdout/stderr/command JSON and original generated C data, no executable binaries; each entry SHA recorded inside. Original first RED preserved, missing v1 per-command archive never invented.'),indent=2)+'\n')
print('ALL LOCAL GATES complete physical144 rawZIP',zip_path.stat().st_size,'entries',len(entries),'sourceSHA',v['source_freeze_SHA256'])
