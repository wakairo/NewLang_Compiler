from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

root = Path(__file__).resolve().parent
label, *command = sys.argv[1:]
dest = root / (label + '.json')
assert command and not dest.exists(), ('preserve first result', label)
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
r = subprocess.run(command, capture_output=True, timeout=1800)
for stream in ['stdout','stderr']:
    (root/(label+'.'+stream)).write_bytes(getattr(r,stream))
value = dict(command=command,exit=r.returncode,raw_host_UTC_start=started,
             raw_host_UTC_finish=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             stdout_SHA256=hashlib.sha256(r.stdout).hexdigest(),
             stderr_SHA256=hashlib.sha256(r.stderr).hexdigest())
dest.write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(value),flush=True)
print(r.stdout.decode(errors='replace')[-2200:])
print(r.stderr.decode(errors='replace')[-4000:])
raise SystemExit(r.returncode)
