P1062 preserve complete prior output
