#include "/tmp/p1079/tests/p965/shared.h"
int main(int argc,char **argv){(void)node_backend;NLSemanticContext *base=NULL;TestNode n={0};if(argc!=2||!registry(argv[1],&base)||!checked(base,&n))return 1;char *c=NULL;size_t z=777;NLNodeCStatus s=nl_checked_c_node(n.entry,&c,&z);fprintf(stderr,"status=%d bytes=%zu\n",s,z);free(c);node_checked_destroy(&n);nl_semantic_destroy(base);return 0;}
