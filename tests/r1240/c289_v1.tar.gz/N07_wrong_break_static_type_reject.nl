struct PulseGate { leftward: u8, rightward: u8, }

fn other_phase(x: usize) -> usize {
    if (x == usize(0)) { usize(1) } else { usize(2) }
}

fn invalid_result(writer: ref<write,u8>, seed: usize) -> u8 {
    let selected = loop (iteration = seed) {
        if (iteration == usize(0)) {
            continue(other_phase(iteration));
        } else {
            if (iteration == usize(1)) {
                break usize(72);
            } else {
                break replace(writer, u8(5));
            }
        }
    };
    return selected;
}

fn main() -> unit {
    let instance = PulseGate { rightward: u8(64), leftward: u8(22) };
    let old = loan_write(instance@rightward) { |writer|
        invalid_result(writer, usize(0))
    };
    let post = instance@rightward;
    let sibling = instance@leftward;
    unit
}
