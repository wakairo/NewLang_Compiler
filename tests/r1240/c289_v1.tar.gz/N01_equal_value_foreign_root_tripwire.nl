struct DialSet { stable: u8, stroke: u8, }

fn nudge(position: usize) -> usize {
    if (position == usize(0)) { usize(1) } else { usize(2) }
}

fn change_other(writer: ref<write,u8>, value: u8) -> u8 {
    let old = loop (position = usize(0)) {
        if (position == usize(2)) {
            break replace(writer, value);
        } else {
            continue(nudge(position));
        }
    };
    return old;
}

fn main() -> unit {
    let left = DialSet { stroke: u8(118), stable: u8(41) };
    let right = DialSet { stable: u8(89), stroke: u8(118) };
    let old_right = loan_write(right@stroke) { |reference|
        change_other(reference, u8(6))
    };
    let left_stroke = left@stroke;
    let right_stroke = right@stroke;
    let left_stable = left@stable;
    let right_stable = right@stable;
    unit
}
