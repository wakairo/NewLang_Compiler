struct BeamNote { margin: u8, gain: u8, }

fn increment_phase(t: usize) -> usize {
    if (t == usize(0)) { usize(1) } else { usize(2) }
}

fn change_gain(field: ref<write,u8>) -> u8 {
    let previous = loop (index = usize(0)) {
        if (index == usize(2)) {
            break replace(field, u8(14));
        } else {
            continue(increment_phase(index));
        }
    };
    return previous;
}

fn main() -> unit {
    let a = BeamNote { gain: u8(109), margin: u8(26) };
    let old_gain = loan_write(a@gain) { |ref_gain|
        change_gain(ref_gain)
    };
    let before_sibling = a@margin;
    let old_sibling = loan_write(a@margin) { |ref_margin|
        replace(ref_margin, u8(96))
    };
    let after_sibling = a@margin;
    let after_gain = a@gain;
    unit
}
