struct FlashSlot { name: u8, level: u8, }

fn next_level(n: usize) -> usize {
    if (n == usize(0)) { usize(1) } else { usize(2) }
}

fn main() -> unit {
    let item = FlashSlot { level: u8(96), name: u8(18) };
    let escaped = loan_write(item@level) { |writer|
        writer
    };
    let old = loop (counter = usize(0)) {
        if (counter == usize(2)) {
            break replace(escaped, u8(16));
        } else {
            continue(next_level(counter));
        }
    };
    let now = item@level;
    unit
}
