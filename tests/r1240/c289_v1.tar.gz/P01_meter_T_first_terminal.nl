struct MeterLog { flank: u8, signal: u8, }

fn next_tick(tick: usize) -> usize {
    if (tick == usize(0)) {
        usize(1)
    } else {
        usize(2)
    }
}

struct RelayPod { path: Option<ptr<RelayPod>>, mark: u8, }

fn handoff_tail(
    head_edge: ref<write, Option<ptr<RelayPod>>>,
    tail_address: ptr<RelayPod>,
    tail_claim: Allocation,
    tail_domain: LifetimeDomain
) -> LiveTail {
    let detached = replace(head_edge, Option<ptr<RelayPod>>::None);
    return LiveTail {
        owned_ptr: tail_address,
        owned_allocation: tail_claim,
        owned_domain: tail_domain
    };
}

fn complete_tail(
    address: ptr<RelayPod>,
    claim: Allocation,
    domain: LifetimeDomain
) -> unit {
    loan_read(domain) { |still_live|
        let passive = ref_from_ptr(read, address, still_live);
        unit
    };
    let vacant = loan_exclusive_read(domain) { |ending|
        destroy(address, ending)
    };
    let recovered = erase_slot<RelayPod>(vacant);
    finalize_domain(domain);
    deallocate(claim, recovered);
    unit
}

fn old_at_terminal(writer: ref<write,u8>, replacement: u8) -> u8 {
    let old = loop (tick = usize(0)) {
        if (tick == usize(2)) {
            break replace(writer, replacement);
        } else {
            continue(next_tick(tick));
        }
    };
    return old;
}

fn main() -> unit {
    let watch = MeterLog { signal: u8(137), flank: u8(63) };
    let peer = MeterLog { flank: u8(24), signal: u8(137) };
    let old_signal = loan_write(watch@signal) { |write_signal|
        old_at_terminal(write_signal, u8(19))
    };
    let current_signal = watch@signal;
    let current_flank = watch@flank;
    let peer_signal = peer@signal;
    let peer_flank = peer@flank;
    match try_allocate_one<RelayPod>() {
        None => { unit },
        Some(top_grant) => {
            let OneBacking { allocation, raw } = top_grant;
            let top_claim = allocation;
            let top_slot = into_slot<RelayPod>(raw);
            let top_domain = lifetime_domain();
            let top_ptr = loan_read(top_domain) { |top_stable|
                initialize(
                    top_slot,
                    RelayPod { path: Option<ptr<RelayPod>>::None, mark: u8(31) },
                    top_stable
                )
            };
            match try_allocate_one<RelayPod>() {
                None => {
                    let vacant_top = loan_exclusive_read(top_domain) { |top_end|
                        destroy(top_ptr, top_end)
                    };
                    let recovered_top = erase_slot<RelayPod>(vacant_top);
                    finalize_domain(top_domain);
                    deallocate(top_claim, recovered_top);
                    unit
                },
                Some(bottom_grant) => {
                    let OneBacking { allocation, raw } = bottom_grant;
                    let bottom_claim = allocation;
                    let bottom_slot = into_slot<RelayPod>(raw);
                    let bottom_domain = lifetime_domain();
                    let bottom_ptr = loan_read(bottom_domain) { |bottom_stable|
                        initialize(
                            bottom_slot,
                            RelayPod { path: Option<ptr<RelayPod>>::None, mark: u8(167) },
                            bottom_stable
                        )
                    };
                    let link_before = loan_read(top_domain) { |top_stable|
                        let node_write = ref_from_ptr(write, top_ptr, top_stable);
                        replace(node_write@path, Option<ptr<RelayPod>>::Some(bottom_ptr))
                    };
                    let linked = loan_read(top_domain) { |top_stable|
                        let node_read = ref_from_ptr(read, top_ptr, top_stable);
                        read(node_read@path)
                    };
                    match linked {
                        None => { unit },
                        Some(target_address) => {
                            loan_read(bottom_domain) { |bottom_stable|
                                let target_read = ref_from_ptr(read, target_address, bottom_stable);
                                unit
                            }
                        },
                    };
                    let LiveTail {
                        owned_ptr,
                        owned_allocation,
                        owned_domain
                    } = loan_read(top_domain) { |top_stable|
                        let node_write2 = ref_from_ptr(write, top_ptr, top_stable);
                        handoff_tail(node_write2@path, bottom_ptr, bottom_claim, bottom_domain)
                    };
                    loan_read(owned_domain) { |bottom_stable|
                        let still_present = ref_from_ptr(read, owned_ptr, bottom_stable);
                        unit
                    };
                    complete_tail(owned_ptr, owned_allocation, owned_domain);
                    let vacant_top = loan_exclusive_read(top_domain) { |top_end|
                        destroy(top_ptr, top_end)
                    };
                    let recovered_top = erase_slot<RelayPod>(vacant_top);
                    finalize_domain(top_domain);
                    deallocate(top_claim, recovered_top);
                    unit
                },
            }
        },
    };
    let signal_after_heap = watch@signal;
    let flank_after_heap = watch@flank;
    let peer_after_heap = peer@signal;
    unit
}
