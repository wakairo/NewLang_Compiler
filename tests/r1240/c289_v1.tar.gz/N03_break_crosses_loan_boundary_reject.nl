struct SpanMode { side: u8, pulse: u8, }

fn advance_mode(n: usize) -> usize {
    if (n == usize(0)) { usize(1) } else { usize(2) }
}

fn main() -> unit {
    let item = SpanMode { pulse: u8(82), side: u8(17) };
    let measured = loop (n = usize(0)) {
        if (n == usize(2)) {
            let wrong = loan_write(item@pulse) { |writer|
                break replace(writer, u8(3));
            };
            break u8(0);
        } else {
            continue(advance_mode(n));
        }
    };
    let after = item@pulse;
    unit
}
