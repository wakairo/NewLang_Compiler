struct BraidStem { edge: Option<ptr<BraidStem>>, mark: u8, }

fn separate_owner(
    head_edge: ref<write, Option<ptr<BraidStem>>>,
    tail_address: ptr<BraidStem>,
    tail_claim: Allocation,
    tail_domain: LifetimeDomain
) -> LiveTail {
    let detached = replace(head_edge, Option<ptr<BraidStem>>::None);
    return LiveTail {
        owned_ptr: tail_address,
        owned_allocation: tail_claim,
        owned_domain: tail_domain
    };
}

fn close_owner(
    address: ptr<BraidStem>,
    claim: Allocation,
    domain: LifetimeDomain
) -> unit {
    loan_read(domain) { |still_live|
        let passive = ref_from_ptr(read, address, still_live);
        unit
    };
    let vacant = loan_exclusive_read(domain) { |ending|
        destroy(address, ending)
    };
    let recovered = erase_slot<BraidStem>(vacant);
    finalize_domain(domain);
    deallocate(claim, recovered);
    unit
}

struct OrchardState { primary: u8, shadow: u8, }

fn hop_counter(value: usize) -> usize {
    if (value == usize(0)) {
        usize(1)
    } else {
        if (value == usize(1)) {
            usize(2)
        } else {
            usize(3)
        }
    }
}

fn original_at_last(writer: ref<write,u8>, fresh: u8) -> u8 {
    let previous = loop (position = usize(0)) {
        if (position < usize(3)) {
            let inner_break_decoy = loop () {
                break u8(249);
            };
            continue(hop_counter(position));
        } else {
            break replace(writer, fresh);
        }
    };
    return previous;
}

fn main() -> unit {
    let first = OrchardState { shadow: u8(53), primary: u8(211) };
    let second = OrchardState { primary: u8(211), shadow: u8(7) };
    let original = loan_write(first@primary) { |field_writer|
        original_at_last(field_writer, u8(46))
    };
    let first_now = first@primary;
    let shadow_now = first@shadow;
    let second_now = second@primary;
    match try_allocate_one<BraidStem>() {
        None => { unit },
        Some(top_grant) => {
            let OneBacking { allocation, raw } = top_grant;
            let top_claim = allocation;
            let top_slot = into_slot<BraidStem>(raw);
            let top_domain = lifetime_domain();
            let top_ptr = loan_read(top_domain) { |top_stable|
                initialize(
                    top_slot,
                    BraidStem { edge: Option<ptr<BraidStem>>::None, mark: u8(17) },
                    top_stable
                )
            };
            match try_allocate_one<BraidStem>() {
                None => {
                    let vacant_top = loan_exclusive_read(top_domain) { |top_end|
                        destroy(top_ptr, top_end)
                    };
                    let recovered_top = erase_slot<BraidStem>(vacant_top);
                    finalize_domain(top_domain);
                    deallocate(top_claim, recovered_top);
                    unit
                },
                Some(bottom_grant) => {
                    let OneBacking { allocation, raw } = bottom_grant;
                    let bottom_claim = allocation;
                    let bottom_slot = into_slot<BraidStem>(raw);
                    let bottom_domain = lifetime_domain();
                    let bottom_ptr = loan_read(bottom_domain) { |bottom_stable|
                        initialize(
                            bottom_slot,
                            BraidStem { edge: Option<ptr<BraidStem>>::None, mark: u8(209) },
                            bottom_stable
                        )
                    };
                    let link_before = loan_read(top_domain) { |top_stable|
                        let node_write = ref_from_ptr(write, top_ptr, top_stable);
                        replace(node_write@edge, Option<ptr<BraidStem>>::Some(bottom_ptr))
                    };
                    let linked = loan_read(top_domain) { |top_stable|
                        let node_read = ref_from_ptr(read, top_ptr, top_stable);
                        read(node_read@edge)
                    };
                    match linked {
                        None => { unit },
                        Some(target_address) => {
                            loan_read(bottom_domain) { |bottom_stable|
                                let target_read = ref_from_ptr(read, target_address, bottom_stable);
                                unit
                            }
                        },
                    };
                    let LiveTail {
                        owned_ptr,
                        owned_allocation,
                        owned_domain
                    } = loan_read(top_domain) { |top_stable|
                        let node_write2 = ref_from_ptr(write, top_ptr, top_stable);
                        separate_owner(node_write2@edge, bottom_ptr, bottom_claim, bottom_domain)
                    };
                    loan_read(owned_domain) { |bottom_stable|
                        let still_present = ref_from_ptr(read, owned_ptr, bottom_stable);
                        unit
                    };
                    close_owner(owned_ptr, owned_allocation, owned_domain);
                    let vacant_top = loan_exclusive_read(top_domain) { |top_end|
                        destroy(top_ptr, top_end)
                    };
                    let recovered_top = erase_slot<BraidStem>(vacant_top);
                    finalize_domain(top_domain);
                    deallocate(top_claim, recovered_top);
                    unit
                },
            }
        },
    };
    let first_after_heap = first@primary;
    let shadow_after_heap = first@shadow;
    let second_after_heap = second@primary;
    unit
}
