struct CueTrack { hold: u8, level: u8, }

fn step_once(n: usize) -> usize {
    if (n == usize(0)) { usize(1) } else { usize(2) }
}

fn return_new_instead(writer: ref<write,u8>, incoming: u8) -> u8 {
    let selected = loop (idx = usize(0)) {
        if (idx == usize(2)) {
            let discarded_old = replace(writer, incoming);
            break incoming;
        } else {
            continue(step_once(idx));
        }
    };
    return selected;
}

fn main() -> unit {
    let state = CueTrack { hold: u8(28), level: u8(124) };
    let result = loan_write(state@level) { |writer|
        return_new_instead(writer, u8(7))
    };
    let now = state@level;
    let same_hold = state@hold;
    unit
}
