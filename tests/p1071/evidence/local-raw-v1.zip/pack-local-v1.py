from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parent
target = Path('/tmp/p1071/tests/p1071/evidence/local-raw-v1.zip')
assert not target.exists()
files = []
for p in root.rglob('*'):
    if not p.is_file() or p.name in ('STATE.md', 'observe', 'R-archive-ref-reachability.txt'):
        continue
    if p.suffix not in ('.json','.stdout','.stderr','.log','.py','.txt','.data'):
        continue
    files.append(p)
files.sort()
manifest = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
with zipfile.ZipFile(target, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in files:
        z.writestr(str(p.relative_to(root)), p.read_bytes())
    z.writestr('archive-SHA256.json', json.dumps(manifest, indent=2)+'\n')
with zipfile.ZipFile(target) as z:
    assert z.testzip() is None and set(z.namelist()) == set(manifest) | {'archive-SHA256.json'}
    assert all(hashlib.sha256(z.read(n)).hexdigest()==h for n,h in manifest.items())
print('RAW ZIP', len(files)+1, 'entries', target.stat().st_size, 'bytes SHA256',hashlib.sha256(target.read_bytes()).hexdigest())
