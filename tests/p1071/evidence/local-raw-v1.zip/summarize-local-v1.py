from pathlib import Path
import hashlib
import json
import re
import subprocess

art = Path(__file__).resolve().parent
repo = Path('/tmp/p1071')
result = {'candidate': subprocess.check_output(['git','-C',str(repo),'rev-parse','HEAD'],text=True).strip(),
          'main': '2cf49e44aebc20c62469f9ea113bbaf01f4e752f', 'local': {}, 'new_profiles': {}}

def tests(label):
    meta = json.loads((art/(label+'.json')).read_bytes())
    text = (art/(label+'.stdout')).read_text()
    rows = re.findall(r'^\s*\d+/\d+ Test\s*#\d+:\s+(\S+)\s+\.{2,}(.*)$',text,re.M)
    assert rows and len(rows)==len({n for n,s in rows}), label
    return {n: 'PASS' if re.match(r'\s+Passed\s',s) else 'FAIL' for n,s in rows}, meta

gcc={}
for label in ['gcc-contract-FIRST','gcc-regression-FIRST','gcc-tooling-contract-FIRST']:
    rows,meta=tests(label);assert meta['exit']==0 and all(s=='PASS' for s in rows.values())
    assert not gcc.keys() & rows.keys();gcc.update(rows)
clang,meta=tests('clang-full-FIRST');assert meta['exit']==0 and all(s=='PASS' for s in clang.values())
assert len(gcc)==len(clang)==595 and gcc.keys()==clang.keys()
result['local']['GCC13']={'PASS':595,'partitions':[3,590,2],'tests':gcc}
result['local']['Clang23']={'PASS':595,'tests':clang}
initial,meta=tests('asan-targeted-FIRST')
assert meta['exit']==8 and [n for n,s in initial.items() if s!='PASS']==['p633_local_cli.integration']
repair,meta=tests('asan-p633-repaired-environment-FIRST');assert meta['exit']==0 and repair=={'p633_local_cli.integration':'PASS'}
asan=dict(initial);asan.update(repair)
ubsan,meta=tests('ubsan-targeted-FIRST');assert meta['exit']==0 and all(s=='PASS' for s in ubsan.values())
planned=set(json.loads((art/'sanitizer-scope-v2.json').read_bytes())['tests'])
assert asan.keys()==ubsan.keys()==planned and len(planned)==123
result['local']['ASan_LSan']={'initial_PASS':122,'initial_FAIL':1,'first_RED':'missing indirect p713_public_probe build prerequisite; FileNotFoundError; no source/oracle/Production change','repaired_only':['p633_local_cli.integration'],'final_PASS':123,'initial_tests':initial,'final_tests':asan}
result['local']['UBSan']={'PASS':123,'tests':ubsan}
for lane in ['gcc','clang','asan','ubsan']:
    summary=[]
    for path in sorted((art/(lane+'-contract')).glob('*/commands-FIRST.json')):
        commands=json.loads(path.read_bytes())
        emitted=next(c for c in commands if c['label']=='C17')
        assert emitted['exit']==0
        physical=[c for c in commands if re.fullmatch(r'-O[02]-guest[012]',c['label'])]
        assert len(physical)==6 and all(c['exit']==0 for c in physical)
        positions=int(re.search(r'OOM SUMMARY reached=(\d+)',(path.parent/'reached-OOM.stdout').read_text())[1])
        owner=(path.parent/'current-owner-negative.stdout').read_text()
        counts={key:owner.count('P1062 '+key+' REJECT') for key in ['ACTUAL','H','WORLD']}
        assert counts=={'ACTUAL':14,'H':4,'WORLD':7}
        summary.append({'profile':path.parent.name.split('-')[1], 'C_SHA256':emitted['stdout_SHA256'],
                        'physical_traces':6,'reached_emitter_OOM':positions,'host_negative':counts,
                        'foreign_B_survival':True,'named_no_clobber_exact_retry':True})
    assert len(summary)==3 and sum(s['reached_emitter_OOM'] for s in summary)==1369
    result['new_profiles'][lane]=summary
    old=[]
    for path in (art/(lane+'-regression')).glob('*/commands-FIRST.json'):
        oom=''.join(p.read_text() for p in path.parent.glob('*-reached-OOM.stdout'))
        old += list(map(int,re.findall(r'OOM SUMMARY reached=(\d+)',oom)))
    assert len(old)==6 and sum(old)==2750,(lane,old)
    result['local'][{'gcc':'GCC13','clang':'Clang23','asan':'ASan_LSan','ubsan':'UBSan'}[lane]]['old_P1062_emitter_OOM']=sum(old)
    log=art/({'clang':'clang-full-LastTest.log','asan':'asan-targeted-LastTest-FIRST.log','ubsan':'ubsan-targeted-LastTest-FIRST.log'}.get(lane,''))
    if lane!='gcc':
        text=log.read_text()
        assert not re.search(r'ERROR: (AddressSanitizer|LeakSanitizer)|runtime error:|UndefinedBehaviorSanitizer:',text)
        owner=len(re.findall(r'P965 parent=.*B-live exactly-once PASS',text))
        oom=list(map(int,re.findall(r'P965 reached OOM positions=(\d+)',text)))
        assert owner==494 and len(oom)==16 and sum(oom)==502,(lane,owner,oom)
        result['local'][{'clang':'Clang23','asan':'ASan_LSan','ubsan':'UBSan'}[lane]].update(P965_ownership_trials=owner,P965_ledger_OOM=sum(oom))
result['physical_traces_new']=72
result['scope']='Final literal unit RETURN only in existing authenticated closed-main H/T consumer; no new issuer/API/ABI/IR or semantics'
result['unverified']=['full local sanitizer suite (123 targeted, natural CI full pending)', 'independent F/R new-candidate audit', 'general RETURN/CFG and legal unsupported sources','human author+safe caller audit locality, performance and Product GO']
dest=art/'local-results-v1.json';assert not dest.exists();dest.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['local','new_profiles']},indent=2))
print('Local summaries', {k:{n:x for n,x in v.items() if n not in ['tests','initial_tests','final_tests']} for k,v in result['local'].items()})
print('SHA256',hashlib.sha256(dest.read_bytes()).hexdigest())
