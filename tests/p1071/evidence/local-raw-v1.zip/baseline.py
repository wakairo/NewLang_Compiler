from pathlib import Path
import hashlib
import json
import subprocess

repo = Path('/tmp/p1071')
data = repo / 'tests/p1071'
out = Path('/workspace/p1071-artifacts/parent-FIRST')
out.mkdir(exist_ok=False)
cli = Path('/tmp/p1067-gcc/newlangc')
cc = '/workspace/p1030-validation-tools/usr/bin/gcc-13'
commands = []

def run(label, args):
    args = list(map(str, args))
    r = subprocess.run(args, capture_output=True, timeout=180)
    (out / (label + '.stdout')).write_bytes(r.stdout)
    (out / (label + '.stderr')).write_bytes(r.stderr)
    commands.append(dict(label=label, command=args, exit=r.returncode,
                         stdout_SHA256=hashlib.sha256(r.stdout).hexdigest(),
                         stderr_SHA256=hashlib.sha256(r.stderr).hexdigest()))
    (out / 'commands-FIRST.json').write_text(json.dumps(commands, indent=2)+'\n')
    assert r.returncode >= 0, (label, r.returncode, r.stderr)
    return r

for name, digest in json.loads((data/'source-freeze-v1.json').read_bytes())['files'].items():
    assert hashlib.sha256((repo/name).read_bytes()).hexdigest() == digest
libs = [cli.parent / ('libnewlang_'+n+'.a') for n in
        ['semantic','parser','checked_c_node','lexer','checked','syntax','source','diagnostic']]
r=run('build-observe', [cc,'-std=c17','-Wall','-Wextra','-Werror','-pedantic-errors','-O0','-g',
    '-fno-pie','-no-pie','-I'+str(repo/'include'),repo/'tests/p1062/observe.c',
    '-Wl,--start-group',*libs,'-Wl,--end-group','-o',out/'observe'])
assert r.returncode == 0 and not r.stderr, r.stderr
summary=[]
for profile in json.loads((data/'oracle-v1.json').read_bytes())['profiles']:
    name=profile['name']; source=repo/profile['source']
    check=run(name+'-CHECK',[cli,'--check',source])
    assert not check.stdout
    if 'negative' not in profile:
        assert check.returncode == 0 and not check.stderr
        view=run(name+'-public-current',[out/'observe',source,'2'])
        assert view.returncode == 0 and not view.stderr, view.stderr
        rows=[json.loads(s) for s in view.stdout.splitlines() if s.startswith(b'{')]
        currents=[v for v in rows if v['P1062']=='current']
        assert len(currents)==2 and all(v['GET_body'] and v['GET_parameters'] and v['body']==v['parameters']==0 for v in currents)
    else:
        expected=profile['negative']
        assert check.returncode in expected.get('CHECK_allowed',[expected.get('CHECK')])
    named=out/(name+'.sentinel.c'); sentinel=b'P1071 preserve parent failure output\n'
    named.write_bytes(sentinel); before=named.stat()
    emitted=run(name+'-C17-FIRST',[cli,source])
    wanted=4 if check.returncode==0 else check.returncode
    assert emitted.returncode==wanted and not emitted.stdout,(name,emitted.returncode,emitted.stderr)
    rejected=run(name+'-named-no-clobber',[cli,'--emit-c17-to',named,source])
    after=named.stat()
    assert rejected.returncode==wanted and not rejected.stdout
    assert named.read_bytes()==sentinel and (before.st_dev,before.st_ino)==(after.st_dev,after.st_ino)
    summary.append(dict(source=name,CHECK=check.returncode,public_current='PASS' if 'negative' not in profile else 'not measured',C17=emitted.returncode,named_no_clobber=True,diagnostic=emitted.stderr.decode()))
(out/'results-FIRST.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
