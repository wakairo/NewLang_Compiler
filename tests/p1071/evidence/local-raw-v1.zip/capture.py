from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

root = Path(__file__).resolve().parent
label, *command = sys.argv[1:]
dest = root / (label + '.json')
assert command and not dest.exists(), ('preserve first result', label)
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
with (root / (label + '.stdout')).open('xb') as out, (root / (label + '.stderr')).open('xb') as err:
    result = subprocess.run(command, stdout=out, stderr=err, timeout=1800)
stdout = (root / (label + '.stdout')).read_bytes()
stderr = (root / (label + '.stderr')).read_bytes()
value = dict(command=command, cwd=str(Path.cwd()), exit=result.returncode,
             raw_host_UTC_start=started,
             raw_host_UTC_finish=datetime.datetime.now(datetime.timezone.utc).isoformat(),
             stdout_SHA256=hashlib.sha256(stdout).hexdigest(),
             stderr_SHA256=hashlib.sha256(stderr).hexdigest())
dest.write_text(json.dumps(value, indent=2) + '\n')
print(json.dumps(value), flush=True)
print(stdout.decode(errors='replace')[-2200:])
print(stderr.decode(errors='replace')[-3000:])
raise SystemExit(result.returncode)
