set auto-load python-scripts off
set debuginfod enabled off
set style enabled off
set environment ASAN_OPTIONS=detect_leaks=0:halt_on_error=1
break current_preserve_caller
commands 1
silent
printf "FRAME definition=%d function=%zu root=%zu floor=%zu readonly=%zu\n", check->definition, check->body_function, s->root, check->function_place_floor, s->readonly_parameter
set $idx=0
set $roots=0
while $idx < check->function_place_floor
if check->context->places[$idx].live && check->context->places[$idx].independent_root && check->context->places[$idx].fixed_field_count
printf "PREFIX ROOT id=%zu type=%zu fields=%zu/%zu incarnation=%zu\n", $idx+1, check->context->places[$idx].type, check->context->places[$idx].fixed_fields[0], check->context->places[$idx].fixed_fields[1], check->context->places[$idx].incarnation
set $roots=$roots+1
end
set $idx=$idx+1
end
printf "PREFIX ROOT COUNT=%zu\n", $roots
continue
end
break /workspace/p1359-c653/repo/src/current_loop_check_internal.h:2357
run
printf "ACTUAL REFUSAL definition=%d looproot=%zu previous=%zu candidate=%zu\n", check->definition, s->root, s->preserved_root, i+1
bt 5
finish
continue
