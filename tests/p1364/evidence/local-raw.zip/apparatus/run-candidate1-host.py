import pathlib,subprocess,json,hashlib,os,sys
R=pathlib.Path('/workspace/p1364-c670');S=R/'repo';host=sys.argv[1];mode={'gcc':'none','asan':'address','ubsan':'undefined'}[host]
CMAKE='/workspace/p1236-c291/tools/cmake/cmake/data/bin/cmake';SDK='/workspace/p1236-c291/sdk/.deps/toolchains/ubuntu-24.04-x86_64-7c9921be7919a10d/newlang-llvm-23.1.3-linux-x64'
CC='/usr/bin/gcc' if host=='gcc' else '/workspace/p1295-c439/tools/clang19/clang'
f=json.loads((R/'candidate1/preexecution-freeze.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==f['HEAD']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S)
for p,h in f['files'].items():assert hashlib.sha256((S/p).read_bytes()).hexdigest()==h
out=R/'candidate1';b=R/'builds'/host;assert not b.exists();b.parent.mkdir(exist_ok=True)
env=dict(os.environ,NEWLANG_SDK_ROOT=SDK,PATH=SDK+'/bin:'+os.environ['PATH'],ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
cmds=[('configure',[CMAKE,'-S',str(S),'-B',str(b),'-DCMAKE_BUILD_TYPE='+('Release' if host=='gcc' else 'Debug'),'-DCMAKE_C_COMPILER='+CC,'-DCMAKE_CXX_COMPILER=/usr/bin/g++','-DLLVM_CONFIG='+SDK+'/bin/llvm-config-23','-DNEWLANG_SANITIZER='+mode,'-DNEWLANG_FRONTEND_ONLY=OFF']),
('build',[CMAKE,'--build',str(b),'--target','newlangc','p1364_wrapper','p1332_cli_oom','--parallel','2']),
('StageA',[str(pathlib.Path(CMAKE).with_name('ctest')),'--test-dir',str(b),'-R','^p1364_.*[.]unit$','-V','--stop-on-failure','-j1'])]
(out/(host+'-commands.json')).write_text(json.dumps({'HEAD':f['HEAD'],'CC':CC,'sanitizer':mode,'commands':cmds},indent=2)+'\n')
for label,cmd in cmds:
 p=out/(host+'-'+label+'.raw')
 with p.open('xb') as log:q=subprocess.run(cmd,cwd=S,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(host,label,'status',q.returncode,flush=True)
 if q.returncode:print(p.read_text(errors='replace')[-5000:],flush=True);raise SystemExit(q.returncode)
 if label=='build':
  import shutil
  saved=out/'ELF'/host;saved.mkdir(parents=True,exist_ok=True);bins={}
  for name in ['newlangc','p1364_wrapper']:
   shutil.copyfile(b/name,saved/name);bins[name]=hashlib.sha256((saved/name).read_bytes()).hexdigest()
  (out/(host+'-ELF.json')).write_text(json.dumps(bins,indent=2)+'\n')
print(host,'Stage A PASS',flush=True)
