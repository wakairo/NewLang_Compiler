import json
import os
import pathlib
import subprocess
import sys

r = pathlib.Path('/workspace/p1364-c670')
out = r / 'candidate1'
plan = json.loads((out / 'StageB-plan.json').read_text())
item = next(x for x in plan['commands'] if x['name'] == sys.argv[1])
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=r/'repo', text=True).strip() == plan['HEAD']
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=r/'repo')
env = dict(os.environ, ASAN_OPTIONS='detect_leaks=1:halt_on_error=1', UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
log = out / (item['name'] + '-native.raw')
with log.open('xb') as f:
    p = subprocess.run(item['command'], cwd=r/'repo', env=env, stdout=f, stderr=subprocess.STDOUT)
(out / (item['name']+'-native-status.json')).write_text(json.dumps({'HEAD': plan['HEAD'], 'command': item['command'], 'exit_status': p.returncode}, indent=2)+'\n')
print(item['name'], p.returncode, flush=True)
print(log.read_text(errors='replace')[-3000:], flush=True)
raise SystemExit(p.returncode)
