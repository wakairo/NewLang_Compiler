C256 final sentinel
