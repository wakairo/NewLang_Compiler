C256 preexisting output
