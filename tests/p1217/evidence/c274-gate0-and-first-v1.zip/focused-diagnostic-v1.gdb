set confirm off
set pagination off
set print pretty off
set debuginfod enabled off
set disable-randomization off
unset environment LD_LIBRARY_PATH
handle SIGABRT nostop print pass
tbreak start
run emit /tmp/p1217/main/tests/p1217/sources/03-postheap-current-loop.nl 2
printf "C274 START point=%zu\n", point
up
set $c274_root_before = a.root
printf "C274 BEFORE root=%p\n", a.root
down
break inject if enabled && calls + 1 == fail_at
commands
silent
printf "C274 SITE ordinal=%zu pc=%p kind=%c\n", calls+1, pc, kind
bt 9
continue
end
break /tmp/p1217/main/tests/p1217/oom.c:142
commands
silent
printf "C274 ACTUAL status=%d out=%p length=%zu a.root=%p same_root=%d calls=%zu fail_at=%zu\n", status, out, length, a.root, a.root == $c274_root_before, calls, fail_at
print (NLNodeCStatus)status
printf "C274 CONJUNCTS status_is_expected_OOM=%d out_is_NULL=%d length_unchanged=%d root_nonNULL=%d\n", status == NL_NODE_C_OUT_OF_MEMORY, out == 0, length == 98765, a.root != 0
continue
end
continue
