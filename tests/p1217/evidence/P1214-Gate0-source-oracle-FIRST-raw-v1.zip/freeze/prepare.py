import hashlib,json,pathlib
root=pathlib.Path(__file__).parent
(root/'sources').mkdir()
base='''struct Meter { active:u8, reserve:u8 }
fn select_code(tick:usize)->u8 {
 let argument=tick;
 BODY
}
fn main()->unit {
 let seed=usize(0);
 let start=seed;
 let original=Meter{active:u8(52),reserve:u8(197)};
 let finish=loop(index=start){
  if(index < usize(5)){
   let actual=index;
   let next_value=select_code(actual);
   let previous=loan_write(original@active){|writer|replace(writer,next_value)};
   let previous_copy=previous;
   previous_copy;
   let observed=original@active;
   let sibling=original@reserve;
   observed;
   sibling;
   continue(index + usize(1));
  }else{break index;}
 };
 let after=original@active;
 let unchanged=original@reserve;
 let count=finish;
 unit
}
'''
statement='if(argument < usize(3)){return u8(29);}else{u8(181)};\n return u8(101);'
bound='let ignored=if(argument < usize(3)){return u8(29);}else{u8(181)};\n ignored;\n return u8(101);'
a=base.replace('BODY',statement)
b=base.replace('BODY',bound)
heap='''struct Link { next:Option<ptr<Link>>, payload:u8 }
struct Sample { lower:u8, upper:u8 }
fn take_tail(edge:ref<write,Option<ptr<Link>>>, address:ptr<Link>, allocation:Allocation, domain:LifetimeDomain)->LiveTail {
 let detached=replace(edge,Option<ptr<Link>>::None);
 return LiveTail{owned_ptr:address,owned_allocation:allocation,owned_domain:domain};
}
fn end_tail(address:ptr<Link>, allocation:Allocation, domain:LifetimeDomain)->unit {
 loan_read(domain){|stable|let live=ref_from_ptr(read,address,stable);unit};
 let vacant=loan_exclusive_read(domain){|ending|destroy(address,ending)};
 let storage=erase_slot<Link>(vacant);
 finalize_domain(domain);
 deallocate(allocation,storage);
 unit
}
fn phase_code(value:usize)->u8 {
 if(value < usize(2)){u8(67)}else{u8(191)}
}
fn main()->unit {
 PREFIX
 match try_allocate_one<Link>(){
  None=>{unit},
  Some(first_backing)=>{
   let OneBacking{allocation,raw}=first_backing;
   let first_allocation=allocation;
   let first_slot=into_slot<Link>(raw);
   let first_domain=lifetime_domain();
   let first=loan_read(first_domain){|stable|
    initialize(first_slot,Link{next:Option<ptr<Link>>::None,payload:u8(14)},stable)
   };
   match try_allocate_one<Link>(){
    None=>{
     let vacant=loan_exclusive_read(first_domain){|ending|destroy(first,ending)};
     let storage=erase_slot<Link>(vacant);
     finalize_domain(first_domain);
     deallocate(first_allocation,storage);
     unit
    },
    Some(second_backing)=>{
     let OneBacking{allocation,raw}=second_backing;
     let second_allocation=allocation;
     let second_slot=into_slot<Link>(raw);
     let second_domain=lifetime_domain();
     let second=loan_read(second_domain){|stable|
      initialize(second_slot,Link{next:Option<ptr<Link>>::None,payload:u8(235)},stable)
     };
     let absent=loan_read(first_domain){|stable|
      let link=ref_from_ptr(write,first,stable);
      replace(link@next,Option<ptr<Link>>::Some(second))
     };
     let seen=loan_read(first_domain){|stable|
      let view=ref_from_ptr(read,first,stable);
      read(view@next)
     };
     match seen{
      None=>{unit},
      Some(address)=>{loan_read(second_domain){|stable|let view=ref_from_ptr(read,address,stable);unit}},
     };
     let LiveTail{owned_ptr,owned_allocation,owned_domain}=loan_read(first_domain){|stable|
      let link=ref_from_ptr(write,first,stable);
      take_tail(link@next,second,second_allocation,second_domain)
     };
     loan_read(owned_domain){|stable|let view=ref_from_ptr(read,owned_ptr,stable);unit};
     end_tail(owned_ptr,owned_allocation,owned_domain);
     let vacant=loan_exclusive_read(first_domain){|ending|destroy(first,ending)};
     let storage=erase_slot<Link>(vacant);
     finalize_domain(first_domain);
     deallocate(first_allocation,storage);
     unit
    },
   }
  },
 };
 POSTFIX
}
'''
loop='''let initial=usize(0);
 let start=initial;
 let finish=loop(phase=start){
  if(phase < usize(4)){
   let argument=phase;
   let incoming=phase_code(argument);
   let old=loan_write(original@lower){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let current=original@lower;
   let sibling=original@upper;
   current;
   sibling;
   continue(phase + usize(1));
  }else{break phase;}
 };
 let final=original@lower;
 let sibling=original@upper;
 let iterations=finish;
 unit'''
construct='let original=Sample{lower:u8(43),upper:u8(229)};'
c=heap.replace('PREFIX','').replace('POSTFIX',construct+'\n '+loop)
d=heap.replace('PREFIX',construct).replace('POSTFIX',loop)
# Profile D uses the other declared field and equality, not an H-success-only T.
d=d.replace('if(value < usize(2)){u8(67)}else{u8(191)}','if(value == usize(1)){u8(83)}else{u8(173)}').replace('original@lower','original@upper').replace('original@upper;\n   current;','original@lower;\n   current;').replace('let sibling=original@upper;\n let iterations','let sibling=original@lower;\n let iterations')
profiles={
 '01-statement-mixed.nl':a,
 '02-binding-control.nl':b,
 '03-postheap-current-loop.nl':c,
 '04-preheap-original-current-loop.nl':d,
 '90-wrong-return-type.nl':b.replace('return u8(29);','return usize(29);'),
 '91-wrong-continue-type.nl':b.replace('continue(index + usize(1));','continue(u8(1));'),
 '92-escaped-write-ref.nl':b.replace('let previous=loan_write(original@active){|writer|replace(writer,next_value)};','let escaped=loan_write(original@active){|writer|writer};\n   let previous=next_value;'),
 '93-missing-failure-cleanup.nl':c.replace('     deallocate(first_allocation,storage);\n     unit\n    },','     unit\n    },',1),
}
assert len(profiles)==8 and c!=d
for n,s in profiles.items():
 (root/'sources'/n).write_text(s)
oracle={
 'baseline':'491f54adfa64ae7308344923ed14a9fcad08a8e9',
 'phase':'Gate0 BEFORE ANY SOURCE EXECUTION',
 'eligibility_references':['Draft17.34 16.3.8 one H plus one T; 18.1b original live-tail return and all 0/1/2 cleanup; 19.1 expression-statement discard; 27.4 normal vs RETURN edge; 27.5/27.9 and dependency inductive current rules'],
 'positive':{
  '01-statement-mixed.nl':{'source':'eligible; statement normal u8 discarded, early RETURN does not join normal continuation','prediction':'safe refusal in helper/current proof; no output; exact diagnostic/layer to be measured','incoming':[29,29,29,101,101],'old':[52,29,29,29,101],'final':101,'sibling':197,'loop_result':5},
  '02-binding-control.nl':{'source':'eligible; same runtime behavior as 01 via binding and explicit discard','prediction':'CHECK success, owned/current valid, C17 success','incoming':[29,29,29,101,101],'old':[52,29,29,29,101],'final':101,'sibling':197,'loop_result':5},
  '03-postheap-current-loop.nl':{'source':'eligible selected H cleanup completes in every allocation world before constructing T and running finite current loop','prediction':'conservative CHECK/issuer precision refusal or C17 dual-carrier unsupported; true first layer UNKNOWN','heap_worlds':[0,1,2],'heap_releases':[0,1,2],'incoming':[67,67,191,191],'old':[43,67,67,191],'final':191,'sibling':229,'loop_result':4},
  '04-preheap-original-current-loop.nl':{'source':'eligible same lexical T exists before H allocation and survives all cleanup worlds; update its other field after H completion','prediction':'conservative CHECK/issuer precision refusal or C17 dual-carrier unsupported; true first layer UNKNOWN','heap_worlds':[0,1,2],'heap_releases':[0,1,2],'incoming':[173,83,173,173],'old':[229,173,83,173],'final':173,'sibling':43,'loop_result':4}
 },
 'negative':{
  '90-wrong-return-type.nl':'invalid u8 helper RETURN type; CHECK reject, no output',
  '91-wrong-continue-type.nl':'invalid loop-carried static type; CHECK reject, no output',
  '92-escaped-write-ref.nl':'invalid escape of scoped writer; CHECK reject, no output',
  '93-missing-failure-cleanup.nl':'invalid undischarged original head Allocation on second-allocation failure; CHECK reject, no output'
 },
 'budget':{'positive_max':4,'negative_max':6,'all_direct_cli_and_proof_max':24,'focused_native_asan_oom_max':4,'remote':0},
 'execution':'Every invocation recorded before process start in append-only observations.jsonl; never execute refused or syntactically-invalid generated C. Named output sentinel must retain bytes/inode/mtime on refusal. Unsafe admission, owner/current mismatch or new public/world authority STOP before implementation.',
 'prior_evidence':'P1212 originals read-only; no R source/oracle/raw/rationale referenced',
 'selection_rule':'Prioritize genuine earlier H+T/current-loop dependency over optional statement syntax if it prevents ordinary reusable source. Safe binding is a cheaper A alternative. No automatic full-v0 claim.'
}
(root/'oracle-v1.json').write_text(json.dumps(oracle,indent=2)+'\n')
freeze={'before_execution':True,'main':oracle['baseline'],'tree':'603a72c443f0795bc58852d52ea8b0fe8771012a','files':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file()}}
(root/'source-freeze-v1.json').write_text(json.dumps(freeze,indent=2)+'\n')
print(json.dumps({'profiles':len(profiles),'freeze_sha256':hashlib.sha256((root/'source-freeze-v1.json').read_bytes()).hexdigest(),'oracle_sha256':hashlib.sha256((root/'oracle-v1.json').read_bytes()).hexdigest(),'sources':freeze['files']},indent=2))
