P1214 C271 postmerge source-critical Gate0 — LOCAL NO CHANGE

実mainは491f54adfa64ae7308344923ed14a9fcad08a8e9、parentsはbd3aed71d7c912d0096626fd20bb79ddf998af52と2f1f7a78f0777c5882fb10a3150bcd4618d801ed、treeは603a72c443f0795bc58852d52ea8b0fe8771012a。CURRENT_SPEC→Draft17.34、Compass→Value1.1/1.3→Process4.1.2/4.3.1/4.3.2/7とBackend Execution Policyを確認。live mainとPR1210実採用をread-only照合しました。

4独自正例/対照＋4負例を先行freezeし、直接source CLI16＋owned/current診断3＋backend診断2＋CHECK費用census1＝22観測。strict native focused2を含めて数えても24以内、focused上限4以内です。full回帰0、注入OOM0、Production/commit/remote branch/push/PR/Actions/CI0。既存main自然CIの読み取りは発火に数えず、Cのpostmerge FULL5確認を代行しません。

| 対象 | 実測Gate |
| --- | --- |
| statement mixed IF typed early RETURN→normal discard→later RETURN | source-eligible YES、CHECK3 P14-LOOP-PRECISION。安全なunsupportedを維持 |
| 同じ意味のbinding再表現 | CHECK0、actual owned/current/helper lineage成功、C17成功、GCC O0 / Clang O2 ASan+LSan+UBSan native成功 |
| H全cleanup後のT構築→current loop | CHECK0、元H-origin/producer・private current relation成功、C17=4 unsupported |
| H前からの同じ元T→cleanup後の他field loop | 同上。T original/root/child/fieldの対応をactual CHECKから確認 |
| wrong RETURN / wrong Continue / writer escape / missing failure cleanup | 全CHECK3、対応するsemantic診断、C17拒否時bytes/inode/mtime不変 |
| public single-direct-Break getter | actual Continue profileにはfalse。別契約の既存private full-loop validator成功と混同しない |

H+Tの最初の内部拒否は、loop自身や新issuerではありません。mixed consumerのcopy_prepare_atはstateful Copy-call parametersだけからcopy_type/issuer/anchorを発見します。pure usize→u8/current-loopの本sourceではcopy_prepare=1でも三つとも未設定です。従ってT constructorを専用copy_constructorへ渡せず、H-only shapeのrecursive nominal guardで拒否します。post-H sourceはH0/1/2分岐のcleanupをstagingした後、pre-H sourceは先頭Tで拒否しました。partial stagingは診断用txtとして保存し、C17成果物やnativeにはしていません。

優先する次工程は「stateful Copy helperの存在に依存しない元T physical carrier発見→全H cleanup world→既存current-loop/Break summary」のprivate合成です。statement版はbindingで同じ意味を保持できるため、Bを迂回して表記だけを拡張しません。今回の2独立sourceで、構築位置・Hをまたぐ同一original・field index・helper guardが異なる依存を確認しました。

必要な最小契約は、(1) CHECKのsealed loop entryとactual constructorから元T/root/incarnation/child/known initial fieldを借用認証、(2) Hの全None/Some cleanupを別々に完了してcommon continuationへ合流させ、H成功worldを昇格しない、(3)同じphysical Tに既存current-loop emitterを接続しold Copyと更新後field-current/sibling/Break summaryを区別、(4)型付きusize carrierとpure actual helper operandを既存制約で下げる、の一まとまりです。copy_bindとcopy_closed_worldの現契約（後者は2 roots/2 stateful calls）を単に緩める修復は不採用です。

新public issuer/API/worldが不可欠との証拠は得ていません。ただし二つのbackendのcarrier/current台帳を接続する健全性は未検証で、guard一箇所の修復には収まりません。今回の小さなconditional修復として安全に成立したとは主張せず、ProductionはNO CHANGE、affected implementation HOLDでCへ返します。次の有限縦実装の概算は1–2 P日で初候補、既存private view/borrow・C17 carrier consumer・H common continuationに限定し、新しいretained proof graph/snapshotを増やさない案を第一候補とします。これは見積であり実装/安全性PASSではありません。大きな一般CFG/issuer案が必要と判明したらその時点でSTOPです。

費用：B03一回の既存CHECKで、tracked requested heapはCHECK前132,277B、CHECK直後3,350,659B、peak3,361,173B。完全破棄後live bytes/allocations0、unknown free0。これはparse/register/context/checked trees全体で、proof専用bytes、allocator overhead、libc内部、census table BSSを含む一般性能指標ではありません。借用APIで辿れたfragmentはcontrol8/B16、隠れた全proof graphの総数ではありません。この作業によるProduction保持量・履歴snapshot増分0です。

未検証：新H+T sourceの実C17/native・guest0/1/2 failure physical paths・注入OOM/rollback、新statement typed lowering、一般CFG/複数loop/多nominal、全compiler sanitizer/full frontend。postmerge main FULL5は最後の読み取り時in_progress、PARTIALsuccessで、Cの全6確認待ちのままです。

旧P1212 STOP/FIRST/rawのworkspace保存packet二つはSHA一致。旧/tmp worktree/binary/local refsは再開時に存在せず、復旧済みとは扱っていません。GitHub固定mainから完全sourceを新規取得してfresh buildしました。旧候補や元証拠を書き換えず、v36/v53/v54/v55/v56もadopted mainと同一です。新observerの最初のhost compile error（診断引数の型取り違え）はsource/logを残したv2で機械修復。census v1は実行せず、realloc後の無効pointer値を読まないv2を先行freezeして一回だけ計測しました。

VALUE-ALIGNMENT-RISK（技術Gateと別）：Hのallocation/lifetime/failure policyと同じT physical identityを保つ合成は、通常CLIの利用可能性に関わるv0依存です。snapshot複製や特定fixture例外を増やすと、作者/ordinary-safe callerのUB防止監査・再監査責務とcompiler自体の保守費用が増え得ます。well-factored Cに対する監査局所性は未測定、CAPABILITYを一般soundnessやProduct PASSにしません。GO624 PAUSED/H1 HOLD、P1036 STOPを維持します。R1213/R1207/R1197 source/oracle/raw/rationaleは未読、新P起動0、READY/merge/Product GO0。
