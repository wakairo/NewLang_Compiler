#include <assert.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>
static uint8_t *p1214_active,*p1214_sibling;
static size_t p1214_phase,p1214_visits,p1214_locals,p1214_reads,p1214_results;
static unsigned p1214_mask;
static const uint8_t p1214_old[]={52,29,29,29,101};
static const uint8_t p1214_next[]={29,29,29,101,101};
static void p1214_finish(void)
{
 assert(p1214_visits==6 && p1214_locals==30 && p1214_reads==2 && p1214_results==1);
 puts("P1214 binding control: 5 real backedges, typed RETURN, old/Copy/current/sibling and original field addresses PASS");
}
static void p1214_bind(uint8_t *a,uint8_t *b)
{
 assert(!p1214_active && a!=b && b==a+1 && *a==52 && *b==197);
 p1214_active=a;p1214_sibling=b;assert(atexit(p1214_finish)==0);
}
static void p1214_enter(size_t phase,uint8_t *a,uint8_t *b)
{
 assert(phase==p1214_visits && phase<=5 && a==p1214_active && b==p1214_sibling && *b==197);
 if(phase) assert(p1214_mask==63);
 assert(*a==(phase<5?p1214_old[phase]:101));
 p1214_mask=0;p1214_phase=phase;++p1214_visits;
}
static void p1214_local(size_t id,uintmax_t value)
{
 assert(p1214_phase<5);unsigned bit=0;uintmax_t expected=0;
 switch(id){
 case 5:bit=1;expected=p1214_phase;break;
 case 9:bit=2;expected=p1214_next[p1214_phase];break;
 case 11:bit=4;expected=p1214_old[p1214_phase];break;
 case 12:bit=8;expected=p1214_old[p1214_phase];break;
 case 13:bit=16;expected=p1214_next[p1214_phase];break;
 case 14:bit=32;expected=197;break;
 default:assert(0);
 }
 assert(!(p1214_mask&bit) && value==expected);p1214_mask|=bit;++p1214_locals;
 if(bit>=4) assert(*p1214_active==p1214_next[p1214_phase] && *p1214_sibling==197);
}
static void p1214_result(size_t result)
{
 assert(result==5 && p1214_visits==6 && *p1214_active==101 && *p1214_sibling==197);++p1214_results;
}
static void p1214_read(uint8_t *field,uint8_t value)
{
 assert(p1214_results==1);
 assert(field==(p1214_reads==0?p1214_active:p1214_sibling));
 assert(value==(p1214_reads==0?101:197));++p1214_reads;
}
#define NL_LOOP_BIND(a,b) p1214_bind(a,b)
#define NL_LOOP_READ(a,b) p1214_read(a,b)
#define NL_CURRENT_PHASE(p,a,b) p1214_enter(p,a,b)
#define NL_CURRENT_LOCAL(i,v) p1214_local(i,(uintmax_t)(v))
#define NL_CURRENT_RESULT(v) p1214_result(v)
