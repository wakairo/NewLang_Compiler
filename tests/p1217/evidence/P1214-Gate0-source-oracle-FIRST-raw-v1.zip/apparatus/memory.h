#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
typedef struct {void *address;size_t bytes;} P1214Allocation;
static P1214Allocation p1214_allocations[32768];
static size_t p1214_count,p1214_live,p1214_peak,p1214_calls,p1214_untracked;
void *__real_malloc(size_t);
void *__real_calloc(size_t,size_t);
void *__real_realloc(void *,size_t);
void __real_free(void *);
static size_t p1214_find(void *p)
{for(size_t i=0;i<p1214_count;++i)if(p1214_allocations[i].address==p)return i;return SIZE_MAX;}
static void p1214_add(void *p,size_t bytes)
{
 if(!p)return;
 assert(p1214_count<32768 && SIZE_MAX-p1214_live>=bytes);
 p1214_allocations[p1214_count++]=(P1214Allocation){p,bytes};
 p1214_live+=bytes;++p1214_calls;if(p1214_live>p1214_peak)p1214_peak=p1214_live;
}
static void p1214_remove(size_t i)
{if(i==SIZE_MAX){++p1214_untracked;return;}p1214_live-=p1214_allocations[i].bytes;p1214_allocations[i]=p1214_allocations[--p1214_count];}
void *__wrap_malloc(size_t bytes)
{void *p=__real_malloc(bytes);p1214_add(p,bytes);return p;}
void *__wrap_calloc(size_t count,size_t bytes)
{void *p=__real_calloc(count,bytes);if(p){assert(!bytes||count<=SIZE_MAX/bytes);p1214_add(p,count*bytes);}return p;}
void *__wrap_realloc(void *p,size_t bytes)
{
 size_t old=p?p1214_find(p):SIZE_MAX;void *q=__real_realloc(p,bytes);
 if(!q && bytes)return NULL;
 if(p)p1214_remove(old);
 p1214_add(q,bytes);return q;
}
void __wrap_free(void *p)
{if(p)p1214_remove(p1214_find(p));__real_free(p);}
static void p1214_memory(const char *phase)
{printf("MEMORY %s live_bytes=%zu live_allocations=%zu peak_requested_bytes=%zu successful_allocations=%zu untracked_free=%zu\n",phase,p1214_live,p1214_count,p1214_peak,p1214_calls,p1214_untracked);}
