/* Diagnostic-only: same adopted backend functions, no alternate admission. */
#include "checked_c_node.c"
#include "newlang/parser.h"
#include <assert.h>
int main(int argc,char **argv)
{
 assert(argc==3);
 NLSource *source=NULL,*actual=NULL; NLParser *parser=NULL,*ap=NULL;
 NLSyntaxTree *tree=NULL,*at=NULL; NLSemanticContext *world=NULL;
 NLCheckedFragment *entry=NULL;
 assert(nl_source_load(argv[1],&source)==NL_SOURCE_OK);
 assert(nl_parser_create(source,&parser)==NL_PARSE_OK);
 assert(nl_parser_parse_function_unit(parser,&tree,NULL)==NL_PARSE_OK);
 assert(nl_semantic_create(&world)==NL_CHECK_OK);
 const NLSyntaxTree *units[]={tree};
 assert(nl_semantic_register_function_unit(world,units,1,NULL)==NL_CHECK_OK);
 assert(nl_source_create("main()",6,"P1214 backend stages",&actual)==NL_SOURCE_OK);
 assert(nl_parser_create(actual,&ap)==NL_PARSE_OK);
 assert(nl_parser_parse_expression_fragment(ap,&at,NULL)==NL_PARSE_OK);
 assert(nl_semantic_check_expression(world,at,&entry,NULL)==NL_CHECK_OK);
 assert(nl_h_custody_validate(entry) && nl_h_origin_validate(entry));
 const NLCheckedFragment *body=nl_checked_call_body(entry,nl_checked_root(entry));
 const NLSemanticContext *c=nl_checked_context(body);
 Emit e={.origin_root=entry,.unit=nl_semantic_unit_type(c),.u8=nl_semantic_core_type(c,NL_TYPE_U8)};
 e.text=calloc(C_BYTES,1); assert(e.text);
 Env env={.artifact=body}; e.two_heap=two_profile(body,0);
 bool returns=return_profile(&e,body,0);
 printf("return_profile=%d two_heap=%d live_tail=%zu status=%d\n",returns,e.two_heap,e.live_tail,e.status);
 for(NLCheckedNodeId id=1;id<=nl_checked_node_count(body);++id){
  const NLCheckedNodeView *n=get(&env,id);
  if(n->kind==NL_CHECKED_TRY_ALLOCATE_ONE && n->result_count==0){e.allocated=true;assert(shape(&e,&env,n->allocation_target));}
 }
 bool copied=copy_prepare(&e,body);
 printf("copy_prepare=%d copy_type=%zu copy_issuer=%d copy_anchor=%d expected_calls=%zu\n",copied,e.copy_type,e.copy_issuer!=NULL,e.copy_anchor!=NULL,e.copy_expected_calls);
 Value result={0}; bool accepted=block(&e,&env,nl_checked_root(body),&result);
 printf("block=%d status=%d H_roots=%zu allocations=%zu destroys=%zu releases=%zu domains=%zu finalized=%zu producer_calls=%zu terminal_calls=%zu text_bytes=%zu\n",accepted,e.status,e.roots,e.allocations,e.destroys,e.releases,e.domains,e.finalized,e.producer_calls,e.owner_calls,e.used);
 FILE *partial=fopen(argv[2],"wx");assert(partial);assert(fwrite(e.text,1,e.used,partial)==e.used);assert(fclose(partial)==0);
 assert(!accepted && e.status==NL_NODE_C_UNSUPPORTED && e.copy_type==0);
 free(e.text);free(e.receiver);free(e.producer);free(e.recipient);
 nl_checked_destroy(entry);nl_semantic_destroy(world);
 nl_syntax_tree_destroy(at);nl_parser_destroy(ap);nl_source_destroy(actual);
 nl_syntax_tree_destroy(tree);nl_parser_destroy(parser);nl_source_destroy(source);
 return 0;
}
