import datetime,hashlib,json,pathlib,subprocess
root=pathlib.Path('/tmp/p1214');ledger=root/'records/observations.jsonl'
for name in ['02-binding-control.nl','03-postheap-current-loop.nl','04-preheap-original-current-loop.nl']:
 source=root/'freeze/sources'/name
 number=len(ledger.read_text().splitlines())+1;assert number<=24
 record={'number':number,'mode':'owned-current-readonly','source':name,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'observer_sha256':hashlib.sha256((root/'apparatus/observe-v2').read_bytes()).hexdigest()}
 with ledger.open('a') as f:f.write(json.dumps(record)+'\n')
 stem=root/'records'/f'{number:02}-{source.stem}-owned-FIRST'
 with stem.with_suffix('.stdout').open('xb') as out,stem.with_suffix('.stderr').open('xb') as err:
  result=subprocess.run(['stdbuf','-oL',root/'apparatus/observe-v2',source],stdout=out,stderr=err,timeout=40)
 print(name,'status',result.returncode,flush=True)
 print(stem.with_suffix('.stdout').read_text(),end='',flush=True)
 print(stem.with_suffix('.stderr').read_text(),end='',flush=True)
 record['returncode']=result.returncode
 stem.with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n')
 if result.returncode:raise SystemExit('STOP: owned/current observation must be diagnosed')
print('OBSERVATIONS',len(ledger.read_text().splitlines()))
