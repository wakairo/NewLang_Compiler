import datetime,hashlib,json,pathlib,subprocess
root=pathlib.Path('/tmp/p1214'); frozen=root/'freeze'; records=root/'records'; binary=root/'build-main/newlangc'
manifest=json.loads((frozen/'source-freeze-v1.json').read_text())
for name,digest in manifest['files'].items():
 assert hashlib.sha256((frozen/name).read_bytes()).hexdigest()==digest,name
out=root/'gate0';out.mkdir()
ledger=records/'observations.jsonl'
def invoke(mode,source,argv):
 entries=ledger.read_text().splitlines() if ledger.exists() else []
 number=len(entries)+1;assert number<=24
 stem=out/f'{number:02}-{source.stem}-{mode}'
 planned={'number':number,'mode':mode,'source':source.name,'argv':list(map(str,argv)),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with ledger.open('a') as f:f.write(json.dumps(planned)+'\n')
 with stem.with_suffix('.stdout').open('xb') as stdout,stem.with_suffix('.stderr').open('xb') as stderr:
  result=subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=40)
 receipt={**planned,'returncode':result.returncode,'stdout_sha256':hashlib.sha256(stem.with_suffix('.stdout').read_bytes()).hexdigest(),'stderr_sha256':hashlib.sha256(stem.with_suffix('.stderr').read_bytes()).hexdigest()}
 stem.with_suffix('.json').write_text(json.dumps(receipt,indent=2)+'\n')
 return result.returncode,stem.with_suffix('.stderr').read_text()
summary=[]
for source in sorted((frozen/'sources').glob('*.nl')):
 negative=source.name[:2]>='90'
 code,diagnostic=invoke('check',source,[binary,'--check',source])
 print(source.name,'CHECK',code,diagnostic.strip(),flush=True)
 if negative and code==0:raise RuntimeError('SAFETY STOP: invalid negative source accepted')
 target=out/f'{source.stem}.c'
 target.write_bytes(b'P1214 named output must remain unchanged on refusal.\n')
 before=(target.read_bytes(),target.stat().st_ino,target.stat().st_mtime_ns)
 emitted,emit_diagnostic=invoke('emit',source,[binary,'--emit-c17-to',target,source])
 after=(target.read_bytes(),target.stat().st_ino,target.stat().st_mtime_ns)
 if emitted:
  assert after==before,('SAFETY STOP: clobber',source.name)
 else:
  assert code==0 and not negative,('SAFETY STOP: inconsistent CHECK/emitter',source.name)
 print(source.name,'C17',emitted,emit_diagnostic.strip(),'no_clobber',after==before if emitted else 'N/A',flush=True)
 summary.append({'source':source.name,'check':code,'emit':emitted,'check_diagnostic':diagnostic,'emit_diagnostic':emit_diagnostic,'no_clobber':after==before if emitted else None,'generated_path':str(target) if emitted==0 else None})
(records/'Gate0-FIRST-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('OBSERVATIONS',len(ledger.read_text().splitlines()))
