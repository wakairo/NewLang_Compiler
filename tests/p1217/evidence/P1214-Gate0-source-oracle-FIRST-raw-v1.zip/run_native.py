import datetime,hashlib,json,os,pathlib,subprocess
r=pathlib.Path('/tmp/p1214');out=r/'native';out.mkdir();source=r/'gate0/02-binding-control.c'
configurations=[('gcc-O0','/workspace/p1030-validation-tools/usr/bin/gcc-13',['-O0']),('clang-O2-ASan-UBSan','/workspace/p965/.deps/toolchains/ubuntu-24.04-x86_64-7c9921be7919a10d/newlang-llvm-23.1.3-linux-x64/bin/clang',['-O2','-fsanitize=address,undefined','-fno-sanitize-recover=all','-fno-omit-frame-pointer'])]
for name,cc,flags in configurations:
 exe=out/name
 argv=[cc,'-std=c17','-Wall','-Wextra','-Wpedantic','-Werror',*flags,'-DNEWLANG_CURRENT_LOOP_OBSERVER="/tmp/p1214/apparatus/native-observer.h"',str(source),'-o',str(exe)]
 receipt={'configuration':name,'compile_argv':argv,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'observer_sha256':hashlib.sha256((r/'apparatus/native-observer.h').read_bytes()).hexdigest(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expected':'v1 values unchanged; 5 updates/backedges and original physical field addresses, 6 header visits, 30 local observations, two postloop reads, result5'}
 with (out/f'{name}-compile.stdout').open('xb') as stdout,(out/f'{name}-compile.stderr').open('xb') as stderr:compiled=subprocess.run(argv,stdout=stdout,stderr=stderr,timeout=40)
 receipt['compile_exit']=compiled.returncode
 if compiled.returncode:raise SystemExit(f'STOP strict C17 compile {name}')
 env=os.environ.copy();env.update(ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
 with (r/'records/focused-checks.jsonl').open('a') as f:f.write(json.dumps(receipt)+'\n')
 with (out/f'{name}-run.stdout').open('xb') as stdout,(out/f'{name}-run.stderr').open('xb') as stderr:ran=subprocess.run([exe],stdout=stdout,stderr=stderr,env=env,timeout=10)
 receipt['native_exit']=ran.returncode;receipt['stderr_bytes']=(out/f'{name}-run.stderr').stat().st_size
 (out/f'{name}-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(name,ran.returncode,'stderr_bytes',receipt['stderr_bytes']);print((out/f'{name}-run.stdout').read_text(),end='')
 if ran.returncode or receipt['stderr_bytes']:raise SystemExit('SAFETY STOP native/sanitizer')
