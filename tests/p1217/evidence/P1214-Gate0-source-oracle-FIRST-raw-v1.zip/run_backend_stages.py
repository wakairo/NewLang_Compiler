import datetime,hashlib,json,pathlib,subprocess
r=pathlib.Path('/tmp/p1214');ledger=r/'records/observations.jsonl'
for name in ['03-postheap-current-loop.nl','04-preheap-original-current-loop.nl']:
 source=r/'freeze/sources'/name
 number=len(ledger.read_text().splitlines())+1;assert number<=24
 stem=r/'records'/f'{number:02}-{source.stem}-backend-stages-FIRST'
 p={'number':number,'mode':'backend-stage-diagnostic','source':name,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'apparatus_sha256':hashlib.sha256((r/'apparatus/backend-stages').read_bytes()).hexdigest(),'prediction':'No Copy body call parameters means copy_prepare has no T carrier anchor; retained staging output only, never native.'}
 with ledger.open('a') as f:f.write(json.dumps(p)+'\n')
 with stem.with_suffix('.stdout').open('xb') as out,stem.with_suffix('.stderr').open('xb') as err:
  q=subprocess.run(['stdbuf','-oL',r/'apparatus/backend-stages',source,stem.with_suffix('.partial.txt')],stdout=out,stderr=err,timeout=40)
 p['returncode']=q.returncode;stem.with_suffix('.json').write_text(json.dumps(p,indent=2)+'\n')
 print(name,q.returncode);print(stem.with_suffix('.stdout').read_text(),end='');print(stem.with_suffix('.stderr').read_text(),end='')
 if q.returncode:raise SystemExit('STOP diagnostic unexpected result')
 print('LAST_STAGED_TEXT',repr(stem.with_suffix('.partial.txt').read_text()[-350:]))
print('OBSERVATIONS',len(ledger.read_text().splitlines()))
