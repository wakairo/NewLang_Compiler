P1214 named output must remain unchanged on refusal.
