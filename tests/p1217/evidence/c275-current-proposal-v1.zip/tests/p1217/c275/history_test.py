"""Original P733/P738 assertions and measured FIRST remain historical truth."""
from pathlib import Path
import hashlib
import json
import zipfile

root = Path(__file__).resolve().parents[3]
here = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
frozen = json.loads((here / 'current-freeze-v1.json').read_bytes())
for name, expected in frozen['old_inputs'].items():
    data = (root / name).read_bytes()
    assert sha(data) == expected, name
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == frozen['old_git_blobs'][name], name
for name, expected in frozen['current_files'].items():
    assert sha((root / name).read_bytes()) == expected, name
archive = root / frozen['archive']
assert sha(archive.read_bytes()) == frozen['archive_sha256']
with zipfile.ZipFile(archive) as z:
    for name, expected in frozen['old_inputs'].items():
        assert sha(z.read(name)) == expected, name
    assert b'at < 32 && staging_failures == 3 && validation_failures != 0' in z.read('tests/unit/live_return_backend_test.c')
    assert b'p738_local_return_existing_controls.unit' in z.read('C274-original-p738-FIRST-regression.log')
    for config in ['gcc', 'asan']:
        actual = json.loads(z.read('diagnostic/records/' + config + '-diagnostic-1.json'))
        assert actual['final'] == dict(at=19, calls=19, staging_failures=19, validation_failures=0, conjuncts=[True, False, False])
        assert actual['inferior_exit'] == 1
        failed = [x for x in actual['trials'] if x['status']]
        assert len(failed) == 19
        for row in failed:
            assert row['status'] == 2 and row['out_null'] and row['length'] == 37 and row['root_world_fields_unchanged'] and row['fault']
            assert len([x for x in actual['retries'] if x['at'] == row['at'] and x['success']]) == 2
        assert all(x['actual_return'] == 4 for x in actual['causes'])
        assert actual['trials'][-1]['status'] == 0 and actual['trials'][-1]['fault'] is None
print('C275 original source/oracle/RED + exact measured classification + versioned CURRENT PASS')
