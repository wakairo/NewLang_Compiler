/* Retain the frozen C275 harness; record every interposed allocator failure.
 * GCC Release can lower malloc plus zeroing to calloc in unchanged code. */
#define main c275_original_p733_main
#define __wrap_calloc c275_original_wrap_calloc
#define __wrap_realloc c275_original_wrap_realloc
#include "../c275/p733_current_v1.c"
#undef __wrap_realloc
#undef __wrap_calloc
#undef main

void *__wrap_calloc(size_t n, size_t s)
{
    if (inject && calls++ == at) {
        failure_injected = true;
        failure_site = __builtin_return_address(0);
        return NULL;
    }
    return __real_calloc(n, s);
}
void *__wrap_realloc(void *p, size_t n)
{
    if (inject && calls++ == at) {
        failure_injected = true;
        failure_site = __builtin_return_address(0);
        return NULL;
    }
    return __real_realloc(p, n);
}
int main(int argc, char **argv)
{
    return c275_original_p733_main(argc, argv);
}
