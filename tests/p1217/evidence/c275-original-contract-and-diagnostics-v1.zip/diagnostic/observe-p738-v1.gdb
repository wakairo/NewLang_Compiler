set confirm off
set pagination off
set print pretty off
set debuginfod enabled off
set disable-randomization off
unset environment LD_LIBRARY_PATH
python
import gdb, json, os
record = {'purpose':'Read-only C275 original P738 classification diagnosis; original assert is not changed', 'trials':[], 'causes':[], 'retries':[]}
pre = None
fault = None
pending = None

def number(expr):
    return int(gdb.parse_and_eval(expr))

def state():
    return {n:number(expr) for n,expr in {
        'root':'n.entry','world':'n.context','types':'n.context->types',
        'functions':'n.context->functions','values':'n.context->values',
        'places':'n.context->places','value_count':'n.context->value_count',
        'place_count':'n.context->place_count','function_count':'n.context->function_count',
        'scope_count':'n.context->scope_count','domain_count':'n.context->domain_count',
        'region_count':'n.context->region_count',
        'last_incarnation':'n.context->last_incarnation',
        'last_value_fact':'n.context->last_value_fact'}.items()}

class Before(gdb.Breakpoint):
    def stop(self):
        global pre, fault
        pre=state();fault=None
        return False

class Allocation(gdb.Breakpoint):
    def stop(self):
        global fault
        if not number('inject') or number('calls') != number('at'):
            return False
        frames=[];f=gdb.newest_frame().older()
        for i in range(8):
            if not f:break
            sal=f.find_sal()
            frames.append({'function':f.name(),'line':sal.line,'file':sal.symtab.fullname() if sal.symtab else None,'pc':int(f.pc())})
            f=f.older()
        fault={'at':number('at'),'ordinal':number('at')+1,'allocator':self.location,'frames':frames}
        print('C275 FAULT '+json.dumps(fault))
        return False

class CauseReturn(gdb.FinishBreakpoint):
    def __init__(self, frame, name):
        self.label=name
        self.point=number('at')
        super().__init__(frame, internal=True)
    def stop(self):
        value=int(self.return_value) if self.return_value is not None else None
        if value:
            row={'at':self.point,'function':self.label,'actual_return':value}
            record['causes'].append(row);print('C275 CAUSE '+json.dumps(row))
        return False

class Cause(gdb.Breakpoint):
    def stop(self):
        if number('inject'):
            CauseReturn(gdb.newest_frame(),self.location)
        return False

class After(gdb.Breakpoint):
    def stop(self):
        global pending
        row={'at':number('at'),'calls':number('calls'),'status':number('status'),
             'out_null':number('out')==0,'length':number('sentinel'),
             'root_world_fields_unchanged':pre==state(),'fault':fault}
        record['trials'].append(row);print('C275 ACTUAL '+json.dumps(row))
        pending=row['at'] if row['status'] else None
        return False

class RetryReturn(gdb.FinishBreakpoint):
    def __init__(self, frame, label, point):
        self.label=label;self.point=point
        super().__init__(frame,internal=True)
    def stop(self):
        global pending
        row={'at':self.point,'function':self.label,'success':bool(int(self.return_value)) if self.return_value is not None else None}
        record['retries'].append(row);print('C275 RETRY '+json.dumps(row))
        if self.label=='expect':pending=None
        return False

class Retry(gdb.Breakpoint):
    def stop(self):
        if pending is not None and not number('inject'):
            RetryReturn(gdb.newest_frame(),self.location,pending)
        return False

class Final(gdb.Breakpoint):
    def stop(self):
        row={n:number(n) for n in ['at','calls','staging_failures','validation_failures']}
        row['conjuncts']=[row['at']<32,row['staging_failures']==3,row['validation_failures']!=0]
        record['final']=row;print('C275 FINAL '+json.dumps(row))
        return False

def exited(event):
    record['inferior_exit']=getattr(event,'exit_code',None)
    with open(os.environ['P1217_C275_RECORD_JSON'],'x') as f:json.dump(record,f,indent=2);f.write('\n')
    print('C275 EXIT '+str(record['inferior_exit']))

gdb.events.exited.connect(exited)
Before('/tmp/p1217/main/tests/unit/live_return_backend_test.c:166')
After('/tmp/p1217/main/tests/unit/live_return_backend_test.c:171')
Final('/tmp/p1217/main/tests/unit/live_return_backend_test.c:188')
for name in ['__wrap_malloc','__wrap_calloc','__wrap_realloc']:Allocation(name)
for name in ['nl_raw_validate','nl_producer_validate','nl_producer_local_return_validate']:Cause(name)
for name in ['nl_checked_producer_valid','expect']:Retry(name)
end
run /tmp/p1217/main/tests/p738/sprout.nl /tmp/p1217/main/tests/p738/ticket.nl
