P1217 original named C17 output
