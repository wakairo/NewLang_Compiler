C274 named output must stay unchanged
