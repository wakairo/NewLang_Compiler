set pagination off
set confirm off
set breakpoint pending on
set disable-randomization off
unset environment LD_LIBRARY_PATH
break /tmp/p1217/main/tests/p1217/c275/live_return_backend_current_v1.c:214
commands
silent
printf "RELEASE_CURRENT at=%zu calls=%zu inject=%d recorded=%d site=%p status=%d out=%p length=%zu\n", at,calls,inject,failure_injected,failure_site,status,out,sentinel
continue
end
break __wrap_calloc
commands
silent
if inject && calls == at
printf "RELEASE_CALLOC selected at=%zu calls=%zu recorded-before=%d site-before=%p\n",at,calls,failure_injected,failure_site
end
continue
end
run
