from pathlib import Path
import datetime, hashlib, json, os, subprocess, zipfile
r=Path('/tmp/p1217/c273');binary=Path('/tmp/p1217/build-gcc/p1217_oom')
meta=json.loads((r/'diagnostic-freeze-v1.json').read_bytes())
for name,digest in meta['apparatus'].items():
 assert hashlib.sha256((r/name).read_bytes()).hexdigest()==digest,name
assert hashlib.sha256(binary.read_bytes()).hexdigest()==meta['original_binary_sha256']
source=Path(meta['source']);assert hashlib.sha256(source.read_bytes()).hexdigest()==meta['source_sha256']
ledger=r/'records/replay-invocations.jsonl'
records=ledger.read_text().splitlines() if ledger.exists() else []
assert len(records)<2
number=len(records)+1
row={'number':number,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binary_sha256':meta['original_binary_sha256'],'source_sha256':meta['source_sha256'],'point':2,'assertion':'original unchanged'}
with ledger.open('a') as f:f.write(json.dumps(row)+'\n')
root=r/'gdb-packages/root';env=os.environ.copy();env['LD_LIBRARY_PATH']=str(root/'usr/lib/x86_64-linux-gnu')
argv=[str(root/'usr/bin/gdb'),'--data-directory='+str(root/'usr/share/gdb'),'--nx','--nh','-q','--batch','-x',str(r/'diagnostic-v1.gdb'),str(binary)]
(r/'records'/f'replay-{number}.argv.json').write_text(json.dumps(argv,indent=2)+'\n')
with (r/'records'/f'replay-{number}.stdout').open('xb') as out,(r/'records'/f'replay-{number}.stderr').open('xb') as err:
 p=subprocess.run(argv,cwd='/tmp/p1217/main',env=env,stdout=out,stderr=err,timeout=45)
row['debugger_exit']=p.returncode
row['binary_unchanged']=hashlib.sha256(binary.read_bytes()).hexdigest()==meta['original_binary_sha256']
(r/'records'/f'replay-{number}.json').write_text(json.dumps(row,indent=2)+'\n')
print(json.dumps(row))
print((r/'records'/f'replay-{number}.stdout').read_text())
print((r/'records'/f'replay-{number}.stderr').read_text())
