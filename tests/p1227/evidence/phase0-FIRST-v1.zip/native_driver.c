#include <stddef.h>
#include <stdio.h>
void p1227_Bpre_run(size_t quota);
void p1227_Bpost_run(size_t quota);
int main(void)
{
    for(size_t quota=0;quota<=2;++quota){
        p1227_Bpre_run(quota);
        p1227_Bpost_run(quota);
    }
    puts("P1227 B GCC-preH/Clang-postH H0/H1/H2 all six entry calls PASS");
    return 0;
}
