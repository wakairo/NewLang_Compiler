from pathlib import Path
import json,subprocess,hashlib
out=Path('/tmp/p1227-c280');raw=out/'FIRST';prior=json.loads((raw/'first-pair-results.json').read_bytes());assert len(prior)==2
rows=[];compiler='/tmp/p1217/c277/build-gcc-release/newlangc'
plan=[('B-preH','CHECK',0),('A-preH','CHECK',0),('B-postH','C17',0),('A-postH','C17',4),('N-return-type','CHECK',3),('N-return-type','C17',3),('N-loan-escape','CHECK',3),('N-loan-escape','C17',3),('N-foreign-owner','CHECK',3),('N-foreign-owner','C17',3)]
for name,kind,expected in plan:
 source=out/'inputs'/(name+'.nl');label=name+'-'+kind;target=raw/(name+'.c') if kind=='C17' else None
 if target:
  assert not target.exists();target.write_bytes(b'P1227 intact named C17 target\n');before=(target.read_bytes(),target.stat().st_ino,target.stat().st_mtime_ns)
 argv=[compiler,'--emit-c17-to',str(target),str(source)] if target else [compiler,'--check',str(source)]
 p=subprocess.run(argv,capture_output=True,timeout=25)
 (raw/(label+'.stdout')).write_bytes(p.stdout);(raw/(label+'.stderr')).write_bytes(p.stderr)
 row={'source_observation':3+len(rows),'source':name,'kind':kind,'argv':argv,'exit':p.returncode,'stderr':p.stderr.decode()}
 if target:
  after=(target.read_bytes(),target.stat().st_ino,target.stat().st_mtime_ns);row['no_clobber_on_refusal']=before==after if p.returncode else None;row['C17_sha256']=hashlib.sha256(after[0]).hexdigest() if not p.returncode else None
  if p.returncode and before!=after:raise SystemExit('STOP named output clobbered')
 rows.append(row);(raw/'remaining-cli-FIRST-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(name,kind,p.returncode,p.stderr.decode()[:550],flush=True)
 if p.returncode!=expected:raise SystemExit('STOP unexpected first result; no remaining observations')
print('source CLI12/18; native/observer0/3; reserve4 source API checks and2 unused observations',flush=True)
