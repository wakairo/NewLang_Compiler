from pathlib import Path
import subprocess,json,hashlib
out=Path('/tmp/p1227-c280');raw=out/'FIRST';raw.mkdir(exist_ok=False)
f=json.loads((out/'phase0-freeze-v1.json').read_bytes())
for name,pin in f['files'].items():assert hashlib.sha256((out/name).read_bytes()).hexdigest()==pin,name
compiler='/tmp/p1217/c277/build-gcc-release/newlangc';rows=[]
for name in ['B-preH','A-preH']:
 source=out/'inputs'/(name+'.nl');target=raw/(name+'.c');target.write_bytes(b'P1227 original named output\n');before=(target.read_bytes(),target.stat().st_ino,target.stat().st_mtime_ns)
 argv=[compiler,'--emit-c17-to',str(target),str(source)];p=subprocess.run(argv,capture_output=True,timeout=25)
 (raw/(name+'.stdout')).write_bytes(p.stdout);(raw/(name+'.stderr')).write_bytes(p.stderr)
 after=(target.read_bytes(),target.stat().st_ino,target.stat().st_mtime_ns)
 row={'source_observation':len(rows)+1,'source':name,'argv':argv,'exit':p.returncode,'stderr':p.stderr.decode(),'no_clobber_on_refusal':before==after if p.returncode else None,'C17_sha256':hashlib.sha256(after[0]).hexdigest() if p.returncode==0 else None}
 rows.append(row);(raw/'first-pair-results.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(row),flush=True)
 if p.returncode and before!=after:raise SystemExit('STOP output clobber')
 if name=='B-preH' and p.returncode!=0:raise SystemExit('STOP unexpected B first refusal; no A or subsequent trials')
 if name=='A-preH' and p.returncode not in [0,4]:raise SystemExit('STOP unexpected A upstream refusal; no subsequent trials')
print('first pair complete; no Production edits/native/branch',flush=True)
