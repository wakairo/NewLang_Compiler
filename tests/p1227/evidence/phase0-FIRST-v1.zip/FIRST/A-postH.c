P1227 intact named C17 target
