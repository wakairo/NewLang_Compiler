P1227 original named output
