from pathlib import Path
import json,hashlib,zipfile,datetime
out=Path('/tmp/p1227-c280');inputs=out/'inputs';inputs.mkdir(exist_ok=False)
common='''struct Spool { chain: Option<ptr<Spool>>, tag: u8 }
struct Meter { channel: u8, watermark: u8 }

fn disconnect(field: ref<write,Option<ptr<Spool>>>, address: ptr<Spool>, allocation: Allocation, life: LifetimeDomain) -> LiveTail {
    let old_link = replace(field, Option<ptr<Spool>>::None);
    return LiveTail { owned_ptr: address, owned_allocation: allocation, owned_domain: life };
}

fn retire(address: ptr<Spool>, allocation: Allocation, life: LifetimeDomain) -> unit {
    loan_read(life) { |stable|
        let observed = ref_from_ptr(read, address, stable);
        unit
    };
    let empty = loan_exclusive_read(life) { |ending| destroy(address, ending) };
    let full = erase_slot<Spool>(empty);
    finalize_domain(life);
    deallocate(allocation, full);
    unit
}
'''
helpers={
'A':'''\nfn sample(position: usize) -> u8 {
    let normal = if (position < usize(1)) {
        return u8(53);
    } else {
        u8(149)
    };
    let copied = normal;
    copied
}
''',
'B':'''\nfn sample(position: usize) -> u8 {
    if (position < usize(1)) {
        u8(53)
    } else {
        u8(149)
    }
}
'''}
heap='''    match try_allocate_one<Spool>() {
        None => { unit },
        Some(first_bundle) => {
            let OneBacking { allocation, raw } = first_bundle;
            let first_allocation = allocation;
            let first_slot = into_slot<Spool>(raw);
            let first_life = lifetime_domain();
            let first_ptr = loan_read(first_life) { |stable_first|
                initialize(first_slot, Spool { chain: Option<ptr<Spool>>::None, tag: u8(41) }, stable_first)
            };
            match try_allocate_one<Spool>() {
                None => {
                    let vacant_first = loan_exclusive_read(first_life) { |ending_first| destroy(first_ptr, ending_first) };
                    let full_first = erase_slot<Spool>(vacant_first);
                    finalize_domain(first_life);
                    deallocate(first_allocation, full_first);
                    unit
                },
                Some(second_bundle) => {
                    let OneBacking { allocation, raw } = second_bundle;
                    let second_allocation = allocation;
                    let second_slot = into_slot<Spool>(raw);
                    let second_life = lifetime_domain();
                    let second_ptr = loan_read(second_life) { |stable_second|
                        initialize(second_slot, Spool { chain: Option<ptr<Spool>>::None, tag: u8(167) }, stable_second)
                    };
                    let initial_none = loan_read(first_life) { |stable_first|
                        let writer = ref_from_ptr(write, first_ptr, stable_first);
                        replace(writer@chain, Option<ptr<Spool>>::Some(second_ptr))
                    };
                    let copied_link = loan_read(first_life) { |stable_first|
                        let reader = ref_from_ptr(read, first_ptr, stable_first);
                        read(reader@chain)
                    };
                    match copied_link {
                        None => { unit },
                        Some(reachable) => {
                            loan_read(second_life) { |stable_second|
                                let checked = ref_from_ptr(read, reachable, stable_second);
                                unit
                            }
                        },
                    };
                    let LiveTail { owned_ptr, owned_allocation, owned_domain } = loan_read(first_life) { |stable_first|
                        let writer_again = ref_from_ptr(write, first_ptr, stable_first);
                        disconnect(writer_again@chain, second_ptr, second_allocation, second_life)
                    };
                    loan_read(owned_domain) { |stable_second|
                        let returned = ref_from_ptr(read, owned_ptr, stable_second);
                        unit
                    };
                    retire(owned_ptr, owned_allocation, owned_domain);
                    let vacant_first = loan_exclusive_read(first_life) { |ending_first| destroy(first_ptr, ending_first) };
                    let full_first = erase_slot<Spool>(vacant_first);
                    finalize_domain(first_life);
                    deallocate(first_allocation, full_first);
                    unit
                },
            }
        },
    };
'''
original='    let original = Meter { channel: u8(31), watermark: u8(203) };\n'
loop='''    let initial = usize(0);
    let start = initial;
    let finish = loop (phase = start) {
        if (phase < usize(3)) {
            let argument = phase;
            let incoming = sample(argument);
            let old = loan_write(original@channel) { |writer| replace(writer, incoming) };
            let old_copy = old;
            old_copy;
            let current = original@channel;
            let sibling = original@watermark;
            current;
            sibling;
            continue(phase + usize(1));
        } else {
            break phase;
        }
    };
    let final = original@channel;
    let sibling = original@watermark;
    let iterations = finish;
    unit
'''
for form in ['A','B']:
 for place in ['preH','postH']:
  data=common+helpers[form]+'\nfn main() -> unit {\n'+(original+heap if place=='preH' else heap+original)+loop+'}\n'
  assert 'lt(' not in data and 'add(' not in data
  (inputs/(form+'-'+place+'.nl')).write_text(data)
negative={
 'N-return-type.nl':(inputs/'A-preH.nl').read_text().replace('return u8(53);','return usize(53);'),
 'N-loan-escape.nl':(inputs/'B-preH.nl').read_text().replace('loan_write(original@channel) { |writer| replace(writer, incoming) }','loan_write(original@channel) { |writer| writer }'),
 'N-foreign-owner.nl':(inputs/'B-preH.nl').read_text().replace('disconnect(writer_again@chain, second_ptr, second_allocation, second_life)','disconnect(writer_again@chain, second_ptr, first_allocation, second_life)')}
for name,data in negative.items():(inputs/name).write_text(data)
oracle={'phase':'C280 Phase0, mainaa8dce8935f44d7b0732d24695f1c0f7c305efb1 Draft17.34','canonical':'5.2 infix <,+;16.3.8 oneH+oneT;17.1/17.4 source-owned fixed fields/scoped Change;18.5/19.1/27.3/27.9 true RETURN excluded from normal join;27.5/27.6/27.7 literal-initialized phase with adopted scalar BREAK only;26 exact failure/cleanup','independence':'New source authored for C280, not old P1226v2 replay; P calibrated by canonical and own adopted controls, no independent R material','predictions':{'B-preH.nl':{'CHECK':0,'C17':0},'A-preH.nl':{'CHECK':0,'C17':4,'reason':'localized private helper normal_arms2/direct-if-tail guard only, not inferred until owned evidence measured'},'B-postH.nl':{'CHECK':0,'C17':0},'A-postH.nl':{'CHECK':0,'C17':4},'negative':'source CHECK/C17 semantic3 and named output preserved; reject wrong typed RETURN, loan escape, foreign allocation owner'},'expected':{'H0':{'attempts':1,'allocations':0,'finalizes':0,'destroys':0,'frees':0},'H1':{'attempts':2,'allocations':1,'finalizes':1,'destroys':1,'frees':1,'tag':41},'H2':{'attempts':2,'allocations':2,'finalizes':2,'destroys':2,'frees':2,'tags':[41,167],'same_returned_tail_R_A_D':True,'head_link_None_before_destroy':True},'T':{'source_originals':1,'same_record_and_field_addresses':True,'index':0,'initial':31,'incoming':[53,149,149],'old':[31,53,149],'current':[53,149,149],'sibling':203,'loop_result':3,'final_current':149,'real_backedges':3,'loan_ends_before_each_edge':True,'all_T_operations_after_H_closed':True,'preH_original_exists_during_heap':True,'postH_original_begins_after_heap':True}},'equivalence':'A/B differ only pure helper body; one comparison, no effects/allocations/dependencies; all usize inputs result53 below1 else149. Normal continuation Copy is effect-free. Same main, all failure worlds and physical contract; no same-layout replacement or semantic return-edge normalization. No exact CPU-cycle equality claim.','initial_order':'First B-preH emit-C17-to (also actual CHECK), then A-preH same; STOP batch on first unexpected parser/CHECK/status and preserve raw before any more source execution. No version repetition.','budget':{'phase0_source_max':18,'phase0_native_observer_processes_max':3,'source_accounting':'4 CLI emissions +2 explicit primary CHECKs +4 genuine-source owned/API checks +3 negative CHECK/C17 pairs =16; reserve2, all API source checks counted.','native_accounting':'At most1 owned observer process checking4 sources (4 source observations) plus2 strict GCC/Clang native harness process executions; each native harness explicitly exercises both B placements/H0,H1,H2 entry calls with independent observer reset. Exactly3 process executions;12 guest-entry invocations disclosed, not12 hidden processes. All only after actual B C17.','no_baseline_rerun':True},'phase1':'No Production edit unless all conditional facts posted: genuine A/B CHECK+owned/current, B physical/native H0/H1/H2 strictC17, A-only localized private refusal. If both emit work, stop no code. Public issuer/source/world/ABI/generalCFG forbidden.','value':'Capability-only selected-v0 composition. B is cheaper source alternative if actual physical/cleanup equivalence measured. No Product audit-locality or general soundness claim.'}
(out/'oracle-v1.json').write_text(json.dumps(oracle,indent=2)+'\n')
files={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(inputs.iterdir())}
for n in ['author_phase0.py','oracle-v1.json','actual-START-v1.json']:files[n]=hashlib.sha256((out/n).read_bytes()).hexdigest()
freeze={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before_any_C280_source_native_trial':True,'CLI':0,'native':0,'files':files};(out/'phase0-freeze-v1.json').write_text(json.dumps(freeze,indent=2)+'\n')
packet=out/'P1227-C280-before-execution-v1.zip'
with zipfile.ZipFile(packet,'x',zipfile.ZIP_DEFLATED) as z:
 for n in [*files,'phase0-freeze-v1.json']:z.write(out/n,n)
print('SOURCES',json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(inputs.iterdir())},indent=2));print('oracleSHA',hashlib.sha256((out/'oracle-v1.json').read_bytes()).hexdigest());print('freezeSHA',hashlib.sha256((out/'phase0-freeze-v1.json').read_bytes()).hexdigest());print('packetSHA',hashlib.sha256(packet.read_bytes()).hexdigest())
