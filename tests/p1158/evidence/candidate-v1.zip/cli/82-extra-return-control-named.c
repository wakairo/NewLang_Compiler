C232 initial named output must survive rejection
