P1343 preserve rejected output
