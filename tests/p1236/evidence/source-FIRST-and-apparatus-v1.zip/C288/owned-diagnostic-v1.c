/* P-owned actual source CHECK/owner proof, not a synthetic result issuer. */
#define main p1236_preserved_cli_main
#include "main.c"
#undef main
#include <assert.h>

typedef struct {
    NLSource *source, *call_source;
    NLParser *parser, *call_parser;
    NLSyntaxTree *tree, *call_tree;
    NLSemanticContext *context;
    NLCheckedFragment *owned, *owner;
    NLCheckedNodeId loop;
    NLLinearBreakView view;
} Input;
static const NLCheckedFragment *visited[256];
static size_t visited_count;
static void find_loop(Input *t, const NLCheckedFragment *f)
{
    if (!f)
        return;
    for (size_t i = 0; i < visited_count; ++i)
        if (visited[i] == f)
            return;
    assert(visited_count < 256);
    visited[visited_count++] = f;
    for (NLCheckedNodeId i = 1; i <= nl_checked_node_count(f); ++i) {
        const NLCheckedNodeView *n = nl_checked_node_view(f, i);
        assert(n);
        if (n->kind == NL_CHECKED_LOOP) {
            assert(!t->owner);
            t->owner = (NLCheckedFragment *)f;
            t->loop = i;
        }
        find_loop(t, nl_checked_call_body(f, i));
        if (n->kind == NL_CHECKED_IF)
            for (size_t a = 0; a < 2; ++a)
                find_loop(t, nl_checked_if_arm(f, i, a));
        if (n->kind == NL_CHECKED_MATCH)
            for (size_t a = 0; a < n->item_count; ++a)
                find_loop(t, nl_checked_match_arm(f, i, a));
        if (n->kind == NL_CHECKED_LOOP)
            find_loop(t, nl_checked_loop_body(f, i));
    }
}
static void load(Input *t, const char *path)
{
    NLParseDiagnostic p = {0};
    NLCheckDiagnostic d = {0};
    NLFunctionUnitDiagnostic u = {0};
    assert(nl_source_load(path, &t->source) == NL_SOURCE_OK);
    assert(nl_parser_create(t->source, &t->parser) == NL_PARSE_OK);
    assert(nl_parser_parse_function_unit(t->parser, &t->tree, &p) ==
           NL_PARSE_OK);
    assert(nl_semantic_create(&t->context) == NL_CHECK_OK);
    const NLSyntaxTree *trees[] = {t->tree};
    assert(nl_semantic_register_function_unit(t->context, trees, 1, &u) ==
           NL_CHECK_OK);
    assert(nl_source_create("main()", 6, "P1236 genuine call",
                            &t->call_source) == NL_SOURCE_OK);
    assert(nl_parser_create(t->call_source, &t->call_parser) == NL_PARSE_OK);
    assert(nl_parser_parse_expression_fragment(t->call_parser, &t->call_tree,
                                               &p) == NL_PARSE_OK);
    NLCheckStatus status =
        nl_semantic_check_expression(t->context, t->call_tree, &t->owned, &d);
    printf("SOURCE %s CHECK=%d owned=%d\n", path, status, t->owned != NULL);
    assert(status == NL_CHECK_OK && t->owned);
    assert(nl_h_custody_validate(t->owned) && nl_h_origin_has_sites(t->owned) &&
           nl_h_origin_validate(t->owned));
    visited_count = 0;
    find_loop(t, t->owned);
    assert(t->owner && nl_linear_break_validate(t->owner, t->loop, &t->view) ==
                           NL_CHECK_OK);
}
static void dispose(Input *t)
{
    nl_checked_destroy(t->owned);
    nl_semantic_destroy(t->context);
    nl_syntax_tree_destroy(t->call_tree);
    nl_parser_destroy(t->call_parser);
    nl_source_destroy(t->call_source);
    nl_syntax_tree_destroy(t->tree);
    nl_parser_destroy(t->parser);
    nl_source_destroy(t->source);
}
static void accepted(Input *t)
{
    NLLinearBreakView v = {0};
    assert(nl_linear_break_validate(t->owner, t->loop, &v) == NL_CHECK_OK);
    assert(v.terminal_old && v.changing_current && !v.scalar_loop &&
           v.breaking && v.terminal_loan);
    const NLCheckedField c = v.terminal_change;
    const NLControlExitView *x = nl_control_exit_view(v.breaking->exits, 0);
    const NLSemanticContext *exit =
        nl_control_state_context((NLControlState *)x->state);
    const NLCheckedNodeView *br =
        nl_checked_node_view(v.breaking, x->source_node);
    const NLCheckedNodeView *loan =
        nl_checked_node_view(v.breaking, v.terminal_loan);
    assert(x && x->kind == NL_EXIT_BREAK && x->count == 1 &&
           x->source_owner == v.breaking && br &&
           br->kind == NL_CHECKED_BREAK && br->initializer == v.break_value &&
           loan && loan->kind == NL_CHECKED_LOAN_HEADER && loan->loan.scope &&
           !v.breaking->context->scopes[loan->loan.scope - 1].active);
    NLSourceView input_bytes, registered_bytes;
    bool input_ok = nl_source_view(t->source, (NLSourceSpan){0,nl_source_length(t->source)}, &input_bytes);
    bool body_ok = nl_source_view(v.breaking->source, (NLSourceSpan){0,nl_source_length(v.breaking->source)}, &registered_bytes);
    printf("DIAG input_source_equal=%d owner_source_equal=%d plan_source_equal=%d input_len=%zu registered_len=%zu byte_equal=%d present=%d deps=%d parent=%zu/%zu child=%zu/%zu index=%zu/%zu incarnation=%zu/%zu child_incarnation=%zu/%zu\n",
       v.breaking->source == t->source, v.breaking->source == t->owner->source,
       t->owner->body_owner && t->owner->body_owner->source == v.breaking->source,
       nl_source_length(t->source), nl_source_length(v.breaking->source),
       input_ok && body_ok && input_bytes.length==registered_bytes.length && !memcmp(input_bytes.bytes,registered_bytes.bytes,input_bytes.length),
       c.present,c.dependency_compatible,c.parent,v.root,c.child,v.child,c.index,v.index,
       c.parent_incarnation,v.incarnation,c.child_incarnation,v.child_incarnation);
    assert(v.breaking->source == t->source && c.present &&
           c.dependency_compatible && c.parent == v.root &&
           c.child == v.child && c.index == v.index &&
           c.parent_incarnation == v.incarnation &&
           c.child_incarnation == v.child_incarnation);
    const NLSemanticContext *post = v.post_world;
    const NLTypeId u8 = nl_semantic_core_type(post, NL_TYPE_U8);
    assert(v.result.type == u8 && v.result.type == x->values[0].type &&
           v.result.value == x->values[0].value &&
           nl_copy_plain(post, v.result.value, u8));
    assert(post->values[v.result.value - 1].scalar_known == false);
    assert(post->places[v.child - 1].current_value == c.new_value &&
           post->places[v.root - 1].incarnation == v.incarnation &&
           post->places[v.child - 1].incarnation == v.child_incarnation &&
           post->values[c.new_value - 1].scalar_known &&
           (post->values[c.new_value - 1].scalar_value == 239 ||
            post->values[c.new_value - 1].scalar_value == 157));
    const NLPlaceId peer = post->places[v.root - 1].fixed_fields[1 - v.index];
    assert(post->values[post->places[peer - 1].current_value - 1].scalar_known);
    assert(exit->values[v.result.value - 1].type == u8 &&
           exit->places[v.child - 1].current_value ==
               post->places[v.child - 1].current_value);
    printf("OWNED current=1 terminal_old=1 scalar_loop=0 result_type=u8 "
           "old_known=0 post=%zu sibling=%zu field=%zu closed_loan=1 "
           "source_break=%zu\n",
           post->values[c.new_value - 1].scalar_value,
           post->values[post->places[peer - 1].current_value - 1].scalar_value,
           v.index, x->source_node);
    t->view = v;
}
static void rejected(Input *t)
{
    NLLinearBreakView out = {.root = 987654};
    assert(nl_linear_break_validate(t->owner, t->loop, &out) != NL_CHECK_OK &&
           out.root == 987654);
}
static void adversarial(const char *path)
{
    Input a = {0}, b = {0};
    load(&a, path);
    load(&b, path);
    accepted(&a);
    accepted(&b);
    assert(a.view.result.value == b.view.result.value &&
           a.view.post_world != b.view.post_world);
    NLCheckedFragment *arm = (NLCheckedFragment *)a.view.breaking;
    const NLSemanticContext *world = arm->context;
    arm->context = b.view.breaking->context;
    rejected(&a);
    arm->context = world;
    const NLSource *source = arm->source;
    arm->source = b.view.breaking->source;
    rejected(&a);
    arm->source = source;
    NLControlExits *exits = arm->exits;
    arm->exits = b.view.breaking->exits;
    rejected(&a);
    arm->exits = exits;
    NLControlExitView *edge =
        (NLControlExitView *)nl_control_exit_view(arm->exits, 0);
    NLControlExitView old_edge = *edge;
    edge->source_node = old_edge.source_node + 1;
    rejected(&a);
    *edge = old_edge;
    NLCheckedNodeView *loop = &a.owner->nodes[a.loop - 1];
    NLCheckedNodeView old_loop = *loop;
    loop->results[0].value = a.view.terminal_change.new_value;
    rejected(&a);
    *loop = old_loop;
    NLCheckedNodeView *loan = &arm->nodes[a.view.terminal_loan - 1];
    NLSemanticContext *mutable_world = (NLSemanticContext *)world;
    assert(!mutable_world->scopes[loan->loan.scope - 1].active);
    mutable_world->scopes[loan->loan.scope - 1].active = true;
    rejected(&a);
    mutable_world->scopes[loan->loan.scope - 1].active = false;
    NLCheckedNodeView *body = &arm->nodes[loan->initializer - 1];
    NLCheckedNodeView *change = &arm->nodes[body->tail - 1];
    NLCheckedNodeView old_change = *change;
    change->field.index = 1 - change->field.index;
    rejected(&a);
    *change = old_change;
    change->field.child_incarnation++;
    rejected(&a);
    *change = old_change;
    NLCheckedFragment shallow = *a.owner;
    NLLinearBreakView bad = {.root = 987654};
    assert(nl_linear_break_validate(&shallow, a.loop, &bad) != NL_CHECK_OK &&
           bad.root == 987654);
    accepted(&a);
    NLCheckedFragment *graph =
        (NLCheckedFragment *)nl_checked_loop_body(a.owner, a.loop);
    bool substituted = false;
    for (size_t i = 0; i < graph->arm_count; ++i)
        if (graph->arms[i].artifact == arm) {
            graph->arms[i].artifact = (NLCheckedFragment *)b.view.breaking;
            substituted = true;
            break;
        }
    assert(substituted);
    rejected(&a);
    dispose(
        &a); /* Canonical child ownership, foreign B deliberately unrestored. */
    accepted(&b);
    dispose(&b);
    puts("NEGATIVE 10 genuine "
         "foreign-source/world/edge/result/loan/field/incarnation/shallow/"
         "whole-arm controls PASS; A destroyed/B survives");
}
int main(int argc, char **argv)
{
    assert(argc > 1);
    setvbuf(stdout, NULL, _IONBF, 0);
    for (int i = 1; i < argc; ++i) {
        Input t = {0};
        load(&t, argv[i]);
        accepted(&t);
        dispose(&t);
    }
    adversarial(argv[1]);
    puts("P1236 genuine source CHECK/owned typed terminal transfer and "
         "foreign-issuer refusal PASS");
    return 0;
}
