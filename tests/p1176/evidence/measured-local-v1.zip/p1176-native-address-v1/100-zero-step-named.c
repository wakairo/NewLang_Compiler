C243 named-output sentinel
