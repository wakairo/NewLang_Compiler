Track: P

C243 SOURCE/ORACLE PRE-EXECUTION FREEZE v1。別localの後継cohort 6 positive/12 negative/既存2 controlを実行前に固定しました。原P1174の4+4 source bytesと原oracle/FIRST/v1-v2/bundleは不変で、後継oracleだけが認可候補のCHECK/current/C17成功を予測します。

source-freeze-v1.json SHA256 `dab0846d26e74e968eaa0def0cc6c33c72a2edeab3911f1eb1e9aec7f78883ed`、oracle SHA256 `0df0009d82427765341c0279032477c5bce7af20760a120a3826b30cd655e184`、別archive `/workspace/p1176-c243-checkpoint/source-prefreeze-v1.zip` SHA256 `abd30e2872acbbba17120a779eb4b357cb59d17ec4d3f7b53e48bc8d0bb43e1a`。固定base870e4f0/tree5db3576のまま、新candidate/source実行0、push/PR/CI0。

core4正例に実phase equalityとincoming Copy aliasを追加。0/1/複数edge、両field、反復中の両IF arm、same-bitsを含みます。新negativeはwrong-phase、resultと無関係なincoming、escaping ref、Break store、second IF、zero step、arm type等。合法だが有限profile外のsourceとsemantic-invalidを区別し、初回実診断を記録します。

### 01-phase-left.nl

551 bytes / SHA256 `b44db6b770275cc386e3f8a788b28936c5e21285c002635f1bddd9125398d279`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(5)){
   let incoming=if(cursor < usize(2)){u8(53)}else{u8(149)};
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

### 02-phase-right.nl

551 bytes / SHA256 `7f549da3a1173aac3122c069811e33434863d1ac123c650bcd9ac7d7e294348d`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(158),peer:u8(34)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(8)){
   let incoming=if(cursor < usize(4)){u8(87)}else{u8(202)};
   let old=loan_write(original@peer){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@peer;
   let beside=original@live;
   during;
   beside;
   continue(cursor + usize(2));
  }else{break cursor;}
 };
 let final=original@peer;
 let peer=original@live;
 let copied=result;
 unit
}
```

### 03-one-edge.nl

550 bytes / SHA256 `7988aff843641a3b5db0bcda11a44a05430ad1ff5f74eec6b9871e3826599a6b`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(91),peer:u8(17)};
 let result=loop(cursor=usize(3)){
  if(cursor < usize(4)){
   let incoming=if(cursor < usize(4)){u8(65)}else{u8(181)};
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(2));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

### 04-zero-edge.nl

552 bytes / SHA256 `5f8baa425c966281d7ef301b5440eca0443fba79abf8007deee3c1f1bb75a4f7`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(192),peer:u8(37)};
 let result=loop(cursor=usize(7)){
  if(cursor < usize(6)){
   let incoming=if(cursor < usize(8)){u8(103)}else{u8(224)};
   let old=loan_write(original@peer){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@peer;
   let beside=original@live;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@peer;
 let peer=original@live;
 let copied=result;
 unit
}
```

### 05-phase-equality.nl

552 bytes / SHA256 `01ef703d16c725bf1ae478688d304705ce261b2b1f9a2a988511aab2beb8823c`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(5)){
   let incoming=if(cursor == usize(2)){u8(53)}else{u8(149)};
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

### 06-incoming-alias.nl

601 bytes / SHA256 `a1a3b78c4ad8f627ed8d82ce603dc951e7e172955234676e4f2170fe7ac09cfa`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(158),peer:u8(34)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(8)){
   let incoming=if(cursor < usize(4)){u8(87)}else{u8(202)};
   let chosen=incoming;
   let forwarded=chosen;
   let old=loan_write(original@peer){|writer|replace(writer,forwarded)};
   let old_copy=old;
   old_copy;
   let during=original@peer;
   let beside=original@live;
   during;
   beside;
   continue(cursor + usize(2));
  }else{break cursor;}
 };
 let final=original@peer;
 let peer=original@live;
 let copied=result;
 unit
}
```

### 100-zero-step.nl

551 bytes / SHA256 `92e4589835743ed7c41f24c6e6bbeea1e64f3a1ad4ed99ca4e3fd96d9a2d646c`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(5)){
   let incoming=if(cursor < usize(2)){u8(53)}else{u8(149)};
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(0));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

### 101-arm-type.nl

554 bytes / SHA256 `13cd601b6bec04e96eea4cde403fb766cbde03231d1ceb38e655890d3651d70b`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(5)){
   let incoming=if(cursor < usize(2)){u8(53)}else{usize(149)};
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

### 80-literal-control.nl

496 bytes / SHA256 `1cedd7fb7a5d87b5598c86b1e634d8c43eb14385b0c0c90e0c7b132e4b3a2b85`

```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   let old=loan_write(original@latch){|writer|replace(writer,u8(203))};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   continue(cursor + usize(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

### 81-stutter-control.nl

309 bytes / SHA256 `c21827ac467cc9d22996c563005852b653d4fec10c0b450efbae1fac2ca8e6bb`

```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   continue(cursor + usize(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

### 90-incoming-usize.nl

557 bytes / SHA256 `6bea2d24881954c806fff59727fbdf704bf3194128515b015f84d1a1321eb51c`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(5)){
   let incoming=if(cursor < usize(2)){usize(53)}else{usize(149)};
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

### 91-phase-shadow.nl

575 bytes / SHA256 `5d75d5affb70f1ad8ee19e25d6f5f9f2530d2791f078223ea912838bd442d50d`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(5)){
   let cursor=usize(0);
   let incoming=if(cursor < usize(2)){u8(53)}else{u8(149)};
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

### 92-inner-effect.nl

625 bytes / SHA256 `b75576de47548efc18899ea33d83ac6a4bb3245a292089810f8fc6914e8bc1bc`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(5)){
   let incoming=if(cursor < usize(2)){let extra=loan_write(original@peer){|spare|replace(spare,u8(33))}; extra; u8(53)}else{u8(149)};
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

### 93-overflow.nl

570 bytes / SHA256 `f2475886bee9944f0585ad109f2420d6a498d478030de2a775e174e9d9db1f7c`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(158),peer:u8(34)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(8)){
   let incoming=if(cursor < usize(4)){u8(87)}else{u8(202)};
   let old=loan_write(original@peer){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@peer;
   let beside=original@live;
   during;
   beside;
   continue(cursor + usize(18446744073709551615));
  }else{break cursor;}
 };
 let final=original@peer;
 let peer=original@live;
 let copied=result;
 unit
}
```

### 94-other-phase.nl

581 bytes / SHA256 `5a3b047925c06d6cfed5945400860e6276fad81b6859ddafe9f6824013222f7d`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(5)){
   let elsewhere=usize(0);
   let incoming=if(elsewhere < usize(2)){u8(53)}else{u8(149)};
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

### 95-unrelated-literal.nl

549 bytes / SHA256 `7791da181671397b6af596709e3e44684c06a8b415bc150a47d7cf4b1962d30d`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(5)){
   let incoming=if(cursor < usize(2)){u8(53)}else{u8(149)};
   let old=loan_write(original@live){|writer|replace(writer,u8(53))};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

### 96-escaping-arm.nl

618 bytes / SHA256 `99ee79f241db9e7f4d5bacc597f0a65811646eb06cc28d08dcc9253eddfc711d`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(5)){
   let incoming=if(cursor < usize(2)){loan_read(original@live){|borrow|borrow}}else{loan_read(original@live){|borrow|borrow}};
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

### 97-break-store.nl

623 bytes / SHA256 `08dba4a06e67840cd953413c315cf5af2cf3a0f9c7b4903c5c3a7742b03bf476`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(5)){
   let incoming=if(cursor < usize(2)){u8(53)}else{u8(149)};
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{let extra=loan_write(original@live){|last|replace(last,u8(61))}; extra; break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

### 98-second-if.nl

621 bytes / SHA256 `00e23577e945548590833d489db99405cd358ae306dc06e43668907d926edf80`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(5)){
   let incoming=if(cursor < usize(2)){u8(53)}else{u8(149)};
   let another=if(cursor < usize(3)){u8(17)}else{u8(32)};
   another;
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

### 99-unrelated-copy.nl

567 bytes / SHA256 `d60ac1ec882a770f486ddd9420dcc3a1d9e89277b3a5e35fc2d144e79dd6ad75`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let prior=u8(53);
 let result=loop(cursor=usize(0)){
  if(cursor < usize(5)){
   let incoming=if(cursor < usize(2)){u8(53)}else{u8(149)};
   let old=loan_write(original@live){|writer|replace(writer,prior)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

### Successor oracle

```json
{
  "authority": "C243 / fixed PR1171 870e4f0972abb9725b7cf9f38d09178e51ff1280",
  "cases": {
    "01-phase-left": {
      "category": "positive",
      "semantic_legality": "dependency-free finite source family",
      "index": 0,
      "initial": 26,
      "sibling": 211,
      "headers": [
        0,
        1,
        2,
        3,
        4,
        5
      ],
      "header_child": [
        26,
        53,
        53,
        149,
        149,
        149
      ],
      "olds": [
        26,
        53,
        53,
        149,
        149
      ],
      "incoming": [
        53,
        53,
        149,
        149,
        149
      ],
      "final": 149,
      "result": 5,
      "check": 0,
      "emit": 0,
      "private_current": 0,
      "runtime_incoming": true
    },
    "02-phase-right": {
      "category": "positive",
      "semantic_legality": "dependency-free finite source family",
      "index": 1,
      "initial": 34,
      "sibling": 158,
      "headers": [
        1,
        3,
        5,
        7,
        9
      ],
      "header_child": [
        34,
        87,
        87,
        202,
        202
      ],
      "olds": [
        34,
        87,
        87,
        202
      ],
      "incoming": [
        87,
        87,
        202,
        202
      ],
      "final": 202,
      "result": 9,
      "check": 0,
      "emit": 0,
      "private_current": 0,
      "runtime_incoming": true
    },
    "03-one-edge": {
      "category": "positive",
      "semantic_legality": "dependency-free finite source family",
      "index": 0,
      "initial": 91,
      "sibling": 17,
      "headers": [
        3,
        5
      ],
      "header_child": [
        91,
        65
      ],
      "olds": [
        91
      ],
      "incoming": [
        65
      ],
      "final": 65,
      "result": 5,
      "check": 0,
      "emit": 0,
      "private_current": 0,
      "runtime_incoming": true
    },
    "04-zero-edge": {
      "category": "positive",
      "semantic_legality": "dependency-free finite source family",
      "index": 1,
      "initial": 37,
      "sibling": 192,
      "headers": [
        7
      ],
      "header_child": [
        37
      ],
      "olds": [],
      "incoming": [],
      "final": 37,
      "result": 7,
      "check": 0,
      "emit": 0,
      "private_current": 0,
      "runtime_incoming": true
    },
    "05-phase-equality": {
      "category": "positive",
      "semantic_legality": "dependency-free finite source family",
      "index": 0,
      "initial": 26,
      "sibling": 211,
      "headers": [
        0,
        1,
        2,
        3,
        4,
        5
      ],
      "header_child": [
        26,
        149,
        149,
        53,
        149,
        149
      ],
      "olds": [
        26,
        149,
        149,
        53,
        149
      ],
      "incoming": [
        149,
        149,
        53,
        149,
        149
      ],
      "final": 149,
      "result": 5,
      "check": 0,
      "emit": 0,
      "private_current": 0,
      "runtime_incoming": true
    },
    "06-incoming-alias": {
      "category": "positive",
      "semantic_legality": "dependency-free finite source family",
      "index": 1,
      "initial": 34,
      "sibling": 158,
      "headers": [
        1,
        3,
        5,
        7,
        9
      ],
      "header_child": [
        34,
        87,
        87,
        202,
        202
      ],
      "olds": [
        34,
        87,
        87,
        202
      ],
      "incoming": [
        87,
        87,
        202,
        202
      ],
      "final": 202,
      "result": 9,
      "check": 0,
      "emit": 0,
      "private_current": 0,
      "runtime_incoming": true
    },
    "100-zero-step": {
      "category": "negative",
      "check": 3,
      "emit": 3,
      "private_current": null,
      "reason": "outside finite phase-pure-IF/one-writer contract or invalid type/loan/quantity; first actual rejection will be recorded"
    },
    "101-arm-type": {
      "category": "negative",
      "check": 3,
      "emit": 3,
      "private_current": null,
      "reason": "outside finite phase-pure-IF/one-writer contract or invalid type/loan/quantity; first actual rejection will be recorded"
    },
    "80-literal-control": {
      "category": "control",
      "index": 0,
      "initial": 112,
      "sibling": 39,
      "headers": [
        1,
        5,
        9,
        13
      ],
      "header_child": [
        112,
        203,
        203,
        203
      ],
      "olds": [
        112,
        203,
        203
      ],
      "incoming": [
        203,
        203,
        203
      ],
      "final": 203,
      "result": 13,
      "check": 0,
      "emit": 0,
      "private_current": 0,
      "runtime_incoming": false
    },
    "81-stutter-control": {
      "category": "control",
      "check": 0,
      "emit": 0,
      "private_current": 0,
      "changing_current": false
    },
    "90-incoming-usize": {
      "category": "negative",
      "reason": "invalid replace incoming type",
      "check": 3,
      "emit": 3,
      "private_current": null
    },
    "91-phase-shadow": {
      "category": "negative",
      "reason": "legal source outside exact unchanged-phase finite family",
      "check": 3,
      "emit": 3,
      "private_current": null
    },
    "92-inner-effect": {
      "category": "negative",
      "reason": "legal source outside pure-IF/one-writer family",
      "check": 3,
      "emit": 3,
      "private_current": null
    },
    "93-overflow": {
      "category": "negative",
      "reason": "actual first ADD is not representable on the fixed 64-bit target",
      "check": 3,
      "emit": 3,
      "private_current": null
    },
    "94-other-phase": {
      "category": "negative",
      "check": 3,
      "emit": 3,
      "private_current": null,
      "reason": "outside finite phase-pure-IF/one-writer contract or invalid type/loan/quantity; first actual rejection will be recorded"
    },
    "95-unrelated-literal": {
      "category": "negative",
      "check": 3,
      "emit": 3,
      "private_current": null,
      "reason": "outside finite phase-pure-IF/one-writer contract or invalid type/loan/quantity; first actual rejection will be recorded"
    },
    "96-escaping-arm": {
      "category": "negative",
      "check": 3,
      "emit": 3,
      "private_current": null,
      "reason": "outside finite phase-pure-IF/one-writer contract or invalid type/loan/quantity; first actual rejection will be recorded"
    },
    "97-break-store": {
      "category": "negative",
      "check": 3,
      "emit": 3,
      "private_current": null,
      "reason": "outside finite phase-pure-IF/one-writer contract or invalid type/loan/quantity; first actual rejection will be recorded"
    },
    "98-second-if": {
      "category": "negative",
      "check": 3,
      "emit": 3,
      "private_current": null,
      "reason": "outside finite phase-pure-IF/one-writer contract or invalid type/loan/quantity; first actual rejection will be recorded"
    },
    "99-unrelated-copy": {
      "category": "negative",
      "check": 3,
      "emit": 3,
      "private_current": null,
      "reason": "outside finite phase-pure-IF/one-writer contract or invalid type/loan/quantity; first actual rejection will be recorded"
    }
  },
  "semantics": "Actual phase selects exactly one pure u8 arm per Continue; original T, one scoped replace, old and sibling preserved. Zero-edge has no IF evaluation or store.",
  "limits": {
    "positive": 6,
    "negative": 12,
    "control": 2
  },
  "expected_first_before_implementation": "P1174 first registration USIZE-ADDITION-PRECISION retained; new oracle predicts only successor candidate behavior",
  "ownership": "No view/count/foreign arm becomes destructor authority; preserve fresh same-bits facts; complete graph/current correspondence required"
}
```

機材の拡張は実行前に別freezeし、候補SHA/build identityと対応させます。censusを先に測り、見積から実質的に増大すれば大量failure実行前にCへ返します。未知/foreign状態で既知unsafe実行をせず、scope/authority/material findingはaffected STOP。PR1171採用前の新公開0、新P/Rアクセス/READY/merge0。
