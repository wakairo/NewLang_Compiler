C243 sentinel
