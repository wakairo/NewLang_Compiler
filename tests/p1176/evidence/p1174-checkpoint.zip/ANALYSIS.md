# P1174 / C242 diagnostic-only return

Research target: PR1171 HEAD `870e4f0972abb9725b7cf9f38d09178e51ff1280`,
tree `5db3576a09f2627f8975a21295419dee6433a629`.
Adopted main remains `425e7f6c8c54643765e861b8235620348a3c91a3`,
tree `261a8e404a1cf1982e13d3b94e3223d5da0e0499`; research is not adoption.
Same Debian GNU/Linux 13.6 x86_64 Codex P environment; no new executor/SDK.
Compass, Value Strategy 1.1/1.3, Process 4.1.2/4.3.1/4.3.2 and CURRENT_SPEC
to canonical Draft17.34 13.5a/17.4/27.4-27.7 were consulted.

## Measurements, not predictions

Four independently prepared positive sources use a real-phase pure IF to
produce a u8 binding and then one scoped replace on the original T. They
cover zero, one and multiple Continue edges and both field indices. The two
multiple-edge oracles select both IF arms and include equal-bits rewrites.
Those arrays are expected executions, not observed executions of the new
workload: the unchanged compiler rejects all four before native generation.

| source | CLI check/emit/named | first diagnostic | later stages |
|---|---|---|---|
| 01-phase-left | 3/3/3 | USIZE-ADDITION-PRECISION, 14:20 | not reached |
| 02-phase-right | 3/3/3 | USIZE-ADDITION-PRECISION, 14:20 | not reached |
| 03-one-edge | 3/3/3 | USIZE-ADDITION-PRECISION, 14:20 | not reached |
| 04-zero-edge | 3/3/3 | USIZE-ADDITION-PRECISION, 14:20 | not reached |
| 90-incoming-usize | 3/3/3 | P3-TYPE-MISMATCH | not reached |
| 91-phase-shadow | 3/3/3 | P14-LOOP-PRECISION | not reached |
| 92-inner-effect | 3/3/3 | USIZE-ADDITION-PRECISION | not reached |
| 93-overflow | 3/3/3 | USIZE-ADDITION-PRECISION | not reached |
| 80-literal-control | 0/0/0 | none | owned/current/C17/native success |

For the eight rejected sources, function-unit registration itself fails while
checking the definition. Actual `main()` invocation and public owned/private
current acquisition are not attempted. No artifact is published. The wrong
incoming type is a semantic error; shadow and inner-effect cases are also
finite-profile exclusions, not blanket language prohibitions. ADD precision
masks the deeper overflow and inner-effect obligations; their rejection does
not independently verify those deeper checks.

All rejected named outputs retain bytes, inode and mtime. The one inherited
literal control has exact baseline C17 bytes, genuine registered-main owned
body and successful private changing-current validation. Four strict native
runs (GCC13/Clang23, O0/O2) pass the passive original-address, phase, old,
current, sibling and Break/post-read checks. No new workload native was run.
Totals: 9 source profiles, 27 CLI observations, 9 initial owned probes, 8
focused registration trace probes, 4/20 allowed native executions. Compiler
clean builds, full regression, OOM matrix, sanitizer matrix, Production
changes, existing-test changes, branch publication, push, PR and CI are zero.

## Actual internal path

The read-only v2 observer links the unchanged fixed libraries, records calls
and returns their exact original values/status. It also captures bytes of the
actual retained body plan, so spans are interpreted in that plan's namespace.
The unchanged CLI remains the primary acceptance/diagnostic observation.

1. `current_source_shape` reads the incoming initializer as `NL_SYNTAX_IF`
   (kind 17) at current_loop_check_internal.h:105. The category test at
   lines 128-131 excludes IF, so the distinct changing-current route is not
   selected. The shadow case instead exits at the phase-name check, line 103.
2. `source_loop`, semantic_check.c:6174-6182, takes its generic fallback.
   The actual `nl_loop_header_create_bounded` call returns precision status 3
   with no header; this refusal is tolerated temporarily by the fallback.
3. The body proceeds through the value IF and the u8 replace, then reaches
   the actual ADD. With unknown phase and neither stutter nor current route
   active, the guarded quantity hooks cannot certify it. The guard at
   semantic_check.c:2576-2589 emits the first fatal diagnostic above.

Thus the shape guard is the first route-selection boundary, whereas the
observed fatal CHECK boundary is ADD precision during registration. Reaching
the IF/replace within an ultimately failed transaction is not a complete
issued proof, successful current validation or a backend observation.

The v1 observer enabled tracing only after successful registration, so its
eight rejected cases contain no private-path trace. Its explanatory excerpts
also used the wrong full-unit span basis; those excerpts are excluded. Its
CLI diagnostics, raw PCs, control owned/current and four native results remain
valid. All v1 source/equipment/raw is retained. V2 adds registration/retained-
plan observation only, with its own pre-execution freeze; no successful CLI
or native run is repeated and no frozen source/oracle is changed.

## Minimum prospective private implementation

No new public issuer, source law, API or ABI appears necessary for this finite
family. This is a design hypothesis, not an implemented or independently
reviewed safety result. C242 authorizes no Production edit; a new C release
must decide the actual implementation and budget.

Keep C238's dependency-free arbitrary-u8/usize header H and exact structural
frame. A pure value IF does not require a new loop invariant or a general
fixed-point/range framework. Preserve the existing guarded ADD lemma; do not
make unknown ADD generally legal or substitute the initial concrete phase.

- Extend the finite source/transfer walker with one two-normal-arm pure u8
  IF before the sole writer. Authenticate the real phase symbol/value/fact,
  condition, complete arm graphs, matching result type, dependency-free Copy
  result, and exact unchanged root/child/sibling/phase frame across both arms
  and their join. No hidden call effects, write, loan escape or control exit
  is allowed inside that IF. Reuse existing `source_if` normal-result and
  `arm_frame_with_field` checking and canonical owned IF-arm getters.
- Track the actual IF result -> ordinary binding/Copy -> replace argument
  through source-owned nodes and their worlds. `current_loan` currently
  requires a literal at line 404; `current_relation` requires known bits at
  lines 567-575. Replace these restrictions only in an authenticated runtime
  incoming variant, not by treating every unknown u8 as interchangeable.
  Old package transfer, fresh child plus root facts, canonical owner mapping,
  dependency incidence, all Continue/Break exits and caller projection remain
  mandatory, including same-bits writes and zero-edge executions.
- Seal and revalidate the two newly owned IF-arm graphs and their contexts
  along with the existing graph/node/source/target/custody/registry seals.
  Current C238 seals three graphs; a finite optional pair needs five total,
  with source-bound membership and independent canonical destruction.
  Foreign A/B and altered display arrays/counts must never become ownership
  authority. Existing root-origin and public getter/issuer code stays intact.
- Add a phase-aware private C17 value consumer. Existing `copy_if_selection`
  (main.c:808-833) assumes a known boolean/equality profile and scalar-depth
  limits, so calling it unchanged is insufficient. Reuse emission primitives
  with an authenticated actual-phase environment and unique C names. Emit
  exactly one selected u8 arm into an iteration-local value, then the existing
  old load/store/Copy uses and real carry. Never fold to initial phase, move a
  store into Break, rebuild T, or read a shadowed C phase/result variable.

The existing field-IF validator is not a generic pure scalar-IF certificate:
`nl_if_field_plan` finds no changed field here and `nl_if_field_finish` does
not issue a complete field-update proof without `ready`. Reuse the existing
CHECK producer and owned arms; add the finite scalar-transfer checks inside
the private current consumer, rather than inventing or misusing public proof.

## Cost estimate and next verification

The frozen compiler's prior C238 census is 24 relevant retained contexts.
For the proposed implementation, a static estimate is +3 existing producer
contexts (pure IF entry and two arm worlds) and +2 sealed arm-world copies:
about 29 total for these bodies, independent of runtime iteration count.
This is NOT measured candidate cost. Extra IF proof, fragment/node arrays,
anchors, clone temporaries and larger state packages add allocations beyond
that retained-context count. The current work does not run a new allocation
census or reuse the old 6091 injections as evidence for an unbuilt change.

Estimated implementation plus focused local completion is 1-2 focused P
engineering days, roughly a few hundred private lines if the existing producer
and emitter primitives compose. This is an estimate, not measured effort or
an unconditional approval. An early candidate must measure retained contexts
and allocation census before exhaustive failure injection; unbounded graph
growth, a new authority requirement or dependency/frame loss returns to C.

Next authorized candidate should preserve these original source/oracles and
FIRST, separately freeze successor expectations, verify all four genuine
current/native cases, exact literal control, wrong type/shadow/effect/overflow,
inner-arm/source/phase/result/foreign-world tampering, same-bits freshness,
owner/count destruction, new reached OOM/rollback/no-clobber/cleanup/retry,
and focused ASan/LSan/UBSan. Broader regression and CI require that release's
explicit scope/budget. Current implementation feasibility remains UNKNOWN
until those checks; no production code or new PR is supplied by C242.

## Alternatives and value alignment

Literal incoming is a working baseline when a fixed value meets the workload,
but does not implement real-phase value selection. Moving selection outside
the loop changes that contract. Branching around two literal writers changes
the task into a memory-state join/multiple-static-writer problem. A helper
call adds callable/effect composition and does not remove the current shape
frontier. SUB or an unrelated outer consumer does not solve this value flow.
The smallest promising route is one pure scalar transfer within the existing
H, rather than a new general framework or public certificate.

VALUE-ALIGNMENT-RISK: ordinary IF/Copy/replace/loop composition is reusable and
on the selected v0 critical path, but another source walker, nested graph seal,
phase-aware emitter and roughly five more contexts enlarge maintenance and
re-audit dependencies. This investigation is capability evidence, not UB-
prevention audit-locality/Product PASS. Audit locality is UNMEASURED;
GO624 PAUSED, H1 HOLD and P1036/PR1050 STOP remain. No independent R input,
oracle, runner or report was consulted and no new Track was started.

Gate: boundary located YES; new workload supported NO; literal control YES;
proposed private implementation and general safety UNKNOWN. Return at the
first useful checkpoint, with no material safety finding observed and no
authority/scope expansion. DRAFT/HOLD PR1171 and all its evidence remain
unchanged. No READY/merge/Product GO; this is not a new PR1171 adoption gate.
