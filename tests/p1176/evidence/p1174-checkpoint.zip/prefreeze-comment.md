Track: P

C242 PRE-EXECUTION FREEZE v1。通常source/CHECK/emit/probe/native実行はまだ0。固定PR1171/Production/旧testは不変で、source4正例＋4負例＋既存対照1を凍結しました。

Research HEAD `870e4f0972abb9725b7cf9f38d09178e51ff1280` / tree `5db3576a09f2627f8975a21295419dee6433a629`、実main authority `425e7f6c8c54643765e861b8235620348a3c91a3`。固定CLI SHA256 `1ec64ab01c388663464b18ad8e627c69abaeed20dbabb2620f18c47fcec9c5dd`。

freeze-v1.json SHA256 `a19bd10031930af086326902c1932c43c4efd6321f08930c476fae151be37c41`、oracle SHA256 `d71c97815eb630564112ce65c25288608e7dfd819f6857fb7bc21689cc46c8c7`。source/機材全文/observer ELF/依存library identityを含む別archive `/workspace/p1174-c242-checkpoint/inputs-prefreeze-v1.zip` SHA256 `38a695d67f80d27d9c71bbf85fa2bb71398113db23bd28feecffea772c194c7e`。

予測はCHECK precision refusalであり、受理能力や意味論的違法性の断定ではありません。current source-shapeでIF bindingが除外され、その後の既存fallbackでどの診断が最初になるかを実測します。negativeのうちphase shadowとIF内writerはsource自体の一律違法宣言ではなく今回の有限契約外です。

機材observe.cは元libraryのsyntax getter/bounded-header呼出しを記録し、実戻り値/statusをそのまま返します。CHECK/issuerを改変・代替せず、固定CLIの到達結果と区別します。新compiler build/Production変更は0。全cohortのordinary/named CLIとgenuine registered-main観察に限定し、C17成立＋真正currentを確認した場合だけstrict GCC/Clang O0/O2、最大20 nativeへ進みます。full/OOM/sanitizer matrixは反復しません。

### 01-phase-left.nl

551 bytes / SHA256 `b44db6b770275cc386e3f8a788b28936c5e21285c002635f1bddd9125398d279`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(5)){
   let incoming=if(cursor < usize(2)){u8(53)}else{u8(149)};
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

### 02-phase-right.nl

551 bytes / SHA256 `7f549da3a1173aac3122c069811e33434863d1ac123c650bcd9ac7d7e294348d`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(158),peer:u8(34)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(8)){
   let incoming=if(cursor < usize(4)){u8(87)}else{u8(202)};
   let old=loan_write(original@peer){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@peer;
   let beside=original@live;
   during;
   beside;
   continue(cursor + usize(2));
  }else{break cursor;}
 };
 let final=original@peer;
 let peer=original@live;
 let copied=result;
 unit
}
```

### 03-one-edge.nl

550 bytes / SHA256 `7988aff843641a3b5db0bcda11a44a05430ad1ff5f74eec6b9871e3826599a6b`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(91),peer:u8(17)};
 let result=loop(cursor=usize(3)){
  if(cursor < usize(4)){
   let incoming=if(cursor < usize(4)){u8(65)}else{u8(181)};
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(2));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

### 04-zero-edge.nl

552 bytes / SHA256 `5f8baa425c966281d7ef301b5440eca0443fba79abf8007deee3c1f1bb75a4f7`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(192),peer:u8(37)};
 let result=loop(cursor=usize(7)){
  if(cursor < usize(6)){
   let incoming=if(cursor < usize(8)){u8(103)}else{u8(224)};
   let old=loan_write(original@peer){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@peer;
   let beside=original@live;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@peer;
 let peer=original@live;
 let copied=result;
 unit
}
```

### 80-literal-control.nl

496 bytes / SHA256 `1cedd7fb7a5d87b5598c86b1e634d8c43eb14385b0c0c90e0c7b132e4b3a2b85`

```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   let old=loan_write(original@latch){|writer|replace(writer,u8(203))};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   continue(cursor + usize(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

### 90-incoming-usize.nl

557 bytes / SHA256 `6bea2d24881954c806fff59727fbdf704bf3194128515b015f84d1a1321eb51c`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(5)){
   let incoming=if(cursor < usize(2)){usize(53)}else{usize(149)};
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

### 91-phase-shadow.nl

575 bytes / SHA256 `5d75d5affb70f1ad8ee19e25d6f5f9f2530d2791f078223ea912838bd442d50d`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(5)){
   let cursor=usize(0);
   let incoming=if(cursor < usize(2)){u8(53)}else{u8(149)};
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

### 92-inner-effect.nl

625 bytes / SHA256 `b75576de47548efc18899ea33d83ac6a4bb3245a292089810f8fc6914e8bc1bc`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(5)){
   let incoming=if(cursor < usize(2)){let extra=loan_write(original@peer){|spare|replace(spare,u8(33))}; extra; u8(53)}else{u8(149)};
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

### 93-overflow.nl

570 bytes / SHA256 `f2475886bee9944f0585ad109f2420d6a498d478030de2a775e174e9d9db1f7c`

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(158),peer:u8(34)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(8)){
   let incoming=if(cursor < usize(4)){u8(87)}else{u8(202)};
   let old=loan_write(original@peer){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@peer;
   let beside=original@live;
   during;
   beside;
   continue(cursor + usize(18446744073709551615));
  }else{break cursor;}
 };
 let final=original@peer;
 let peer=original@live;
 let copied=result;
 unit
}
```

### Frozen oracle / expectations

```json
{
  "authority": "PR1171 870e4f0972abb9725b7cf9f38d09178e51ff1280",
  "cases": {
    "01-phase-left": {
      "category": "positive",
      "semantic_legality": "dependency-free finite source family",
      "index": 0,
      "initial": 26,
      "sibling": 211,
      "headers": [
        0,
        1,
        2,
        3,
        4,
        5
      ],
      "header_child": [
        26,
        53,
        53,
        149,
        149,
        149
      ],
      "olds": [
        26,
        53,
        53,
        149,
        149
      ],
      "incoming": [
        53,
        53,
        149,
        149,
        149
      ],
      "final": 149,
      "result": 5,
      "prediction": {
        "check": 3,
        "emit": 3,
        "layer": "CHECK precision; current_source_shape excludes IF binding, fallback may fail earlier than its loop closure",
        "exact_diagnostic": "to be measured, not assumed"
      }
    },
    "02-phase-right": {
      "category": "positive",
      "semantic_legality": "dependency-free finite source family",
      "index": 1,
      "initial": 34,
      "sibling": 158,
      "headers": [
        1,
        3,
        5,
        7,
        9
      ],
      "header_child": [
        34,
        87,
        87,
        202,
        202
      ],
      "olds": [
        34,
        87,
        87,
        202
      ],
      "incoming": [
        87,
        87,
        202,
        202
      ],
      "final": 202,
      "result": 9,
      "prediction": {
        "check": 3,
        "emit": 3,
        "layer": "CHECK precision; current_source_shape excludes IF binding, fallback may fail earlier than its loop closure",
        "exact_diagnostic": "to be measured, not assumed"
      }
    },
    "03-one-edge": {
      "category": "positive",
      "semantic_legality": "dependency-free finite source family",
      "index": 0,
      "initial": 91,
      "sibling": 17,
      "headers": [
        3,
        5
      ],
      "header_child": [
        91,
        65
      ],
      "olds": [
        91
      ],
      "incoming": [
        65
      ],
      "final": 65,
      "result": 5,
      "prediction": {
        "check": 3,
        "emit": 3,
        "layer": "CHECK precision; current_source_shape excludes IF binding, fallback may fail earlier than its loop closure",
        "exact_diagnostic": "to be measured, not assumed"
      }
    },
    "04-zero-edge": {
      "category": "positive",
      "semantic_legality": "dependency-free finite source family",
      "index": 1,
      "initial": 37,
      "sibling": 192,
      "headers": [
        7
      ],
      "header_child": [
        37
      ],
      "olds": [],
      "incoming": [],
      "final": 37,
      "result": 7,
      "prediction": {
        "check": 3,
        "emit": 3,
        "layer": "CHECK precision; current_source_shape excludes IF binding, fallback may fail earlier than its loop closure",
        "exact_diagnostic": "to be measured, not assumed"
      }
    },
    "90-incoming-usize": {
      "category": "negative",
      "reason": "invalid replace incoming type",
      "prediction": {
        "check": 3,
        "emit": 3,
        "layer": "CHECK rejection, possibly masked by earlier shape/precision frontier"
      }
    },
    "91-phase-shadow": {
      "category": "negative",
      "reason": "legal source outside exact unchanged-phase finite family",
      "prediction": {
        "check": 3,
        "emit": 3,
        "layer": "CHECK rejection, possibly masked by earlier shape/precision frontier"
      }
    },
    "92-inner-effect": {
      "category": "negative",
      "reason": "legal source outside pure-IF/one-writer family",
      "prediction": {
        "check": 3,
        "emit": 3,
        "layer": "CHECK rejection, possibly masked by earlier shape/precision frontier"
      }
    },
    "93-overflow": {
      "category": "negative",
      "reason": "actual first ADD is not representable on the fixed 64-bit target",
      "prediction": {
        "check": 3,
        "emit": 3,
        "layer": "CHECK rejection, possibly masked by earlier shape/precision frontier"
      }
    },
    "80-literal-control": {
      "category": "control",
      "index": 0,
      "initial": 112,
      "sibling": 39,
      "headers": [
        1,
        5,
        9,
        13
      ],
      "header_child": [
        112,
        203,
        203,
        203
      ],
      "olds": [
        112,
        203,
        203
      ],
      "incoming": [
        203,
        203,
        203
      ],
      "final": 203,
      "result": 13,
      "prediction": {
        "check": 0,
        "emit": 0,
        "layer": "public owned/private current/C17/native"
      }
    }
  },
  "maximum_native_runs": 20,
  "compiler_changes": 0,
  "distinction": "Positive CHECK/emit=3 is a precision forecast, not a semantic rejection requirement. Negative acceptance or native mismatch is STOP. No existing R input used."
}
```

元FIRST/RED/bundle/raw/refs、R独立性を保全。Production/push/PR/CI0、SDK導入/更新0。危険な受理やnative差異・authority/scope疑義はaffected STOP→C。audit locality UNMEASURED、READY/merge/Product GO0。
