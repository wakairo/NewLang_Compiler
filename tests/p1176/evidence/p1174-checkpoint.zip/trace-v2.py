from pathlib import Path
import subprocess,json,re,sys

p=Path(__file__).resolve().parent;raw=p/'raw-v2';probe=p/'observe-v2'
oracle=json.loads((p/'oracle.json').read_text())
rows=[]
for name,meta in oracle['cases'].items():
    if meta['category']=='control':continue # Already valid owned/current/native evidence; no rerun.
    src=p/'sources'/(name+'.nl')
    r=subprocess.run([str(probe),str(src)],capture_output=True,timeout=30)
    (raw/(name+'.out')).write_bytes(r.stdout);(raw/(name+'.err')).write_bytes(r.stderr)
    rows.append(dict(source=name,command=[str(probe),str(src)],status=r.returncode))
    (raw/'observations.json').write_text(json.dumps(rows,indent=2)+'\n')
    assert r.returncode==0 and not r.stderr,(name,r.returncode)
    out=r.stdout.decode()
    m=re.search(r'C242 PLAN bytes=(\d+) hex=([0-9a-f]+)',out);assert m
    plan=bytes.fromhex(m[2]);assert len(plan)==int(m[1])
    (raw/(name+'-retained-plan.nl')).write_bytes(plan)
    pcs=list(dict.fromkeys(re.findall(r'C242 TRACE pc=(0x[0-9a-f]+)',out)))
    lines=subprocess.run(['addr2line','-f','-e',str(probe),*pcs],check=True,capture_output=True,text=True).stdout.splitlines()
    symbols=dict(zip(pcs,zip(lines[::2],lines[1::2])))
    result=[]
    for pc,kind,start,end,stage in re.findall(r'C242 TRACE pc=(0x[0-9a-f]+) kind=(-?\d+) span=(\d+):(\d+) stage=(\d+)',out):
        function,location=symbols[pc]
        if function in ('current_source_shape','stutter_source_shape','source_loop','expression','source_if','usize_addition'):
            a,b=int(start),int(end)
            result.append(dict(pc=pc,caller=function,location=location,kind=int(kind),start=a,end=b,stage=int(stage),
                               retained_plan_excerpt=plan[a:b].decode() if 0<=a<=b<=len(plan) else 'OUTSIDE_PLAN'))
    (raw/(name+'-semantic-trace.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(name,'registration/retained-plan trace captured',flush=True)
