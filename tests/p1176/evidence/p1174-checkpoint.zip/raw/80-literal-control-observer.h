#include <assert.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
static uint8_t *c242_a,*c242_b;
static size_t c242_phases,c242_results,c242_reads;
static size_t c242_locals[4];
static const size_t c242_headers[]={((size_t)UINTMAX_C(1)),((size_t)UINTMAX_C(5)),((size_t)UINTMAX_C(9)),((size_t)UINTMAX_C(13))};
static const size_t c242_header_child[]={((size_t)UINTMAX_C(112)),((size_t)UINTMAX_C(203)),((size_t)UINTMAX_C(203)),((size_t)UINTMAX_C(203))};
static const size_t c242_olds[]={((size_t)UINTMAX_C(112)),((size_t)UINTMAX_C(203)),((size_t)UINTMAX_C(203))};
static const size_t c242_incoming[]={((size_t)UINTMAX_C(203)),((size_t)UINTMAX_C(203)),((size_t)UINTMAX_C(203))};
static void c242_finish(void){
 assert(c242_phases==4 && c242_results==1 && c242_reads==2);
 for(size_t i=0;i<sizeof c242_locals/sizeof c242_locals[0];++i)assert(c242_locals[i]==3);
 puts("C242 actual-original/phase/old/current/sibling/result PASS");
}
static void c242_bind(uint8_t *a,uint8_t *b){
 assert(!c242_a && !c242_b && a!=b && *a==112 && *b==39);
 c242_a=a;c242_b=b;assert(atexit(c242_finish)==0);
}
static void c242_phase(size_t n,uint8_t *a,uint8_t *b){
 assert(a==c242_a && b==c242_b && c242_phases<sizeof c242_headers/sizeof c242_headers[0]);
 assert(n==c242_headers[c242_phases]);
 assert(*((0)?b:a)==c242_header_child[c242_phases]);
 assert(*((0)?a:b)==39);++c242_phases;
}
static void c242_local(size_t symbol,uint8_t v){
 assert(c242_phases && c242_phases<=sizeof c242_olds/sizeof c242_olds[0]);
 switch(symbol){case 4: assert(v==c242_olds[c242_phases-1]); ++c242_locals[0]; break;
case 5: assert(v==c242_olds[c242_phases-1]); ++c242_locals[1]; break;
case 6: assert(v==c242_incoming[c242_phases-1]); ++c242_locals[2]; break;
case 7: assert(v==39); ++c242_locals[3]; break; default: assert(0);}
}
static void c242_result(size_t n){
 assert(n==((size_t)UINTMAX_C(13)));
 assert(*c242_a==203 && *c242_b==39);++c242_results;
}
static void c242_read(uint8_t *a,uint8_t v){
 assert((a==c242_a || a==c242_b) && v==*a);
 assert(v==(a==c242_a?203:39));++c242_reads;
}
#define NL_LOOP_BIND(a,b) c242_bind(a,b)
#define NL_CURRENT_PHASE(n,a,b) c242_phase(n,a,b)
#define NL_CURRENT_LOCAL(s,v) c242_local(s,v)
#define NL_CURRENT_RESULT(n) c242_result(n)
#define NL_LOOP_READ(a,v) c242_read(a,v)
