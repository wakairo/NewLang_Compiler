C242 named-output sentinel
