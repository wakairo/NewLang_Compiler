from pathlib import Path
import json,re,subprocess,sys

p=Path(__file__).resolve().parent
compiler,probe,gcc,clang=sys.argv[1:]
oracle=json.loads((p/'oracle.json').read_text())
raw=p/'raw';rows=[];native_runs=0
def run(cmd,label,allowed=(0,)):
    r=subprocess.run(list(map(str,cmd)),capture_output=True,timeout=90)
    (raw/(label+'.out')).write_bytes(r.stdout);(raw/(label+'.err')).write_bytes(r.stderr)
    row=dict(label=label,command=list(map(str,cmd)),status=r.returncode)
    rows.append(row);(raw/'observations.json').write_text(json.dumps(rows,indent=2)+'\n')
    if r.returncode not in allowed:
        (raw/'FIRST-unexpected.json').write_text(json.dumps(row,indent=2)+'\n')
        raise AssertionError(row)
    return r
def observer(meta,symbols):
    fields=[meta['initial'],meta['sibling']] if meta['index']==0 else [meta['sibling'],meta['initial']]
    final=[meta['final'],meta['sibling']] if meta['index']==0 else [meta['sibling'],meta['final']]
    array=lambda xs:','.join('((size_t)UINTMAX_C('+str(x)+'))' for x in xs) or '0'
    expected={'old':'c242_olds[c242_phases-1]','old_copy':'c242_olds[c242_phases-1]',
              'incoming':'c242_incoming[c242_phases-1]', 'during':'c242_incoming[c242_phases-1]',
              'beside':str(meta['sibling'])}
    cases='\n'.join('case '+str(symbols[n])+': assert(v=='+expected[n]+'); ++c242_locals['+str(i)+']; break;' for i,n in enumerate(symbols))
    return '''#include <assert.h>
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
static uint8_t *c242_a,*c242_b;
static size_t c242_phases,c242_results,c242_reads;
static size_t c242_locals['''+str(len(symbols))+'''];
static const size_t c242_headers[]={'''+array(meta['headers'])+'''};
static const size_t c242_header_child[]={'''+array(meta['header_child'])+'''};
static const size_t c242_olds[]={'''+array(meta['olds'])+'''};
static const size_t c242_incoming[]={'''+array(meta['incoming'])+'''};
static void c242_finish(void){
 assert(c242_phases=='''+str(len(meta['headers']))+''' && c242_results==1 && c242_reads==2);
 for(size_t i=0;i<sizeof c242_locals/sizeof c242_locals[0];++i)assert(c242_locals[i]=='''+str(len(meta['olds']))+''');
 puts("C242 actual-original/phase/old/current/sibling/result PASS");
}
static void c242_bind(uint8_t *a,uint8_t *b){
 assert(!c242_a && !c242_b && a!=b && *a=='''+str(fields[0])+''' && *b=='''+str(fields[1])+''');
 c242_a=a;c242_b=b;assert(atexit(c242_finish)==0);
}
static void c242_phase(size_t n,uint8_t *a,uint8_t *b){
 assert(a==c242_a && b==c242_b && c242_phases<sizeof c242_headers/sizeof c242_headers[0]);
 assert(n==c242_headers[c242_phases]);
 assert(*(('''+str(meta['index'])+''')?b:a)==c242_header_child[c242_phases]);
 assert(*(('''+str(meta['index'])+''')?a:b)=='''+str(meta['sibling'])+''');++c242_phases;
}
static void c242_local(size_t symbol,uint8_t v){
 assert(c242_phases && c242_phases<=sizeof c242_olds/sizeof c242_olds[0]);
 switch(symbol){'''+cases+''' default: assert(0);}
}
static void c242_result(size_t n){
 assert(n==((size_t)UINTMAX_C('''+str(meta['result'])+''')));
 assert(*c242_a=='''+str(final[0])+''' && *c242_b=='''+str(final[1])+''');++c242_results;
}
static void c242_read(uint8_t *a,uint8_t v){
 assert((a==c242_a || a==c242_b) && v==*a);
 assert(v==(a==c242_a?'''+str(final[0])+''':'''+str(final[1])+'''));++c242_reads;
}
#define NL_LOOP_BIND(a,b) c242_bind(a,b)
#define NL_CURRENT_PHASE(n,a,b) c242_phase(n,a,b)
#define NL_CURRENT_LOCAL(s,v) c242_local(s,v)
#define NL_CURRENT_RESULT(n) c242_result(n)
#define NL_LOOP_READ(a,v) c242_read(a,v)
'''

summary={}
for name,meta in oracle['cases'].items():
    src=p/'sources'/(name+'.nl');category=meta['category']
    check=run([compiler,'--check',src],name+'-check',(0,3))
    if category=='negative' and check.returncode==0:raise AssertionError(('STOP negative CHECK accepted',name))
    proof=run([probe,src],name+'-owned-trace')
    pcs=list(dict.fromkeys(re.findall(r'C242 TRACE pc=(0x[0-9a-f]+)',proof.stdout.decode())))
    symbols={}
    if pcs:
        lines=run(['addr2line','-f','-e',probe,*pcs],name+'-symbols').stdout.decode().splitlines()
        symbols=dict(zip(pcs,zip(lines[::2],lines[1::2])))
    trace=[]
    source=src.read_text()
    for pc,kind,start,end in re.findall(r'C242 TRACE pc=(0x[0-9a-f]+) kind=(-?\d+) span=(\d+):(\d+)',proof.stdout.decode()):
        trace.append(dict(pc=pc,kind=int(kind),start=int(start),end=int(end),caller=symbols[pc][0],location=symbols[pc][1],text=source[int(start):int(end)]))
    (raw/(name+'-trace.json')).write_text(json.dumps(trace,indent=2)+'\n')
    assert ('C242 CHECK=0 artifact=1' in proof.stdout.decode())==(check.returncode==0)
    emitted=run([compiler,src],name+'-emit',(0,3))
    target=raw/(name+'-named.c');sentinel=b'C242 named-output sentinel\n';target.write_bytes(sentinel);before=target.stat()
    named=run([compiler,'--emit-c17-to',target,src],name+'-named',(0,3))
    assert emitted.returncode==named.returncode
    if emitted.returncode:
        assert not emitted.stdout and target.read_bytes()==sentinel
        assert (target.stat().st_ino,target.stat().st_mtime_ns)==(before.st_ino,before.st_mtime_ns)
    else:assert target.read_bytes()==emitted.stdout
    summary[name]=dict(check=check.returncode,emit=emitted.returncode,named=named.returncode,
                       predicted=meta['prediction'],native_runs=0)
    (raw/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    if category=='control':
        assert check.returncode==0 and emitted.returncode==0
        assert emitted.stdout==(p/'control.c17').read_bytes()
    if emitted.returncode==0:
        assert check.returncode==0 and 'C242 private-current=0 changing=1 scalar=1' in proof.stdout.decode()
        locals={n:int(i) for n,i in re.findall(r'C242 LOCAL name=(\w+) symbol=(\d+)',proof.stdout.decode())}
        assert {'old','old_copy','during','beside'}<=locals.keys()
        header=raw/(name+'-observer.h');header.write_text(observer(meta,locals))
        file=raw/(name+'.c');file.write_bytes(emitted.stdout)
        for tag,cc in [('gcc',gcc),('clang',clang)]:
            for opt in ['O0','O2']:
                assert native_runs<20
                label=name+'-'+tag+'-'+opt;exe=raw/label
                run([cc,'-std=c17','-Wall','-Wextra','-Wpedantic','-Werror','-UNDEBUG','-'+opt,'-include',header,file,'-o',exe],label+'-build')
                result=run([exe],label+'-native');native_runs+=1;summary[name]['native_runs']+=1
                assert not result.stderr and b'C242 actual-original' in result.stdout
    (raw/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
assert len(summary)==9
print('C242 finite Gate0 observations complete; native runs',native_runs)
