#!/bin/bash
set -eu
fixed=/tmp/p1174-c242-fixed
prior_build=/tmp/p1169-build
cd /tmp/p1174-c242
/workspace/p1030-validation-tools/usr/bin/gcc-13 -std=c17 -O0 -g -Wall -Wextra -Wpedantic -Werror -UNDEBUG -fno-pie -no-pie -I "$fixed/include" -I "$fixed/src" observe.c -o observe -Wl,--wrap=nl_syntax_node_view -Wl,--wrap=nl_loop_header_create_bounded "$prior_build/libnewlang_semantic.a" "$prior_build/libnewlang_checked.a" "$prior_build/libnewlang_parser.a" "$prior_build/libnewlang_diagnostic.a" "$prior_build/libnewlang_syntax.a" "$prior_build/libnewlang_lexer.a" "$prior_build/libnewlang_source.a"
