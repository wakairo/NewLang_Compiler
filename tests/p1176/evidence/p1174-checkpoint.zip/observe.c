/* P-owned read-only observer. All CHECK/issuer logic is the unchanged fixed
 * library. Linker wrappers record calls and return the original exact result. */
#include "newlang/parser.h"
#include "newlang/semantic.h"
#include "newlang/checked.h"
#include "semantic_internal.h"
#include "linear_break_internal.h"
#include "control.h"
#include <assert.h>
#include <stdio.h>

typedef struct { void *pc; int kind; NLSourceSpan span; } Trace;
static Trace trace[8192];
static size_t count;
static bool enabled,truncated;
const NLSyntaxView *__real_nl_syntax_node_view(const NLSyntaxNode *);
const NLSyntaxView *__wrap_nl_syntax_node_view(const NLSyntaxNode *n)
{
    const NLSyntaxView *v=__real_nl_syntax_node_view(n);
    if(enabled){
        if(count<8192)trace[count++]=(Trace){__builtin_return_address(0),v?(int)v->kind:-1,v?v->span:(NLSourceSpan){0}};
        else truncated=true;
    }
    return v;
}
NLCheckStatus __real_nl_loop_header_create_bounded(const NLControlState *,NLControlTarget *,const NLValueId *,size_t,bool,bool,NLLoopHeader **);
static NLCheckStatus header_status;
static size_t header_calls;
static bool header_published;
NLCheckStatus __wrap_nl_loop_header_create_bounded(const NLControlState *e,NLControlTarget *t,const NLValueId *v,size_t n,bool a,bool b,NLLoopHeader **out)
{
    NLCheckStatus s=__real_nl_loop_header_create_bounded(e,t,v,n,a,b,out);
    if(enabled){++header_calls;header_status=s;header_published=out&&*out;}
    return s;
}
int main(int argc,char **argv)
{
    assert(argc==2);
    NLSource *s=NULL,*entry=NULL; NLParser *p=NULL,*q=NULL;
    NLSyntaxTree *tree=NULL,*call=NULL; NLSemanticContext *world=NULL;
    NLCheckedFragment *f=NULL;NLCheckDiagnostic diagnostic={0};
    assert(nl_source_load(argv[1],&s)==NL_SOURCE_OK);
    assert(nl_parser_create(s,&p)==NL_PARSE_OK);
    NLParseStatus parse=nl_parser_parse_function_unit(p,&tree,NULL);
    printf("C242 parse=%d\n",(int)parse);assert(parse==NL_PARSE_OK);
    assert(nl_semantic_create(&world)==NL_CHECK_OK);
    const NLSyntaxTree *units[]={tree};
    NLCheckStatus registration=nl_semantic_register_function_unit(world,units,1,NULL);
    printf("C242 registration=%d\n",(int)registration);
    NLCheckStatus checked=registration;
    if(registration==NL_CHECK_OK){
        assert(nl_source_create("main()",6,"C242 genuine main invocation",&entry)==NL_SOURCE_OK);
        assert(nl_parser_create(entry,&q)==NL_PARSE_OK);
        assert(nl_parser_parse_expression_fragment(q,&call,NULL)==NL_PARSE_OK);
        enabled=true;
        checked=nl_semantic_check_expression(world,call,&f,&diagnostic);
        enabled=false;
    }
    printf("C242 CHECK=%d artifact=%d diagnostic=%s span=%zu:%zu\n",(int)checked,f!=NULL,
       diagnostic.diagnostic.code?diagnostic.diagnostic.code:"none",diagnostic.span.start_byte,diagnostic.span.end_byte);
    printf("C242 bounded-header calls=%zu status=%d published=%d trace=%zu truncated=%d\n",header_calls,(int)header_status,header_published,count,truncated);
    assert(!truncated);
    for(size_t i=0;i<count;++i)
        printf("C242 TRACE pc=%p kind=%d span=%zu:%zu\n",trace[i].pc,trace[i].kind,trace[i].span.start_byte,trace[i].span.end_byte);
    if(checked==NL_CHECK_OK){
        assert(f);
        const NLCheckedFragment *body=nl_checked_call_body(f,nl_checked_root(f));
        assert(body);puts("C242 public-owned=YES");
        size_t loops=0;
        for(size_t i=0;i<body->count;++i)if(body->nodes[i].kind==NL_CHECKED_LOOP){
            NLLinearBreakView v={0};
            NLCheckStatus status=nl_linear_break_validate(body,i+1,&v);
            printf("C242 private-current=%d changing=%d scalar=%d\n",(int)status,v.changing_current,v.scalar_loop);
            if(status==NL_CHECK_OK&&v.iteration)
                for(size_t j=0;j<v.iteration->count;++j){
                    const NLCheckedNodeView *n=&v.iteration->nodes[j];
                    if(n->kind==NL_CHECKED_BINDING&&n->symbol)
                        printf("C242 LOCAL name=%s symbol=%zu\n",v.iteration->context->bindings[n->symbol-1].name,n->symbol);
                }
            ++loops;
        }
        assert(loops==1);
    }else assert(!f);
    nl_checked_destroy(f);nl_semantic_destroy(world);
    nl_syntax_tree_destroy(call);nl_parser_destroy(q);nl_source_destroy(entry);
    nl_syntax_tree_destroy(tree);nl_parser_destroy(p);nl_source_destroy(s);
    return 0;
}
