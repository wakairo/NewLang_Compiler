from pathlib import Path
import json

p=Path(__file__).resolve().parent
cases={}
def source(index,initial,sibling,start,limit,step,threshold,left,right):
    values=[initial,sibling] if index==0 else [sibling,initial]
    field=('live','peer')[index];other=('peer','live')[index]
    return f'''struct PhaseCell {{ live:u8, peer:u8 }}
fn main()->unit {{
 let original=PhaseCell{{live:u8({values[0]}),peer:u8({values[1]})}};
 let result=loop(cursor=usize({start})){{
  if(cursor < usize({limit})){{
   let incoming=if(cursor < usize({threshold})){{u8({left})}}else{{u8({right})}};
   let old=loan_write(original@{field}){{|writer|replace(writer,incoming)}};
   let old_copy=old;
   old_copy;
   let during=original@{field};
   let beside=original@{other};
   during;
   beside;
   continue(cursor + usize({step}));
  }}else{{break cursor;}}
 }};
 let final=original@{field};
 let peer=original@{other};
 let copied=result;
 unit
}}
'''
configs=[('01-phase-left',0,26,211,0,5,1,2,53,149),
         ('02-phase-right',1,34,158,1,8,2,4,87,202),
         ('03-one-edge',0,91,17,3,4,2,4,65,181),
         ('04-zero-edge',1,37,192,7,6,1,8,103,224)]
for name,index,initial,sibling,start,limit,step,threshold,left,right in configs:
    text=source(index,initial,sibling,start,limit,step,threshold,left,right)
    (p/'sources'/(name+'.nl')).write_text(text)
    phase=start;child=initial;headers=[phase];header_child=[child];olds=[];incoming=[]
    while phase<limit:
        value=left if phase<threshold else right
        olds.append(child);incoming.append(value);child=value
        phase+=step;headers.append(phase);header_child.append(child)
    cases[name]=dict(category='positive',semantic_legality='dependency-free finite source family',
      index=index,initial=initial,sibling=sibling,headers=headers,header_child=header_child,
      olds=olds,incoming=incoming,final=child,result=phase,
      prediction=dict(check=3,emit=3,layer='CHECK precision; current_source_shape excludes IF binding, fallback may fail earlier than its loop closure',
                      exact_diagnostic='to be measured, not assumed'))
a=(p/'sources/01-phase-left.nl').read_text()
b=(p/'sources/02-phase-right.nl').read_text()
negatives={
 '90-incoming-usize':(a.replace('{u8(53)}else{u8(149)}','{usize(53)}else{usize(149)}'),
                       'invalid replace incoming type'),
 '91-phase-shadow':(a.replace('   let incoming=', '   let cursor=usize(0);\n   let incoming='),
                    'legal source outside exact unchanged-phase finite family'),
 '92-inner-effect':(a.replace('{u8(53)}else',
      '{let extra=loan_write(original@peer){|spare|replace(spare,u8(33))}; extra; u8(53)}else'),
                     'legal source outside pure-IF/one-writer family'),
 '93-overflow':(b.replace('cursor + usize(2)','cursor + usize(18446744073709551615)'),
                 'actual first ADD is not representable on the fixed 64-bit target')}
for name,(text,reason) in negatives.items():
    (p/'sources'/(name+'.nl')).write_text(text)
    cases[name]=dict(category='negative',reason=reason,prediction=dict(check=3,emit=3,layer='CHECK rejection, possibly masked by earlier shape/precision frontier'))
control=Path('/tmp/p1174-c242-fixed/tests/p1169/sources/03-multiple.nl').read_bytes()
(p/'sources/80-literal-control.nl').write_bytes(control)
cases['80-literal-control']=dict(category='control',index=0,initial=112,sibling=39,
 headers=[1,5,9,13],header_child=[112,203,203,203],olds=[112,203,203],
 incoming=[203,203,203],final=203,result=13,prediction=dict(check=0,emit=0,layer='public owned/private current/C17/native'))
oracle=dict(authority='PR1171 870e4f0972abb9725b7cf9f38d09178e51ff1280',
 cases=cases,maximum_native_runs=20,compiler_changes=0,
 distinction='Positive CHECK/emit=3 is a precision forecast, not a semantic rejection requirement. Negative acceptance or native mismatch is STOP. No existing R input used.')
(p/'oracle.json').write_text(json.dumps(oracle,indent=2)+'\n')
