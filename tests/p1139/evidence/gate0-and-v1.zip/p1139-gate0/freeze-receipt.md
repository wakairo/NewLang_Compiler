Track: P

### C223 Gate0 pre-execution freeze

完全bytesはP環境に別凍結、R入力0。固定候補0caf948/ treef18fb0を構築した保持済みGCC compilerを使用。compiler SHA256 `f6f73f0afcd7a6a6df44ec49aa4257e51579eb42bde65b8cd9ebeb4e77cb55b0`。freeze SHA256 `83b93f62326bc48d86d5213268501fc0565590104f41d20a8ae8df4c914da324`、oracle `1548606e392517dc1de1a753d5573757265c3ca9e5e630e8e4499da5c733a69f`、runner `be208f7b2d328f3281168b1618b858aa94abe05c5b96b962c709c54888ca627e`。

|Source|SHA256|期待値|
|---|---|---|
|01-add-many|`b4da04923d30990ef7dda2039072466f8f8aa7f44d46d1a835912a6aa06844d5`|trace [2, 5, 8, 11]; normal result 11; source helper tag 43|
|02-add-zero|`7d2837e12f69b4f3fd1b63220af3794ecbdc14ba53f3ffbb581ec3cc7da3976b`|trace [11]; normal result 11; source helper tag 207|
|03-add-one|`a282619283e5f0e4640fcbafe64ac0e0c78d5f1665710e073813171ed92ed71e`|trace [8, 11]; normal result 11; source helper tag 43|
|04-add-overshoot|`c67f95f0e6ed3ad9faf231ef8fd7e9da6f3618d50e87416609090074f628397c`|trace [3, 7, 11]; normal result 11; source helper tag 207|
|05-sub-many|`f2af20cf23f5a81a196fdb675604b519511d4f9416992d9a958f82b40c801001`|trace [17, 12, 7, 2]; normal result 2; source helper tag 53|
|90-unsafe-step|`bbd688bae6107d56b48d71c3f6ffb32d3f0132425e9c8f69be7d9d45ef91b7e8`|CHECK/precision拒否、named保全|
|91-sub-underflow|`e01ac65812c8dc70bd6a1851fa9fa8f233a7c6e4be6a2485779c303099c4335d`|CHECK/precision拒否、named保全|
|92-arity|`fe7bfbcf29864cbf4b8e1be121aa56b86c1e71f4031f01c65bc6dd9a5541bf25`|CHECK/precision拒否、named保全|
|93-wrong-type|`319d7e36e44dcb5361bed6a003a20693c774abb27fc3f7229e672ab7e2c60f68`|CHECK/precision拒否、named保全|
|94-ending-loan|`665a268a5803e8e6c4ee929066c5e05b27d276f4377e732427fee5097165624d`|CHECK/precision拒否、named保全|

5正常sourceの実結果をouter binding→Copy→named usize/u8 predicateへ渡し、結果の違いがsource選択へ反映されることを要求。UnknownはUnknownのまま。最初の実行は01/05のCHECK/emit/named各3、計6観測のみ。予測はUnknown arithmetic precisionであり実測ではない。新PR/CI0、元PR1137変更0。