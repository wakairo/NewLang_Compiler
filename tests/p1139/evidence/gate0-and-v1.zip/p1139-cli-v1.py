from pathlib import Path
import json,hashlib,subprocess,sys
p=Path('/tmp/p1139-gate0');f=json.loads((p/'freeze.json').read_bytes());o=json.loads((p/'oracle.json').read_bytes());b=Path(sys.argv[1]);raw=Path(sys.argv[2]);raw.mkdir();rows=[]
for n,s in f['files'].items():assert hashlib.sha256((p/n).read_bytes()).hexdigest()==s
for case in [*o['cases'],*o['negative']]:
    positive=case in o['cases'];source=p/'sources'/(case+'.nl');out=raw/(case+'.c');out.write_bytes(b'C223 old output\x00\xff\n');before=out.stat()
    for mode,args in [('check',['--check',source]),('emit',[source]),('named',['--emit-c17-to',out,source])]:
        r=subprocess.run([str(b),*map(str,args)],capture_output=True,timeout=60);label=case+'-'+mode
        (raw/(label+'.out')).write_bytes(r.stdout);(raw/(label+'.err')).write_bytes(r.stderr);rows.append(dict(case=case,mode=mode,status=r.returncode,stderr=r.stderr.decode()));(raw/'observations.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,r.returncode,r.stderr.decode(),flush=True)
        assert r.returncode==0 if positive else r.returncode in [2,3]
        if not positive and mode=='named':assert out.read_bytes()==b'C223 old output\x00\xff\n' and (before.st_ino,before.st_mtime_ns)==(out.stat().st_ino,out.stat().st_mtime_ns)
