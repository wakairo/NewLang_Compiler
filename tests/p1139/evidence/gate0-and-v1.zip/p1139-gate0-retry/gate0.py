from pathlib import Path
import json,hashlib,subprocess,sys
p=Path(__file__).resolve().parent;raw=p/'raw';raw.mkdir();binary=Path(sys.argv[1]);f=json.loads((p/'freeze.json').read_bytes())
for n,s in f['files'].items():assert hashlib.sha256((p/n).read_bytes()).hexdigest()==s
assert hashlib.sha256(binary.read_bytes()).hexdigest()==f['compiler_sha256']
rows=[]
for case in ['01-add-many','05-sub-many']:
    source=p/'sources'/(case+'.nl');out=raw/(case+'.c');sentinel=b'C223 preserve original\x00\xff\n';out.write_bytes(sentinel);before=out.stat()
    for mode,args in [('check',['--check',source]),('emit',[source]),('named',['--emit-c17-to',out,source])]:
        r=subprocess.run([str(binary),*map(str,args)],capture_output=True,timeout=60);label=case+'-'+mode
        (raw/(label+'.out')).write_bytes(r.stdout);(raw/(label+'.err')).write_bytes(r.stderr);rows.append(dict(case=case,mode=mode,status=r.returncode,stderr=r.stderr.decode()));(raw/'observations.json').write_text(json.dumps(rows,indent=2)+'\n');print(label,r.returncode,r.stderr.decode(),flush=True)
        if mode=='named' and r.returncode:assert out.read_bytes()==sentinel and (before.st_ino,before.st_mtime_ns)==(out.stat().st_ino,out.stat().st_mtime_ns)
