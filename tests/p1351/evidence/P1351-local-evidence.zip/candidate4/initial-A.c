/* North Star V0/V1/AVS Checked-C reference output. */
#include <stdint.h>

#include <limits.h>
_Static_assert(CHAR_BIT == 8, "NewLang C17 requires 8-bit bytes");
_Static_assert(UINT8_MAX == 255 && sizeof(uint8_t) == 1 && ((uint8_t)-1) == 255, "NewLang C17 requires exact 8-bit uint8_t");
typedef struct { uint8_t f0; uint8_t f1; } nl_type_10;

static void nl_fn_11(void);
static uint8_t nl_fn_12(void);

static void nl_fn_11(void)
{
    const uint8_t nl_call_2 = nl_fn_12();
    (void)nl_call_2;
    const uint8_t nl_local_15 = nl_call_2;
    (void)nl_local_15;
    const uint8_t nl_local_16 = nl_local_15;
    (void)nl_local_16;
    (void)nl_local_16;
    (void)0;
}

static uint8_t nl_fn_12(void)
{
    nl_type_10 nl_local_1 = { .f0 = 41, .f1 = 167, };
    (void)nl_local_1;
    NL_LOOP_BIND(&nl_local_1.f0, &nl_local_1.f1);
    const uint8_t nl_local_2 = nl_local_1.f1;
    (void)nl_local_2;
    NL_LOOP_READ(&nl_local_1.f1, nl_local_2);
    const uint8_t nl_call_12 = nl_fn_10(nl_local_2);
    NL_CURRENT_CALL_RESULT(10, 12, nl_call_12);
    (void)nl_call_12;
    const uint8_t nl_local_9 = nl_call_12;
    NL_CURRENT_CALLER_COPY(9, nl_local_9);
    (void)nl_local_9;
    uint8_t nl_loan_result_1;
    {
        uint8_t *const nl_local_10 = &nl_local_1.f0;
        (void)nl_local_10;
        const uint8_t nl_replace_old_18 = *nl_local_10;
        *nl_local_10 = nl_local_9;
        nl_loan_result_1 = nl_replace_old_18;
    }
    (void)nl_loan_result_1;
    const uint8_t nl_local_11 = nl_loan_result_1;
    (void)nl_local_11;
    NL_CURRENT_LOCAL(11, nl_local_11);
    const uint8_t nl_local_12 = nl_local_1.f0;
    (void)nl_local_12;
    NL_LOOP_READ(&nl_local_1.f0, nl_local_12);
    const uint8_t nl_local_13 = nl_local_1.f1;
    (void)nl_local_13;
    NL_LOOP_READ(&nl_local_1.f1, nl_local_13);
    (void)nl_local_11;
    (void)nl_local_12;
    (void)nl_local_13;
    const uint8_t nl_local_14 = nl_local_9;
    NL_CURRENT_CALLER_COPY(14, nl_local_14);
    (void)nl_local_14;
    return nl_local_14;
}

int main(void)
{
    nl_fn_11();
    return 0;
}
