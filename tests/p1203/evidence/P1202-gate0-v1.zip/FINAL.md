# P1202 / C259 finite Gate0 report

Track: P. Date: 2026-11-06 UTC. Same existing Debian13.6 environment.

## Result and disposition

The frozen two-source comparison establishes a **pre-existing compositional
precision gap**, with **no candidate-only regression in the tested pair**.

| P-owned source | main53 CHECK | candidate0fd24 CHECK | C17 |
|---|---|---|---|
| normal helper + original T update + computed Continue + phase-result Break | exit0, empty stdout/stderr | exit0, empty stdout/stderr | both exit0; 3,743 bytes; byte-identical |
| exactly the same source with phase-independent literal Break | exit3, USIZE-ADDITION-PRECISION | exit3, USIZE-ADDITION-PRECISION | not queried after CHECK refusal |

The target's first refusal is at line17, columns18-19, the Continue addition.
The two original stderr files are each182 bytes and byte-identical, SHA256
`76b579cd3c28f636139c96ef9ee88510adf96fc2891fd44843c218cbbd8bcff6`.
The control's generated C files have SHA256
`92d1d6ddc1025f90adfffaef340e200ec4ea23373f9232461fba0a5e7892c6fb`.

The distinction matters: computed carry after a normal helper/T Change is
already supported when Break returns the current phase. The missing composition
is the **Break-result contract** for that changing-current loop. The arithmetic
diagnostic is the first observed symptom of falling outside that private
source/proof family. It is not evidence that all guarded computed carry is
unsupported, and not evidence that PR1199 introduced this boundary.

Classification Gate: YES. Existing-machinery finite extension: code-derived YES,
not implemented or measured here. General issuer/world necessity: none found
for the proposed literal-result family. Broader phase-independent Break bodies
remain UNKNOWN and outside the minimum proposal.

## Fixed identities and build binding

Main: `53c125b8cd66523651a21e803827eff6d2a06428`, parents
[`70059189c2030f927ad3daa0044c8898848b4548`,
`f1648a1382ae058e5ab5b9ccdea1e3200879f2af`], whole tree
`1a4fcf50e76b0d2def314fdf7720f88d52a6581c`.

The existing clean f164 checkout/build has exactly the same whole tree,
independently confirmed against GitHub's Git commit metadata. Its existing
compiler is the **tree-equivalent main build**, not a claim that the main merge
commit itself was checked out and compiled:

- ELF: `/tmp/p1188-c254-clean-build/newlangc`;
- bytes1,979,176; SHA256
  `855dceb5bbe968a6e9f265951b05f55fea1755ec870473c0782a8c8cb46f4ed7`.

Candidate: `0fd24ad3ed08c51845819aab48506c9d43fdccf6`, sole parent
`24339b077ed0e0a3e847f23aed170c67d2b3d20a`, whole tree
`121ca6c13b81768c9c1b854a5d72d76841f6df10`.

- ELF: `/tmp/p1193-c256-gcc-clean/newlangc`;
- bytes1,999,216; SHA256
  `2cd50ff9ec674f8fae963f2e6696dbef910ba346371f2ae80c460fe4d4fa8ce5`.

Both preserved worktrees were clean before and after observation. All71 tracked
src/include/CMake inputs per checkout matched their actual Git blob identities.
Both use existing GCC13 Debug strict-C17 builds. No build was necessary.
CURRENT_SPEC selects Draft17.34. Compass, Value Strategy §§1.1/1.3, Process
§§4.1.2/4.3.1/4.3.2, canonical §§5.2/27.5/27.6 and P1133's declared boundary
were read. Original24339/0fd24, P1188, P1193 and P1200 evidence/refs remain
unchanged. R literal source/oracle/raw/report access0; new P0.

## Pre-execution freeze and actual observations

Freeze-v1 SHA256:
`dc45062c2ba5054e237e407589422b054207c63638d8fe39ee11dd140d33d68e`.

- `sources/01-current-phase-break.nl`: 611 bytes, SHA256
  `608bfbf920ebb3a7d7981d25cd46347025e5d49a3b9ac18211f74e5ce60d705c`.
- `sources/02-independent-break.nl`: 616 bytes, SHA256
  `b22868c3f907d3e7c028a7237c8236b1615a6a158c4a6e0c6fd562470e8f2b78`.
- `oracle-v1.json`: SHA256
  `b283442394f3bcca9920df7dcdbdf87abbe93587e8229e05491ed23072471cad`.
- Both complete sources, oracle, runner and binary identities were frozen before
  any query. The exact single source delta is the Break result expression.
- Actual START receipt: Issue1202 comment6679090684; FIRST/result checkpoint:
  comment6679097411. A larger proposed START containing full source and local
  paths was rejected by automatic approval review; a materially smaller
  hash/identity/plan receipt was posted. The source payload stayed local.
- Actual queries ran once at06:53:25 UTC: control main/candidate CHECK, control
  main/candidate C17, then target main/candidate CHECK. All matched predictions.
- Raw argv, timestamps, status, stdout/stderr bytes and SHA256 are retained in
  `raw/01-*.json` through `raw/06-*.json` and the matching stdout/stderr files.
- `raw/result-v1.json` SHA256:
  `529a8351124b68fdc1b56fae54c05c5e003e15246a816a38497355fc8c82b632`.

The semantic trace/old/current/sibling/physical identity expectations in the
oracle are **predictions, not native observations**. C17 success traverses the
existing current-loop/private helper admission and finished-result receipt.
This Gate0 did not separately invoke each public proof getter/validator or
inject host mutations. The target fails during definition CHECK before an
actual published main-loop owned proof or target C17 is available.

Counters: positive/control sources2/4; negative/boundary sources0/4; total
queries6/24. Builds0, guest native0, Production/spec edits0, remote
branch/push/PR/Actions/CI0. No further diagnostic probes after the identical
target refusal. No sanitizer/OOM/regression matrix was run.

## Exact first missing private contract

At fixed0fd24 (the relevant gates are also present unchanged on main's tree):

1. `stutter_loop_check_internal.h::stutter_continue` lines80-95 admits an entire
   Continue block only when its single item is the direct Continue. Our helper,
   T Change and ordinary old/current/sibling uses exclude that family. Its
   `stutter_frame` must remain exact; it cannot be widened to silently erase T
   changes.
2. `current_loop_check_internal.h::current_source_shape` lines297-306 requires
   the Break arm to pass `stutter_scalar_source`. That helper (lines97-112 in
   stutter_loop_check_internal.h) requires a single `break <same phase name>`.
   Our target has a genuine literal usize result, so this gate returns false.
3. `semantic_check.c::source_loop` lines6175-6183 tries stutter, current and
   linear-Break families in order. The generic fallback's `LoopControl` has
   neither the private stutter nor current relation installed. Its loop slot
   is represented as Unknown; in `usize_arithmetic` lines2578-2588 neither
   private arithmetic hook can authenticate the guarded operation. Hence the
   actual USIZE-ADDITION-PRECISION refusal, even though the fixed guard/step is
   mathematically representable for every header state.

Admission alone is insufficient. Further hard-coded assumptions must change
together in a later implementation:

- `current_arm` lines1123-1128 accepts only a copied phase identifier on Break.
- `current_relation` lines1221-1229 requires both leaf/union results to satisfy
  `stutter_free_quantity`, which specifically describes an **Unknown** flat
  usize. A source literal is Known and must have its own exact validation.
  Do not weaken this helper globally or relax Continue's Unknown obligation.
- The genuine Break leaf/union source owner, source node, target, result type
  and world-local value must remain authenticated through the existing
  `nl_control_source_terminal_valid` and sealed graph/world/exit machinery.
- `source_current_loop`/`validate_current_cycle` currently publish and validate
  a free Unknown usize caller result paired with the original T's projected
  postcurrent. A literal-result variant must prove that summary compatibility
  explicitly. It must never copy an arm-world value ID into the caller or
  substitute the loop phase for the actual Break result. An Unknown flat result
  is a sound over-approximation if the literal leaf/union and source result
  compatibility are established; no new Known-number receipt is necessary.
- `main.c::emit_current_loop` lines3085-3088 currently always assigns the final
  runtime phase as the loop result. A widened CHECK gate alone would miscompile
  this source. The emitter must instead consume the authenticated Break-result
  mode/expression for the new family.

`semantic_check.c` and `stutter_loop_check_internal.h` have no changes between
the two fixed trees. The current source gate and current arithmetic hook are
also unchanged. PR1199's different RETURN/signature authentication cannot be
reached on the target because the current source gate is already false.

## Reusable relation and minimum implementation proposal

Retain the existing current relation:

`H = exact persistent frame E × selected original-T root/child current package
     abstracted to a dependency-free u8 × one dependency-free usize phase`.

Its complete Continue walk already checks the normal helper's argument/formal,
effects/body/result, unchanged phase place/incarnation/current fact, one scoped
field Change, old Copy, updated current, sibling, and closure back into H.
`current_quantity` already applies `finite_add_bound`: L>0 and
`step <= SIZE_MAX-(L-1)` on the actual true arm. The generated control C computes
from the real current phase; no fixed successor is replayed. These mechanisms
are reusable without weakening P1133's stutter E or adding a range engine.

Smallest coherent next increment:

- keep the existing one-slot direct-LT / positive-ADD / one-helper / one-T-field
  update / one Continue / one Break family;
- add an effect-free, dependency-free **literal core-usize Break result** as
  an alternative to the existing phase result, for arbitrary representable
  literal values, field indices, legal names and bounded helper values;
- authenticate literal source/node/scalar result and the same result in the
  exact leaf and body-union worlds; preserve all source/target/cardinality and
  original-T postcurrent checks;
- expose only a compiler-private borrowed Break-result description, freshly
  filled after validation, to the emitter; a small addition to
  `NLLinearBreakView` in `src/linear_break_internal.h` suffices;
- emit that actual authenticated Break value once at the exit. Keep current
  phase-result emission byte-identical;
- preserve the current Unknown caller-result projection, or a stronger
  source-authenticated literal summary if justified during implementation;
  do not create authority or a new public arithmetic receipt.

Expected Production surface: `current_loop_check_internal.h`,
`linear_break_internal.h`, `main.c`; roughly80-160 changed/additional lines.
This is an implementation estimate, not an observed patch. No semantic_check
arithmetic relaxation, public issuer/API/ABI, new world/graph or general CFG/MIR
is indicated by current evidence.

Out of this minimum increment: changing T in Break as well as Continue,
arbitrary expressions/helper calls/effects in Break, new result types, nested or
multiple backedges, variable/commuted guards/steps, SUB on the T-changing path,
general range inference, mixed-RETURN continuation from1200.

## Cost, failure and later tests

No new owned graph/context/exit snapshot, RETURN record, signature-ledger world
slot, ownership transfer or heap allocation site is expected. The new literal
uses the already retained Break graph/leaf/union worlds. A transient private
borrow/result descriptor may add approximately16-32 stack bytes on LP64; deriving
its value from the existing sealed graph can avoid persistent proof growth.
Actual alignment/size and retained bytes must be measured on a later candidate.
The existing registry-sized signature metadata/scan cost remains real.

Plan about half a focused P day to the first implementation and matched census,
then roughly another half to one P day for finite native, negative, reached-OOM,
sanitizer, local regression and prospective history work, subject to a new C
release. CI/publication must be separately allocated: PR1199 is already at its
12/12 actual-job budget and this scout releases no further push or CI.

Future tests, not run here:

- preserve these sources/oracle/FIRST and add prospective implementation-target
  predictions rather than rewriting the Gate0;
- zero/one/multiple backedges, both helper outcomes, multiple literal exit
  values, both T fields, old/current/sibling/original address and final loop
  result; strict GCC/Clang O0/O2 only after CHECK and genuine validation;
- all-H ADD overflow boundary and wrong guard arm/source/phase/current fact;
  wrong Break source/result/type/owner/target/leaf-union/cardinality; signature
  substitutions; existing phase-result and P1133 stutter refusals retained;
- OOM at freshly reached construction/emission sites (even if no new C call
  site), partial cleanup, no publication, same-context retry, canonical/foreign
  survival, named-output bytes/inode/mtime and temporary cleanup;
- focused ASan/LSan/UBSan plus risk-proportionate local regressions and original
  phase-result C17 byte preservation.

## Priority, alternatives and STOP

For the failing richer-loop workload, this Break-result composition is a lower
dependency than1200's mixed-RETURN continuation: it already fails with a normal
helper. Recommend a bounded carry/Break composition implementation before
promoting the combined workload.1200 remains preserved and unimplemented; it
does not logically depend on literal Break when used with the supported
phase-result envelope.

Current source workaround is to return the phase and separately construct an
unconditional phase-independent value outside the loop, if that preserves the
application's real contract. The minimum private extension avoids that source
restriction. Replacing this with general world/range machinery or erasing T
effects from stutter's exact frame is unjustified.

Gate0 execution is complete. Any new public authority/API/semantics, unresolved
original/current/loan/dependency contradiction, larger retained machinery or
scope/cost excess in a later stage requires affected STOP to Coordination.
No candidate-only regression was found here; no safety/adoption PASS for all
PR1199 inputs is inferred. No Ready, merge, Product GO or F/R start.

## VALUE-ALIGNMENT-RISK

The useful increment is reusable loop-result composition under selected
semantics. Its cost is another private result mode and its checker/validator/
emitter consistency tests, not new mathematical arithmetic. Keeping arithmetic
events and original-T current transfer shared avoids fixture-specific dispatch
growth. Finite CHECK/C17 success and this precise refusal do not measure human
UB-prevention audit locality or establish general soundness. Audit locality
UNMEASURED; GO624 PAUSED; H1 HOLD; P1036/PR1050 STOP remain.
