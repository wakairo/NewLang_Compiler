"""C259 finite CLI comparison; this program never builds or runs a guest."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def save_new(path, data):
    mode = "xb" if isinstance(data, bytes) else "x"
    with path.open(mode) as stream:
        stream.write(data)

freeze = json.loads((HERE / "freeze-v1.json").read_text())
for name, wanted in freeze["files"].items():
    assert digest(HERE / name) == wanted, name
oracle = json.loads((HERE / "oracle-v1.json").read_text())
identity = json.loads((HERE / "binary-identities-v1.json").read_text())
for baseline in identity["baselines"].values():
    assert digest(Path(baseline["binary"])) == baseline["binary_sha256"]
assert not (HERE / "raw" / "result-v1.json").exists()

queries = []
stopped = False
reason = None
for index, (source_name, label, mode) in enumerate(oracle["query_order"], 1):
    baseline = identity["baselines"][label]
    source = HERE / "sources" / (source_name + ".nl")
    command = [baseline["binary"]]
    if mode == "check":
        command.append("--check")
    command.append(str(source))
    assert index <= 24
    prefix = HERE / "raw" / f"{index:02d}-{source_name}-{label}-{mode}"
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    began = time.monotonic()
    result = subprocess.run(command, capture_output=True, timeout=30)
    elapsed = time.monotonic() - began
    save_new(prefix.with_suffix(".stdout"), result.stdout)
    save_new(prefix.with_suffix(".stderr"), result.stderr)
    entry = {
        "query": index, "source": source_name, "baseline": label,
        "mode": mode, "command": command, "started_utc": started,
        "seconds": elapsed, "status": result.returncode,
        "stdout_bytes": len(result.stdout), "stderr_bytes": len(result.stderr),
        "stdout_sha256": hashlib.sha256(result.stdout).hexdigest(),
        "stderr_sha256": hashlib.sha256(result.stderr).hexdigest()
    }
    predicted = oracle["sources"][source_name][mode + "_prediction_each_baseline"]
    matches = result.returncode == predicted["exit"]
    if "stdout_bytes" in predicted:
        matches = matches and len(result.stdout) == predicted["stdout_bytes"]
    if "stderr_bytes" in predicted:
        matches = matches and len(result.stderr) == predicted["stderr_bytes"]
    if "diagnostic" in predicted:
        matches = matches and predicted["diagnostic"].encode() in result.stderr
    if predicted.get("nonempty_stdout"):
        matches = matches and bool(result.stdout)
    entry["matches_prediction"] = bool(matches)
    queries.append(entry)
    save_new(prefix.with_suffix(".json"), json.dumps(entry, indent=2) + "\n")
    print(json.dumps(entry), flush=True)
    if label == "candidate0fd24" and mode == "check":
        main = next(q for q in queries if q["source"] == source_name and
                    q["baseline"] == "main53" and q["mode"] == mode)
        if main["status"] == 0 and result.returncode != 0:
            stopped = True
            reason = "candidate-only regression: immediate STOP"
            break
    if not matches:
        stopped = True
        reason = "unexpected result; preserve FIRST and return for finite diagnosis"
        break

summary = {"queries": queries, "queries_used": len(queries),
           "stopped": stopped, "reason": reason,
           "builds": 0, "native": 0, "production_edits": 0,
           "remote_push_pr_ci": 0, "r_access": 0}
c17 = [q for q in queries if q["mode"] == "c17"]
if len(c17) == 2:
    summary["positive_control_c17_equal"] = c17[0]["stdout_sha256"] == c17[1]["stdout_sha256"]
    if not summary["positive_control_c17_equal"]:
        summary["stopped"] = True
        summary["reason"] = "unpredicted positive-control C17 bytes differ; inspect before further execution"
save_new(HERE / "raw" / "result-v1.json", json.dumps(summary, indent=2) + "\n")
print(json.dumps({k: v for k, v in summary.items() if k != "queries"}), flush=True)
sys.exit(1 if summary["stopped"] else 0)
