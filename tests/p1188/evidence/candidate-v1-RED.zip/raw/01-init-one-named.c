P1188 named-output sentinel
