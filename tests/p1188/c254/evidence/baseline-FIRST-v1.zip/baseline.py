from pathlib import Path
import hashlib
import json
import subprocess

source = Path('/tmp/p1188-c254/tests/p1188/c254')
raw = Path('/workspace/p1188-c254-checkpoint/baseline-v1')
raw.mkdir(exist_ok=False)
compiler = Path('/tmp/p1188-c250a-clean-build/newlangc')
assert hashlib.sha256(compiler.read_bytes()).hexdigest() == '31d9d81338e3e3964021f6b6beadf4cad5199432782f5b9766be21aa4f720dc4'
oracle = json.loads((source / 'oracle-v1.json').read_bytes())
rows = []
for name, case in oracle['cases'].items():
    path = source / 'sources' / (name + '.nl')
    for label, command in [('check', [compiler, '--check', path]), ('emit', [compiler, path])]:
        result = subprocess.run(list(map(str, command)), capture_output=True, timeout=90)
        (raw / (name + '-' + label + '.out')).write_bytes(result.stdout)
        (raw / (name + '-' + label + '.err')).write_bytes(result.stderr)
        rows.append(dict(source=name, stage=label, status=result.returncode,
                         expected_CHECK=case['baseline_CHECK']))
        (raw / 'observations.json').write_text(json.dumps(rows, indent=2) + '\n')
        if case['class'] == 'target-positive' and label == 'check' and not (raw / 'FIRST.json').exists():
            (raw / 'FIRST.json').write_text(json.dumps(rows[-1], indent=2) + '\n')
        if result.returncode < 0:
            raise AssertionError('unsafe host failure: stop')
        if case['class'] == 'existing-byte-control' and label == 'emit':
            assert result.stdout == (source / 'evidence' / (name + '.c17')).read_bytes()
        print(name, label, result.returncode, flush=True)
print('Baseline source42 not run: actual CHECK14/emit14; generated guest compile/native0')
