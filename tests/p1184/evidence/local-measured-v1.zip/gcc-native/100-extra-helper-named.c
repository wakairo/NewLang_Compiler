C245 named-output sentinel
