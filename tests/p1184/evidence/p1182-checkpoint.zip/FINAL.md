Track: P

### C244 FINAL — first boundary measured / Production NO CHANGE

同じ既存Debian GNU/Linux13.6 x86_64 Codex Pで有限Gate0を完了しました。固定PR1180 **bb8b33cefc030ed99941c9c93fef9c7ef89b0ac0**／tree **d8fd0b0a95184d3449d7e1525ba56574429dbf8f** と元P1176 FIRST/RED/source/oracle/raw/archives/bundle/refsは不変。START時実mainは **11d4d078c2a9deb68b77c428bba079431dee72fc** であり、baseをmain採用済みとは扱っていません。

[実START6652073190](https://github.com/wakairo/NewLang_Compiler/issues/1182#issuecomment-6652073190)、[初回実行前の完全source/oracle/観測器freeze6652253968](https://github.com/wakairo/NewLang_Compiler/issues/1182#issuecomment-6652253968)。既測CLI SHA256 **d7e2eb6db69b7784125cd85acf74cf451f73edcb830e5bba1556b44a8eb92ef7** は元final-code continuity archiveと一致しました。追加compiler build0です。

#### 1. 最初の実拒否

最初の01-helper-loopの通常CLI CHECKは**exit3、stdout空**:
```
sources/01-helper-loop.nl:17:20-17:21:
error(precision)[USIZE-ADDITION-PRECISION]:
addition needs known dependency-free quantity operands in this profile
```
first stderr SHA256 **c5adfbf4a12f26e1e9baac90dba75eb10c09497e7d6fea24130c7c62230c7449**、source SHA256 **31873ab92f0497a1c00d519d030a9efcb5091c512a0e805451600159fc44e664**。

既存P1117 observerでも `parse=0; registration=3 unchanged=1 no_owner=1`。登録contextのstruct比較が不変で、entry invocation/owned発行へ進んでいません。これをC17の拒否や、既発行loop proofのvalidator拒否とは分類しません。原FIRST.json/stdout/stderrを保全しています。

コード照合による原因: [current_source_shape](https://github.com/wakairo/NewLang_Compiler/blob/bb8b33cefc030ed99941c9c93fef9c7ef89b0ac0/src/current_loop_check_internal.h#L79)は、内側IFまたはliteral/name/fieldを許す一方、binding initializerのREGISTERED CALL sourceを受け付けません（同file L166付近）。[source_loop](https://github.com/wakairo/NewLang_Compiler/blob/bb8b33cefc030ed99941c9c93fef9c7ef89b0ac0/src/semantic_check.c#L6174)はcurrent専用Hの経路に入らず通常経路へ進み、未知phaseのADDが[既存quantity guard](https://github.com/wakairo/NewLang_Compiler/blob/bb8b33cefc030ed99941c9c93fef9c7ef89b0ac0/src/semantic_check.c#L2573)で拒否されます。これはdiagnosticの実測と、固定コードのcontrol-flow照合を組み合わせた説明であり、新しいデバッグ用compilerを作ったものではありません。

#### 2. 有限結果

| source | CHECK／最初の層 | owned/current／C17/native |
|---|---|---|
| 01 helper LT→loop live | exit3 / registration ADD precision | observerで未発行。C17/native未到達 |
| 02 helper EQ＋result Copy aliases→loop peer | exit3 / registration ADD precision | 追加matrixなし。C17/native未到達 |
| 04 literal-u8 bodyの狭いhelper→one-edge loop | exit3 / registration ADD precision | bodyを狭めてもcall source境界は残る |
| 03 helper単体、IF→binding→Copy→normal u8 | exit0 | 実owned/current consumer成功、C17 exit0、strict native8/8 |
| 90 wrong result usize→u8 field | exit3 / P3-TYPE-MISMATCH | 型の負例をloopによるmaskなしで拒否 |
| 91 wrong actual u8→usize formal | exit3 / P3-TYPE-MISMATCH | argument type拒否 |
| 92 normal IF arm u8/usize不一致 | exit3 / P13-IF-RESULT | normal result type拒否 |
| 80 元inline IF control | CHECK/C17 exit0 | 元C17 bytes完全一致。旧nativeを再実行せず |

03の既測observerは、formal CHECKで `bool_known=0 node_known=0 dependencies=0 count=0`、登録成功、`actual invocation=0 owner=1`、`actual checked consumer=1 functions=2` を出力しました。普通のcall/bodyと実CHECK-issued ownerを既存private consumerが受理します。専用の新公開Copy validatorを呼んだという結果ではありません。

生成Cは実size_t parameterを比較し、u8結果をbinding/Copyからreturnする関数と、3つのordinary callsです。目視後、GCC13/Clang23、strict C17 `-Wall -Wextra -Wpedantic -Werror`、O0/O2のraw/passive各4＝**8 guest実行**が成功。passiveは元のreturn値を変更せず、各toolchain/optで実値 **0→53、2→149、5→149** と3回のentry/returnを観測しました。

**これはhelper単体の証拠です。** loop内の未知actual phase→call→original T store/currentの合成はCHECKで未到達であり、H_loop/old Copy/postcurrent/物理originalの合成成功へ読み替えません。新しいhelper-loop OOM/no-clobber/sanitizer/censusも未実施です。

#### 3. 既存証拠の再利用性と下流の静的障害

再利用可能な核:
- ordinary registration、actual source-owned call body取得、current function entryのNULL/bounds/body-plan/signature/effect/source checks。
- [predicate_scalar/body/call](https://github.com/wakairo/NewLang_Compiler/blob/bb8b33cefc030ed99941c9c93fef9c7ef89b0ac0/src/c17_predicate_internal.h#L82)の完全なpure IF両arm、normal u8、source name/Copy origin/bindingの照合。単にtype/Unknown/bits一致でproducerを作らない。
- 既存usize parameterのu8関数C17 emission、current-loopのH/frame/fresh facts/leaf-union/caller post、one scoped replaceとold/current/sibling/physical originalの既存経路。

**そのまま接続は不可**:
- [predicate_call](https://github.com/wakairo/NewLang_Compiler/blob/bb8b33cefc030ed99941c9c93fef9c7ef89b0ac0/src/c17_predicate_internal.h#L331)はbackendのV0Program/root policyに結合し、aggregate時のpost-loop origin条件、`linear_break`等の除外があります。quantity actualの既存admissionも、loop headerの現在phase用ではありません。ガードを削除して流用してはいけません。
- 現current walkのincoming producerはinline IFとそのCopy chain。graph seal topologyはouter3＋inner arms2の5で、[current_graph_at](https://github.com/wakairo/NewLang_Compiler/blob/bb8b33cefc030ed99941c9c93fef9c7ef89b0ac0/src/current_loop_check_internal.h#L806)がhelper bodyを辿りません。
- 公開CopyBodyParametersは既存write-ref＋u8の2引数用であり、usize→u8 pure helperの証拠として転用できません。
- 狭いliteral-only helper案も01等と同じCHECK入口で止まり、既存predicate_body自体もone selectionを要求します。定数bodyへの表記変更だけでは今回の障害を解消しません。

上記下流条件は**静的確認**であり、拒否されたloop sourceのbackendまで実到達したという測定ではありません。

#### 4. 最小の次実装案・費用（推定）

次の別RELEASEで、**one known-direct helper／one usize formal／one dependency-free normal u8／one LTまたはEQ＋literal-u8両arm／binding・Copy aliases／one Continue・one scoped writer**に限定したprivate合成を提案します。

1. CHECKとbackendから再利用できる小さなprivate pure-call graph契約を抽出する。backendのProgram/root配置policyをCHECKへ持ち込まず、actual caller phase→actual argument→当該call固有formal→callee両arm/normal result→caller binding/Copy→同じChange incomingを、source/node/owner/world/registryと既存entry authenticityで結ぶ。caller H/frameと全prefix package・loan/current保持を確認する。
2. current-loop source/walkにauthenticated call producer variantを追加し、callee bodyとIF armsをcanonical ownerから借用してsealする。display/countを破棄権限にせず、全新failureをouter commit前へ置きrollback/OOM/cleanupを検査する。旧inline/literal/stutterは維持。
3. C17 preflightで真正helperを収集し、iterationの実phase C変数をactual argumentへ一度渡す。返った実u8を既存one storeへ流し、zero/Breakでは余分なcall/storeをせず、old/current/siblingと同じoriginal addressを維持する。

静的topology目安は**5→6 retained graph seal slots（helper bodyが1つ追加）**。これは設計上の最小増分で、実装後のclone/context/allocation数を測った値ではありません。現在の29 contextsや旧+5／7158 ordinalsを新helper差分の費用に使いません。callee CHECK・parameter/cleanup・world sealが増やす**実context数、OOM PCs/ordinals、ピークメモリはUNMEASURED**。最初の候補で新censusを取り、予算を超えるなら大量注入前にCへ返す必要があります。

工学的初期見積は**1–2 focused P engineering days、private Production数百行程度＋focused tests/census**。不確実性はcurrent-loopとcalleeのworld/parameter対応をどこまで既存契約から共有できるかです。大きな一般IRや新公開issuer/source lawが必要になるならaffected STOP→C。これを既実装/費用上限の証明とは扱いません。

代替比較: inline IF維持は現在使える低費用経路ですがordinary helperへの計算分離を実現しません。literal-only bodyは入口障害を解消しない実測です。既存predicateの純粋部分をprivate共有する案が、ガード複製や権限付きsource inliningより小さく、actual call originを保つ初期案です。一般pure/recursive call、複数helper/loop、effectful/ref引数、任意Hへの拡張は次scopeに含めません。

#### 5. Gate・STOP・予算

- **Gate0 YES: 障害層とhelper単体の再利用可能な能力を独立P sourceで確定。**
- **現在のhelper-loop合成 NO（未対応）**。既存consumerを無変更で再利用する案もNO。
- **private実装成立性はCONDITIONAL/未検証**。新しい公開issuerや意味論が不可避という矛盾は今回見つかりませんでしたが、上記finite current relationを構成・検証した結果ではありません。
- C244はここで**Production NO CHANGE**として返却。追加実装・OOM・CIは別認可が必要です。一般soundnessやProduct PASSは主張しません。
- 実消費: **4正例/3負例/1既存control、通常CLI10観測（CHECK8/C17 2）、既測owned observer2、strict guest compile8/guest実行8（上限32）**。拒否sourceのC17/native matrix反復0。
- **Production/compiler/test-framework/workflow変更、compiler build/full regression、SDK、local/remote branch/push/PR/Actions/CI0**。guest Cの限定コンパイル8はIssue §有限作業3の認可内で、compilerのrebuildではありません。
- R入力/oracle/runner/report参照0、新Track/P起動0、READY/merge0。最新C245 preflightはPR1180固定HEAD/first-green停止維持の非PASS記録であり、material findingではありません。Cからの新material findingは未受信です。

事前prepareのPython構文誤りは実行開始前の資料作成エラーとして別記録しています（compiler/source観測0）。凍結後source/oracle/観測器を変更せず、原FIRST/REDを後続成功で置換していません。

#### VALUE-ALIGNMENT-RISK（技術結果と別）

ordinary functionへの計算分離は、既選択v0 sourceの再利用を進める候補です。一方で、private call/body/parameter認証、nested seal、phase-aware emitterの依存閉包が増え、二重のpurity walkerを増殖させれば監査・保守費用を上げます。小さな共通pure-call契約と既存inline経路を比較し、利用者の実負担改善は未測定とします。audit locality **UNMEASURED**／GO624 **PAUSED**／H1 **HOLD**／P1036–PR1050 **STOP**を維持し、今回のGate0/native結果をProduct GOや一般cyclic soundnessへ読み替えません。

