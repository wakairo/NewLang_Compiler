Track: P

### C244実行前freeze v1 — CLI/guest実行0

START: [6652073190](https://github.com/wakairo/NewLang_Compiler/issues/1182#issuecomment-6652073190)。固定PR1180 bb8b33c/tree d8fd0b0、既測CLI SHA256 d7e2eb6d…、原FIRST/raw/bundle/refs不変。別local領域だけに資料を作成しました。

- **4正例／3負例／1既存control**。まず各sourceの通常CLI CHECKを一度だけ実行し、拒否sourceはC17/native matrixへ進めません。
- 予測: 01/02/04はloop source envelopeのordinary call拒否→registration/ADD precision。03 helper単体は既存unknown-usize predicate callを通過、90/91/92はそれぞれresult/actual/arm type拒否。
- canonicalの正例期待値と、現在のcompilerに対する拒否予測は別です。coverage拒否を正例の言語的成功には数えません。
- 既存P1117 observerを01（registration/rollback/no-owner）と03（実CHECK-owned/current consumer）にだけ再利用。C243 IF専用safety binaryへhelperを強制入力せず、新build0。
- C17が通り目視確認できた03だけ、strict GCC13/Clang23 O0/O2のraw/passive各4＝**guest計8予定（上限32）**。passive instrumentationは実引数0/2/5と実u8結果53/149/149を観測し、元Cのreturn値をそのまま返します。controlのnative既知成功は反復しません。
- Production/compiler/test-framework/workflow変更、compiler build、full regression、SDK、branch/push/PR/Actions/CI0。R入力・報告参照0。予測外結果／安全性疑義は原結果を保全してaffected STOP、PR1180 material findingを優先。

freeze manifest SHA256 **d277b5d36a26254c0d7c86f95c822b6dae9dcd4dc0d2197389a03f67a21cdace**  
oracle-v1 SHA256 **f491cda4df11a085593a485716e20917c062c70c9c430d73707eeaed9b6f7b19**  
実行前archive SHA256 **eaeff50d2be34e071a048e6254c453869f0b19ac8cf65be9948e2ab07d89652a**（/workspace/p1182-c244-checkpoint/prefreeze-v1.zip）

<details><summary>完全source（既存controlを含む8件）</summary>

#### 01-helper-loop.nl

```text
struct PhaseCell { live:u8, peer:u8 }
fn select_phase(phase:usize)->u8 {
 if(phase < usize(2)){u8(53)}else{u8(149)}
}
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(5)){
   let incoming=select_phase(cursor);
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

#### 02-helper-alias-loop.nl

```text
struct PhaseCell { live:u8, peer:u8 }
fn select_other(phase:usize)->u8 {
 let selected=if(phase == usize(3)){u8(87)}else{u8(202)};
 let copied=selected;
 copied
}
fn main()->unit {
 let original=PhaseCell{live:u8(158),peer:u8(34)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(8)){
   let incoming=select_other(cursor);
   let chosen=incoming;
   let forwarded=chosen;
   let old=loan_write(original@peer){|writer|replace(writer,forwarded)};
   let old_copy=old;
   old_copy;
   let during=original@peer;
   let beside=original@live;
   during;
   beside;
   continue(cursor + usize(2));
  }else{break cursor;}
 };
 let final=original@peer;
 let peer=original@live;
 let copied=result;
 unit
}
```

#### 03-helper-only.nl

```text
fn select_phase(phase:usize)->u8 {
 let selected=if(phase < usize(2)){u8(53)}else{u8(149)};
 let forwarded=selected;
 forwarded
}
fn main()->unit {
 let before=select_phase(usize(0));
 let boundary=select_phase(usize(2));
 let after=select_phase(usize(5));
 return unit;
}
```

#### 04-constant-helper-loop.nl

```text
struct PhaseCell { live:u8, peer:u8 }
fn constant_phase(phase:usize)->u8 {u8(61)}
fn main()->unit {
 let original=PhaseCell{live:u8(91),peer:u8(17)};
 let result=loop(cursor=usize(3)){
  if(cursor < usize(4)){
   let incoming=constant_phase(cursor);
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(2));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

#### 80-inline-control.nl

```text
struct PhaseCell { live:u8, peer:u8 }
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(5)){
   let incoming=if(cursor < usize(2)){u8(53)}else{u8(149)};
   let old=loan_write(original@live){|writer|replace(writer,incoming)};
   let old_copy=old;
   old_copy;
   let during=original@live;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@live;
 let peer=original@peer;
 let copied=result;
 unit
}
```

#### 90-wrong-result.nl

```text
struct PhaseCell { live:u8, peer:u8 }
fn bad_result(phase:usize)->usize {phase}
fn main()->unit {
 let original=PhaseCell{live:u8(26),peer:u8(211)};
 let incoming=bad_result(usize(0));
 let old=loan_write(original@live){|writer|replace(writer,incoming)};
 unit
}
```

#### 91-wrong-actual.nl

```text
fn select_phase(phase:usize)->u8 {
 if(phase < usize(2)){u8(53)}else{u8(149)}
}
fn main()->unit {
 let incoming=select_phase(u8(1));
 unit
}
```

#### 92-arm-type.nl

```text
fn bad_arm(phase:usize)->u8 {
 if(phase < usize(2)){u8(53)}else{usize(149)}
}
fn main()->unit {
 let incoming=bad_arm(usize(0));
 unit
}
```

</details>

<details><summary>完全oracle・期待値・予測層</summary>

```json
{
  "authority": "C244 Issue1182, CURRENT_SPEC -> Draft17.34",
  "base": "bb8b33cefc030ed99941c9c93fef9c7ef89b0ac0",
  "tree": "d8fd0b0a95184d3449d7e1525ba56574429dbf8f",
  "scope": "Gate0 only; canonical expected behavior and current-implementation predictions are separate",
  "budget": {
    "positives": 4,
    "negatives": 3,
    "controls": 1,
    "guest_maximum": 32,
    "planned_guest": 8,
    "compiler_builds": 0,
    "production_changes": 0,
    "remote_push_pr_ci": 0
  },
  "execution": "one CLI CHECK per source; emit only CHECK-passed source; existing probe only 01 and 03; inspect emitted C before helper-only native; do not matrix-repeat refused loops",
  "cases": {
    "01-helper-loop": {
      "category": "positive",
      "language_valid": true,
      "question": "actual loop phase -> pure helper normal u8 -> binding -> original live replace",
      "current_prediction": {
        "check": 3,
        "first_layer": "registration CHECK: call excluded by current_source_shape; predicted ADD precision"
      },
      "probe": true,
      "expected": {
        "phases": [
          0,
          1,
          2,
          3,
          4,
          5
        ],
        "helper_args": [
          0,
          1,
          2,
          3,
          4
        ],
        "incoming": [
          53,
          53,
          149,
          149,
          149
        ],
        "old": [
          26,
          53,
          53,
          149,
          149
        ],
        "final": 149,
        "sibling": 211,
        "loop_result": 5,
        "physical_original": "same original/selected child"
      }
    },
    "03-helper-only": {
      "category": "positive",
      "language_valid": true,
      "question": "existing independent pure usize/u8 helper, formal unknown -> IF -> binding/Copy normal result",
      "current_prediction": {
        "check": 0,
        "emit": 0,
        "first_layer": "existing source/owned/current/C17 expected to admit"
      },
      "probe": true,
      "expected": {
        "helper_args": [
          0,
          2,
          5
        ],
        "helper_results": [
          53,
          149,
          149
        ],
        "native_exit": 0,
        "proves_loop_transfer": false
      }
    },
    "02-helper-alias-loop": {
      "category": "positive",
      "language_valid": true,
      "question": "EQ helper and ordinary result Copy aliases -> peer field of original",
      "current_prediction": {
        "check": 3,
        "first_layer": "registration CHECK; same source call envelope"
      },
      "expected": {
        "phases": [
          1,
          3,
          5,
          7,
          9
        ],
        "helper_args": [
          1,
          3,
          5,
          7
        ],
        "incoming": [
          202,
          87,
          202,
          202
        ],
        "old": [
          34,
          202,
          87,
          202
        ],
        "final": 202,
        "sibling": 158,
        "loop_result": 9,
        "physical_original": "same original/selected child"
      }
    },
    "04-constant-helper-loop": {
      "category": "positive",
      "language_valid": true,
      "question": "narrow literal-result helper still needs actual call producer transfer",
      "current_prediction": {
        "check": 3,
        "first_layer": "registration CHECK; call excluded even with literal helper body"
      },
      "expected": {
        "phases": [
          3,
          5
        ],
        "helper_args": [
          3
        ],
        "incoming": [
          61
        ],
        "old": [
          91
        ],
        "final": 61,
        "sibling": 17,
        "loop_result": 5
      }
    },
    "90-wrong-result": {
      "category": "negative",
      "language_valid": false,
      "question": "usize result cannot replace u8 field",
      "current_prediction": {
        "check": 3,
        "first_layer": "type mismatch, without a loop masking the refusal"
      }
    },
    "91-wrong-actual": {
      "category": "negative",
      "language_valid": false,
      "question": "u8 actual cannot substitute usize formal",
      "current_prediction": {
        "check": 3,
        "first_layer": "argument type mismatch"
      }
    },
    "92-arm-type": {
      "category": "negative",
      "language_valid": false,
      "question": "u8 and usize arms cannot produce one normal u8 result",
      "current_prediction": {
        "check": 3,
        "first_layer": "IF result type mismatch"
      }
    },
    "80-inline-control": {
      "category": "existing-control",
      "language_valid": true,
      "current_prediction": {
        "check": 0,
        "emit": 0
      },
      "c17_sha256": "c61b72bdbb136e2a29465498cea658a31893103e2ae8cbf97ff6664461425cae",
      "native": "reuse measured C243 control; no repeated guest"
    }
  },
  "stop": "unexpected status or safety/ownership doubt -> preserve and affected STOP; C material finding takes priority"
}
```

</details>

<details><summary>実行前manifest（source/oracle/観測器/binary SHA）</summary>

```json
{
  "authority": "C244 Issue1182, CURRENT_SPEC -> Draft17.34",
  "base": "bb8b33cefc030ed99941c9c93fef9c7ef89b0ac0",
  "tree": "d8fd0b0a95184d3449d7e1525ba56574429dbf8f",
  "live_main_at_start": "11d4d078c2a9deb68b77c428bba079431dee72fc",
  "compiler": "/tmp/p1176-build/newlangc",
  "compiler_sha256": "d7e2eb6db69b7784125cd85acf74cf451f73edcb830e5bba1556b44a8eb92ef7",
  "probe": "/tmp/p1176-build/p1117_probe",
  "probe_sha256": "ac4bd5e30ac6a6ad10ac7ae3ca68c2023990274e1b6394c16e0cd940286282f8",
  "probe_source_sha256": "232007fcdb72cfd22d0a75ad9372f45398c9e708618cb200f772e0c0731f4777",
  "files": {
    "sources/01-helper-loop.nl": "31873ab92f0497a1c00d519d030a9efcb5091c512a0e805451600159fc44e664",
    "sources/02-helper-alias-loop.nl": "3dc95818db2994cbea12b2563042bf482e45b3545d3ec7fa84c3ec6465259a1b",
    "sources/03-helper-only.nl": "149494374b7f55e224f112d191766079eeb6cbd51617742315ea7223213199be",
    "sources/04-constant-helper-loop.nl": "a3a15bfd79425292ab8bd6b1f2163c384c0abb74b3b1062e58d7273af264c6fc",
    "sources/80-inline-control.nl": "b44db6b770275cc386e3f8a788b28936c5e21285c002635f1bddd9125398d279",
    "sources/90-wrong-result.nl": "557851d6929b90bf93cb4d1a47dbafd8fa5834d61f34e7955931ebe9b1b347b6",
    "sources/91-wrong-actual.nl": "ea06887e31373212525a371631d7970f317ededdca4b0ce699cc91e1dd482159",
    "sources/92-arm-type.nl": "f58e3f5dcb4e0a58299e2828ac01cfe0a42393b64856a009cf5413071886d635",
    "oracle-v1.json": "f491cda4df11a085593a485716e20917c062c70c9c430d73707eeaed9b6f7b19",
    "observe.py": "c6ccbd0f2a0864bb4b6cd83e677f73be1d6456a7f09f9142c146c8f6f802ae21"
  }
}
```

</details>

<details><summary>凍結したlocal観測器全文（Production/test-framework変更なし）</summary>

```python
"""C244 local Gate0; no compiler build or repository mutation."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
p=Path(__file__).resolve().parent
raw=p/'raw';raw.mkdir(exist_ok=True)
freeze=json.loads((p/'freeze-v1.json').read_text())
for name,digest in freeze['files'].items():
    assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest,name
compiler=Path('/tmp/p1176-build/newlangc')
probe=Path('/tmp/p1176-build/p1117_probe')
assert hashlib.sha256(compiler.read_bytes()).hexdigest()==freeze['compiler_sha256']
assert hashlib.sha256(probe.read_bytes()).hexdigest()==freeze['probe_sha256']
oracle=json.loads((p/'oracle-v1.json').read_text())
rows=json.loads((raw/'observations.json').read_text()) if (raw/'observations.json').exists() else []
def run(cmd,label,category):
    assert not any(x['label']==label for x in rows),label
    result=subprocess.run(list(map(str,cmd)),capture_output=True,timeout=90)
    (raw/(label+'.out')).write_bytes(result.stdout)
    (raw/(label+'.err')).write_bytes(result.stderr)
    row={'label':label,'category':category,'command':list(map(str,cmd)),
         'status':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),
         'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()}
    rows.append(row);(raw/'observations.json').write_text(json.dumps(rows,indent=2)+'\n')
    if category=='cli-check' and result.returncode and not (raw/'FIRST.json').exists():
        (raw/'FIRST.json').write_text(json.dumps(row,indent=2)+'\n')
    print(label,result.returncode,flush=True)
    return result
def require(ok,label):
    if not ok:
        (raw/'UNEXPECTED-STOP.json').write_text(json.dumps({'label':label,'last':rows[-1] if rows else None},indent=2)+'\n')
        raise AssertionError(label)
mode=sys.argv[1]
if mode=='cli':
    for name,case in oracle['cases'].items():
        source=p/'sources'/(name+'.nl')
        checked=run([compiler,'--check',source],name+'-check','cli-check')
        require(checked.returncode==case['current_prediction']['check'] and not checked.stdout,name+' check prediction')
        if case.get('probe'):
            observed=run([probe,source],name+'-owned','existing-owned-observer')
            require(observed.returncode==0,name+' probe exit')
            if checked.returncode:
                require(re.search(rb'registration=[1-9][0-9]* unchanged=1 no_owner=1',observed.stdout) is not None,name+' rollback/no-owner')
            else:
                require(b'actual invocation=0 owner=1' in observed.stdout and b'actual checked consumer=1' in observed.stdout and b'bool_known=0 node_known=0' in observed.stdout,name+' genuine/unknown formal/current consumer')
        if checked.returncode:
            continue
        emitted=run([compiler,source],name+'-c17','cli-c17')
        require(emitted.returncode==case['current_prediction']['emit'],name+' emit prediction')
        require(bool(emitted.stdout)==(emitted.returncode==0),name+' output boundary')
        if case.get('c17_sha256'):
            require(hashlib.sha256(emitted.stdout).hexdigest()==case['c17_sha256'],name+' unchanged control C17')
        if not emitted.returncode:
            (raw/(name+'.c17')).write_bytes(emitted.stdout)
    print('C244 frozen boundary predictions checked; refused legal loops remain unsupported',flush=True)
elif mode=='native':
    case=oracle['cases']['03-helper-only']
    original=(raw/'03-helper-only.c17').read_text()
    header='''#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static const size_t c244_args[]={0,2,5};
static const unsigned c244_values[]={53,149,149};
static size_t c244_entered,c244_returned;
static void c244_finish(void) { assert(c244_entered==3 && c244_returned==3); puts("C244 actual helper results PASS"); }
static void c244_input(size_t arg) { assert(c244_entered==c244_returned && c244_entered<3); assert(arg==c244_args[c244_entered]); if(!c244_entered) assert(atexit(c244_finish)==0); ++c244_entered; }
static uint8_t c244_output(uint8_t value) { assert(c244_returned+1==c244_entered); assert(value==c244_values[c244_returned]); printf("C244 phase=%zu result=%u\\n",c244_args[c244_returned],(unsigned)value); ++c244_returned; return value; }
'''
    pattern=r'(static uint8_t nl_fn_\d+\((?:const )?size_t (nl_local_\d+)\)\n\{\n)(.*?)(^\})'
    def passive(m):
        body,count=re.subn(r'\breturn ([^;\n]+);',r'return c244_output(\1);',m[3])
        require(count==1,'one normal helper return')
        return m[1]+'    c244_input('+m[2]+');\n'+body+m[4]
    observed,count=re.subn(pattern,passive,original,flags=re.S|re.M)
    require(count==1,'one ordinary usize/u8 emitted function')
    observed=observed.replace('#include <stdint.h>','#include <stdint.h>\n#include <stddef.h>\n'+header,1)
    for variant,text in [('raw',original),('passive',observed)]:
        c=raw/('03-helper-only-'+variant+'.c');c.write_text(text)
        for cc in [Path('/workspace/p1030-validation-tools/usr/bin/gcc-13'),Path('/workspace/p965/.deps/toolchains/ubuntu-24.04-x86_64-7c9921be7919a10d/newlang-llvm-23.1.3-linux-x64/bin/clang')]:
            for opt in ['-O0','-O2']:
                label='03-'+variant+'-'+cc.name+'-'+opt[1:]
                exe=raw/(label+'.exe')
                built=run([cc,'-std=c17','-Wall','-Wextra','-Wpedantic','-Werror',opt,c,'-o',exe],label+'-build','guest-compile')
                require(built.returncode==0,label+' strict build')
                require(sum(x['category']=='guest' for x in rows)<32,'guest budget')
                native=run([exe],label+'-native','guest')
                require(native.returncode==0 and not native.stderr,label+' native')
                if variant=='passive':require(b'C244 actual helper results PASS' in native.stdout,label+' actual values')
                exe.unlink()
    print('C244 helper-only strict native PASS; no loop helper transfer claim',flush=True)
else:
    raise ValueError(mode)

```

</details>

このfreezeはhelper-loop受理や追加context/OOM費用を実測済みとするものではありません。旧+5/7158を新差分の根拠に流用せず、技術境界・推論・未実施・VALUE-ALIGNMENT-RISKをFINALで分けます。
