/* North Star V0/V1/AVS Checked-C reference output. */
#include <stdint.h>
#include <stddef.h>
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static const size_t c244_args[]={0,2,5};
static const unsigned c244_values[]={53,149,149};
static size_t c244_entered,c244_returned;
static void c244_finish(void) { assert(c244_entered==3 && c244_returned==3); puts("C244 actual helper results PASS"); }
static void c244_input(size_t arg) { assert(c244_entered==c244_returned && c244_entered<3); assert(arg==c244_args[c244_entered]); if(!c244_entered) assert(atexit(c244_finish)==0); ++c244_entered; }
static uint8_t c244_output(uint8_t value) { assert(c244_returned+1==c244_entered); assert(value==c244_values[c244_returned]); printf("C244 phase=%zu result=%u\n",c244_args[c244_returned],(unsigned)value); ++c244_returned; return value; }


#include <limits.h>
_Static_assert(CHAR_BIT == 8, "NewLang C17 requires 8-bit bytes");
_Static_assert(UINT8_MAX == 255 && sizeof(uint8_t) == 1 && ((uint8_t)-1) == 255, "NewLang C17 requires exact 8-bit uint8_t");
#include <stddef.h>
_Static_assert(SIZE_MAX == UINTMAX_C(18446744073709551615), "NewLang usize target mismatch");

static void nl_fn_10(void);
static uint8_t nl_fn_11(size_t nl_local_1);

static void nl_fn_10(void)
{
    const uint8_t nl_call_2 = nl_fn_11(((size_t)UINTMAX_C(0)));
    (void)nl_call_2;
    const uint8_t nl_local_4 = nl_call_2;
    (void)nl_local_4;
    const uint8_t nl_call_6 = nl_fn_11(((size_t)UINTMAX_C(2)));
    (void)nl_call_6;
    const uint8_t nl_local_8 = nl_call_6;
    (void)nl_local_8;
    const uint8_t nl_call_10 = nl_fn_11(((size_t)UINTMAX_C(5)));
    (void)nl_call_10;
    const uint8_t nl_local_12 = nl_call_10;
    (void)nl_local_12;
    (void)0;
    return;
}

static uint8_t nl_fn_11(size_t nl_local_1)
{
    c244_input(nl_local_1);
    (void)nl_local_1;
    const size_t nl_less_left_2 = nl_local_1;
    const size_t nl_less_right_2 = ((size_t)UINTMAX_C(2));
    const uint8_t nl_local_2 = ((nl_less_left_2 < nl_less_right_2) ? 53 : 149);
    (void)nl_local_2;
    const uint8_t nl_local_3 = nl_local_2;
    (void)nl_local_3;
    return c244_output(nl_local_3);
}

int main(void)
{
    nl_fn_10();
    return 0;
}
