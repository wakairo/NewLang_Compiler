Track: P

### C244実START — 同じ既存Codex P / Gate0のみ

同じDebian GNU/Linux13.6 x86_64環境で開始しました。調査baseは未採用の固定PR1180 **`bb8b33cefc030ed99941c9c93fef9c7ef89b0ac0`**／tree **`d8fd0b0a95184d3449d7e1525ba56574429dbf8f`**、working tree clean。実mainはAPI再取得で **`11d4d078c2a9deb68b77c428bba079431dee72fc`**。baseとmainを分け、C6651782040の既知4-file裁定を維持します。PR1180は同HEADのDRAFT/HOLDで、C/PRの連絡からmaterial findingは届いていません。

既測GCC Debug CLI **`/tmp/p1176-build/newlangc`** のSHA256は **`d7e2eb6db69b7784125cd85acf74cf451f73edcb830e5bba1556b44a8eb92ef7`**。P1176原 `final-C17-continuity.json` にあるfinal-code binary hashと一致。build cacheのsource rootは `/tmp/p1176-c243`。再buildせず利用します。既測owned/current機材 `p1176_safety` はSHA256 `00deb887d574354875582b492812d954ab439e34b65e4342faf9586a3b01b072` ですが、IF専用assertionを持つためhelperへそのまま流用できるとは扱いません。

原source/oracle/FIRST/RED/raw/archives/bundle/refsを不変に保持。publication bundle SHA256 `7ae8305f9f5a422bda02a82d0f4605e268df402d43602f4835863bf5d0b9793f`、first-green CI archive `5cb74460d30fc79216611617c563137c644d84dda3a768c097651a490f0f4d27` を再照合しました。別の `/tmp/p1182-c244` と `/workspace/p1182-c244-checkpoint` をGate0資料用に使い、固定branch/PR1180は変更しません。

Compass→Value Strategy §1.1／Process／Charter／Review／CURRENT_SPEC→Draft17.34のauthorityを確認中。予測は「helper単体の未知phase→normal u8と、loopの既存inline producer制約を別々に観測する必要がある」です。既存inline IF、既存call証拠のprivate再利用、より狭いhelper bodyを比較し、新しい公開issuerやUnknown/type/bits一致による権限生成は提案しません。

新source/oracle/期待値/予測層は初回実行前に別freezeしてIssueへ掲載します。最大4正例/4負例/2control、guest最大32。現時点CLI/guest実行0。**Production/compiler/test-framework/workflow変更、build、full回帰、SDK、branch/push/PR/Actions/CI0**。R入力・報告参照0、新P/Track起動0、READY/merge0。PR1180 material finding受信時はそちらを優先します。

VALUE-ALIGNMENT-RISKは技術結果と別に返却し、audit locality UNMEASURED／GO624 PAUSED／H1 HOLD／P1036–PR1050 STOPを維持します。
