"""C244 local Gate0; no compiler build or repository mutation."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
p=Path(__file__).resolve().parent
raw=p/'raw';raw.mkdir(exist_ok=True)
freeze=json.loads((p/'freeze-v1.json').read_text())
for name,digest in freeze['files'].items():
    assert hashlib.sha256((p/name).read_bytes()).hexdigest()==digest,name
compiler=Path('/tmp/p1176-build/newlangc')
probe=Path('/tmp/p1176-build/p1117_probe')
assert hashlib.sha256(compiler.read_bytes()).hexdigest()==freeze['compiler_sha256']
assert hashlib.sha256(probe.read_bytes()).hexdigest()==freeze['probe_sha256']
oracle=json.loads((p/'oracle-v1.json').read_text())
rows=json.loads((raw/'observations.json').read_text()) if (raw/'observations.json').exists() else []
def run(cmd,label,category):
    assert not any(x['label']==label for x in rows),label
    result=subprocess.run(list(map(str,cmd)),capture_output=True,timeout=90)
    (raw/(label+'.out')).write_bytes(result.stdout)
    (raw/(label+'.err')).write_bytes(result.stderr)
    row={'label':label,'category':category,'command':list(map(str,cmd)),
         'status':result.returncode,'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),
         'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()}
    rows.append(row);(raw/'observations.json').write_text(json.dumps(rows,indent=2)+'\n')
    if category=='cli-check' and result.returncode and not (raw/'FIRST.json').exists():
        (raw/'FIRST.json').write_text(json.dumps(row,indent=2)+'\n')
    print(label,result.returncode,flush=True)
    return result
def require(ok,label):
    if not ok:
        (raw/'UNEXPECTED-STOP.json').write_text(json.dumps({'label':label,'last':rows[-1] if rows else None},indent=2)+'\n')
        raise AssertionError(label)
mode=sys.argv[1]
if mode=='cli':
    for name,case in oracle['cases'].items():
        source=p/'sources'/(name+'.nl')
        checked=run([compiler,'--check',source],name+'-check','cli-check')
        require(checked.returncode==case['current_prediction']['check'] and not checked.stdout,name+' check prediction')
        if case.get('probe'):
            observed=run([probe,source],name+'-owned','existing-owned-observer')
            require(observed.returncode==0,name+' probe exit')
            if checked.returncode:
                require(re.search(rb'registration=[1-9][0-9]* unchanged=1 no_owner=1',observed.stdout) is not None,name+' rollback/no-owner')
            else:
                require(b'actual invocation=0 owner=1' in observed.stdout and b'actual checked consumer=1' in observed.stdout and b'bool_known=0 node_known=0' in observed.stdout,name+' genuine/unknown formal/current consumer')
        if checked.returncode:
            continue
        emitted=run([compiler,source],name+'-c17','cli-c17')
        require(emitted.returncode==case['current_prediction']['emit'],name+' emit prediction')
        require(bool(emitted.stdout)==(emitted.returncode==0),name+' output boundary')
        if case.get('c17_sha256'):
            require(hashlib.sha256(emitted.stdout).hexdigest()==case['c17_sha256'],name+' unchanged control C17')
        if not emitted.returncode:
            (raw/(name+'.c17')).write_bytes(emitted.stdout)
    print('C244 frozen boundary predictions checked; refused legal loops remain unsupported',flush=True)
elif mode=='native':
    case=oracle['cases']['03-helper-only']
    original=(raw/'03-helper-only.c17').read_text()
    header='''#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static const size_t c244_args[]={0,2,5};
static const unsigned c244_values[]={53,149,149};
static size_t c244_entered,c244_returned;
static void c244_finish(void) { assert(c244_entered==3 && c244_returned==3); puts("C244 actual helper results PASS"); }
static void c244_input(size_t arg) { assert(c244_entered==c244_returned && c244_entered<3); assert(arg==c244_args[c244_entered]); if(!c244_entered) assert(atexit(c244_finish)==0); ++c244_entered; }
static uint8_t c244_output(uint8_t value) { assert(c244_returned+1==c244_entered); assert(value==c244_values[c244_returned]); printf("C244 phase=%zu result=%u\\n",c244_args[c244_returned],(unsigned)value); ++c244_returned; return value; }
'''
    pattern=r'(static uint8_t nl_fn_\d+\((?:const )?size_t (nl_local_\d+)\)\n\{\n)(.*?)(^\})'
    def passive(m):
        body,count=re.subn(r'\breturn ([^;\n]+);',r'return c244_output(\1);',m[3])
        require(count==1,'one normal helper return')
        return m[1]+'    c244_input('+m[2]+');\n'+body+m[4]
    observed,count=re.subn(pattern,passive,original,flags=re.S|re.M)
    require(count==1,'one ordinary usize/u8 emitted function')
    observed=observed.replace('#include <stdint.h>','#include <stdint.h>\n#include <stddef.h>\n'+header,1)
    for variant,text in [('raw',original),('passive',observed)]:
        c=raw/('03-helper-only-'+variant+'.c');c.write_text(text)
        for cc in [Path('/workspace/p1030-validation-tools/usr/bin/gcc-13'),Path('/workspace/p965/.deps/toolchains/ubuntu-24.04-x86_64-7c9921be7919a10d/newlang-llvm-23.1.3-linux-x64/bin/clang')]:
            for opt in ['-O0','-O2']:
                label='03-'+variant+'-'+cc.name+'-'+opt[1:]
                exe=raw/(label+'.exe')
                built=run([cc,'-std=c17','-Wall','-Wextra','-Wpedantic','-Werror',opt,c,'-o',exe],label+'-build','guest-compile')
                require(built.returncode==0,label+' strict build')
                require(sum(x['category']=='guest' for x in rows)<32,'guest budget')
                native=run([exe],label+'-native','guest')
                require(native.returncode==0 and not native.stderr,label+' native')
                if variant=='passive':require(b'C244 actual helper results PASS' in native.stdout,label+' actual values')
                exe.unlink()
    print('C244 helper-only strict native PASS; no loop helper transfer claim',flush=True)
else:
    raise ValueError(mode)
