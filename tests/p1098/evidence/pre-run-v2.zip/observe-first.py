import pathlib, subprocess, json, sys, hashlib
root=pathlib.Path(__file__).parent
out=pathlib.Path(sys.argv[2]); out.mkdir(exist_ok=True)
oracle=json.loads((root/'oracle-v1.json').read_text())
results=[]
for name,c in oracle['cases'].items():
 for mode in ('check','c17'):
  cmd=[sys.argv[1]]+(['--check'] if mode=='check' else [])+[str(root/(name+'.nl'))]
  p=subprocess.run(cmd,capture_output=True)
  stem=out/(name+'-'+mode)
  stem.with_suffix('.stdout').write_bytes(p.stdout);stem.with_suffix('.stderr').write_bytes(p.stderr)
  row={'case':name,'mode':mode,'command':cmd,'returncode':p.returncode,'stdout_bytes':len(p.stdout),'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr':p.stderr.decode(errors='replace')}
  results.append(row)
  (out/'FIRST.json').write_text(json.dumps(results,indent=2)+'\n')
  expected=c['check' if mode=='check' else 'parent_c17']
  print(name,mode,p.returncode,len(p.stdout),flush=True)
  if p.returncode!=expected: raise SystemExit('FIRST unexpected observation; saved; STOP candidate')
