/* North Star V0/V1/AVS Checked-C reference output. */
#include <stdint.h>

#include <limits.h>
_Static_assert(CHAR_BIT == 8, "NewLang C17 requires 8-bit bytes");
_Static_assert(UINT8_MAX == 255 && sizeof(uint8_t) == 1 && ((uint8_t)-1) == 255, "NewLang C17 requires exact 8-bit uint8_t");
typedef struct { uint8_t f0; uint8_t f1; } nl_type_10;

#ifdef NEWLANG_LOOP_OBSERVER
#include NEWLANG_LOOP_OBSERVER
#endif
#ifndef NL_LOOP_BIND
#define NL_LOOP_BIND(...) ((void)0)
#endif
#ifndef NL_LOOP_READ
#define NL_LOOP_READ(...) ((void)0)
#endif
#ifndef NL_LOOP_BEFORE
#define NL_LOOP_BEFORE(...) ((void)0)
#endif
#ifndef NL_LOOP_AFTER
#define NL_LOOP_AFTER(...) ((void)0)
#endif

static void nl_fn_10(void);

static void nl_fn_10(void)
{
    const nl_type_10 nl_local_1 = { .f0 = 117, .f1 = 206, };
    (void)nl_local_1;
    NL_LOOP_BIND(&nl_local_1.f0, &nl_local_1.f1);
    const nl_type_10 nl_local_2 = { .f1 = 73, .f0 = 189, };
    (void)nl_local_2;
    NL_LOOP_BIND(&nl_local_2.f0, &nl_local_2.f1);
    NL_LOOP_BEFORE(&nl_local_2.f0, &nl_local_2.f1, 0);
    const uint8_t nl_local_4 = nl_local_2.f0;
    nl_local_2.f0 = 28;
    NL_LOOP_AFTER(&nl_local_2.f0, &nl_local_2.f1, 0, nl_local_4);
    (void)nl_local_4;
    const uint8_t nl_local_5 = nl_local_4;
    (void)nl_local_5;
    const uint8_t nl_local_6 = nl_local_1.f0;
    (void)nl_local_6;
    NL_LOOP_READ(&nl_local_1.f0, nl_local_6);
    const uint8_t nl_local_7 = nl_local_1.f1;
    (void)nl_local_7;
    NL_LOOP_READ(&nl_local_1.f1, nl_local_7);
    const uint8_t nl_local_8 = nl_local_2.f0;
    (void)nl_local_8;
    NL_LOOP_READ(&nl_local_2.f0, nl_local_8);
    const uint8_t nl_local_9 = nl_local_2.f1;
    (void)nl_local_9;
    NL_LOOP_READ(&nl_local_2.f1, nl_local_9);
    (void)0;
    return;
}

int main(void)
{
    nl_fn_10();
    return 0;
}
