from pathlib import Path
import subprocess,hashlib,json
r=Path(__file__).parent
freeze=json.loads((r/'freeze.json').read_bytes())
for name,expected in freeze['files'].items():assert hashlib.sha256((r/name).read_bytes()).hexdigest()==expected
compilers=['/usr/bin/gcc','/workspace/p965/.deps/toolchains/ubuntu-24.04-x86_64-7c9921be7919a10d/newlang-llvm-23.1.3-linux-x64/bin/clang-23']
rows=[]
for source in sorted((r/'inputs').glob('*.c')):
 for cc in compilers:
  for opt in ('-O0','-O2'):
   stem=source.stem+'-'+Path(cc).name+opt
   exe=r/'runs'/stem
   cmd=[cc,'-std=c17','-Wall','-Wextra','-Wpedantic','-Werror',opt,'-DNEWLANG_LOOP_OBSERVER="'+str(source.with_suffix('.h'))+'"',str(source),'-o',str(exe)]
   if 'clang' in Path(cc).name:cmd.insert(1,'-Wno-error=gcc-install-dir-libstdcxx')
   build=subprocess.run(cmd,capture_output=True)
   row={'source':source.name,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'command':cmd,'compile_status':build.returncode,'compile_stderr':build.stderr.decode(errors='replace')}
   rows.append(row);(r/'FIRST.json').write_text(json.dumps(rows,indent=2)+'\n');assert build.returncode==0,row
   native=subprocess.run([str(exe)],capture_output=True)
   (r/'runs'/(stem+'.stdout')).write_bytes(native.stdout);(r/'runs'/(stem+'.stderr')).write_bytes(native.stderr)
   row.update({'native_status':native.returncode,'stdout':native.stdout.decode(errors='replace'),'stderr':native.stderr.decode(errors='replace')});(r/'FIRST.json').write_text(json.dumps(rows,indent=2)+'\n')
   assert native.returncode==0 and not native.stderr and b'PASS' in native.stdout,row
   print(stem,native.stdout.decode().strip(),flush=True)
print('P1098 raw native traces COMPLETE',len(rows))
