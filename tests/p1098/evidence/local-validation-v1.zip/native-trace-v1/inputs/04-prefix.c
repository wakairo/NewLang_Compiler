/* North Star V0/V1/AVS Checked-C reference output. */
#include <stdint.h>

#include <limits.h>
_Static_assert(CHAR_BIT == 8, "NewLang C17 requires 8-bit bytes");
_Static_assert(UINT8_MAX == 255 && sizeof(uint8_t) == 1 && ((uint8_t)-1) == 255, "NewLang C17 requires exact 8-bit uint8_t");
typedef struct { uint8_t f0; uint8_t f1; } nl_type_10;

#ifdef NEWLANG_LOOP_OBSERVER
#include NEWLANG_LOOP_OBSERVER
#endif
#ifndef NL_LOOP_BIND
#define NL_LOOP_BIND(...) ((void)0)
#endif
#ifndef NL_LOOP_READ
#define NL_LOOP_READ(...) ((void)0)
#endif
#ifndef NL_LOOP_BEFORE
#define NL_LOOP_BEFORE(...) ((void)0)
#endif
#ifndef NL_LOOP_AFTER
#define NL_LOOP_AFTER(...) ((void)0)
#endif

static void nl_fn_10(void);

static void nl_fn_10(void)
{
    nl_type_10 nl_local_1 = { .f0 = 21, .f1 = 176, };
    (void)nl_local_1;
    NL_LOOP_BIND(&nl_local_1.f0, &nl_local_1.f1);
    uint8_t nl_loan_result_1;
    {
        uint8_t *const nl_local_2 = &nl_local_1.f0;
        (void)nl_local_2;
        const uint8_t nl_replace_old_11 = *nl_local_2;
        *nl_local_2 = 88;
        nl_loan_result_1 = nl_replace_old_11;
    }
    (void)nl_loan_result_1;
    const uint8_t nl_local_3 = nl_loan_result_1;
    (void)nl_local_3;
    NL_LOOP_BEFORE(&nl_local_1.f0, &nl_local_1.f1, 1);
    const uint8_t nl_local_6 = nl_local_1.f1;
    nl_local_1.f1 = 244;
    NL_LOOP_AFTER(&nl_local_1.f0, &nl_local_1.f1, 1, nl_local_6);
    (void)nl_local_6;
    uint8_t nl_loan_result_3;
    {
        uint8_t *const nl_local_7 = &nl_local_1.f0;
        (void)nl_local_7;
        const uint8_t nl_replace_old_21 = *nl_local_7;
        *nl_local_7 = nl_local_6;
        nl_loan_result_3 = nl_replace_old_21;
    }
    (void)nl_loan_result_3;
    const uint8_t nl_local_8 = nl_loan_result_3;
    (void)nl_local_8;
    const uint8_t nl_local_9 = nl_local_1.f0;
    (void)nl_local_9;
    NL_LOOP_READ(&nl_local_1.f0, nl_local_9);
    const uint8_t nl_local_10 = nl_local_1.f1;
    (void)nl_local_10;
    NL_LOOP_READ(&nl_local_1.f1, nl_local_10);
    (void)0;
    return;
}

int main(void)
{
    nl_fn_10();
    return 0;
}
