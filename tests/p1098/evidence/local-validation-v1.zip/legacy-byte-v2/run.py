from pathlib import Path
import subprocess,json,hashlib,sys
r=Path(sys.argv[1]);base,candidate=sys.argv[2:]
d=Path(__file__).parent
frozen=json.loads((d/'freeze.json').read_bytes())
results=[]
for name,expected in frozen['sources'].items():
 p=r/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==expected
 a=subprocess.run([base,str(p)],capture_output=True)
 b=subprocess.run([candidate,str(p)],capture_output=True)
 row={'source':name,'baseline_status':a.returncode,'candidate_status':b.returncode,'baseline_bytes':len(a.stdout),'candidate_bytes':len(b.stdout),'baseline_sha256':hashlib.sha256(a.stdout).hexdigest(),'candidate_sha256':hashlib.sha256(b.stdout).hexdigest(),'match':a.returncode==b.returncode and a.stdout==b.stdout}
 results.append(row);(d/'FIRST.json').write_text(json.dumps(results,indent=2)+'\n')
 assert row['match'],row
 print(name,a.returncode,len(a.stdout),'byte-identical',flush=True)
print('legacy byte stability',len(results),'profiles; successful outputs',sum(x['baseline_status']==0 for x in results))
