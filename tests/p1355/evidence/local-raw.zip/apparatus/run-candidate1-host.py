import pathlib,subprocess,json,hashlib,os,sys
R=pathlib.Path('/workspace/p1355-c640');S=R/'repo';host=sys.argv[1];mode={'gcc':'none','asan':'address','ubsan':'undefined'}[host]
CMAKE='/workspace/p1236-c291/tools/cmake/cmake/data/bin/cmake';SDK='/workspace/p1236-c291/sdk/.deps/toolchains/ubuntu-24.04-x86_64-7c9921be7919a10d/newlang-llvm-23.1.3-linux-x64'
CC='/usr/bin/gcc' if host=='gcc' else '/workspace/p1295-c439/tools/clang19/clang'
f=json.loads((R/'candidate1/preexecution-freeze.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==f['HEAD']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S)
for p,h in f['files'].items():assert hashlib.sha256((S/p).read_bytes()).hexdigest()==h
out=R/'candidate1';b=R/'builds'/host;assert not b.exists();b.parent.mkdir(exist_ok=True)
env=dict(os.environ,NEWLANG_SDK_ROOT=SDK,PATH=SDK+'/bin:'+os.environ['PATH'])
cmds=[('configure',[CMAKE,'-S',str(S),'-B',str(b),'-DCMAKE_BUILD_TYPE='+('Release' if host=='gcc' else 'Debug'),'-DCMAKE_C_COMPILER='+CC,'-DCMAKE_CXX_COMPILER=/usr/bin/g++','-DLLVM_CONFIG='+SDK+'/bin/llvm-config-23','-DNEWLANG_SANITIZER='+mode,'-DNEWLANG_FRONTEND_ONLY=OFF']),
('build',[CMAKE,'--build',str(b),'--target','newlangc','p1355_wrapper','p1332_cli_oom','--parallel','2']),
('StageA',[str(pathlib.Path(CMAKE).with_name('ctest')),'--test-dir',str(b),'-R','^p1355_.*[.]unit$','-V','--stop-on-failure','-j1'])]
(out/(host+'-commands.json')).write_text(json.dumps({'HEAD':f['HEAD'],'CC':CC,'sanitizer':mode,'commands':cmds},indent=2)+'\n')
for label,cmd in cmds:
 p=out/(host+'-'+label+'.raw')
 with p.open('xb') as log:q=subprocess.run(cmd,cwd=S,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(host,label,'status',q.returncode,flush=True)
 if q.returncode:print(p.read_text(errors='replace')[-5000:],flush=True);raise SystemExit(q.returncode)
print(host,'Stage A PASS',flush=True)
