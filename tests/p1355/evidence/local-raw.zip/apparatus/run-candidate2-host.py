import pathlib,json,subprocess,hashlib,os,sys
R=pathlib.Path('/workspace/p1355-c640');S=R/'repo';host=sys.argv[1];f=json.loads((R/'candidate2/preexecution-freeze.json').read_text());b=R/'builds'/host;out=R/'candidate2'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==f['HEAD']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S)
for p,h in f['files'].items():assert hashlib.sha256((S/p).read_bytes()).hexdigest()==h
cmake='/workspace/p1236-c291/tools/cmake/cmake/data/bin/cmake'
SDK='/workspace/p1236-c291/sdk/.deps/toolchains/ubuntu-24.04-x86_64-7c9921be7919a10d/newlang-llvm-23.1.3-linux-x64'
env=dict(os.environ,NEWLANG_SDK_ROOT=SDK,PATH=SDK+'/bin:'+os.environ['PATH'],ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
cmds=[('build',[cmake,'--build',str(b),'--target','newlangc','p1355_wrapper','p1332_cli_oom','--parallel','2']),('StageA',[str(pathlib.Path(cmake).with_name('ctest')),'--test-dir',str(b),'-R','^p1355_.*[.]unit$','-V','--stop-on-failure','-j1'])]
(out/(host+'-commands.json')).write_text(json.dumps({'HEAD':f['HEAD'],'config':'same candidate1 host config; unchanged flags','commands':cmds},indent=2)+'\n')
for label,cmd in cmds:
 p=out/(host+'-'+label+'.raw')
 with p.open('xb') as log:q=subprocess.run(cmd,cwd=S,env=env,stdout=log,stderr=subprocess.STDOUT)
 print(host,label,q.returncode,flush=True)
 if label=='build' and q.returncode==0:(out/(host+'-ELF.json')).write_text(json.dumps({'HEAD':f['HEAD'],'binary':str(b/'newlangc'),'sha256':hashlib.sha256((b/'newlangc').read_bytes()).hexdigest()},indent=2)+'\n')
 if q.returncode:print(p.read_text(errors='replace')[-5600:],flush=True);raise SystemExit(q.returncode)
print(host,'Stage A PASS',flush=True)
