P1058 parent output must survive
