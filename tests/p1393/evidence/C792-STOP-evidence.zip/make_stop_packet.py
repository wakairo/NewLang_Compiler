from pathlib import Path
import hashlib,json,subprocess,datetime,zipfile
r=Path(__file__).resolve().parent; repo=r/'repo'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
v2=Path('/workspace/p1393-c786'); frozen=json.loads((v2/'TEXT-PREP-FINAL-FREEZE.json').read_text())
for n,row in frozen['files'].items():
 b=(v2/n).read_bytes(); assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['SHA256']
assert sha(Path('/workspace/p1387-c768/FIRST.json'))=='dc39ebd1634f64bc230bd2afff5badc5cc351a0693613773aab00ea62c88a2a9'
assert sha(Path('/workspace/p1387-c768/builds/gcc/newlangc'))=='e59a35816520dbac1b4a31d0f2fd952a250e7ee827c5e2faaabbe187f55d352e'
assert not subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True)
bundle=r/'P1393-C792-STOP.bundle'; assert bundle.exists()
verify=subprocess.run(['git','bundle','verify',str(bundle)],cwd=repo,capture_output=True,text=True,check=True)
(r/'STOP-bundle-verification.txt').write_text(verify.stdout+verify.stderr)
counts={}
for h in ('gcc','asan','ubsan'):
 text=(r/'logs'/('C6-'+h+'-CTest-LastTest.raw')).read_text()
 if h!='gcc':assert 'actual selected capture+validator+emitter OOM=77 PASS' in text
 focused=json.loads((r/'logs'/('C6-'+h+'-focused.json')).read_text())
 assert focused['status']==8 # original foreign-view harness RED kept
 console=(r/'logs'/('C6-'+h+'-focused.stdout')).read_text()
 assert 'p1393_temporal_oom.unit' in console and 'Passed' in console
 q=json.loads((r/'logs'/('C7-'+h+'-owned.json')).read_text()); assert q['status']==0
 counts[h]={'OOM_unit':'PASS all77 assertions completed; original console retained','per_point_stdout':'preserved' if h!='gcc' else 'NOT_RETAINED: subsequent CTest show-only inventory replaced LastTest.log; original console result retained, not reconstructed','legacy_p1387_tests':6,'p1393_source':True,'old_owned_failure':'foreign fixture getter incorrectly required nonNULL; original failure and LSan output retained','C7_owned':q}
native=json.loads((r/'C5-native/guest-ledger.json').read_text()); assert len(native)==26 and all(x['status']==0 for x in native)
x={'time_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),'state':'STOP ACK / current operand versus historical read authentication discrepancy unresolved','Issue_STOP':'https://github.com/wakairo/NewLang_Compiler/issues/1393#issuecomment-6848310131','baseline':'7c1eab33171d7f77ea5ff49eae38481ceaa54117','canonical':'Draft17.37','HEAD':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'tree':subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=repo,text=True).strip(),'parents':subprocess.check_output(['git','show','-s','--format=%P','HEAD'],cwd=repo,text=True).strip().split(),'fixed_ledger':7,'meaningful_private_candidates':3,'host_CMake_configs':3,'diagnostic_build_note':'same GCC toolchain non-sanitized diagnostic objects at O0, not a fourth full CMake host matrix; commands retained','guest_count':26,'push_PR_CI':0,'manual':0,'main_Required6':'5 success + ASan in progress at last GET, not publication PASS','checks':counts,'material_FIRST':{'tuple':(r/'logs/C7-read-permission-FIRST.stdout').read_text(),'diagnostic_freeze_SHA256':sha(r/'C7-read-permission-diagnostic/freeze.json'),'stdout_SHA256':sha(r/'logs/C7-read-permission-FIRST.stdout'),'scope':'host metadata alteration; no poisoned native; does not establish ordinary-source UB or general unsoundness'},'not_run':['broader compiled related regressions after STOP','prospective historical adapter tests','remote publication and CI','independent F/R','raw optimized hardware load/timing observation'],'protected_v1_v2_old_FIRST_ELF':'verified unchanged','bundle':{'path':str(bundle),'bytes':bundle.stat().st_size,'SHA256':sha(bundle)},'VALUE-ALIGNMENT-RISK':'finite source capability, not Product PASS/audit locality; exact-profile proof and apparatus cost; Product GO PAUSED/H1 HOLD'}
(r/'STOP-FINAL.json').write_text(json.dumps(x,indent=2)+'\n')
files=[]
for p in sorted(r.rglob('*')):
 if not p.is_file() or repo in p.parents or r/'builds' in p.parents: continue
 if p.name.endswith(('.zip','.pyc')) or p.name in ('STOP-PACKET-MANIFEST.json','STOP-PACKET-RECEIPT.json'): continue
 with p.open('rb') as f:
  if f.read(4)==b'\x7fELF': continue
 if p.suffix=='.o':continue
 files.append(p)
manifest={str(p.relative_to(r)):{'bytes':p.stat().st_size,'SHA256':sha(p)} for p in files}
elfs={}
for h in ('gcc','asan','ubsan'):
 for n in ('newlangc','p1393_owned','p1393_probe'):
  p=r/'builds'/h/n;elfs[str(p.relative_to(r))]={'bytes':p.stat().st_size,'SHA256':sha(p)}
(r/'STOP-PACKET-MANIFEST.json').write_text(json.dumps({'files':manifest,'retained_ELFs':elfs},indent=2)+'\n')
packet=r/'P1393-C792-STOP-evidence.zip'
with zipfile.ZipFile(packet,'x',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
 for p in files:z.write(p,str(p.relative_to(r)))
 z.write(r/'STOP-PACKET-MANIFEST.json','STOP-PACKET-MANIFEST.json')
 for base in (Path('/workspace/p1391-c775'),Path('/workspace/p1393-c786')):
  for p in sorted(base.iterdir()):
   if p.is_file() and p.suffix in ('.nl','.json','.md','.patch'):z.write(p,'protected-inputs/'+base.name+'/'+p.name)
receipt={'HEAD':x['HEAD'],'tree':x['tree'],'bundle':x['bundle'],'packet':{'path':str(packet),'bytes':packet.stat().st_size,'SHA256':sha(packet)},'STOP_receipt_SHA256':sha(r/'STOP-FINAL.json'),'manifest_SHA256':sha(r/'STOP-PACKET-MANIFEST.json')}
(r/'STOP-PACKET-RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
