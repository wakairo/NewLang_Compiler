from pathlib import Path
p=Path('src/captured_closure.c');s=p.read_text()
s=s.replace('static NLCheckStatus change_validate(const NLCheckedFragment *f,\n                                     const NLCapturedChange *c)', 'static NLCheckStatus access_validate(const NLCheckedFragment *f,\n                                     const NLCapturedChange *c, bool read)')
s=s.replace('v == NULL || v->kind != NL_CHECKED_REPLACE || !v->field.present ||','v == NULL || v->kind != (read ? NL_CHECKED_LINK_READ : NL_CHECKED_REPLACE) ||\n        !v->field.present ||',1)
s=s.replace('v->field.access != NL_ACCESS_WRITE)', 'v->field.access != (read ? NL_ACCESS_READ : NL_ACCESS_WRITE))',1)
s=s.replace('v->argument_count != 2 || projection->argument_count != 1 ||\n        projected == NULL || incoming == NULL ||', 'v->argument_count != (read ? 1u : 2u) || projection->argument_count != 1 ||\n        projected == NULL || (!read && incoming == NULL) ||',1)
s=s.replace('input_id(f, v, 1) > b->value_count || projected->type == 0 ||\n        projected->type > b->type_count || input_id(f, v, 1) != e.new_value ||','(!read && input_id(f, v, 1) > b->value_count) || projected->type == 0 ||\n        projected->type > b->type_count ||\n        (!read && input_id(f, v, 1) != e.new_value) ||',1)
s=s.replace('projection->field.access != NL_ACCESS_WRITE ||', 'projection->field.access != e.access ||',1)
s=s.replace('incoming->type != e.type || v->result_count != 1 ||\n        v->results[0].value != e.old_value || v->results[0].type != e.type)', '(!read && incoming->type != e.type) || v->result_count != 1 ||\n        (!read && v->results[0].value != e.old_value) ||\n        v->results[0].type != e.type || v->results[0].value == 0 ||\n        v->results[0].value > a->value_count)',1)
s=s.replace('const NLSemanticValueView saved_incoming = b->values[input_id(f, v, 1) - 1];','const NLSemanticValueView saved_incoming =\n        read ? (NLSemanticValueView){0} : b->values[input_id(f, v, 1) - 1];',1)
s=s.replace('saved_incoming.type != incoming->type ||\n        saved_incoming.variant != incoming->variant ||\n        saved_incoming.sum_payload != incoming->sum_payload)', '(!read && (saved_incoming.type != incoming->type ||\n                   saved_incoming.variant != incoming->variant ||\n                   saved_incoming.sum_payload != incoming->sum_payload)))',1)
s=s.replace('rt.access != NL_ACCESS_WRITE || root_ref.reference_count != 0 ||','rt.access != e.access || root_ref.reference_count != 0 ||',1)
s=s.replace('!root_ref.reference.writable || !root_ref.reference.readable ||','root_ref.reference.writable != !read || !root_ref.reference.readable ||',1)
s=s.replace('nl_allocated_write_access(b, input_id(f, acquired, 0)) != NL_CHECK_OK ||','(!read && nl_allocated_write_access(b, input_id(f, acquired, 0)) !=\n                      NL_CHECK_OK) ||',1)
s=s.replace('argument_node(f, v, 1)->value_use != NL_VALUE_USE_NONE ||\n        nl_fixed_change_dependencies(b, e.child, 0) != NL_CHECK_OK)', '(!read && argument_node(f, v, 1)->value_use != NL_VALUE_USE_NONE) ||\n        (!read && nl_fixed_change_dependencies(b, e.child, 0) != NL_CHECK_OK))',1)
a='''    if (status == NL_CHECK_OK)
        status = nl_fixed_change(expected, e.child, e.new_value, false);
    if (status == NL_CHECK_OK &&
        (!nl_packet_same_entry(expected, a) ||
         a->places[e.parent - 1].current_fact != e.parent_post_fact ||
         a->places[e.child - 1].current_fact != e.child_post_fact ||
         a->places[e.child - 1].payload_occurrence !=
             e.post_payload_occurrence))
        status = INVALID;'''
b='''    if (status == NL_CHECK_OK && read) {
        NLValueId copied = 0;
        status = nl_sem_copy_value(expected, e.old_value, &copied);
        if (status == NL_CHECK_OK) {
            nl_sem_end_value(expected, input_id(f, v, 0));
            if (copied != v->results[0].value ||
                v->value_use != NL_VALUE_COPIED || e.new_value != 0 ||
                !nl_packet_same_entry(expected, a))
                status = INVALID;
        }
    } else if (status == NL_CHECK_OK) {
        status = nl_fixed_change(expected, e.child, e.new_value, false);
        if (status == NL_CHECK_OK &&
            (!nl_packet_same_entry(expected, a) ||
             a->places[e.parent - 1].current_fact != e.parent_post_fact ||
             a->places[e.child - 1].current_fact != e.child_post_fact ||
             a->places[e.child - 1].payload_occurrence !=
                 e.post_payload_occurrence))
            status = INVALID;
    }'''
assert s.count(a)==1;s=s.replace(a,b)
s=s.replace('change_validate(f, change)', 'access_validate(f, change, false)')
p.write_text(s)
