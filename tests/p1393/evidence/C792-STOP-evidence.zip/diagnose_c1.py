from pathlib import Path
import hashlib,json,shlex,subprocess
r=Path('/workspace/p1393-c792');repo=r/'repo';d=r/'C1-diagnostic';d.mkdir()
s=(repo/'src/captured_closure.c').read_text();s='#include <stdio.h>\n'+s.replace('return INVALID;','{fprintf(stderr,"C1 DIAGNOSTIC rejection at %s:%d\\n",__func__,__LINE__); return INVALID;}')
p=d/'captured_closure.c';p.write_text(s)
x={'source_commit':'347c9d925180984626f28ab3f51d6ffb8db90715','source_SHA256':hashlib.sha256((repo/'src/captured_closure.c').read_bytes()).hexdigest(),'diagnostic_only':'passive print before INVALID returns; all branches/semantics unchanged; not a production candidate or acceptance proof','diagnostic_SHA256':hashlib.sha256(p.read_bytes()).hexdigest()}
(d/'freeze.json').write_text(json.dumps(x,indent=2)+'\n')
subprocess.run(['/usr/bin/gcc','-std=c17','-O0','-Wall','-Wextra','-Wpedantic','-Werror','-I'+str(repo/'include'),'-I'+str(repo/'src'),'-c',str(p),'-o',str(d/'captured_closure.o')],check=True)
link=shlex.split((r/'builds/gcc/CMakeFiles/newlangc.dir/link.txt').read_text());link.insert(1,str(d/'captured_closure.o'));idx=link.index('-o');link[idx+1]=str(d/'newlangc')
subprocess.run(link,cwd=r/'builds/gcc',check=True)
