Track: P

## C786 TEXT PREP FINAL → STOP / implementation HARD HOLD

同じ唯一PでTEXT-PREPARATION ONLYを完了し、ここで停止します。固定採用main **feb8398e136949b765fcfd3abf086f9ccbf145d8**／tree **5cc5428eec6e92d54a081e86e3dae7049bd7a6da**／CURRENT_SPEC→Draft17.36。保持code HEAD/ref/worktreeは変更していません。

**C情報露出:** C786からbare None armの指摘を受領しました。F1392/Rを含む独立資料原文・source/oracle/fixtureは開いていません。canonical [§26.9](https://github.com/wakairo/NewLang_Compiler/blob/feb8398e136949b765fcfd3abf086f9ccbf145d8/docs/reference/NewLang_v0_spec_Draft17_36.md#269-match) の `sum_pattern => lexical_block` に照合しました。

### v1不変／別名v2の最小差分

P1391で凍結したP1/N1/N2/N3・oracle-v1・元SHA・元NOT_RUNを保全。各別名v2は **1行／1箇所のみ、`None => unit,` → `None => { unit },`**、各+4bytes。逆置換すると元bytesそのものに戻ることを確認しました。header/comment、他の全tokens/whitespace、5 allocation sites、9 Changes、C完全解放、actual A.prev→Some payload→D_B/B.next、survivor cleanup、3つの負例の意図はそのままです。

新blockにはbinding/loan/effectを追加せずunitだけを置きます。この特定構文欠陥のtext修正であり、parser PASSやsource全体の適格性・意味論上の正負結果を実測したとはしません。追加grammar要件・意味変更は今回の限定text照合では特定していません。旧v1を遡及的にsemantic負例へ再分類しません。

| v2 source | v1 SHA256 | v2 UTF-8 bytes | v2 SHA256 |
|---|---|---:|---|
| P1-C-free-current-tail-read-v2.nl | `a243312bec43dd81d55ffaf0ab4d5c94632f0364129884d5c3aa8113339802b2` | 17686 | `105fc934021586050ad875d05f251c65a30de70c34f330913bb1738022be11b4` |
| N1-saved-old-C-pointer-v2.nl | `8fd3d46e4a8c80a7f311a729f9416908a0e80b96e101bc6fe1459b44e1f6265e` | 17685 | `d07b8f532c590f8f9ef0850a6cbd4c3cf7aa2b5994bb53d384be4a15812f65ee` |
| N2-wrong-tail-domain-v2.nl | `f3e3a4e8661cf6d44ad534f6394120dbcf6b66596dcc1cc1926c54bdbf28f3a4` | 17686 | `54ff7207e93eff6dd330798b1ec7ccb8d4633152e408b75864825f7a498a6245` |
| N3-missing-survivor-B-release-v2.nl | `465a3e57ddafe78ba6c8d792f1ed64ee42e0403635c91b6ab5f7676f2ef15262` | 17722 | `873a8cec852ac81de363d1b076f7963b51816f9804a5923cd63db7a788fdc352` |

- 元oracle-v1 SHA **340a97993bc3971cadb9d4da5bf5390e17cab4ed06ab4dd2db3e2b8f96152c69**、元TEXT-FREEZE-v1 SHA **01083c7472ec78569c59aa779f460ea3df7f26a0a6d3f0500ede4412685a1d3e** は不変。
- oracle-v2 SHA **178c76aea095990a533d85fe952e5396fd24244f6a9d1fcad1b02b33ecfe57c1**。正例のcurrent B/None、N1 stale saved Some(C)、N2 wrong D_A、N3 missing B Allocation/Storage責任の予測を保持し、全observed項目はNOT_RUN。
- source差分/SHA receipt **8114480806dc1983f23fa6dc54d71f934d2a5e90303999acc903a4b7dc0749ca**。
- observer PLAN ONLY SHA **4176902be27abed109b82deb7d8cc7af548a34b0295c41bcd0d7f638856da621**。
- 最終text freeze SHA **b07159b40e91308923fe0ab04b3cb4d3b5f8ea1f9b15ba28eb155d3b28cbdcb4**。

保持先 `/workspace/p1393-c786`。元v1全文/負例差分は [P1391 FINAL](https://github.com/wakairo/NewLang_Compiler/issues/1391#issuecomment-6845597505)、新4差分とoracle/計画全文は下記appendix。これらからv2を復元できます。**旧v1へin-place適用せず、別名コピーを使用**してください。

### phase-aware observer計画（コード・機材未実装）

1. exact9後、全5 originalが生存中にqualified root/incarnation/Allocation/Domainと必要な整数addressを記録。C依存loanを全て閉じ、**C EndRoot前にtyped C slotを退役**。Cのdestroy→erase_slot→D_C finalize→元Allocation_C/full Storage_C deallocateを追い、実free完了を確認してからA.prevのsource readへ進む予測です。
2. postfreeはlive A/Bのactual field-ref／Copy resultだけを観測。実A.prev load→Option temp→実Some binder q→元D_BによるB ref→B.next loadのdef-useを静的IR/Cで追跡し、qと元B identityを別途照合。直接ptr_B、host期待Some/None、同じbitsだけの対応で置換しません。src/dstはlifecycle IDs/countersで追い、postfreeの全5 Node再走査やC field/古いSome(C) packageの値渡し・print・比較はしません。
3. **Source-semantic read／生成C def-use／raw native／passive actual memory observationを分離。** 未使用Copy readは最適化で消去・定数化・移動され得るためraw exit0を実loadの証拠にしません。源sourceやProductionにvolatile/人工的useを足しません。将来許可されたread-only hook/別TU observerが実値やlive A/B memoryを読む場合、それは観測追加による別binaryの証拠であり、raw machineで同じloadが残った証拠ではありません。現FiveにLINK_READ観測機材が実装済みともしていません。
4. B loanを閉じ、dst/B/A/srcを各一度だけ解放、Cを含む合計5。W0〜W4の旧0〜4 cleanupは不変。unsafe負例をnativeで試す案はなし。guest allocation failureとhost OOMは分け、新候補の実到達OOM/rollback/no-clobber/retryは別認可後、今回NOT_RUN。

### Gate / STOP

**TEXT PREP COMPLETE＝YES。parser/semantic CHECK/owned/C17/native/Lean/model/build/configure＝NOT_RUN、Production/登録tests/workflow/PR編集・branch/ref/worktree/commit/push/Actions/CI＝0。** 新observer/harnessの実装も0です。追加syntax/意味変更、新issuer/owner/API/ABI、未知のpostfree pointer評価、第二proof、大幅scope/costが必要ならSTOP C。

本実装は**実mainでCURRENT_SPEC→Draft17.37が実採用され、Cが本Issueに別途明示RELEASEするまでHARD HOLD**。候補PR/独立レビュー/候補CIやtext修正を実装GOと扱わず、このFINALをもってPの本作業を停止します。自己READY/merge0、Product GO PAUSED / H1 HOLD。

**VALUE-ALIGNMENT-RISK（技術結果と別）:** 構文修復は証拠準備であり製品価値の実証ではありません。cached-tail継続／appendの安全性や、十分にfactorしたC/Rustに対する作者＋safe callerのUB監査・再監査局所性優位は未実測。旧SHA世代管理・新proof機構を増やさず、必要な小さい準備で収束しました。

<details><summary>4件のv1→v2完全差分（新sourceは別名、実行0）</summary>

```diff
--- P1391-v1/N1-saved-old-C-pointer.nl
+++ P1393-C786/N1-saved-old-C-pointer-v2.nl
@@ -217,9 +217,9 @@
                                                 let p1391_read_A = ref_from_ptr(read, ptr_A, p1391_stable_A);
                                                 read(p1391_read_A@prev)
                                             };
                                             match p1386_old_A_prev {
-                                                None => unit,
+                                                None => { unit },
                                                 Some(p1391_tail_ptr) => {
                                                     let p1391_current_B_next = loan_read(life_B) { |p1391_stable_B|
                                                         let p1391_read_B = ref_from_ptr(read, p1391_tail_ptr, p1391_stable_B);
                                                         read(p1391_read_B@next)
```

```diff
--- P1391-v1/N2-wrong-tail-domain.nl
+++ P1393-C786/N2-wrong-tail-domain-v2.nl
@@ -217,9 +217,9 @@
                                                 let p1391_read_A = ref_from_ptr(read, ptr_A, p1391_stable_A);
                                                 read(p1391_read_A@prev)
                                             };
                                             match p1391_cached_tail {
-                                                None => unit,
+                                                None => { unit },
                                                 Some(p1391_tail_ptr) => {
                                                     let p1391_current_B_next = loan_read(life_A) { |p1391_stable_B|
                                                         let p1391_read_B = ref_from_ptr(read, p1391_tail_ptr, p1391_stable_B);
                                                         read(p1391_read_B@next)
```

```diff
--- P1391-v1/N3-missing-survivor-B-release.nl
+++ P1393-C786/N3-missing-survivor-B-release-v2.nl
@@ -217,9 +217,9 @@
                                                 let p1391_read_A = ref_from_ptr(read, ptr_A, p1391_stable_A);
                                                 read(p1391_read_A@prev)
                                             };
                                             match p1391_cached_tail {
-                                                None => unit,
+                                                None => { unit },
                                                 Some(p1391_tail_ptr) => {
                                                     let p1391_current_B_next = loan_read(life_B) { |p1391_stable_B|
                                                         let p1391_read_B = ref_from_ptr(read, p1391_tail_ptr, p1391_stable_B);
                                                         read(p1391_read_B@next)
```

```diff
--- P1391-v1/P1-C-free-current-tail-read.nl
+++ P1393-C786/P1-C-free-current-tail-read-v2.nl
@@ -217,9 +217,9 @@
                                                 let p1391_read_A = ref_from_ptr(read, ptr_A, p1391_stable_A);
                                                 read(p1391_read_A@prev)
                                             };
                                             match p1391_cached_tail {
-                                                None => unit,
+                                                None => { unit },
                                                 Some(p1391_tail_ptr) => {
                                                     let p1391_current_B_next = loan_read(life_B) { |p1391_stable_B|
                                                         let p1391_read_B = ref_from_ptr(read, p1391_tail_ptr, p1391_stable_B);
                                                         read(p1391_read_B@next)
```

</details>

<details><summary>oracle-v2全文（semantic予測のみ、全NOT_RUN）</summary>

```json
{
  "kind": "P1393/C786 provisional oracle-v2: lexical-block-only successor; no runtime evidence",
  "authority": {
    "main": "feb8398e136949b765fcfd3abf086f9ccbf145d8",
    "tree": "5cc5428eec6e92d54a081e86e3dae7049bd7a6da",
    "canonical": "Draft17.36; earlyfree+continuation NOT_SELECTED",
    "C_release": "C786 TEXT-PREPARATION ONLY; Draft17.37 actual main selection AND separate explicit C release required for implementation"
  },
  "source_base": {
    "U_SHA256": "63c53ae9c67653071c468f160232b24dab9f6efb1afa6386bf6357d224978f7f",
    "P1387_repo_HEAD": "0bc912d1e57b3c1a3b13173136ab35bd1bcf577e",
    "all_tree_bytes_equal_adopted_main": true,
    "v1_oracle_SHA256": "340a97993bc3971cadb9d4da5bf5390e17cab4ed06ab4dd2db3e2b8f96152c69",
    "v1_text_freeze_SHA256": "01083c7472ec78569c59aa779f460ea3df7f26a0a6d3f0500ede4412685a1d3e"
  },
  "cases": {
    "P1-C-free-current-tail-read-v2.nl": {
      "bytes": 17686,
      "SHA256": "105fc934021586050ad875d05f251c65a30de70c34f330913bb1738022be11b4",
      "source_eligibility_now": "UNSELECTED in Draft17.36; provisional only",
      "observed": {
        "parser": "NOT_RUN",
        "CHECK_definition": "NOT_RUN",
        "CHECK_actual": "NOT_RUN",
        "owned": "NOT_RUN",
        "C17": "NOT_RUN",
        "native": "NOT_RUN",
        "OOM": "NOT_RUN"
      },
      "expected_if_later_selected": {
        "cache_read": "actual current A.prev, copied Option Some(ptr_B) after C full release",
        "tail_ref": "actual Some binder p1391_tail_ptr with original D_B in fresh nonescaping loan; never substitute ptr_B",
        "B_next_read": "actual current None from event7; Copy result in Some arm, UNIT join",
        "old_values_retained": [
          "Some(C) from unlink B.next",
          "Some(C) from unlink A.prev",
          "Some(B) from unlink C.prev"
        ],
        "after_C_release": "C R/field lifetimes ended; Allocation_C+Raw_C consumed; Domain_C finalized; src/A/B/dst original identities and rights still live",
        "success_cleanup_order": [
          "C",
          "dst",
          "B",
          "A",
          "src"
        ],
        "failure_worlds": "first allocation None1..5 unchanged:0,1,2,3,4 releases; no9 writes or continuation; success5 releases",
        "expected_raw": "unit/exit0 only; no native value claim without passive read observation",
        "current_main_static_barrier": "fresh read-only ref/field-ref not authenticated by existing Change-only captured trace; Option-MATCH and C17 LINK_READ also unsupported; exact first diagnostic NOT_OBSERVED"
      },
      "parent_v1": {
        "file": "P1-C-free-current-tail-read.nl",
        "bytes": 17682,
        "SHA256": "a243312bec43dd81d55ffaf0ab4d5c94632f0364129884d5c3aa8113339802b2"
      },
      "grammar_prediction": "The identified bare-arm defect is corrected textually, NOT parser PASS or full source eligibility"
    },
    "N1-saved-old-C-pointer-v2.nl": {
      "bytes": 17685,
      "SHA256": "d07b8f532c590f8f9ef0850a6cbd4c3cf7aa2b5994bb53d384be4a15812f65ee",
      "source_eligibility_now": "UNSELECTED in Draft17.36; provisional only",
      "observed": {
        "parser": "NOT_RUN",
        "CHECK_definition": "NOT_RUN",
        "CHECK_actual": "NOT_RUN",
        "owned": "NOT_RUN",
        "C17": "NOT_RUN",
        "native": "NOT_RUN",
        "OOM": "NOT_RUN"
      },
      "principal": "stale saved event8 old Some(C) cannot be reloaned after C EndRoot/full release",
      "secondary": "D_B also cannot grant access to C; reference_live is checked before D matching. Domain_C is already consumed, so no live D_C loan is fabricated.",
      "expected_if_later_selected": "semantic liveness refusal, likely P3-STALE-POINTER if this site is reached; currently profile precision may mask it",
      "parent_v1": {
        "file": "N1-saved-old-C-pointer.nl",
        "bytes": 17681,
        "SHA256": "8fd3d46e4a8c80a7f311a729f9416908a0e80b96e101bc6fe1459b44e1f6265e"
      },
      "grammar_prediction": "The identified bare-arm defect is corrected textually, NOT parser PASS or full source eligibility"
    },
    "N2-wrong-tail-domain-v2.nl": {
      "bytes": 17686,
      "SHA256": "54ff7207e93eff6dd330798b1ec7ccb8d4633152e408b75864825f7a498a6245",
      "source_eligibility_now": "UNSELECTED in Draft17.36; provisional only",
      "observed": {
        "parser": "NOT_RUN",
        "CHECK_definition": "NOT_RUN",
        "CHECK_actual": "NOT_RUN",
        "owned": "NOT_RUN",
        "C17": "NOT_RUN",
        "native": "NOT_RUN",
        "OOM": "NOT_RUN"
      },
      "principal": "live ptr_B from actual current A.prev under D_A instead of D_B",
      "expected_if_later_selected": "semantic wrong Domain refusal, likely ALLOCATED-DOMAIN-MISMATCH if reached; not source-profile safety evidence",
      "parent_v1": {
        "file": "N2-wrong-tail-domain.nl",
        "bytes": 17682,
        "SHA256": "f3e3a4e8661cf6d44ad534f6394120dbcf6b66596dcc1cc1926c54bdbf28f3a4"
      },
      "grammar_prediction": "The identified bare-arm defect is corrected textually, NOT parser PASS or full source eligibility"
    },
    "N3-missing-survivor-B-release-v2.nl": {
      "bytes": 17722,
      "SHA256": "873a8cec852ac81de363d1b076f7963b51816f9804a5923cd63db7a788fdc352",
      "source_eligibility_now": "UNSELECTED in Draft17.36; provisional only",
      "observed": {
        "parser": "NOT_RUN",
        "CHECK_definition": "NOT_RUN",
        "CHECK_actual": "NOT_RUN",
        "owned": "NOT_RUN",
        "C17": "NOT_RUN",
        "native": "NOT_RUN",
        "OOM": "NOT_RUN"
      },
      "principal": "H5 success normal return retains original Allocation_B and full_B despite B root/domain end",
      "expected_if_later_selected": "responsibility/closure refusal; no accepted leak or native execution. Earlier profile refusal may mask the obligation.",
      "parent_v1": {
        "file": "N3-missing-survivor-B-release.nl",
        "bytes": 17718,
        "SHA256": "465a3e57ddafe78ba6c8d792f1ed64ee42e0403635c91b6ab5f7676f2ef15262"
      },
      "grammar_prediction": "The identified bare-arm defect is corrected textually, NOT parser PASS or full source eligibility"
    }
  },
  "observation_plan_only": {
    "phase_checkpoint": "after C deallocate and before cached read: C ended/freed, survivors src/A/B/dst live; witness actual read A.prev -> Some B -> scoped B ref -> B.next None",
    "physical": "no sixth allocation/reuse; root B address comes from loaded current Option payload, not name/host guess",
    "observer": "never read C fields or load/compare stale pointer packages after C EndRoot/free. Capture C address as uintptr_t while live; afterwards track integer ID/counters only. Old LIFO observer unchanged; future distinct phase-aware observer",
    "failures": "guest platform malloc failure1..5 distinct from host CHECK/validator/emitter OOM",
    "OOM": "future actual source-issued read/custody snapshots+normal arm+consumer allocation failures; status/no artifact/out length/context no-clobber/retry. NOT_RUN"
  },
  "execution_counters": {
    "compiler": 0,
    "parser": 0,
    "owned": 0,
    "C17": 0,
    "native": 0,
    "Lean": 0,
    "model": 0,
    "build": 0,
    "configure": 0,
    "branch": 0,
    "commit": 0,
    "push": 0,
    "PR": 0,
    "Actions": 0,
    "CI": 0
  },
  "stop": "source selection and execution/implementation require separate M/C authority; new owner/issuer/public ABI/second proof/generic graph solver or unsafe suspicion STOP C",
  "C_information_exposure": "C786 supplied the bare-arm grammar defect attributed to independent F1392; no F/R original materials read",
  "syntax_change": "canonical Draft17.36 section26.9 requires sum_pattern => lexical_block; replace one bare None arm by { unit } per file; block has no bindings/loans/effects",
  "semantic_predictions": "Same intended values/owners/lifetimes/negative mutations as v1. Original v1 grammar and NOT_RUN history unchanged. First real v2 refusal remains UNKNOWN until separately authorized Gate0."
}
```

</details>

<details><summary>phase-aware observer計画全文（instrumentationなし）</summary>

# C786 phase-aware observation PLAN ONLY

Authority: pinned main feb8398e136949b765fcfd3abf086f9ccbf145d8 / Draft17.36.
Early C release + cached-tail continuation remains unselected on this main.
No observer code, harness, compiler changes, build or guest execution is created here.
Future implementation and observation require adopted Draft17.37 and a separate explicit C release.

## Separate the four evidence claims

1. **Source/CHECK-owned semantic read:** after full C disposal, real LINK_READ(A.prev) produces a Copy Option, its actual Some payload q retains original B provenance, and original D_B justifies the scoped B ref and current B.next read. Check root/incarnation, field/current Fact/occurrence, Domain/loan and exact call/def-use in the real source-issued artifact. Host expected values or pointer bits are not grants.
2. **Unoptimized emitted C def-use:** inspect the exact raw C bytes for actual A.prev field load -> Option temp -> Some payload binder -> B ref/field projection -> B.next load, in correct lexical scopes and source order after C deallocation. Matching output bits or a direct named ptr_B is insufficient. A C compile is not an execution observation.
3. **Raw native:** use unchanged emitted C. An unused Copy read can be elided, folded or legally moved by O0/O2 optimization. Exit0 alone proves neither that a physical load occurred nor that it happened after free. Mark raw dynamic reads NOT_OBSERVED unless independently established under a later authorized check. Do not alter source, add volatile, inject an artificial use, weaken optimization or modify Production to force a chosen load.
4. **Passive native:** optional read-only hooks may observe actual emitted operands/results and separately inspect live A/B memory. Such instrumentation changes observability and can retain otherwise unused loads. Its values and phase checks are evidence for the instrumented binary, never evidence that the raw binary executed the same physical loads. Keep the raw C file/hash unchanged and distinguish the two binaries/configurations. The current Five emitter has no LINK_READ hooks; this plan does not claim an apparatus is already implemented.

If a future release needs independently timed post-free memory observation, consider a separately compiled, read-only test observer without LTO, called at the real emitted read points. It can compare the actual result/binder with live A/B memory at that callback. That is an extra observer read, not proof that a raw source load survived optimization. Single-TU inlining/constant propagation can also elide observer loads, so do not infer a hardware load from a hook count alone. Any stronger machine-code check/apparatus needs explicit future scope and remains NOT_RUN here.

## Phases and admissible observations

| Phase | Expected source state | Safe observations / obligations |
|---|---|---|
| P0 after exact9 and all write loans closed | All five original roots alive; C isolated; A.prev=Some(B), B.next=None | Capture actual original IDs, root/incarnation/region/Domain and addresses while live. Verify the actual nine old/new operations, correct cached B and unchanged siblings before any C end. An address is an integer label, not owner or membership authority. |
| P1 before C EndRoot | C still has its original Allocation/Domain and complete backing; no C-dependent loan survives | Retire the observer's typed C slot while C is still live. Save any required C address as uintptr_t now. Do not keep a typed C alias for later checks. |
| P2 C destroy -> erase_slot -> finalize_domain -> deallocate | C root/fields ended, slot empty then full raw Storage, original D_C finalized, Allocation_C+Storage_C consumed once; src/A/B/dst remain alive | Track each real lifecycle event by qualified original ID. Convert a free operand to an integer before the real free if needed for bookkeeping; post-free callbacks receive only the saved integer. Never evaluate a C pointer after free to print, compare, convert or dereference it. Verify actual free completion/count, not merely EndRoot. |
| P3 post-C-free A.prev read | Exactly C is released; A and B are alive; A.prev still has the event8 current Some(B) | Use the actual emitted A field-ref and Copy result. Verify root A/current Fact/occurrence, index prev, D_A scope, and Some tag. Match the real payload q; compare its integer identity with B's pre-recorded original while B is live. Never replace it with observer-held ptr_B. |
| P4 Some(q) -> B.next | q is the actual A.prev payload; original D_B loan is live; B.next has event7 None current | Correlate q with the exact B REF_FROM_PTR operand and D_B, then observe its actual field-ref/result. Post-free typed data inspection is confined to live A/B; no all-five-node scan. Independently compare actual result with live B.next when permitted, explicitly label this an observer memory read. No fake None or host-chosen pointer. |
| P5 match/loan completion and cleanup | A/B loans closed; no new ownership/effect; survivor frame unchanged in both UNIT arms | Track actual dst/B/A/src cleanup once each, total five including C. Retire each typed observer alias before that original's EndRoot. src/dst are tracked by real lifecycle IDs/counters, not post-free field scans. Failure worlds retain the old 0/1/2/3/4 cleanup prefixes and do not execute this continuation. |

The planned ordering is genuine Change9/loan-close < C EndRoot < C erase < D_C finalize < C actual deallocate < source A.prev read < Some payload/B ref < B.next read < B loan-close < survivor teardown. This is an oracle/prediction, not an executed model or timing measurement. Legal raw optimization is reported separately.

## Stale data and causal dataflow rules

- Never rescan C fields after EndRoot, or pass an old Some(C) package by value to an observer after free: evaluating its pointer member may itself be invalid even if the observer only intends to print a tag.
- Save old pointer identities as integers at the original Change while their targets are live, if later diagnostics need them. Retain opaque static evidence as evidence; it does not authorize runtime access.
- The last Change.after world still has C alive; the final context has all roots ended. Neither substitutes for the authentic C-freed/survivor-live read world.
- Scope/Domain IDs are qualified by the actual source-owned world and original, not just equal numeric suffixes from different arms. Normal Option Some is not an allocation event or a new B owner.
- Future hooks must receive actual produced values and field/source metadata. They may record private diagnostics but must not write guest fields, repair topology, allocate a replacement original, choose guest branches, manufacture a Domain or return a value used by the program.
- N1 stale saved Some(C), N2 wrong D and N3 omitted B responsibility must be rejected before any native authorization. Do not run them to see whether a sanitizer catches UB. A profile/syntax refusal is not evidence that the intended semantic check was reached.

## Failures, OOM and gate accounting — all future/NOT_RUN

Guest allocation failure1..5 remains separate from host checker/validator/emitter OOM. W0..W4 have original release counts0..4 with no nine writes or new reads. W5 expects actual C-first disposal and the safe continuation, then dst/B/A/src; no sixth allocation or address reuse is introduced.

Once separately authorized, freeze the actual read/custody/replay/consumer allocation census before selected host injections. Check genuine OOM status, no public artifact, unchanged output pointer/length/context/owner state and healthy retry. Do not reuse old P1387 ordinals/results as a new-candidate PASS. Counts/phase observations from hooks are not grants or a general safety proof.

## STOP and value boundary

No extra grammar or semantic correction is silently added to the v2 source. A changed meaning, new syntax requirement, new issuer/owner/API/ABI, invented Known/Domain, a second proof path, uncertain post-free pointer evaluation or broadened cost returns to C. Actual code/instrumentation, build, compiler/parser/owned/C17/native/Lean/model, Production/registered-test/branch/commit/push/PR/Actions/CI remain zero now.

Text repair is evidence hygiene only. This plan does not demonstrate post-free append, an ordinary-safe facade, general soundness or author+safe-caller UB audit/re-audit locality advantage over factored C/Rust. Runtime and engineering burden are UNMEASURED. Product GO PAUSED / H1 HOLD. TEXT PREP FINAL is followed by STOP/HARD HOLD until both actual Draft17.37 main selection and separate C RELEASE.

</details>

<details><summary>最終text freeze全文</summary>

```json
{
  "time_JST": "2026-11-13T16:35:54.991237+09:00",
  "scope": "C786 text-only prep FINAL, then STOP/HARD HOLD",
  "source_receipt_SHA256": "8114480806dc1983f23fa6dc54d71f934d2a5e90303999acc903a4b7dc0749ca",
  "oracle_v2_SHA256": "178c76aea095990a533d85fe952e5396fd24244f6a9d1fcad1b02b33ecfe57c1",
  "observer_PLAN_ONLY_SHA256": "4176902be27abed109b82deb7d8cc7af548a34b0295c41bcd0d7f638856da621",
  "files": {
    "N1-saved-old-C-pointer-v2.nl": {
      "bytes": 17685,
      "SHA256": "d07b8f532c590f8f9ef0850a6cbd4c3cf7aa2b5994bb53d384be4a15812f65ee"
    },
    "N1-saved-old-C-pointer-v2.nl.patch": {
      "bytes": 936,
      "SHA256": "a5a30985b19e67512df4093bcd896e0f8092d6cf5f5c94d2984d2249f30b1f3c"
    },
    "N2-wrong-tail-domain-v2.nl": {
      "bytes": 17686,
      "SHA256": "54ff7207e93eff6dd330798b1ec7ccb8d4633152e408b75864825f7a498a6245"
    },
    "N2-wrong-tail-domain-v2.nl.patch": {
      "bytes": 933,
      "SHA256": "50b67ad2c718cb035c830b528e1f56311db9add3685dc5b3cdf61d4014985e74"
    },
    "N3-missing-survivor-B-release-v2.nl": {
      "bytes": 17722,
      "SHA256": "873a8cec852ac81de363d1b076f7963b51816f9804a5923cd63db7a788fdc352"
    },
    "N3-missing-survivor-B-release-v2.nl.patch": {
      "bytes": 951,
      "SHA256": "91803d8c8eab37a57e9ed6634a17b8ea1af6bb36d46d5fabee4d10eeaa8a84ec"
    },
    "P1-C-free-current-tail-read-v2.nl": {
      "bytes": 17686,
      "SHA256": "105fc934021586050ad875d05f251c65a30de70c34f330913bb1738022be11b4"
    },
    "P1-C-free-current-tail-read-v2.nl.patch": {
      "bytes": 947,
      "SHA256": "9e22fdac2dfcba5f544332aab08a4af0824d57049c21588310a7c0f291b39319"
    },
    "PHASE-AWARE-OBSERVER-PLAN.md": {
      "bytes": 8630,
      "SHA256": "4176902be27abed109b82deb7d8cc7af548a34b0295c41bcd0d7f638856da621"
    },
    "TEXT-v2-SHA-RECEIPT.json": {
      "bytes": 3328,
      "SHA256": "8114480806dc1983f23fa6dc54d71f934d2a5e90303999acc903a4b7dc0749ca"
    },
    "oracle-v2.json": {
      "bytes": 8039,
      "SHA256": "178c76aea095990a533d85fe952e5396fd24244f6a9d1fcad1b02b33ecfe57c1"
    }
  },
  "old_frozen_v1_verified_unchanged": true,
  "all_execution_and_implementation": "0 / NOT_RUN",
  "implementation_release": "NOT_GRANTED: actual Draft17.37 main adoption AND separate explicit C release required",
  "exposure": "C786 grammar finding only; independent F/R materials UNREAD"
}
```

</details>

<!-- END C786 TEXT PREP FINAL -->
