# C786 phase-aware observation PLAN ONLY

Authority: pinned main feb8398e136949b765fcfd3abf086f9ccbf145d8 / Draft17.36.
Early C release + cached-tail continuation remains unselected on this main.
No observer code, harness, compiler changes, build or guest execution is created here.
Future implementation and observation require adopted Draft17.37 and a separate explicit C release.

## Separate the four evidence claims

1. **Source/CHECK-owned semantic read:** after full C disposal, real LINK_READ(A.prev) produces a Copy Option, its actual Some payload q retains original B provenance, and original D_B justifies the scoped B ref and current B.next read. Check root/incarnation, field/current Fact/occurrence, Domain/loan and exact call/def-use in the real source-issued artifact. Host expected values or pointer bits are not grants.
2. **Unoptimized emitted C def-use:** inspect the exact raw C bytes for actual A.prev field load -> Option temp -> Some payload binder -> B ref/field projection -> B.next load, in correct lexical scopes and source order after C deallocation. Matching output bits or a direct named ptr_B is insufficient. A C compile is not an execution observation.
3. **Raw native:** use unchanged emitted C. An unused Copy read can be elided, folded or legally moved by O0/O2 optimization. Exit0 alone proves neither that a physical load occurred nor that it happened after free. Mark raw dynamic reads NOT_OBSERVED unless independently established under a later authorized check. Do not alter source, add volatile, inject an artificial use, weaken optimization or modify Production to force a chosen load.
4. **Passive native:** optional read-only hooks may observe actual emitted operands/results and separately inspect live A/B memory. Such instrumentation changes observability and can retain otherwise unused loads. Its values and phase checks are evidence for the instrumented binary, never evidence that the raw binary executed the same physical loads. Keep the raw C file/hash unchanged and distinguish the two binaries/configurations. The current Five emitter has no LINK_READ hooks; this plan does not claim an apparatus is already implemented.

If a future release needs independently timed post-free memory observation, consider a separately compiled, read-only test observer without LTO, called at the real emitted read points. It can compare the actual result/binder with live A/B memory at that callback. That is an extra observer read, not proof that a raw source load survived optimization. Single-TU inlining/constant propagation can also elide observer loads, so do not infer a hardware load from a hook count alone. Any stronger machine-code check/apparatus needs explicit future scope and remains NOT_RUN here.

## Phases and admissible observations

| Phase | Expected source state | Safe observations / obligations |
|---|---|---|
| P0 after exact9 and all write loans closed | All five original roots alive; C isolated; A.prev=Some(B), B.next=None | Capture actual original IDs, root/incarnation/region/Domain and addresses while live. Verify the actual nine old/new operations, correct cached B and unchanged siblings before any C end. An address is an integer label, not owner or membership authority. |
| P1 before C EndRoot | C still has its original Allocation/Domain and complete backing; no C-dependent loan survives | Retire the observer's typed C slot while C is still live. Save any required C address as uintptr_t now. Do not keep a typed C alias for later checks. |
| P2 C destroy -> erase_slot -> finalize_domain -> deallocate | C root/fields ended, slot empty then full raw Storage, original D_C finalized, Allocation_C+Storage_C consumed once; src/A/B/dst remain alive | Track each real lifecycle event by qualified original ID. Convert a free operand to an integer before the real free if needed for bookkeeping; post-free callbacks receive only the saved integer. Never evaluate a C pointer after free to print, compare, convert or dereference it. Verify actual free completion/count, not merely EndRoot. |
| P3 post-C-free A.prev read | Exactly C is released; A and B are alive; A.prev still has the event8 current Some(B) | Use the actual emitted A field-ref and Copy result. Verify root A/current Fact/occurrence, index prev, D_A scope, and Some tag. Match the real payload q; compare its integer identity with B's pre-recorded original while B is live. Never replace it with observer-held ptr_B. |
| P4 Some(q) -> B.next | q is the actual A.prev payload; original D_B loan is live; B.next has event7 None current | Correlate q with the exact B REF_FROM_PTR operand and D_B, then observe its actual field-ref/result. Post-free typed data inspection is confined to live A/B; no all-five-node scan. Independently compare actual result with live B.next when permitted, explicitly label this an observer memory read. No fake None or host-chosen pointer. |
| P5 match/loan completion and cleanup | A/B loans closed; no new ownership/effect; survivor frame unchanged in both UNIT arms | Track actual dst/B/A/src cleanup once each, total five including C. Retire each typed observer alias before that original's EndRoot. src/dst are tracked by real lifecycle IDs/counters, not post-free field scans. Failure worlds retain the old 0/1/2/3/4 cleanup prefixes and do not execute this continuation. |

The planned ordering is genuine Change9/loan-close < C EndRoot < C erase < D_C finalize < C actual deallocate < source A.prev read < Some payload/B ref < B.next read < B loan-close < survivor teardown. This is an oracle/prediction, not an executed model or timing measurement. Legal raw optimization is reported separately.

## Stale data and causal dataflow rules

- Never rescan C fields after EndRoot, or pass an old Some(C) package by value to an observer after free: evaluating its pointer member may itself be invalid even if the observer only intends to print a tag.
- Save old pointer identities as integers at the original Change while their targets are live, if later diagnostics need them. Retain opaque static evidence as evidence; it does not authorize runtime access.
- The last Change.after world still has C alive; the final context has all roots ended. Neither substitutes for the authentic C-freed/survivor-live read world.
- Scope/Domain IDs are qualified by the actual source-owned world and original, not just equal numeric suffixes from different arms. Normal Option Some is not an allocation event or a new B owner.
- Future hooks must receive actual produced values and field/source metadata. They may record private diagnostics but must not write guest fields, repair topology, allocate a replacement original, choose guest branches, manufacture a Domain or return a value used by the program.
- N1 stale saved Some(C), N2 wrong D and N3 omitted B responsibility must be rejected before any native authorization. Do not run them to see whether a sanitizer catches UB. A profile/syntax refusal is not evidence that the intended semantic check was reached.

## Failures, OOM and gate accounting — all future/NOT_RUN

Guest allocation failure1..5 remains separate from host checker/validator/emitter OOM. W0..W4 have original release counts0..4 with no nine writes or new reads. W5 expects actual C-first disposal and the safe continuation, then dst/B/A/src; no sixth allocation or address reuse is introduced.

Once separately authorized, freeze the actual read/custody/replay/consumer allocation census before selected host injections. Check genuine OOM status, no public artifact, unchanged output pointer/length/context/owner state and healthy retry. Do not reuse old P1387 ordinals/results as a new-candidate PASS. Counts/phase observations from hooks are not grants or a general safety proof.

## STOP and value boundary

No extra grammar or semantic correction is silently added to the v2 source. A changed meaning, new syntax requirement, new issuer/owner/API/ABI, invented Known/Domain, a second proof path, uncertain post-free pointer evaluation or broadened cost returns to C. Actual code/instrumentation, build, compiler/parser/owned/C17/native/Lean/model, Production/registered-test/branch/commit/push/PR/Actions/CI remain zero now.

Text repair is evidence hygiene only. This plan does not demonstrate post-free append, an ordinary-safe facade, general soundness or author+safe-caller UB audit/re-audit locality advantage over factored C/Rust. Runtime and engineering burden are UNMEASURED. Product GO PAUSED / H1 HOLD. TEXT PREP FINAL is followed by STOP/HARD HOLD until both actual Draft17.37 main selection and separate C RELEASE.
