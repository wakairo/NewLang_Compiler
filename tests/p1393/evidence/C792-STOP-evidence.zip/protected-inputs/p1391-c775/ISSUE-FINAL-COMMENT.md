Track: P

## C775 bounded FINAL — code-first preflight完了／実装・実測GOはDEFER

固定main **feb8398e136949b765fcfd3abf086f9ccbf145d8**／tree **5cc5428eec6e92d54a081e86e3dae7049bd7a6da**／CURRENT_SPEC→Draft17.36をGitHub GET照合。保持P1387 HEAD0bc912dと全tree一致のため、旧worktree/HEAD/refを変更せず同一bytesを読みました。Pは一名、M1390・main CIを静的着手待ちにしていません。P1387 source/oracle/FIRST/RED/ELF/rawは不変です。

**Gate:** STATIC/TEXT COMPLETE＝YES。現在source-selected＝NO（§3.2b.6がearly C EndRoot・modified cleanup・cached-link continuationを明示除外）。最初の実CLI拒否／CHECK・owned・C17・native＝UNKNOWN / NOT_RUN。新owner/issuer/API/ABIやgraph solverが不可欠との結論はまだありませんが、既存機構で実装できるとの実証もありません。

### 最初の1〜3障害と最小再利用案（静的予測）

1. [captured trace:717–738](https://github.com/wakairo/NewLang_Compiler/blob/feb8398e136949b765fcfd3abf086f9ccbf145d8/src/captured_closure.c#L717) はREF_FROM_PTR/FIELD_REFを9 Changeのoperandに結び付けます。継続のfresh read-A refはその証拠を持ちません。既存 [link_read:2377](https://github.com/wakairo/NewLang_Compiler/blob/feb8398e136949b765fcfd3abf086f9ccbf145d8/src/semantic_check.c#L2377)・[allocated_ref:9984](https://github.com/wakairo/NewLang_Compiler/blob/feb8398e136949b765fcfd3abf086f9ccbf145d8/src/semantic_check.c#L9984) を使い、**その読取り時点**のC-freed／survivor-live・実field current/occurrence・scopeと正しいDを同じcaptured proofへ接続することが第一契約。last Change.afterはC生存中、最終contextは全原物解放後なので、どちらを単純にpost-free current worldとして使ってもいけません。正確な最初の診断は未観測で、より前の通常CHECK precision拒否も排除していません。
2. [trace:847](https://github.com/wakairo/NewLang_Compiler/blob/feb8398e136949b765fcfd3abf086f9ccbf145d8/src/captured_closure.c#L847) のMATCHは子allocation closure専用。通常のcopied Option matchには [function_match:7968](https://github.com/wakairo/NewLang_Compiler/blob/feb8398e136949b765fcfd3abf086f9ccbf145d8/src/semantic_check.c#L7968)／[node_unit_arm_frame:7233](https://github.com/wakairo/NewLang_Compiler/blob/feb8398e136949b765fcfd3abf086f9ccbf145d8/src/semantic_check.c#L7233)／既存custodyの再利用余地があります。Someを新allocationに見立てず、真正なchild worldと同じoriginal台帳・UNIT frameを照合する必要があります。
3. [Five match:165](https://github.com/wakairo/NewLang_Compiler/blob/feb8398e136949b765fcfd3abf086f9ccbf145d8/src/checked_c_five.c#L165) はTRY_ALLOCATE_ONE専用、exprにLINK_READ loweringなし。現在の [dispatch:3515](https://github.com/wakairo/NewLang_Compiler/blob/feb8398e136949b765fcfd3abf086f9ccbf145d8/src/checked_c_node.c#L3515) はこのH型をFiveへ送り、二H emitterへの横流しはできません。既存heap_link_exprの実load/current照合を材料に、同じFive walkへtyped Option load→実Some payload→B.next load、exact-once coverageを加える案。直接ptr_Bを代入してcache実読を省略する案は目的外です。

**LIFO誤診を除外:** [raw deallocate:542](https://github.com/wakairo/NewLang_Compiler/blob/feb8398e136949b765fcfd3abf086f9ccbf145d8/src/raw_storage.c#L542)、trace:887–950は元region/domainで原物を同定しended/erased/finalized/freedを追い、Fiveも実operandからfreeを出します。逆順indexの拒否はありません。これで新sourceの受理を主張はできませんが、『C先行解放がLIFO guardで最初に落ちる』とは言えません。旧P1387 observerの逆順期待は旧source専用なので変更禁止。将来は別のphase-aware observerが必要です。

collect/deriveのallocation entry／全閉鎖postは保持できます。新readは第五Someの内側、survivor cleanupの前に置き、0–5世界の終端責任は従来どおり全て閉じます。readを通すためにall-live guardを削除せず、9 Changeの全生存検証はそのまま残す案です。新public API/issuerや第二proofが必要と判明したらSTOP C。

### 暫定text/oracle v1の先行freeze

現仕様では未選択、**全compiler/parser/owned/C17/native/Lean/model/build/configure実行0**です。正例1＋負例3のみ。以下のSHA/予測は実測結果ではありません。

| source | UTF-8 bytes | SHA256 |
|---|---:|---|
| P1-C-free-current-tail-read.nl | 17682 | `a243312bec43dd81d55ffaf0ab4d5c94632f0364129884d5c3aa8113339802b2` |
| N1-saved-old-C-pointer.nl | 17681 | `8fd3d46e4a8c80a7f311a729f9416908a0e80b96e101bc6fe1459b44e1f6265e` |
| N2-wrong-tail-domain.nl | 17682 | `f3e3a4e8661cf6d44ad534f6394120dbcf6b66596dcc1cc1926c54bdbf28f3a4` |
| N3-missing-survivor-B-release.nl | 17718 | `465a3e57ddafe78ba6c8d792f1ed64ee42e0403635c91b6ab5f7676f2ef15262` |

P1は元9変更→C完全destroy/erase/finalize/deallocate→D_Aのloanでread(A_ref@prev)→Copy OptionのSome(q)→D_Bのloanでref_from_ptr(read,q,stable_B)→read(B_ref@next)→UNIT→dst/B/A/src cleanup。A.prevからのptrを実際に使い、名前ptr_Bを推測しません。

N1はevent8のsaved old Some(C)を使います。C endedが主な違反で、D_BもCの権限にはなりません（allocated_refはlivenessをD照合より先に検査）。finalize済D_Cの再loanは捏造しません。N2はcurrent Some(B)にD_Aを渡すwrong-D。N3はH5のB deallocateだけを欠落させAllocation_B/full_Bを残す責任違反。現在profile拒否に隠れる可能性があり、これらを『本物のsemantic拒否が実測済み』とは扱いません。

oracle-v1 SHA `340a97993bc3971cadb9d4da5bf5390e17cab4ed06ab4dd2db3e2b8f96152c69`、TEXT-FREEZE-v1 SHA `01083c7472ec78569c59aa779f460ea3df7f26a0a6d3f0500ede4412685a1d3e`。保持先 `/workspace/p1391-c775`。全文と差分を下のappendixに公開し、local-only消失時も元P1と三差分から同じbytesを復元できます。旧P1387は一切書き換えません。

### 0–5失敗世界／観測計画だけ

H0–H4は元のfailure armのまま、release数0/1/2/3/4、追加read/9 Changesは実行されません。H5はCを完全解放した時点でsrc/A/B/dstが生存し、現在のA.prev=Some(B)、B.next=None、A.next=B、B.prev=A、src.child=A、dstのNone linksとsiblings/payloadが維持される予測。最後はC/dst/B/A/srcの合計5 release、各元Allocation/D/Storageを一度だけ消費。

将来のobserverはCのID/uintptr_tを生存中に捕捉し、EndRoot前にtyped pointerを退役。その後C field、stale Some(C) payload、Cのtyped pointer比較/printをしません。全5 Node再走査も不可。A.prev実load／Some payload利用／B.next実loadを観測し、raw exit0と値の証拠を区別。unsafe負例をnativeで実行しないこと。guest malloc失敗とhost OOMは別物で、新read/arm/replay/consumerの実alloc到達・rollback/no-clobber/retryは次認可後の測定対象、今回NOT_RUNです。

### 次工程・費用・代替・STOP

- **推奨:** M/Cによる有限source選択と、別Cのsource-first実測/実装認可の後、まず通常CLIの実FIRSTと既存source-issued temporal read/UNIT-frameの再利用可否を確認。成立すれば同じcaptured証拠をphase-awareに拡張し、次にFive consumerへ接続する一工程。
- **代替:** ptr_B直接＋D_Bはisolationとして安価でもcache実読の問いを満たさず、既存五H profileで通るという実証もありません。C解放を遅らせる案もlifetimeだけの対照で、追加read/Option/C17不足は残ります。元adopted9はbaselineであり本継続の成功ではありません。一般graph solverは既定案にしません。
- **費用:** 静的粗見積2–4 P日（temporal owned/read/normal-arm＋OOM、C17/native/negative互換を含む）、UNMEASURED。過去の一イベント見積の掛け算でも、今回の実装予算認可でもありません。
- **STOP/owner:** source-law選択・実装/実測GOはM/C。新owner返却/public issuer/API/ABI、広いSome世界への昇格、第二proof、一般graph/membership、origin/current/loan guard弱化、大規模化、通常sourceのunsafe受理疑いならSTOP C。実測が無いことを安全性PASSにしません。

Production/登録test/文書変更、branch/ref/worktree/commit/push/PR/Actions/CI追加0。P1387 FIRST SHA dc39ebd1634f64bc230bd2afff5badc5cc351a0693613773aab00ea62c88a2a9、最終元CI receipt SHA a2e408d1d24f70bce4b0e80d0aac5992f536dbf273aa0f012d6ff81f77354d7aを再照合。独立F/R資料未読、唯一P維持、自己READY/merge0。

**VALUE-ALIGNMENT-RISK（技術所見と別）:** 本調査は解放後にも生存リストを実際に扱うための依存整理です。early-free/append UAF防止、ordinary-safe facade、一般soundness、well-factored C/Rustに対する作者＋safe callerの監査・再監査依存閉包の縮小は未実証。exact profile・temporal snapshots・consumer/observerの保守費用も未測定です。既存機構の小さな接続を優先しますが、第二issuer/graph機構が必要なら別投資裁定へ返します。Product GO #624 PAUSED / H1 #268 HOLD。

<details><summary>暫定P1全文（17,682 bytes、NOT_RUN／未選択source）</summary>

```newlang
// P1391 C775 provisional TEXT ONLY; not selected by Draft17.36.
// No compiler/parser/owned/C17/native/model execution. Derived from preserved P1386 U.
struct Node {
    next: Option<ptr<Node>>,
    prev: Option<ptr<Node>>,
    child: Option<ptr<Node>>,
    payload: u8,
}

fn main() -> unit {
    match try_allocate_one<Node>() {  // independent allocation site 1: src
        None => {
            unit
        },
        Some(bundle_src) => {
            let OneBacking { allocation, raw } = bundle_src;
            let allocation_src = allocation;
            let vacant_src = into_slot<Node>(raw);
            let life_src = lifetime_domain();
            let ptr_src = loan_read(life_src) { |stable_src|
                initialize(vacant_src, Node {
                    next: Option<ptr<Node>>::None,
                    prev: Option<ptr<Node>>::None,
                    child: Option<ptr<Node>>::None,
                    payload: u8(1)
                }, stable_src)
            };
            match try_allocate_one<Node>() {  // independent allocation site 2: A
                None => {
                    let empty_src = loan_exclusive_read(life_src) { |ending_src|
                        destroy(ptr_src, ending_src)
                    };
                    let full_src = erase_slot<Node>(empty_src);
                    finalize_domain(life_src);
                    deallocate(allocation_src, full_src);
                    unit
                },
                Some(bundle_A) => {
                    let OneBacking { allocation, raw } = bundle_A;
                    let allocation_A = allocation;
                    let vacant_A = into_slot<Node>(raw);
                    let life_A = lifetime_domain();
                    let ptr_A = loan_read(life_A) { |stable_A|
                        initialize(vacant_A, Node {
                            next: Option<ptr<Node>>::None,
                            prev: Option<ptr<Node>>::None,
                            child: Option<ptr<Node>>::None,
                            payload: u8(2)
                        }, stable_A)
                    };
                    match try_allocate_one<Node>() {  // independent allocation site 3: B
                        None => {
                            let empty_A = loan_exclusive_read(life_A) { |ending_A|
                                destroy(ptr_A, ending_A)
                            };
                            let full_A = erase_slot<Node>(empty_A);
                            finalize_domain(life_A);
                            deallocate(allocation_A, full_A);
                            let empty_src = loan_exclusive_read(life_src) { |ending_src|
                                destroy(ptr_src, ending_src)
                            };
                            let full_src = erase_slot<Node>(empty_src);
                            finalize_domain(life_src);
                            deallocate(allocation_src, full_src);
                            unit
                        },
                        Some(bundle_B) => {
                            let OneBacking { allocation, raw } = bundle_B;
                            let allocation_B = allocation;
                            let vacant_B = into_slot<Node>(raw);
                            let life_B = lifetime_domain();
                            let ptr_B = loan_read(life_B) { |stable_B|
                                initialize(vacant_B, Node {
                                    next: Option<ptr<Node>>::None,
                                    prev: Option<ptr<Node>>::None,
                                    child: Option<ptr<Node>>::None,
                                    payload: u8(3)
                                }, stable_B)
                            };
                            match try_allocate_one<Node>() {  // independent allocation site 4: C
                                None => {
                                    let empty_B = loan_exclusive_read(life_B) { |ending_B|
                                        destroy(ptr_B, ending_B)
                                    };
                                    let full_B = erase_slot<Node>(empty_B);
                                    finalize_domain(life_B);
                                    deallocate(allocation_B, full_B);
                                    let empty_A = loan_exclusive_read(life_A) { |ending_A|
                                        destroy(ptr_A, ending_A)
                                    };
                                    let full_A = erase_slot<Node>(empty_A);
                                    finalize_domain(life_A);
                                    deallocate(allocation_A, full_A);
                                    let empty_src = loan_exclusive_read(life_src) { |ending_src|
                                        destroy(ptr_src, ending_src)
                                    };
                                    let full_src = erase_slot<Node>(empty_src);
                                    finalize_domain(life_src);
                                    deallocate(allocation_src, full_src);
                                    unit
                                },
                                Some(bundle_C) => {
                                    let OneBacking { allocation, raw } = bundle_C;
                                    let allocation_C = allocation;
                                    let vacant_C = into_slot<Node>(raw);
                                    let life_C = lifetime_domain();
                                    let ptr_C = loan_read(life_C) { |stable_C|
                                        initialize(vacant_C, Node {
                                            next: Option<ptr<Node>>::None,
                                            prev: Option<ptr<Node>>::None,
                                            child: Option<ptr<Node>>::None,
                                            payload: u8(4)
                                        }, stable_C)
                                    };
                                    match try_allocate_one<Node>() {  // independent allocation site 5: dst
                                        None => {
                                            let empty_C = loan_exclusive_read(life_C) { |ending_C|
                                                destroy(ptr_C, ending_C)
                                            };
                                            let full_C = erase_slot<Node>(empty_C);
                                            finalize_domain(life_C);
                                            deallocate(allocation_C, full_C);
                                            let empty_B = loan_exclusive_read(life_B) { |ending_B|
                                                destroy(ptr_B, ending_B)
                                            };
                                            let full_B = erase_slot<Node>(empty_B);
                                            finalize_domain(life_B);
                                            deallocate(allocation_B, full_B);
                                            let empty_A = loan_exclusive_read(life_A) { |ending_A|
                                                destroy(ptr_A, ending_A)
                                            };
                                            let full_A = erase_slot<Node>(empty_A);
                                            finalize_domain(life_A);
                                            deallocate(allocation_A, full_A);
                                            let empty_src = loan_exclusive_read(life_src) { |ending_src|
                                                destroy(ptr_src, ending_src)
                                            };
                                            let full_src = erase_slot<Node>(empty_src);
                                            finalize_domain(life_src);
                                            deallocate(allocation_src, full_src);
                                            unit
                                        },
                                        Some(bundle_dst) => {
                                            let OneBacking { allocation, raw } = bundle_dst;
                                            let allocation_dst = allocation;
                                            let vacant_dst = into_slot<Node>(raw);
                                            let life_dst = lifetime_domain();
                                            let ptr_dst = loan_read(life_dst) { |stable_dst|
                                                initialize(vacant_dst, Node {
                                                    next: Option<ptr<Node>>::None,
                                                    prev: Option<ptr<Node>>::None,
                                                    child: Option<ptr<Node>>::None,
                                                    payload: u8(5)
                                                }, stable_dst)
                                            };
                                            // Pre-detach checkpoint: exactly five original live roots;
                                            // distinct R_src/R_A/R_B/R_C/R_dst and D_src/D_A/D_B/D_C/D_dst.
                                            // dst.child stays None from its whole initial construction.
                                            let old_src_child = loan_read(life_src) { |stable_src_child|
                                                let w_src_child = ref_from_ptr(write, ptr_src, stable_src_child);
                                                replace(w_src_child@child,
                                                    Option<ptr<Node>>::Some(ptr_A))
                                            };
                                            let old_A_prev = loan_read(life_A) { |stable_A_prev|
                                                let w_A_prev = ref_from_ptr(write, ptr_A, stable_A_prev);
                                                replace(w_A_prev@prev,
                                                    Option<ptr<Node>>::Some(ptr_C))
                                            };
                                            let old_A_next = loan_read(life_A) { |stable_A_next|
                                                let w_A_next = ref_from_ptr(write, ptr_A, stable_A_next);
                                                replace(w_A_next@next,
                                                    Option<ptr<Node>>::Some(ptr_B))
                                            };
                                            let old_B_prev = loan_read(life_B) { |stable_B_prev|
                                                let w_B_prev = ref_from_ptr(write, ptr_B, stable_B_prev);
                                                replace(w_B_prev@prev,
                                                    Option<ptr<Node>>::Some(ptr_A))
                                            };
                                            let old_B_next = loan_read(life_B) { |stable_B_next|
                                                let w_B_next = ref_from_ptr(write, ptr_B, stable_B_next);
                                                replace(w_B_next@next,
                                                    Option<ptr<Node>>::Some(ptr_C))
                                            };
                                            let old_C_prev = loan_read(life_C) { |stable_C_prev|
                                                let w_C_prev = ref_from_ptr(write, ptr_C, stable_C_prev);
                                                replace(w_C_prev@prev,
                                                    Option<ptr<Node>>::Some(ptr_B))
                                            };
                                            // At this exact point seven current cJSON facts hold:
                                            // src.child=A; A.prev=C; A.next=B; B.prev=A;
                                            // B.next=C; C.prev=B; dst.child=None.
                                            // A.prev=C is the FIRST-CHILD TAIL SHORTCUT, not A.prev=None.
                                            // No B detach, no adoption, no other graph mutation.
                                            // P1386 C754 proposed-only source; all five original H roots remain live.
                                            let p1386_old_B_next = loan_read(life_B) { |p1386_stable_B|
                                                let p1386_write_B = ref_from_ptr(write, ptr_B, p1386_stable_B);
                                                replace(p1386_write_B@next, Option<ptr<Node>>::None)
                                            };
                                            let p1386_old_A_prev = loan_read(life_A) { |p1386_stable_A|
                                                let p1386_write_A = ref_from_ptr(write, ptr_A, p1386_stable_A);
                                                replace(p1386_write_A@prev, Option<ptr<Node>>::Some(ptr_B))
                                            };
                                            let p1386_old_C_prev = loan_read(life_C) { |p1386_stable_C|
                                                let p1386_write_C = ref_from_ptr(write, ptr_C, p1386_stable_C);
                                                replace(p1386_write_C@prev, Option<ptr<Node>>::None)
                                            };
                                            
                                            // Proposed phase: C-only full terminal cleanup before live-tail access.
                                            let empty_C = loan_exclusive_read(life_C) { |ending_C|
                                                destroy(ptr_C, ending_C)
                                            };
                                            let full_C = erase_slot<Node>(empty_C);
                                            finalize_domain(life_C);
                                            deallocate(allocation_C, full_C);
                                            // P1391 proposed continuation: C has been completely released.
                                            let p1391_cached_tail = loan_read(life_A) { |p1391_stable_A|
                                                let p1391_read_A = ref_from_ptr(read, ptr_A, p1391_stable_A);
                                                read(p1391_read_A@prev)
                                            };
                                            match p1391_cached_tail {
                                                None => unit,
                                                Some(p1391_tail_ptr) => {
                                                    let p1391_current_B_next = loan_read(life_B) { |p1391_stable_B|
                                                        let p1391_read_B = ref_from_ptr(read, p1391_tail_ptr, p1391_stable_B);
                                                        read(p1391_read_B@next)
                                                    };
                                                    unit
                                                },
                                            };
                                            // All loans above ended; consume each remaining original exactly once.
                                            let empty_dst = loan_exclusive_read(life_dst) { |ending_dst|
                                                destroy(ptr_dst, ending_dst)
                                            };
                                            let full_dst = erase_slot<Node>(empty_dst);
                                            finalize_domain(life_dst);
                                            deallocate(allocation_dst, full_dst);
                                            let empty_B = loan_exclusive_read(life_B) { |ending_B|
                                                destroy(ptr_B, ending_B)
                                            };
                                            let full_B = erase_slot<Node>(empty_B);
                                            finalize_domain(life_B);
                                            deallocate(allocation_B, full_B);
                                            let empty_A = loan_exclusive_read(life_A) { |ending_A|
                                                destroy(ptr_A, ending_A)
                                            };
                                            let full_A = erase_slot<Node>(empty_A);
                                            finalize_domain(life_A);
                                            deallocate(allocation_A, full_A);
                                            let empty_src = loan_exclusive_read(life_src) { |ending_src|
                                                destroy(ptr_src, ending_src)
                                            };
                                            let full_src = erase_slot<Node>(empty_src);
                                            finalize_domain(life_src);
                                            deallocate(allocation_src, full_src);
                                            unit
                                        },
                                    }
                                },
                            }
                        },
                    }
                },
            }
        },
    }
}
```

</details>

<details><summary>三負例の完全text差分（P1から機械的に復元可能、全NOT_RUN）</summary>

```diff
--- P1-C-free-current-tail-read.nl
+++ N1-saved-old-C-pointer.nl
@@ -216,9 +216,9 @@
                                             let p1391_cached_tail = loan_read(life_A) { |p1391_stable_A|
                                                 let p1391_read_A = ref_from_ptr(read, ptr_A, p1391_stable_A);
                                                 read(p1391_read_A@prev)
                                             };
-                                            match p1391_cached_tail {
+                                            match p1386_old_A_prev {
                                                 None => unit,
                                                 Some(p1391_tail_ptr) => {
                                                     let p1391_current_B_next = loan_read(life_B) { |p1391_stable_B|
                                                         let p1391_read_B = ref_from_ptr(read, p1391_tail_ptr, p1391_stable_B);
```

```diff
--- P1-C-free-current-tail-read.nl
+++ N2-wrong-tail-domain.nl
@@ -219,9 +219,9 @@
                                             };
                                             match p1391_cached_tail {
                                                 None => unit,
                                                 Some(p1391_tail_ptr) => {
-                                                    let p1391_current_B_next = loan_read(life_B) { |p1391_stable_B|
+                                                    let p1391_current_B_next = loan_read(life_A) { |p1391_stable_B|
                                                         let p1391_read_B = ref_from_ptr(read, p1391_tail_ptr, p1391_stable_B);
                                                         read(p1391_read_B@next)
                                                     };
                                                     unit
```

```diff
--- P1-C-free-current-tail-read.nl
+++ N3-missing-survivor-B-release.nl
@@ -238,9 +238,9 @@
                                                 destroy(ptr_B, ending_B)
                                             };
                                             let full_B = erase_slot<Node>(empty_B);
                                             finalize_domain(life_B);
-                                            deallocate(allocation_B, full_B);
+                                            // Negative: original Allocation_B/full_B intentionally not consumed.
                                             let empty_A = loan_exclusive_read(life_A) { |ending_A|
                                                 destroy(ptr_A, ending_A)
                                             };
                                             let full_A = erase_slot<Node>(empty_A);
```

</details>

<details><summary>凍結oracle-v1全文（予測のみ）</summary>

```json
{
  "kind": "P1391/C775 provisional text+oracle v1; NOT a semantic model or executed result",
  "authority": {
    "main": "feb8398e136949b765fcfd3abf086f9ccbf145d8",
    "tree": "5cc5428eec6e92d54a081e86e3dae7049bd7a6da",
    "canonical": "Draft17.36; earlyfree+continuation NOT_SELECTED"
  },
  "source_base": {
    "U_SHA256": "63c53ae9c67653071c468f160232b24dab9f6efb1afa6386bf6357d224978f7f",
    "P1387_repo_HEAD": "0bc912d1e57b3c1a3b13173136ab35bd1bcf577e",
    "all_tree_bytes_equal_adopted_main": true
  },
  "cases": {
    "P1-C-free-current-tail-read.nl": {
      "bytes": 17682,
      "SHA256": "a243312bec43dd81d55ffaf0ab4d5c94632f0364129884d5c3aa8113339802b2",
      "source_eligibility_now": "UNSELECTED in Draft17.36; provisional only",
      "observed": {
        "parser": "NOT_RUN",
        "CHECK_definition": "NOT_RUN",
        "CHECK_actual": "NOT_RUN",
        "owned": "NOT_RUN",
        "C17": "NOT_RUN",
        "native": "NOT_RUN",
        "OOM": "NOT_RUN"
      },
      "expected_if_later_selected": {
        "cache_read": "actual current A.prev, copied Option Some(ptr_B) after C full release",
        "tail_ref": "actual Some binder p1391_tail_ptr with original D_B in fresh nonescaping loan; never substitute ptr_B",
        "B_next_read": "actual current None from event7; Copy result in Some arm, UNIT join",
        "old_values_retained": [
          "Some(C) from unlink B.next",
          "Some(C) from unlink A.prev",
          "Some(B) from unlink C.prev"
        ],
        "after_C_release": "C R/field lifetimes ended; Allocation_C+Raw_C consumed; Domain_C finalized; src/A/B/dst original identities and rights still live",
        "success_cleanup_order": [
          "C",
          "dst",
          "B",
          "A",
          "src"
        ],
        "failure_worlds": "first allocation None1..5 unchanged:0,1,2,3,4 releases; no9 writes or continuation; success5 releases",
        "expected_raw": "unit/exit0 only; no native value claim without passive read observation",
        "current_main_static_barrier": "fresh read-only ref/field-ref not authenticated by existing Change-only captured trace; Option-MATCH and C17 LINK_READ also unsupported; exact first diagnostic NOT_OBSERVED"
      }
    },
    "N1-saved-old-C-pointer.nl": {
      "bytes": 17681,
      "SHA256": "8fd3d46e4a8c80a7f311a729f9416908a0e80b96e101bc6fe1459b44e1f6265e",
      "source_eligibility_now": "UNSELECTED in Draft17.36; provisional only",
      "observed": {
        "parser": "NOT_RUN",
        "CHECK_definition": "NOT_RUN",
        "CHECK_actual": "NOT_RUN",
        "owned": "NOT_RUN",
        "C17": "NOT_RUN",
        "native": "NOT_RUN",
        "OOM": "NOT_RUN"
      },
      "principal": "stale saved event8 old Some(C) cannot be reloaned after C EndRoot/full release",
      "secondary": "D_B also cannot grant access to C; reference_live is checked before D matching. Domain_C is already consumed, so no live D_C loan is fabricated.",
      "expected_if_later_selected": "semantic liveness refusal, likely P3-STALE-POINTER if this site is reached; currently profile precision may mask it"
    },
    "N2-wrong-tail-domain.nl": {
      "bytes": 17682,
      "SHA256": "f3e3a4e8661cf6d44ad534f6394120dbcf6b66596dcc1cc1926c54bdbf28f3a4",
      "source_eligibility_now": "UNSELECTED in Draft17.36; provisional only",
      "observed": {
        "parser": "NOT_RUN",
        "CHECK_definition": "NOT_RUN",
        "CHECK_actual": "NOT_RUN",
        "owned": "NOT_RUN",
        "C17": "NOT_RUN",
        "native": "NOT_RUN",
        "OOM": "NOT_RUN"
      },
      "principal": "live ptr_B from actual current A.prev under D_A instead of D_B",
      "expected_if_later_selected": "semantic wrong Domain refusal, likely ALLOCATED-DOMAIN-MISMATCH if reached; not source-profile safety evidence"
    },
    "N3-missing-survivor-B-release.nl": {
      "bytes": 17718,
      "SHA256": "465a3e57ddafe78ba6c8d792f1ed64ee42e0403635c91b6ab5f7676f2ef15262",
      "source_eligibility_now": "UNSELECTED in Draft17.36; provisional only",
      "observed": {
        "parser": "NOT_RUN",
        "CHECK_definition": "NOT_RUN",
        "CHECK_actual": "NOT_RUN",
        "owned": "NOT_RUN",
        "C17": "NOT_RUN",
        "native": "NOT_RUN",
        "OOM": "NOT_RUN"
      },
      "principal": "H5 success normal return retains original Allocation_B and full_B despite B root/domain end",
      "expected_if_later_selected": "responsibility/closure refusal; no accepted leak or native execution. Earlier profile refusal may mask the obligation."
    }
  },
  "observation_plan_only": {
    "phase_checkpoint": "after C deallocate and before cached read: C ended/freed, survivors src/A/B/dst live; witness actual read A.prev -> Some B -> scoped B ref -> B.next None",
    "physical": "no sixth allocation/reuse; root B address comes from loaded current Option payload, not name/host guess",
    "observer": "never read C fields or load/compare stale pointer packages after C EndRoot/free. Capture C address as uintptr_t while live; afterwards track integer ID/counters only. Old LIFO observer unchanged; future distinct phase-aware observer",
    "failures": "guest platform malloc failure1..5 distinct from host CHECK/validator/emitter OOM",
    "OOM": "future actual source-issued read/custody snapshots+normal arm+consumer allocation failures; status/no artifact/out length/context no-clobber/retry. NOT_RUN"
  },
  "execution_counters": {
    "compiler": 0,
    "parser": 0,
    "owned": 0,
    "C17": 0,
    "native": 0,
    "Lean": 0,
    "model": 0,
    "build": 0,
    "configure": 0,
    "branch": 0,
    "commit": 0,
    "push": 0,
    "PR": 0,
    "Actions": 0,
    "CI": 0
  },
  "stop": "source selection and execution/implementation require separate M/C authority; new owner/issuer/public ABI/second proof/generic graph solver or unsafe suspicion STOP C"
}
```

</details>

<details><summary>凍結text manifest全文</summary>

```json
{
  "time_JST": "2026-11-13T14:51:06.495511+09:00",
  "state": "provisional source/oracle text; all execution NOT_RUN",
  "files": {
    "N1-saved-old-C-pointer.nl": {
      "bytes": 17681,
      "SHA256": "8fd3d46e4a8c80a7f311a729f9416908a0e80b96e101bc6fe1459b44e1f6265e"
    },
    "N1-saved-old-C-pointer.nl.patch": {
      "bytes": 947,
      "SHA256": "28131e48477bd0f79191c59b0b5746bf9aff9f2601b4575faa87f80021696ee8"
    },
    "N2-wrong-tail-domain.nl": {
      "bytes": 17682,
      "SHA256": "f3e3a4e8661cf6d44ad534f6394120dbcf6b66596dcc1cc1926c54bdbf28f3a4"
    },
    "N2-wrong-tail-domain.nl.patch": {
      "bytes": 897,
      "SHA256": "af64e51959689181a6f3dec7aa4ccdbda9f5c461707157a9c0358260f17b99bf"
    },
    "N3-missing-survivor-B-release.nl": {
      "bytes": 17718,
      "SHA256": "465a3e57ddafe78ba6c8d792f1ed64ee42e0403635c91b6ab5f7676f2ef15262"
    },
    "N3-missing-survivor-B-release.nl.patch": {
      "bytes": 870,
      "SHA256": "2ba7b2ae592b938097f774b78dc9ad51efe34ea4e1e14a0d567cef44eb28815c"
    },
    "P1-C-free-current-tail-read.nl": {
      "bytes": 17682,
      "SHA256": "a243312bec43dd81d55ffaf0ab4d5c94632f0364129884d5c3aa8113339802b2"
    },
    "oracle-v1.json": {
      "bytes": 5898,
      "SHA256": "340a97993bc3971cadb9d4da5bf5390e17cab4ed06ab4dd2db3e2b8f96152c69"
    }
  },
  "old_P1387_FIRST_SHA256": "dc39ebd1634f64bc230bd2afff5badc5cc351a0693613773aab00ea62c88a2a9",
  "old_P1387_CI_receipt_SHA256": "a2e408d1d24f70bce4b0e80d0aac5992f536dbf273aa0f012d6ff81f77354d7a"
}
```

</details>

<!-- END C775 BOUNDED FINAL -->
