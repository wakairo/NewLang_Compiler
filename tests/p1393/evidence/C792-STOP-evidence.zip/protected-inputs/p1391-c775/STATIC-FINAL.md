# P1391 C775 bounded STATIC FINAL — no compiler/model execution

Authority: actual adopted main `feb8398e136949b765fcfd3abf086f9ccbf145d8`,
tree `5cc5428eec6e92d54a081e86e3dae7049bd7a6da`, CURRENT_SPEC → Draft17.36.
Read-only code came from retained P1387 HEAD `0bc912d1e57b3c1a3b13173136ab35bd1bcf577e` with exactly that full tree. No ref, branch or worktree was changed. Sole P was checked; M1390 completion and main CI were not start conditions. No fixed M source comment was present in the one GET of M1390 comments; this report does not wait for M.

## Disposition and evidence level

- Static preflight/text preparation: COMPLETE.
- Current selected source law: NO. Draft17.36 §3.2b.6 explicitly excludes early C EndRoot/modified cleanup/cached-link continuation. This is a known M/C selection dependency, not evidence that a pointer Copy creates a lifetime.
- First actual parser/CHECK/owned/C17/native refusal: UNKNOWN / NOT_RUN. The locations below are code-derived predictions, not an observed diagnostic or a safety PASS.
- Need for new owner, public issuer/API/ABI or general graph solver: NOT_ESTABLISHED. A coherent extension of the existing captured lifecycle/per-field proof is plausible, but unmeasured and not implemented.
- Production/registered-test changes, compiler/parser/native/Lean/model/build/configure, branch/commit/push/PR/Actions/CI: all 0.

## First three implementation barriers, in order of dependency

1. **Read-only source-issued current evidence in the captured trace.** `semantic_check.c::link_read` (2377–2408) already obtains the real fixed child current value and emits `NL_CHECKED_LINK_READ`; `allocated_ref` (9984–10088) preserves operand evidence and checks pointer root/incarnation/liveness before checking the exact governing D. `captured_closure.c::trace` (717–738), however, authenticates REF_FROM_PTR/FIELD_REF only as operands of recorded Changes. The fresh read-A ref after C disposal has no such write witness. It is therefore a concrete predicted invalid-proof location if ordinary checking reaches closure validation. An earlier syntax/precision/normal-arm refusal has not been ruled out by execution.
2. **A normal copied Option match, not another allocation.** The same trace (847–870) accepts a MATCH only as its next captured allocation closure; the additional cached Option match is not that event. `semantic_check.c::function_match` (7968ff, 8120ff, 8220ff) and `node_unit_arm_frame` (7233ff) already support allocated-slice known Option + normal UNIT arms with unchanged original resources. `function_arm` preserves actual Some payload facts; it does not grant a root in a hypothetical unknown arm. Existing `nl_h_custody_attach`/canonical child ownership can retain those real arms. Future validation must compose them into this same lifecycle proof with a phase-correct parent/child-world mapping, without importing branch suffix IDs or treating a pointer Some as an allocation grant.
3. **Five-original C17 consumers.** `checked_c_node.c:3515–3525` routes this four-field H family directly to `nl_checked_c_five`; falling through to the two-H emitter is not an available proof shortcut. `checked_c_five.c::expr` has no LINK_READ case, and its `match` (165–177) requires TRY_ALLOCATE_ONE + captured closure. Generic `checked_c_node.c::heap_link_expr` (1537ff) contains typed read/current checks and real C loads useful as implementation material, but its role/lifecycle assumptions cannot be borrowed as an independent certificate. The five-root consumer would need a real `nl_option` load and typed Some payload binding from that load, exact once-only coverage, then the B field load. It must never substitute the original named ptr_B for the actual cached payload.

## Important non-barrier: no universal LIFO release condition

`raw_storage.c:542–568` deallocates the matching original Allocation + full-range raw Storage, not the last numbered region. `captured_closure.c:887–950` identifies a root by its real region/domain and tracks ended/erased/finalized/freed per original. The Five emitter emits destroy/free from actual source operands (583–602). No reverse-root-index check was found in those paths. This does NOT establish acceptance of a new cleanup order, but it rules out describing a presumed LIFO check there as the observed first refusal.

The old P1387 observer DOES require the original reverse order (`observer.h:180,212`), as appropriate for the original frozen source. Keep it unchanged. A future separate observer must describe the new phase/order; changing the old oracle to accommodate this new source would erase evidence.

`collect` remains an all-live ancestor check at allocation entry, and `derive` remains a fully closed post-match frame. The continuation here is inside the fifth Some arm before all four survivors are cleaned up. Thus neither needs to be weakened merely to create an intermediate C-freed read point. The final release histogram alone cannot prove liveness at that intermediate read.

## Minimal future reuse route, not an implementation authorization

Keep all nine existing Change checks/all-live requirements intact. Then validate a bounded new lifecycle phase inside the same source-owned captured trace: C has completed all four terminal operations, and src/A/B/dst retain their original identities and rights. Tie each actual read/ref/field projection to that phase, current Fact/occurrence, scoped real D and owned source instance. Existing owned-context cloning/replay, closure statuses and custody should be reused. If a temporal read record is needed, it must be CHECK-issued and owned by this same mechanism; a separate issuer or host receipt is not an alternative.

The last Change.after snapshot is pre-teardown, with C still alive. It cannot be reinterpreted as a post-free current world or as authorization to reborrow C. Conversely the final fragment context has all roots closed and cannot supply current liveness for the earlier B read. The exact transport of actual read/world facts is the first finite contract to settle in a later Gate0/implementation release.

Copying `read(A_ref@prev)` yields a nonowning pointer package. The subsequent actual Some binder must retain B's real root/incarnation/provenance. Only the existing source-owned D_B loan can justify `ref_from_ptr(read,q,stable_B)`; no owner, Domain or membership is created from those bits. After the B read, its loan closes and both Option arms must leave the survivor resource frame unchanged. Preserve the original final closed-frame proof and all 0–5 release worlds.

## Provisional source/oracle v1

Untracked text is under `/workspace/p1391-c775`. Positive P1 is 17,682 UTF-8 bytes, SHA256 `a243312bec43dd81d55ffaf0ab4d5c94632f0364129884d5c3aa8113339802b2`. It keeps the exact adopted nine-Change prefix and original five failure arms, moves the C terminal block before dst cleanup, reads the actual current A.prev, matches that copied Option, and reads B.next under D_B from its Some binder. Both arms return UNIT; all survivor cleanup remains outside the match. There is no helper, append, sixth allocation or additional Change.

Negatives (all proposed, NOT_RUN):

- N1 uses the saved event8 old `Some(C)` instead of the current cached Option: SHA `8fd3d46e4a8c80a7f311a729f9416908a0e80b96e101bc6fe1459b44e1f6265e`. It must not reborrow ended C. The retained live D_B also is not C's D; liveness is checked before D equality in allocated_ref. No new live D_C is fabricated after its finalization.
- N2 gives D_A to the real live B tail ref: SHA `f3e3a4e8661cf6d44ad534f6394120dbcf6b66596dcc1cc1926c54bdbf28f3a4`. It predicts a genuine wrong-D refusal if reached, not a policy/membership error.
- N3 omits only the H5-success B deallocation: SHA `465a3e57ddafe78ba6c8d792f1ed64ee42e0403635c91b6ab5f7676f2ef15262`. Allocation_B and full_B remain unconsumed. A normal closure cannot accept that responsibility leak.

Oracle SHA `340a97993bc3971cadb9d4da5bf5390e17cab4ed06ab4dd2db3e2b8f96152c69`; text freeze SHA `01083c7472ec78569c59aa779f460ea3df7f26a0a6d3f0500ede4412685a1d3e`. Current profile rejection may mask every semantic negative. Do not mark them as tested rejection or fabricate a precise first diagnostic.

## Future observation/abnormal-path plan only

H0–H4 remain the original failure sites, with 0/1/2/3/4 original releases, no nine changes and no continuation. H5 first frees C, observes survivors live, then finally releases dst/B/A/src; total five, exact order C/dst/B/A/src. Preserve src.child=A, A.next=B, A.prev=B, B.prev=A, B.next=None and dst's None links, with disjoint fields/payloads unchanged. C's fields are not read after its EndRoot.

A future passive observer must capture C's integer address/opaque ID while live, retire its typed pointer before EndRoot and thereafter use only stored integers and counters. It must not print/compare/dereference stale copied pointer packages, rescan all five Node fields after C disposal, or read the old saved Some(C) to build its own evidence. A/B read observations must come from actual generated loads/Some payload uses; raw exit0 alone cannot prove these values. Raw C remains unmodified; no unsafe negative may be natively run.

Guest malloc failure1–5 is separate from host source/CHECK/validator/emitter OOM. A later release should select actually reached allocations in any additional capture/replay/arm/C17 work and check status, unpublished output, unchanged output length/context/owner state and healthy retry. No current ordinal census exists and the P1387 OOM positions are not a new-candidate PASS.

## Alternatives, cost and STOP

- Direct original ptr_B + D_B is an isolation/control concept, not proof that the actual cache was read. It also does not automatically become admitted by the five-H source profile. No extra control source was generated or executed here.
- Retaining C until after the read isolates lifetime effects, but still leaves the extra captured-read/Option/C17 consumers unsupported; the unchanged admitted nine-event source is only a baseline, not the requested continuation. Neither is an equivalent completion of this goal.
- A hypothetical source can use existing ref/read/Copy/UNIT-frame primitives without a general graph solver. Prefer the one existing captured proof plus a typed consumer; do not bolt on a second H/owner issuer or pretend a two-H proof covers these five originals.

Static rough estimate, UNMEASURED: about 2–4 P-days for phase-correct owned/read/normal-arm validation with focused OOM plus C17 consumers/native/negative compatibility. The estimate depends on reusing source-issued worlds and existing Unit-frame checks; it is not a multiplied historical per-event estimate or permission to spend that budget. A future Gate0 must first measure the actual diagnostic and determine whether that one-mechanism route holds.

Implementation is DEFERRED pending M/C source selection and a separate explicit execution/implementation release. New owner returns, public issuer/API/ABI, general graph/membership solving, broad Some-world rights, a second proof path or a required weakening of origin/current/loan checks must STOP C. A normal-source unsafe acceptance suspicion must be reported as safety, not hidden as mere coverage. No such runtime finding was observed because execution is forbidden here.

## VALUE-ALIGNMENT-RISK — separate from technical findings

This prepares a causal source-to-native step toward using the still-live list after freeing C. It does not demonstrate early-free/append UAF prevention, an ordinary-safe facade, generic soundness or a smaller author+ordinary-safe-caller UB audit/re-audit dependency closure against factored C/Rust. Exact profile, temporal snapshots and consumer/observer maintenance have real potential cost; runtime, engineering time and product advantage are UNMEASURED. The code reuse question is meaningful without making Product GO a gate for every small compiler step, but a second issuer/general graph design would require a different investment decision. Product GO #624 PAUSED / H1 #268 HOLD.
