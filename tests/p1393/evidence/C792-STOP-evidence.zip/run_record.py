import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parent
name, *command = sys.argv[1:]
if command[:1] == ["--"]:
    command = command[1:]
assert name and command and "/" not in name
logs = root / "logs"
logs.mkdir(exist_ok=True)
record = {"time_JST": datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat(),
          "command": command, "cwd": os.getcwd()}
attempt = logs / (name + ".attempt.json")
with attempt.open("x") as out:
    json.dump(record, out, indent=2)
    out.write("\n")
start = time.monotonic()
with (logs / (name + ".stdout")).open("xb") as out, (logs / (name + ".stderr")).open("xb") as err:
    result = subprocess.run(command, stdout=out, stderr=err)
record.update(status=result.returncode, seconds=time.monotonic()-start)
for stream in ["stdout", "stderr"]:
    p = logs / (name + "." + stream)
    record[stream] = {"bytes": p.stat().st_size, "SHA256": hashlib.sha256(p.read_bytes()).hexdigest()}
with (logs / (name + ".json")).open("x") as out:
    json.dump(record, out, indent=2)
    out.write("\n")
print(json.dumps({"name": name, **record}), flush=True)
if result.returncode:
    print((logs / (name + ".stderr")).read_text(errors="replace")[-6000:], flush=True)
sys.exit(result.returncode)
