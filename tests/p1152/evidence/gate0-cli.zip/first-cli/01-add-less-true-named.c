C228 initial named output must survive rejection
