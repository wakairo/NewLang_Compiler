/* North Star V0/V1/AVS Checked-C reference output. */
#include <stdint.h>

#include <limits.h>
_Static_assert(CHAR_BIT == 8, "NewLang C17 requires 8-bit bytes");
_Static_assert(UINT8_MAX == 255 && sizeof(uint8_t) == 1 && ((uint8_t)-1) == 255, "NewLang C17 requires exact 8-bit uint8_t");
#include <stddef.h>
_Static_assert(SIZE_MAX == UINTMAX_C(18446744073709551615), "NewLang usize target mismatch");

typedef struct { uint8_t f0; uint8_t f1; } nl_type_10;

static void nl_fn_10(void);

static void nl_fn_10(void)
{
    nl_type_10 nl_local_1 = { .f0 = 66, .f1 = 192, };
    (void)nl_local_1;
    const size_t nl_local_2 = ((size_t)UINTMAX_C(3));
    (void)nl_local_2;
    const size_t nl_less_left_12 = nl_local_2;
    const size_t nl_less_right_12 = ((size_t)UINTMAX_C(9));
    const _Bool nl_local_3 = (nl_less_left_12 < nl_less_right_12);
    (void)nl_local_3;
    uint8_t nl_if_result_18;
    if (nl_local_3) {
        uint8_t nl_loan_result_1;
        {
            uint8_t *const nl_local_4 = &nl_local_1.f0;
            (void)nl_local_4;
            const uint8_t nl_replace_old_4 = *nl_local_4;
            *nl_local_4 = 137;
            nl_loan_result_1 = nl_replace_old_4;
        }
        (void)nl_loan_result_1;
        nl_if_result_18 = nl_loan_result_1;
    } else {
        uint8_t nl_loan_result_1;
        {
            uint8_t *const nl_local_4 = &nl_local_1.f0;
            (void)nl_local_4;
            const uint8_t nl_replace_old_4 = *nl_local_4;
            *nl_local_4 = 23;
            nl_loan_result_1 = nl_replace_old_4;
        }
        (void)nl_loan_result_1;
        nl_if_result_18 = nl_loan_result_1;
    }
    const uint8_t nl_local_4 = nl_if_result_18;
    (void)nl_local_4;
    const uint8_t nl_local_5 = nl_local_1.f0;
    (void)nl_local_5;
    const uint8_t nl_local_6 = nl_local_1.f1;
    (void)nl_local_6;
    const uint8_t nl_local_7 = nl_local_4;
    (void)nl_local_7;
    (void)0;
    return;
}

int main(void)
{
    nl_fn_10();
    return 0;
}
