from pathlib import Path
import json,subprocess,re,os,sys
R=Path('/workspace/p1368-c688');S=R/'repo';host=sys.argv[1];out=R/'candidate3';b=R/'builds'/host
f=json.loads((out/'preexecution-freeze.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==f['HEAD'];assert not subprocess.check_output(['git','status','--porcelain'],cwd=S)
CMAKE='/workspace/p1236-c291/tools/cmake/cmake/data/bin/cmake';ctest=str(Path(CMAKE).with_name('ctest'))
selected=json.loads((out/(host+'-related-plan.json')).read_text())['tests']
done=set(re.findall(r'Test\s+#\d+:\s+(\S+)\s+\.{2,}\s+Passed',(out/(host+'-related-unit.raw')).read_text()))
assert len(done)==28 and done<=set(selected)
pending=[n for n in selected if n not in done]
data=json.loads(subprocess.check_output([ctest,'--test-dir',str(b),'--show-only=json-v1'],text=True))
targets=sorted({Path(a).name for t in data['tests'] if t['name'] in pending for a in t.get('command',[]) if Path(a).parent==b and (b/'CMakeFiles'/(Path(a).name+'.dir')).is_dir() and not Path(a).is_file()})
assert set(targets)=={'p1184_signature','p1193_observe'}
retry=out/'impact-retry1';retry.mkdir(exist_ok=True);testfile=retry/(host+'-pending.txt');testfile.write_text('\n'.join(pending)+'\n')
commands=[('build',[CMAKE,'--build',str(b),'--target',*targets,'--parallel','2']),('unit',[ctest,'--test-dir',str(b),'--tests-from-file',str(testfile),'-V','--stop-on-failure','-j1']),('failure-compat',[ctest,'--test-dir',str(b),'-R','^p(1332|1335|1339|1343|1347|1351|1355|1359|1364|1368)_(negative_cli_oom|legacy_C_origin)[.]integration$','-V','--stop-on-failure','-j1'])]
(retry/(host+'-plan.json')).write_text(json.dumps({'HEAD':f['HEAD'],'prior_passed':sorted(done),'pending':pending,'newly_built':targets,'commands':commands},indent=2)+'\n')
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
for label,cmd in commands:
    with (retry/(host+'-'+label+'.raw')).open('xb') as log:q=subprocess.run(cmd,cwd=S,env=env,stdout=log,stderr=subprocess.STDOUT)
    print(host,'impact recovery',label,q.returncode,'pending',len(pending),flush=True)
    if q.returncode:
        print((retry/(host+'-'+label+'.raw')).read_text(errors='replace')[-5000:],flush=True);raise SystemExit(q.returncode)
print(host,'all119 impact units + failure/compat PASS; no repeated28',flush=True)
