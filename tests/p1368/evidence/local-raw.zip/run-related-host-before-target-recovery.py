import pathlib,json,subprocess,sys,re,os
R=pathlib.Path('/workspace/p1368-c688');S=R/'repo';host=sys.argv[1];candidate=sys.argv[2] if len(sys.argv)>2 else 'candidate3';out=R/candidate;b=R/'builds'/host
f=json.loads((out/'preexecution-freeze.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==f['HEAD']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=S)
CMAKE='/workspace/p1236-c291/tools/cmake/cmake/data/bin/cmake';ctest=str(pathlib.Path(CMAKE).with_name('ctest'))
data=json.loads(subprocess.check_output([ctest,'--test-dir',str(b),'--show-only=json-v1'],text=True))
pattern=r'^(p1117_.*(lineage|current)|p(633|785|790|817|1184|1193|1332|1335|1339|1343|1347|1351|1355|1359|1364)_.*)[.]unit$'
selected=[t for t in data['tests'] if re.search(pattern,t['name'])]
commands={m[1]:m[2] for m in re.finditer(r'add_test\(\[=\[(.*?)\]=\]\s+"([^"]+)"',(b/'CTestTestfile.cmake').read_text())}
targets=sorted({pathlib.Path(commands[t['name']]).name for t in selected if pathlib.Path(commands[t['name']]).parent==b})
assert targets and len(selected)>=85
cmds=[('related-build',[CMAKE,'--build',str(b),'--target',*targets,'--parallel','2']),('related-unit',[ctest,'--test-dir',str(b),'-R',pattern,'-V','--stop-on-failure','-j1']),('failure-compat',[ctest,'--test-dir',str(b),'-R','^p(1332|1335|1339|1343|1347|1351|1355|1359|1364|1368)_(negative_cli_oom|legacy_C_origin)[.]integration$','-V','--stop-on-failure','-j1'])]
(out/(host+'-related-plan.json')).write_text(json.dumps({'HEAD':f['HEAD'],'unit_count':len(selected),'tests':[t['name'] for t in selected],'commands':cmds},indent=2)+'\n')
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
for label,cmd in cmds:
    with (out/(host+'-'+label+'.raw')).open('xb') as log:q=subprocess.run(cmd,cwd=S,env=env,stdout=log,stderr=subprocess.STDOUT)
    print(host,label,q.returncode,'selected',len(selected),flush=True)
    if q.returncode:
        print((out/(host+'-'+label+'.raw')).read_text(errors='replace')[-5000:],flush=True);raise SystemExit(q.returncode)
print(host,'related PASS',flush=True)
