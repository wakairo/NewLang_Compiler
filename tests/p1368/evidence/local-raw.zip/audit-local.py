from pathlib import Path
import json,re,hashlib,subprocess
R=Path('/workspace/p1368-c688');S=R/'repo';out=R/'candidate3';f=json.loads((out/'preexecution-freeze.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==f['HEAD'];assert not subprocess.check_output(['git','status','--porcelain'],cwd=S)
for n,h in f['files'].items():assert hashlib.sha256((S/n).read_bytes()).hexdigest()==h,n
passed=lambda s:re.findall(r'Test\s+#\d+:\s+(\S+)\s+\.{2,}\s+Passed',s)
hosts=[]
for host in ('gcc','asan','ubsan'):
    stage=out if host=='gcc' else out/'apparatus-retry1'
    p=stage/(host+'-StageA.raw');raw=p.read_text();assert '100% tests passed, 0 tests failed out of 8' in raw
    before=(out/(host+'-related-unit.raw')).read_text();after=(out/'impact-retry1'/(host+'-unit.raw')).read_text()
    a=passed(before);b=passed(after);expected=json.loads((out/(host+'-related-plan.json')).read_text())['tests']
    assert len(a)==28 and len(b)==91 and not(set(a)&set(b)) and set(a+b)==set(expected)
    q=out/'impact-retry1'/(host+'-failure-compat.raw');assert len(passed(q.read_text()))==15 and '100% tests passed' in q.read_text()
    hosts.append({'host':host,'new_units':8,'impact_units':119,'impact_completed_attempts':[28,91],'failure_compat':15,'ELF':json.loads((stage/(host+'-ELF.json')).read_text()),'StageA_raw_SHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'impact_retry_SHA256':hashlib.sha256((out/'impact-retry1'/(host+'-unit.raw')).read_bytes()).hexdigest(),'failure_compat_SHA256':hashlib.sha256(q.read_bytes()).hexdigest()})
rows=[]
for mode in ('gcc','clang','asan','ubsan'):
    dirs=list((out/(mode+'-guest')).glob('native-*'));assert len(dirs)==1;d=dirs[0]
    attempts=json.loads((d/'guest-attempts.json').read_text());assert len(attempts)==(8 if mode in ('gcc','clang') else 2) and all(a['status']==0 for a in attempts)
    crows=[]
    for index,name in [(1,'A-current-copy-call'),(0,'B-field-zero-alias')]:
        p=d/(name+'.c');s=p.read_text()
        helper=re.search(r'static uint8_t (nl_fn_\d+)\(uint8_t (nl_local_\d+)\)\n\{\n(.*?)\n\}\n',s,re.S)
        main=re.search(r'static void nl_fn_\d+\(void\)\n\{\n(.*?)\n\}\n',s,re.S);assert helper and main
        hbind=dict(re.findall(r'const uint8_t (nl_local_\d+) = (nl_local_\d+);',helper[3]));ret=re.search(r'return (nl_local_\d+);',helper[3]);assert ret
        current=ret[1]
        for _ in range(len(hbind)+1):
            if current==helper[2]:break
            assert current in hbind;current=hbind[current]
        assert current==helper[2]
        body=main[1];read=re.search(r'const uint8_t (nl_local_\d+) = (nl_local_\d+)\.f'+str(index)+r';',body);assert read
        call=re.search(r'const uint8_t (nl_local_\d+) = '+helper[1]+r'\('+read[1]+r'\);',body);assert call
        aftercall=body[call.end():];store=re.search(r'\*(nl_local_\d+) = (nl_local_\d+);',aftercall);assert store
        ptrs={a:(b,int(i)) for a,b,i in re.findall(r'uint8_t \*(?:const )?(nl_local_\d+) = &(nl_local_\d+)\.f([01]);',body)}
        assert ptrs[store[1]]==(read[2],index)
        bindings=dict(re.findall(r'const uint8_t (nl_local_\d+) = (nl_local_\d+);',aftercall[:store.start()]));incoming=store[2];chain=[incoming]
        for _ in range(len(bindings)+1):
            if incoming==call[1]:break
            assert incoming in bindings;incoming=bindings[incoming];chain.append(incoming)
        assert incoming==call[1]
        crows.append({'source':name,'C_SHA256':hashlib.sha256(p.read_bytes()).hexdigest(),'read':read[1],'original':read[2],'field_index':index,'real_call':helper[1],'returned_binding':call[1],'store_Copy_chain':chain,'stored_to_same_original':True,'callee_return_traces_to_actual_formal':True})
    rows.append({'mode':mode,'guests':len(attempts),'C':crows,'raw_SHA256':hashlib.sha256((out/(mode+'-native.raw')).read_bytes()).hexdigest(),'attempts_SHA256':hashlib.sha256((d/'guest-attempts.json').read_bytes()).hexdigest()})
assert sum(x['guests'] for x in rows)==20
for i in range(2):assert len({x['C'][i]['C_SHA256'] for x in rows})==1
summary={'HEAD':f['HEAD'],'tree':f['tree'],'oracle_SHA256':f['oracle_SHA256'],'hosts':hosts,'native':rows,'registration_OOM':{'A_census':880,'B_census':922,'clones':23,'plans':2,'selected_per_source':11,'exhaustive':False},'actual_OOM':{'A_census':955,'B_census':985,'clones':31,'finished_seals':1,'selected_per_source':10,'exhaustive':False},'legacy_C_cases':20,'public_validator_OOM':'no allocating replay protocol added; registration/actual and CLI emitter selected OOM measured, no exhaustive validator allocation claim','Prod_source_test_inputs_unchanged':True}
(out/'LOCAL-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'hosts':[{k:v for k,v in h.items() if k in ('host','new_units','impact_units','failure_compat')} for h in hosts],'guest':20,'C':rows[0]['C'],'summary_SHA256':hashlib.sha256((out/'LOCAL-summary.json').read_bytes()).hexdigest()}))
