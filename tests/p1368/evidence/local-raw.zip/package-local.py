from pathlib import Path
import datetime, hashlib, json, subprocess, zipfile

R = Path('/workspace/p1368-c688')
S = R / 'repo'
out = S / 'tests/p1368/evidence'
freeze = json.loads((R / 'candidate3/preexecution-freeze.json').read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=S, text=True).strip() == freeze['HEAD']
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=S, text=True).strip() == '?? tests/p1368/README.md'
for name, digest in freeze['files'].items():
    assert sha(S / name) == digest, name
registration = json.loads((R / 'candidate3/test-registration.json').read_text())
assert registration['total'] == 962 and len(registration['new_tests']) == 11
ci = json.loads((R / 'main-ci/receipt.json').read_text())
base_names = set(next(r['name_set'] for r in ci if r['tests'] == 953))
assert base_names - set(registration['all_tests']) == {
    't991_contract_accept.integration', 't991_contract_reject.integration'}
assert set(registration['all_tests']) - base_names == set(registration['new_tests'])
rows = {}
for dirname in ('baseline', 'candidate1', 'candidate2', 'candidate3', 'main-ci'):
    for p in sorted((R / dirname).rglob('*')):
        if p.is_file():
            assert not p.is_symlink()
            rows[str(p.relative_to(R))] = p
for name in ('source-freeze.json', 'authority-local-final.json',
             'apparatus-inode-recovery.json', 'old-derived-build-configs.zip',
             'run-host.py', 'run-host-before-inode-retry.py',
             'run-related-host.py', 'run-related-host-before-target-recovery.py',
             'recover-impact.py', 'run-native.py', 'audit-local.py', 'package-local.py'):
    rows[name] = R / name
for name in freeze['files']:
    rows['tested-input/' + name] = S / name
for name in ('P1366-C676-source-first.zip', 'FIRST.json', 'FINAL.json',
             'oracle.json', 'preexecution-freeze.json'):
    rows['preserved-P1366/' + name] = Path('/workspace/p1366-c676') / name
manifest = {name: {'bytes': p.stat().st_size, 'SHA256': sha(p)} for name, p in rows.items()}
out.mkdir()
packet = out / 'local-raw.zip'
with zipfile.ZipFile(packet, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for name, p in rows.items():
        z.write(p, name)
    z.writestr('MANIFEST.json', json.dumps(manifest, indent=2) + '\n')
with zipfile.ZipFile(packet) as z:
    assert z.testzip() is None
    for name, entry in manifest.items():
        b = z.read(name)
        assert len(b) == entry['bytes'] and hashlib.sha256(b).hexdigest() == entry['SHA256']
summary = json.loads((R / 'candidate3/LOCAL-summary.json').read_text())
final = {
    'time_JST': datetime.datetime.now(datetime.timezone(datetime.timedelta(hours=9))).isoformat(),
    'issue': 1368,
    'authority': {'base_main': 'bbeec928b9ccdaaab0dd083dee7681bc3f07b88b',
                  'base_tree': '63afc0af7f508b9f9aed592b344bc53b2ac3ea3b',
                  'canonical': 'CURRENT_SPEC -> Draft17.35', 'Coordination': ['C688', 'C692']},
    'status': 'LOCAL Stage A + Stage B PASS; publication and new-head CI NOT_RUN',
    'tested_HEAD': freeze['HEAD'], 'tested_tree': freeze['tree'],
    'tested_inputs': freeze['files'],
    'preexecution_freeze_SHA256': sha(R / 'candidate3/preexecution-freeze.json'),
    'source_freeze_SHA256': sha(R / 'source-freeze.json'),
    'baseline_FIRST_SHA256': sha(R / 'baseline/FIRST.json'),
    'preserved_P1366_FIRST_SHA256': sha(Path('/workspace/p1366-c676/FIRST.json')),
    'results': summary,
    'summary_SHA256': sha(R / 'candidate3/LOCAL-summary.json'),
    'registration': {'local_total': 962, 'new_tests': registration['new_tests'],
                     'CI_expected_full': 964, 'CI_expected_partial': 963,
                     'local_unregistered_CI_tooling': ['t991_contract_accept.integration',
                                                     't991_contract_reject.integration']},
    'base_main_original_CI': [{k: r[k] for k in ('job', 'name', 'run', 'checkout', 'tests', 'raw_SHA256')}
                              for r in ci],
    'base_main_CI_receipt_SHA256': sha(R / 'main-ci/receipt.json'),
    'apparatus': {
        'inode_exhaustion': 'Original configure RED retained; archived configs, removed only regenerable old CMake files; same three host tuples retry PASS.',
        'inode_receipt_SHA256': sha(R / 'apparatus-inode-recovery.json'),
        'impact_dependency_omission': 'Each host first 28 PASS, then unexecuted missing wrapped executable. Built p1184_signature/p1193_observe and executed only remaining 91 PASS.',
        'impact_FIRST_SHA256': sha(R / 'candidate3/impact-apparatus-FIRST.json'),
        'static_C_audit': 'External read-only pointer regex corrected. No generated C/source/native rerun or change.',
        'static_C_audit_receipt_SHA256': sha(R / 'candidate3/static-C-audit-apparatus-FIRST.json'),
        'registration_count': 'An unfinished packaging preflight expected CI964 locally; actual local962 is exactly CI minus the two opt-in T991 tooling tests. No packet existed; no compiler/test failure or changed registration.'},
    'self_review': {
        'signature': 'Origin allocation pointer and count preflight retained before scalar body traversal.',
        'custody': 'Canonical destruction untouched; no new owning pointer or proof/certificate issuer.',
        'dataflow': 'Exact current field read, fresh u8 formal, normal Copy alias tail, returned actual call value, same-original scoped store.',
        'world': 'Helper graph is final iteration world, never a pre-call snapshot; existing header/frame/loan/exit relation enforces closure.',
        'legacy': 'Existing usize/IF operand mode remains distinct; 20 old C outputs byte-identical on every producer host.',
        'independence': 'No independent F/R inputs, review, source or oracle read or reused.'},
    'budget': {'functional_implementations': 1, 'fixed_hashes_before_evidence_commit': 3,
               'host_configurations': 3, 'guest_attempts': 20,
               'remote_push_PR_new_CI_at_local_final': 0,
               'preserved_prebuild_unexecuted_hashes': [
                   'f9bed1861ab94ed09ebfa140da0cc5a2d15d1ba8',
                   'a78df42959b9b72b7fbebf60750e3736b994ed3b']},
    'not_claimed': ['exhaustive OOM', 'wrapper/inner-loop B', 'extra originals/formals',
                    'helper nested calls/effects/RETURN/IF extensions', 'general CFG',
                    'universal soundness', 'Product PASS', 'new-head CI success', 'independent F1 result'],
    'VALUE_ALIGNMENT_RISK': 'One shared private authentication mechanism and finite reusable source capability; maintenance grew but no profile-specific authority. Audit-locality and practical C-target value remain unproved. Product GO PAUSED / H1 HOLD.',
    'evidence_packet': {'path': 'local-raw.zip', 'bytes': packet.stat().st_size,
                        'entries': len(manifest) + 1, 'SHA256': sha(packet)}
}
(out / 'LOCAL-FINAL.json').write_text(json.dumps(final, indent=2) + '\n')
print(json.dumps({'packet': final['evidence_packet'],
                  'LOCAL_FINAL_SHA256': sha(out / 'LOCAL-FINAL.json'),
                  'tested_input_files': len(freeze['files'])}))
