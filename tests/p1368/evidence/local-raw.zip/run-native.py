import pathlib,json,subprocess,os,sys,hashlib
R=pathlib.Path('/workspace/p1368-c688');S=R/'repo';mode=sys.argv[1];candidate=sys.argv[2] if len(sys.argv)>2 else 'candidate3';out=R/candidate
f=json.loads((out/'preexecution-freeze.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=S,text=True).strip()==f['HEAD'];assert not subprocess.check_output(['git','status','--porcelain'],cwd=S)
producer='gcc' if mode in ('gcc','clang') else mode
CC='/usr/bin/gcc' if mode=='gcc' else '/workspace/p1295-c439/tools/clang19/clang'
san={'gcc':'none','clang':'none','asan':'address','ubsan':'undefined'}[mode]
binary=R/'builds'/producer/'newlangc';cmd=['python3',str(S/'tests/p1368/native.py'),str(binary),CC,str(out/(mode+'-guest')),san]
receipt={'HEAD':f['HEAD'],'producer':producer,'ELF_SHA256':hashlib.sha256(binary.read_bytes()).hexdigest(),'command':cmd,'maximum_guest_this_mode':8 if san=='none' else 2}
(out/(mode+'-native-plan.json')).write_text(json.dumps(receipt,indent=2)+'\n')
env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:halt_on_error=1',UBSAN_OPTIONS='halt_on_error=1:print_stacktrace=1')
with (out/(mode+'-native.raw')).open('xb') as log:q=subprocess.run(cmd,cwd=S,env=env,stdout=log,stderr=subprocess.STDOUT)
print(mode,'native status',q.returncode,flush=True)
if q.returncode:print((out/(mode+'-native.raw')).read_text(errors='replace')[-5000:],flush=True)
raise SystemExit(q.returncode)
