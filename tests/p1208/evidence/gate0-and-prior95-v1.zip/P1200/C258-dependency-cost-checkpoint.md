# P1200 C258 bounded continuation scout

Date: 2026-11-06 UTC  
Track: P (Production Compiler)  
Disposition: dependency/cost decision only; no implementation authorization used

## Fixed authority and custody

- Scout baseline: published but unadopted PR1199 HEAD
  `0fd24ad3ed08c51845819aab48506c9d43fdccf6`.
- Sole parent: `24339b077ed0e0a3e847f23aed170c67d2b3d20a`.
- Tree: `121ca6c13b81768c9c1b854a5d72d76841f6df10`.
- Adopted main remains
  `53c125b8cd66523651a21e803827eff6d2a06428`; canonical
  `CURRENT_SPEC -> NewLang_v0_spec_Draft17_34.md`.
- Clean worktree: `/tmp/p1193-c256`, branch
  `p-c256-return-call-normal`.
- Existing exact repaired compiler (not executed by this scout):
  `/tmp/p1193-c256-gcc-clean/newlangc`, 1,999,216 bytes, SHA256
  `2cd50ff9ec674f8fae963f2e6696dbef910ba346371f2ae80c460fe4d4fa8ce5`.
- PR1199 remains open, mergeable, and DRAFT/HOLD. Its branch budget is
  exhausted at 12/12 actual jobs, manual0. This scout made no change to it.
- Original source/oracle/FIRST/raw/packets/refs were read only. No R input or
  report was opened.

The preserved legal boundary source is
`tests/p1193/production/95-mixed-result-binding.nl`, SHA256
`f3b329eefb5e989815dcf8b79eb019df60328577653c9d6797c8803f07da3c57`.
Its enrolled evidence already establishes all three CLI refusals at definition
CHECK with `P14-LOOP-PRECISION`, empty stdout, named-output byte/inode/mtime
no-clobber, and a separate genuine sole-normal call result observation. It was
not rerun. The earlier stderr SHA256
`044c0f48fcf3d235225d7daeb61550db50c7e507c13d45c4e5e16fdd5b1032ea`
belongs to the P1188 predecessor FIRST, not to source 95.

Scout counters: new probes 0/4; CLI/proof/C17 queries 0/24; Production/spec
edits0; builds0; native0; regression/sanitizer/OOM0; remote branch/push/PR/CI0.

## Decision

**Bounded existing-machinery reuse: YES.** The desired finite source family can
be connected without a new public issuer, API/ABI, semantic rule, graph family,
or general world mechanism. This is a code-derived design result, not an
implemented or executed PASS. A later implementation release must confirm it.

The missing layer is a shared private representation of this already checked
fact:

1. the IF has exactly one genuine normal arm and one genuine lexical RETURN;
2. the normal result is the CHECK-issued replay result in the parent world;
3. ordinary dependency-free u8 binding/Copy nodes consume that result;
4. the body finishes with either an ordinary normal u8 result or a real outer
   explicit RETURN; and
5. the early-return edge remains terminated and never becomes a normal edge.

The core semantic checker already supplies these facts. `source_if` checks both
forked arms, unions their exits, and replays only the actual sole-normal arm in
the parent world through `nl_if_return_begin/finish`. It does not select a
condition or invent a second normal result. The reusable private predicate walk
also source-matches the real arm and its replay nodes.

The current first refusal is deliberate in `nl_pure_u8_body`: when an IF has a
RETURN edge, it requires the body tail to be the IF itself. The current-proof
consumer and C17 emitter therefore never receive a common description of a
mixed IF followed by ordinary result use.

## Smallest shared private contract

Extend the private pure-u8 walk to produce a transient, allocation-free plan
(either an extension of `NLPureU8Call` or a sibling private structure) with:

- the authenticated body, formal, function, IF node, and arm fragments;
- the exact normal-arm index and returning-arm index;
- the CHECK-issued normal replay result/value and its source node;
- the exact continuation binding/Copy chain already consumed by the predicate
  walker;
- final mode: normal body tail or explicit body RETURN;
- the expected ordered body-exit count and final RETURN ordinal.

All three consumers should use or recompute this same plan from the actual
owned graph. Equal node/value IDs across worlds are insufficient. The plan must
retain the existing source spans, lexical callee target, result package,
function body/source/signature, current caller argument origin, and per-world
signature authentication checks. It need not be retained in public proof state
and should not allocate.

### Checker changes

- Remove the tail-only restriction only for exactly one normal arm.
- Continue walking ordinary dependency-free u8 binding/Copy nodes under the
  existing node/depth/entry bounds.
- For a normal final result, require the one existing early body RETURN exit and
  the actual final u8 result.
- For an explicit final RETURN, require two ordered body exits: the early arm
  RETURN at ordinal 0 and the outer final RETURN at ordinal 1. Validate the
  outer RETURN node, target, result, and body summary exactly.
- Keep both-RETURN continuation rejected: it has no normal value to bind.

### Current-proof changes

`current_return_refs` already retains two records for one returning arm: its
leaf exit and the enclosing body-union exit. Generalize its outer-final-RETURN
case so it appends the actual body RETURN at ordinal `joined`, instead of
requiring `normal_arms == 2` and hard-coding ordinal 0.

- mixed IF + normal final result: 2 records, unchanged from the current
  one-return-arm shape;
- mixed IF + explicit final RETURN: 3 records;
- existing both-RETURN tail: 4 records, unchanged.

The fixed four-record limit and signature slots 12..15 already cover this.
`current_pure_call`, caller binding/Copy propagation, the original-T writer,
Continue/Break authentication, and public result receipt need no new authority.

### C17 changes

The current tail-only emitter can write one conditional `return`, while the
generic IF-binding emitter assumes both arms are normal. Add one private
branch-aware emission helper for a validated mixed-IF binding with continuation:

1. declare the result local before the branch;
2. evaluate the authenticated condition once;
3. emit the actual returning arm as `return <literal>;`;
4. assign the actual sole-normal literal to the result local in the other arm;
5. continue through existing ordinary binding/Copy emission and the existing
   normal or explicit final result emitter.

This preserves the original RETURN path. It does not synthesize a join on that
path. Keep existing tail-only emission on its current path to preserve its C17
bytes unless a separately justified cleanup is made.

## Proposed finite support boundary

Supported in a later implementation stage:

- one known-direct, dependency-free pure `usize -> u8` helper;
- one LT or EQ IF with literal u8 outcomes;
- exactly one arm has a lexical RETURN and the other is the genuine normal arm;
- the normal result flows through ordinary dependency-free u8 bindings/Copy
  accepted by the existing bounded predicate walker;
- the helper ends in either a normal u8 tail or one explicit final RETURN;
- the call remains inside the existing authenticated original-T current-loop
  envelope with its existing argument-Copy, writer, Continue/Break, sibling,
  and physical-original obligations.

Still unsupported/fail-closed:

- continuation after both arms RETURN;
- nested or multiple IFs/helpers, nonliteral arm results, calls/effects in the
  continuation, branch-local state effects, loans/references/nonCopy values;
- general normal/RETURN joins, general CFG/cyclic inference, a standalone
  published RETURN issuer, or any general world mechanism;
- source/API/ABI/semantic changes.

## Ownership, failure, and cleanup

The proposed plan is transient and borrows the checked graph. The existing
`CurrentReturnRef` records continue to borrow core-owned exit states. The
`CurrentReturnSeal` array owns only its existing cloned contexts and anchors.
`return_count` is set before the per-record anchor loop, so existing destruction
releases every successfully built prefix once on failure. Canonical or foreign
function signatures and exit states remain borrowed and are never freed by the
proof.

No new allocation site is expected. The explicit-final variant adds one more
iteration through existing record-array sizing, context clone/anchor creation,
signature-ledger capture, validation, and destruction. A later implementation
must re-census reached OOM for the larger array and the added clone/anchor
iteration, verify partial cleanup and same-context retry, preserve named-output
no-clobber, and retain the repaired all-function signature preflight before
content reads.

## Concrete cost projection

Measured repaired-head baselines, reused without execution:

| shape | records | record bytes | clone-owned bytes | anchor bytes | total RETURN authentication |
|---|---:|---:|---:|---:|---:|
| one retained record | 1 | 608 | 29,204 | 21,912 | 51,724 |
| one returning arm | 2 | 1,216 | 58,408 | 43,824 | 103,448 |
| current maximum | 4 | 2,432 | 116,816 | 87,648 | 206,896 |

- Mixed + normal final remains two records. Its record/anchor cardinality is
  unchanged, but its cloned context contains added continuation nodes/bindings,
  so 103,448 bytes is a baseline, not a measured total for the new source.
- Mixed + explicit final uses three records. Linear projection from the current
  cohort is 1,824 + 87,612 + 65,736 = **155,172 bytes**, before any growth in
  the cloned worlds caused by the continuation.
- Graph count remains unchanged. The proof's fixed arrays and four-record cap
  do not grow. The transient plan can be allocation-free.
- The repaired signature ledger adds one existing world slice for the third
  record. Its exact growth is
  `function_count * sizeof(CurrentSignatureOrigin)`; with the measured
  11-function cohort this projects to 176 bytes. This is not a new allocation
  site or a new observed source census.
- Validation adds one bounded exit/world/signature comparison for the explicit
  final case. Normal-final adds continuation-node walks but no return record.

Expected implementation size is about 80-140 Production lines across the same
three private files (`pure_u8_internal.h`, `current_loop_check_internal.h`, and
`main.c`), plus focused tests and prospective history enrollment. Estimated
engineering cost is about half a focused P day for implementation and focused
validation, followed by roughly another half to one P day for the authorized
full local safety/regression/native/history gates. These are planning estimates,
not authorization or observed completion.

## Later implementation test plan

Preserve source95, its oracle, and FIRST as historical evidence. Add a new
versioned prospective freeze rather than rewriting that evidence.

1. Four positives: RETURN left/right, each with normal final and explicit final
   RETURN, all with a real binding/Copy continuation.
2. Focused negatives: both-RETURN continuation, nested/effectful/nonliteral
   continuation, wrong exit target/ordinal/source/result/world, signature and
   current-state mutation, and named-output no-clobber.
3. Existing tail-only and two-normal helper C17 byte preservation.
4. Current proof, same physical original T, old Copy, postcurrent, sibling,
   Continue/Break, both runtime branch outcomes, GCC/Clang strict C17 O0/O2.
5. Reached OOM for three-record construction, clone/anchor partial cleanup,
   repaired signature ledger, rollback/retry, sanitizer, full frontend, and
   prospective history gates.

## Alternatives and STOP boundary

- **Current tail-only source arrangement:** zero implementation cost and already
  safe, but it requires source refactoring and leaves ordinary helper-body
  composition unsupported.
- **Bounded shared continuation (recommended next increment):** reuses genuine
  CHECK replay, current records, signature ledger, and emitter primitives with
  finite cost and no new authority.
- **General CFG/world/issuer mechanism:** not required by current evidence. If
  implementation discovers it is necessary, or retention/maintenance grows
  materially beyond this projection, STOP and return to Coordination.

## VALUE-ALIGNMENT-RISK

This would add a reusable selected-semantics composition, but it also adds a
branch-aware private contract, one more possible retained snapshot, more
signature-ledger dependencies, tests, and versioned evidence maintenance.
Keeping the checker/current/emitter plan shared is necessary to avoid three
divergent fixture-shaped gates. Even a successful finite implementation would
be capability evidence only. It would not establish general soundness, a
smaller human UB-prevention audit dependency closure, an ordinary-safe library,
or Product PASS. Audit locality remains UNMEASURED; GO624 PAUSED, H1 HOLD, and
P1036/PR1050 STOP remain.
