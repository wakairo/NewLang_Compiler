from pathlib import Path
import hashlib,json,subprocess

repo=Path('/tmp/p1208-c263')
here=repo/'tests/p1208'
raw=Path('/tmp/p1208-records/gate0')
compiler=Path('/tmp/p1193-c256-gcc-clean/newlangc')
assert hashlib.sha256(compiler.read_bytes()).hexdigest()=='2cd50ff9ec674f8fae963f2e6696dbef910ba346371f2ae80c460fe4d4fa8ce5'
for version in (1,2):
 f=json.loads((here/f'source-freeze-v{version}.json').read_text())
 for name,digest in f['files'].items():
  assert hashlib.sha256((here/name).read_bytes()).hexdigest()==digest,name
oracle=json.loads((here/'oracle-v2.json').read_text())
rows=[]
for name,meta in oracle['profiles'].items():
 source=here/'sources'/f'{name}.nl'
 for tag,args in [('check',[str(compiler),'--check',str(source)]),('c17',[str(compiler),str(source)])]:
  result=subprocess.run(args,capture_output=True,timeout=60)
  prefix=raw/f'{name}-{tag}'
  prefix.with_suffix('.out').write_bytes(result.stdout)
  prefix.with_suffix('.err').write_bytes(result.stderr)
  rows.append({'profile':name,'operation':tag,'args':args,'status':result.returncode,
   'stdout_bytes':len(result.stdout),'stdout_sha256':hashlib.sha256(result.stdout).hexdigest(),
   'stderr_sha256':hashlib.sha256(result.stderr).hexdigest()})
  (raw/'observations-v1.json').write_text(json.dumps(rows,indent=2)+'\n')
  assert result.returncode==meta['baseline_check'],rows[-1]
  if meta['baseline_check']:
   assert not result.stdout,rows[-1]
  elif tag=='c17':
   assert result.stdout.startswith(b'/*') or b'#include <stdint.h>' in result.stdout
 print(name,rows[-2]['status'],rows[-1]['status'],flush=True)
print('Gate0 baseline CLI observations',len(rows),'native0')
