from pathlib import Path
import json,hashlib,subprocess
p=Path(__file__).resolve().parent;f=json.loads((p/'freeze.json').read_bytes())
for name,digest in f['files'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
raw=p/'raw';raw.mkdir(exist_ok=False);rows=[]
def run(cmd,name):
    cmd=list(map(str,cmd));r=subprocess.run(cmd,capture_output=True,timeout=1200)
    (raw/(name+'.out')).write_bytes(r.stdout);(raw/(name+'.err')).write_bytes(r.stderr)
    rows.append(dict(name=name,command=cmd,status=r.returncode,stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest()))
    (raw/'observations.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(name,r.returncode,flush=True);return r
sources=Path('/tmp/p1123-c219-gate0/sources');compiler=Path('/tmp/p1123-c220-inputs-v2/newlangc')
expected=json.loads(Path('/tmp/p1123-c219-gate0/oracle-v2.json').read_bytes())['cases']
for case in ['05-flat-header-control','06-equal-bits-continue','07-extra-source-continue','08-wrong-carry-type','09-wrong-carry-arity','10-ending-loan','12-no-nearest-target']:
    source=sources/(case+'.nl');e=expected[case]['predicted_parent']
    check=run([compiler,'--check',source],case+'-check')
    if 'check' in e:assert check.returncode==e['check']
    else:assert check.returncode in [2,3]
    output=raw/(case+'.c');sentinel=b'P1123 keep exact negative bytes\x00\xff\n';output.write_bytes(sentinel);before=output.stat()
    emit=run([compiler,'--emit-c17-to',output,source],case+'-named')
    assert emit.returncode==e.get('emit',check.returncode) and not emit.stdout
    assert output.read_bytes()==sentinel
    after=output.stat();assert (before.st_ino,before.st_mtime_ns)==(after.st_ino,after.st_mtime_ns)
    assert not list(raw.glob('.'+output.name+'*.tmp*'))
    if 'diagnostic' in e:assert e['diagnostic'].encode() in (check.stderr+emit.stderr)
for case in ['03-zero-less-control','04-zero-equality-control']:
    r=run([compiler,sources/(case+'.nl')],case+'-unchanged-c17');assert r.returncode==0 and not r.stderr
    old=list(Path('/tmp/p1123-c219-gate0/raw-v2').glob('*'+case+'-c17.out'));assert len(old)==1
    assert old[0].read_bytes()==r.stdout
positive=[sources/(n+'.nl') for n in ['01-stutter-less','02-stutter-equality','11-prefix-current']]
positive += [Path('/tmp/p1123-c220-native-v1/sources')/(n+'.nl') for n in ['13-reversed-arms','14-first-break']]
for source in positive:
    r=run([p/'probe',source],source.stem+'-expanded-negative');assert r.returncode==0 and not r.stderr
    assert b'genuine public Copy GET/current0' in r.stdout and b'cardinality canonical cleanup PASS' in r.stdout
for source in positive[:3]:
    r=run([p/'oom',source],source.stem+'-all-reached-oom');assert r.returncode==0
    assert b'rollback/no-publication/current retry PASS' in r.stdout and b'exact bytes/inode/mtime/temp/retry PASS' in r.stdout
print('C220 public/current/negative/canonical ownership/named-byte/OOM complete')
