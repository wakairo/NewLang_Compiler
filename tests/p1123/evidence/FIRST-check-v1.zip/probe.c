#define main p1123_cli_main
#include "main.c"
#undef main
#include <assert.h>

typedef struct {
  NLSource *source, *entry_source;
  NLParser *parser, *entry_parser;
  NLSyntaxTree *tree, *entry_tree;
  NLSemanticContext *world;
  NLCheckedFragment *root;
  NLCheckedFragment *owner, *graph;
  NLCheckedNodeId loop;
} Input;
static void dispose(Input *a) {
  nl_checked_destroy(a->root);
  nl_semantic_destroy(a->world);
  nl_syntax_tree_destroy(a->entry_tree);
  nl_parser_destroy(a->entry_parser);
  nl_source_destroy(a->entry_source);
  nl_syntax_tree_destroy(a->tree);
  nl_parser_destroy(a->parser);
  nl_source_destroy(a->source);
}
static void prepare(Input *a, const char *path) {
  assert(nl_source_load(path, &a->source) == NL_SOURCE_OK);
  assert(nl_parser_create(a->source, &a->parser) == NL_PARSE_OK);
  assert(nl_parser_parse_function_unit(a->parser, &a->tree, NULL) ==
         NL_PARSE_OK);
  assert(nl_semantic_create(&a->world) == NL_CHECK_OK);
  const NLSyntaxTree *units[] = {a->tree};
  NLFunctionUnitDiagnostic diagnostic = {0};
  NLCheckStatus status =
      nl_semantic_register_function_unit(a->world, units, 1, &diagnostic);
  printf("C220 REGISTER=%d\n", status);
  if (status != NL_CHECK_OK)
    (void)nl_check_diagnostic_render(stderr, a->source, &diagnostic.diagnostic);
  assert(status == NL_CHECK_OK);
  assert(nl_source_create("main()", 6, "C220-actual-entry", &a->entry_source) ==
         NL_SOURCE_OK);
  assert(nl_parser_create(a->entry_source, &a->entry_parser) == NL_PARSE_OK);
  assert(nl_parser_parse_expression_fragment(a->entry_parser, &a->entry_tree,
                                             NULL) == NL_PARSE_OK);
  status =
      nl_semantic_check_expression(a->world, a->entry_tree, &a->root, NULL);
  printf("C220 INVOKE=%d\n", status);
  assert(status == NL_CHECK_OK);
  a->owner = (NLCheckedFragment *)nl_checked_call_body(
      a->root, nl_checked_root(a->root));
  assert(a->owner);
  for (size_t i = 1; i <= a->owner->count; ++i)
    if (a->owner->nodes[i - 1].kind == NL_CHECKED_LOOP) {
      assert(!a->loop);
      a->loop = i;
    }
  assert(a->loop);
  a->graph = (NLCheckedFragment *)nl_checked_loop_body(a->owner, a->loop);
  assert(a->graph);
}
static bool valid(Input *a) {
  NLLinearBreakView proof = {0};
  if (nl_linear_break_validate(a->owner, a->loop, &proof) != NL_CHECK_OK ||
      !proof.stuttering)
    return false;
  V0Program p = {.unit = nl_semantic_unit_type(a->world),
                 .u8 = nl_semantic_core_type(a->world, NL_TYPE_U8)};
  return v0_validate_call(a->root, nl_checked_root(a->root), &p);
}
int main(int argc, char **argv) {
  assert(argc == 2);
  setvbuf(stdout, NULL, _IONBF, 0);
  Input a = {0}, b = {0};
  prepare(&a, argv[1]);
  NLLinearBreakView proof = {0};
  NLCheckStatus status = nl_linear_break_validate(a.owner, a.loop, &proof);
  printf("C220 PRIVATE=%d stuttering=%d base=%zu field=%zu old-id=%zu "
         "incoming=%zu phase=%zu,%zu limit=%zu\n",
         status, proof.stuttering, proof.base, proof.index, proof.result.value,
         proof.incoming, proof.initial_phase, proof.next_phase, proof.limit);
  assert(status == NL_CHECK_OK && proof.stuttering && valid(&a));
  NLCheckedNodeView *loop = &a.owner->nodes[a.loop - 1];
  size_t old_count = loop->continue_edges;
  loop->continue_edges = 0;
  assert(!valid(&a));
  loop->continue_edges = old_count;
  NLControlExits *saved = a.graph->exits;
  a.graph->exits = NULL;
  assert(!valid(&a));
  a.graph->exits = saved;
  NLCheckedNodeId saved_root = a.graph->root;
  a.graph->root = 0;
  assert(!valid(&a));
  a.graph->root = saved_root;
  NLCheckedFragment *arm = (NLCheckedFragment *)nl_checked_if_arm(
      a.graph, nl_checked_node_view(a.graph, a.graph->root)->tail, 0);
  assert(arm);
  const NLControlExitView *edge = nl_control_exit_view(arm->exits, 0);
  NLControlExitView *mutable_edge = (NLControlExitView *)edge;
  const NLControlTarget *target = edge->target;
  NLControlTarget *foreign = NULL;
  assert(nl_control_target_create(NL_TARGET_LOOP, &foreign) == NL_CHECK_OK);
  mutable_edge->target = foreign;
  assert(!valid(&a));
  mutable_edge->target = target;
  nl_control_target_destroy(foreign);
  NLSemanticContext *post =
      nl_control_state_context((NLControlState *)edge->state);
  NLValueFactId fact = post->places[proof.root - 1].current_fact;
  post->places[proof.root - 1].current_fact = 0;
  assert(!valid(&a));
  post->places[proof.root - 1].current_fact = fact;
  assert(valid(&a));
  puts("C220 missing-edge/count/root/wrong-target/stale-current refusals PASS");
  prepare(&b, argv[1]);
  assert(valid(&b));
  size_t body_slot = SIZE_MAX;
  for (size_t i = 0; i < a.owner->arm_count; ++i)
    if (a.owner->arms[i].match == a.loop &&
        a.owner->arms[i].artifact == a.graph)
      body_slot = i;
  assert(body_slot != SIZE_MAX);
  /* Real B stays alive, and A remains unrestored during A destruction.
   * Canonical custody, not display arrays, must select A's actual child. */
  a.owner->arms[body_slot].artifact = b.graph;
  assert(!valid(&a) && valid(&b));
  dispose(&a);
  assert(valid(&b));
  dispose(&b);
  puts("C220 canonical A destruction / B survives PASS; altered graph never "
       "emitted/native");
  return 0;
}
