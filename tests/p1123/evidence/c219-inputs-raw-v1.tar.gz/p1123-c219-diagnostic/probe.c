/* P1123 passive observations of unmodified CHECK. No result is replaced. */
#define main p1123_driver_main
#include "main.c"
#undef main
#include "control.h"
#include <assert.h>

typedef struct {
  const NLControlTarget *target;
  const NLSemanticContext *entry; /* borrowed only during synchronous wrapper */
  size_t places;
  NLSemanticPlaceView frame[64];
} Entry;
static Entry entries[16];
static size_t entry_count;
static void show_set(const char *where, const NLControlExits *set) {
  size_t cs = 0, bs = 0, rs = 0;
  for (size_t j = 0; j < nl_control_exits_count(set); ++j) {
    const NLControlExitView *e = nl_control_exit_view(set, j);
    cs += e->kind == NL_EXIT_CONTINUE;
    bs += e->kind == NL_EXIT_BREAK;
    rs += e->kind == NL_EXIT_RETURN;
  }
  if (!cs && !bs)
    return;
  printf("P1123 SET where=%s C=%zu B=%zu R=%zu count=%zu\n", where, cs, bs, rs,
         nl_control_exits_count(set));
  for (size_t j = 0; j < nl_control_exits_count(set); ++j) {
    const NLControlExitView *e = nl_control_exit_view(set, j);
    const NLSemanticContext *c =
        nl_control_state_context((NLControlState *)e->state);
    const Entry *entry = NULL;
    for (size_t k = entry_count; k; --k)
      if (entries[k - 1].target == e->target) {
        entry = &entries[k - 1];
        break;
      }
    size_t changed = 0;
    if (entry && entry->places == c->place_count)
      for (size_t k = 0; k < entry->places; ++k) {
        const NLSemanticPlaceView *a = &entry->frame[k], *b = &c->places[k];
        if (memcmp(a, b, sizeof(*a))) {
          ++changed;
          printf("P1123 PLACE edge=%d place=%zu fact=%zu->%zu value=%zu->%zu "
                 "incarnation=%zu->%zu\n",
                 e->kind, k + 1, a->current_fact, b->current_fact,
                 a->current_value, b->current_value, a->incarnation,
                 b->incarnation);
        }
      }
    printf("P1123 EDGE kind=%d target=%p recorded_entry=%d source_owner=%p "
           "source_node=%zu places=%zu observed_frame_changes=%zu\n",
           e->kind, (const void *)e->target, entry != NULL,
           (const void *)e->source_owner, e->source_node, c->place_count,
           changed);
    if (entry) {
      const NLSemanticContext *a = entry->entry;
      size_t package_changes = 0, rich = 0;
      for (size_t k = 0; k < a->value_count; ++k) {
        const NLSemanticValueView *v = &a->values[k];
        const bool same = k < c->value_count &&
                          nl_node_value_same(*v, c->values[k]);
        package_changes += !same;
        if (v->carrier != NL_CARRIER_ENDED && v->field_count) {
          ++rich;
          printf("P1123 EXACT_PACKAGE edge=%d value=%zu current_owner=%zu "
                 "field_count=%zu same=%d deps=%d hidden_count=%zu\n",
                 e->kind, k + 1, v->owner_place, v->field_count, same,
                 v->dependencies, v->value_dependency_count);
        }
      }
      printf("P1123 PREFIX edge=%d rich_live=%zu package_changes=%zu "
             "bindings=%zu/%zu places=%zu/%zu scopes=%zu/%zu "
             "source_link=%d\n", e->kind, rich, package_changes,
             a->binding_count, c->binding_count, a->place_count,
             c->place_count, a->scope_count, c->scope_count,
             e->source_owner != NULL);
    }
    for (size_t k = 0; k < e->count; ++k) {
      NLSemanticValueView v;
      assert(nl_semantic_value_view(c, e->values[k].value, &v));
      printf("P1123 EDGE_VALUE id=%zu type=%zu known=%d bits=%zu deps=%d "
             "dependencies=%zu\n",
             e->values[k].value, v.type, v.scalar_known, v.scalar_value,
             v.dependencies, v.value_dependency_count);
    }
    const NLTypeId boolean = nl_semantic_core_type(c, NL_TYPE_BOOL);
    for (size_t k = 0; k < c->value_count; ++k)
      if (c->values[k].type == boolean)
        printf("P1123 BODY_BOOL id=%zu known=%d deps=%d\n", k + 1,
               c->values[k].scalar_known, c->values[k].dependencies);
  }
}
NLCheckStatus __real_nl_loop_header_create_bounded(const NLControlState *,
                                                   NLControlTarget *,
                                                   const NLValueId *, size_t,
                                                   bool, bool, NLLoopHeader **);
NLCheckStatus __wrap_nl_loop_header_create_bounded(const NLControlState *entry,
                                                   NLControlTarget *target,
                                                   const NLValueId *slots,
                                                   size_t count, bool wide,
                                                   bool memory,
                                                   NLLoopHeader **out) {
  const NLSemanticContext *c =
      nl_control_state_context((NLControlState *)entry);
  assert(entry_count < 16 && c->place_count <= 64);
  Entry *saved = &entries[entry_count++];
  saved->target = target;
  saved->entry = c;
  saved->places = c->place_count;
  if (c->place_count)
    memcpy(saved->frame, c->places, c->place_count * sizeof(*c->places));
  for (size_t i = 0; i < c->value_count; ++i) {
    const NLSemanticValueView *v = &c->values[i];
    if (v->carrier != NL_CARRIER_ENDED && v->field_count)
      printf("P1123 LIVE_AGGREGATE id=%zu type=%zu carrier=%d owner=%zu "
             "fields=%zu deps=%d value_dependencies=%zu\n",
             i + 1, v->type, v->carrier, v->owner_place, v->field_count,
             v->dependencies, v->value_dependency_count);
  }
  NLCheckStatus s = __real_nl_loop_header_create_bounded(
      entry, target, slots, count, wide, memory, out);
  printf("P1123 HEADER target=%p slots=%zu wide_slots=%d wide_memory=%d "
         "status=%d published=%d\n",
         (void *)target, count, wide, memory, s, out && *out != NULL);
  return s;
}
NLCheckStatus __real_nl_control_exits_union(NLControlExits **,
                                            const NLControlExits *);
NLCheckStatus __wrap_nl_control_exits_union(NLControlExits **out,
                                            const NLControlExits *set) {
  NLCheckStatus s = __real_nl_control_exits_union(out, set);
  if (s == NL_CHECK_OK)
    show_set("actual_union", *out);
  return s;
}
NLCheckStatus __real_nl_loop_header_closure(const NLLoopHeader *,
                                            const NLControlExits *);
NLCheckStatus __wrap_nl_loop_header_closure(const NLLoopHeader *h,
                                            const NLControlExits *set) {
  NLCheckStatus s = __real_nl_loop_header_closure(h, set);
  show_set("actual_closure", set);
  printf("P1123 CLOSURE status=%d supplied=%zu\n", s,
         nl_control_exits_count(set));
  /* Contract observations only; these calls NEVER feed a result to CHECK. */
  if (s == NL_CHECK_OK)
    for (size_t i = 0; i < nl_control_exits_count(set); ++i) {
      const NLControlExitView *e = nl_control_exit_view(set, i);
      if (e->kind != NL_EXIT_CONTINUE)
        continue;
      NLControlTarget *wrong = NULL;
      NLControlExits *foreign = NULL;
      assert(nl_control_target_create(NL_TARGET_LOOP, &wrong) == NL_CHECK_OK);
      assert(nl_control_exit_append(&foreign, NL_EXIT_CONTINUE, wrong, e->state,
                                    e->values, e->count) == NL_CHECK_OK);
      NLCheckStatus missing = __real_nl_loop_header_closure(h, NULL);
      NLCheckStatus wrong_status = __real_nl_loop_header_closure(h, foreign);
      printf(
          "P1123 CONTRACT omitted_set=%d (NOT source proof) wrong_target=%d\n",
          missing, wrong_status);
      assert(missing == NL_CHECK_OK && wrong_status != NL_CHECK_OK);
      nl_control_exits_destroy(foreign);
      nl_control_target_destroy(wrong);
      break;
    }
  return s;
}
typedef struct {
  NLSource *source, *call_source;
  NLParser *parser, *call_parser;
  NLSyntaxTree *unit, *call_tree;
  NLSemanticContext *context;
  NLCheckedFragment *root;
  const NLCheckedFragment *owner, *body;
  NLCheckedNodeId loop, call;
} Input;
static void dispose(Input *i) {
  nl_checked_destroy(i->root);
  nl_semantic_destroy(i->context);
  nl_syntax_tree_destroy(i->call_tree);
  nl_parser_destroy(i->call_parser);
  nl_source_destroy(i->call_source);
  nl_syntax_tree_destroy(i->unit);
  nl_parser_destroy(i->parser);
  nl_source_destroy(i->source);
}
static bool prepare(const char *path, Input *i) {
  assert(nl_source_load(path, &i->source) == NL_SOURCE_OK);
  assert(nl_parser_create(i->source, &i->parser) == NL_PARSE_OK);
  NLParseDiagnostic pd = {0};
  NLParseStatus ps = nl_parser_parse_function_unit(i->parser, &i->unit, &pd);
  printf("P1123 PARSE status=%d\n", ps);
  if (ps != NL_PARSE_OK) {
    (void)nl_parse_diagnostic_render(stderr, i->source, &pd);
    return false;
  }
  assert(nl_semantic_create(&i->context) == NL_CHECK_OK);
  NLSemanticContext before = *i->context;
  const NLSyntaxTree *units[] = {i->unit};
  NLFunctionUnitDiagnostic d = {0};
  NLCheckStatus s =
      nl_semantic_register_function_unit(i->context, units, 1, &d);
  printf("P1123 REGISTER status=%d public_unchanged=%d no_root=%d\n", s,
         !memcmp(&before, i->context, sizeof(before)), i->root == NULL);
  if (s != NL_CHECK_OK) {
    assert(!memcmp(&before, i->context, sizeof(before)) && !i->root);
    (void)nl_check_diagnostic_render(stderr, i->source, &d.diagnostic);
    return false;
  }
  assert(nl_source_create("main()", 6, "P1123-entry", &i->call_source) ==
         NL_SOURCE_OK);
  assert(nl_parser_create(i->call_source, &i->call_parser) == NL_PARSE_OK);
  assert(nl_parser_parse_expression_fragment(i->call_parser, &i->call_tree,
                                             NULL) == NL_PARSE_OK);
  s = nl_semantic_check_expression(i->context, i->call_tree, &i->root, NULL);
  printf("P1123 INVOCATION status=%d owner=%d\n", s, i->root != NULL);
  if (s != NL_CHECK_OK)
    return false;
  i->owner = nl_checked_call_body(i->root, nl_checked_root(i->root));
  assert(i->owner);
  for (size_t n = 1; n <= nl_checked_node_count(i->owner); ++n) {
    const NLCheckedNodeView *v = nl_checked_node_view(i->owner, n);
    if (v->kind == NL_CHECKED_LOOP) {
      assert(!i->loop);
      i->loop = n;
    }
  }
  assert(i->loop);
  const NLCheckedNodeView *loop = nl_checked_node_view(i->owner, i->loop);
  i->body = nl_checked_loop_body(i->owner, i->loop);
  printf("P1123 OWNED_LOOP header_inductive=%d C=%zu B=%zu body=%d "
         "break_provenance=%d\n",
         loop->header_inductive, loop->continue_edges, loop->break_edges,
         i->body != NULL,
         nl_checked_loop_break_provenance_valid(i->owner, i->loop));
  if (i->body)
    for (size_t n = 1; n <= nl_checked_node_count(i->body); ++n)
      if (nl_checked_node_view(i->body, n)->kind == NL_CHECKED_REGISTERED_CALL)
        i->call = n;
  V0Program program = {.unit = nl_semantic_unit_type(i->context),
                       .u8 = nl_semantic_core_type(i->context, NL_TYPE_U8)};
  printf("P1123 ACTUAL_BACKEND admitted=%d\n",
         v0_validate_call(i->root, nl_checked_root(i->root), &program));
  return true;
}
static void control(Input *a, const char *path) {
  NLCopyBodyView av = {0}, bv = {0};
  NLCopyBodyParameters ap = {0};
  NLCopyBodyEventView ae = {0};
  assert(a->body && a->call);
  assert(nl_checked_copy_body_view(a->body, a->call, &av));
  assert(nl_checked_copy_body_parameters(a->body, a->call, &ap));
  assert(nl_checked_copy_body_event(a->body, a->call, 0, &ae));
  assert(nl_checked_copy_body_validate(a->body, a->call, &av) == NL_CHECK_OK);
  assert(nl_checked_copy_body_parameters_validate(a->body, a->call, &ap) ==
         NL_CHECK_OK);
  assert(nl_checked_copy_body_event_validate(a->body, a->call, 0, &ae) ==
         NL_CHECK_OK);
  NLLinearBreakView relation = {0};
  assert(nl_linear_break_validate(a->owner, a->loop, &relation) == NL_CHECK_OK);
  NLSemanticValueView old;
  assert(nl_semantic_value_view(a->context, relation.result.value, &old) &&
         old.scalar_known);
  printf("P1123 GENUINE_GET_CURRENT index=%zu old=%zu incoming=%zu root=%zu "
         "child=%zu\n",
         relation.index, old.scalar_value, relation.incoming, relation.root,
         relation.child);
  Input b = {0};
  assert(prepare(path, &b));
  assert(nl_checked_copy_body_view(b.body, b.call, &bv));
  NLCheckStatus fb = nl_checked_copy_body_validate(b.body, b.call, &av);
  NLCheckStatus fp =
      nl_checked_copy_body_parameters_validate(b.body, b.call, &ap);
  NLCheckStatus fe =
      nl_checked_copy_body_event_validate(b.body, b.call, 0, &ae);
  printf("P1123 FOREIGN_SAME_ID body=%d parameters=%d event=%d\n", fb, fp, fe);
  assert(fb != NL_CHECK_OK && fp != NL_CHECK_OK && fe != NL_CHECK_OK);
  NLCopyBodyEventView changed = ae;
  changed.result = ae.incoming;
  assert(nl_checked_copy_body_event_validate(a->body, a->call, 0, &changed) !=
         NL_CHECK_OK);
  puts("P1123 changed event refuses");
  dispose(a);
  memset(a, 0, sizeof(*a));
  assert(nl_checked_copy_body_validate(b.body, b.call, &bv) == NL_CHECK_OK);
  puts("P1123 A destroyed genuine B current remains valid");
  dispose(&b);
}
int main(int argc, char **argv) {
  assert(argc == 2 || argc == 3);
  Input a = {0};
  if (!prepare(argv[1], &a))
    puts("P1123 no published LOOP owner; downstream getters/current/native NOT "
         "TESTED");
  else if (argc == 3)
    control(&a, argv[1]);
  dispose(&a);
  return 0;
}
