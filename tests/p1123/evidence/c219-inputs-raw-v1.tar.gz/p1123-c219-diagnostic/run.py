from pathlib import Path
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parent
inputs = Path('/tmp/p1123-c219-gate0')
freeze = json.loads((root / 'freeze.json').read_bytes())
for name, digest in freeze['files'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest, name
raw = root / 'raw'
raw.mkdir(exist_ok=False)
rows = []

def run(command, name):
    r = subprocess.run(list(map(str, command)), capture_output=True, timeout=120)
    (raw / (name + '.out')).write_bytes(r.stdout)
    (raw / (name + '.err')).write_bytes(r.stderr)
    rows.append(dict(name=name, command=list(map(str, command)), status=r.returncode,
                     stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),
                     stderr_sha256=hashlib.sha256(r.stderr).hexdigest()))
    (raw / 'observations.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(name, 'status', r.returncode, flush=True)
    assert r.returncode == 0, name
    return r.stdout

for case in ['01-stutter-less', '02-stutter-equality', '05-flat-header-control',
             '06-equal-bits-continue', '07-extra-source-continue', '11-prefix-current']:
    data = run([root / 'probe', inputs / 'sources' / (case + '.nl')], case)
    if case in ['01-stutter-less', '02-stutter-equality', '11-prefix-current']:
        assert b'PREFIX edge=1 rich_live=2 package_changes=0' in data
        assert b'status=3 published=0' in data
        assert b'REGISTER status=3 public_unchanged=1 no_root=1' in data
    elif case == '06-equal-bits-continue':
        assert b'EXACT_PACKAGE edge=1 value=3' in data
        assert b'same=0' in data
    elif case == '07-extra-source-continue':
        assert b'C=2 B=1' in data
    else:
        assert b'OWNED_LOOP header_inductive=1 C=1 B=1 body=1' in data
        assert b'break_provenance=0' in data
        assert b'ACTUAL_BACKEND admitted=0' in data

for case in ['01-stutter-less', '02-stutter-equality']:
    data = run([inputs / 'oom', inputs / 'sources' / (case + '.nl')], case + '-oom')
    assert b'rollback/retry-to-precision PASS' in data
    assert b'no LOOP owner/native' in data

print('P1123 diagnostic / reached registration OOM complete; no cyclic success claim')
