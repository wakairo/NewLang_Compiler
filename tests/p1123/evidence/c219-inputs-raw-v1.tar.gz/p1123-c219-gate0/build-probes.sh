#!/usr/bin/env bash
set -euo pipefail
p1123_source=/tmp/p1123-c219-base
p1123_build=/tmp/p1117-c217-clean-build
p1123_output=/tmp/p1123-c219-gate0
p1123_cc=/workspace/p1030-validation-tools/usr/bin/gcc-13
p1123_libraries=()
for p1123_library in checked_c_node semantic checked parser diagnostic syntax lexer source; do
    p1123_libraries+=("$p1123_build/libnewlang_$p1123_library.a")
done
"$p1123_cc" -std=c17 -Wall -Wextra -Wpedantic -Werror -O0 -g -UNDEBUG \
    -fno-pie -no-pie -I"$p1123_source/src" -I"$p1123_source/include" \
    "$p1123_output/probe.c" -Wl,--start-group "${p1123_libraries[@]}" -Wl,--end-group \
    -Wl,--wrap=nl_loop_header_create_bounded -Wl,--wrap=nl_loop_header_closure \
    -Wl,--wrap=nl_control_exits_union -o "$p1123_output/probe"
"$p1123_cc" -std=c17 -Wall -Wextra -Wpedantic -Werror -O0 -g -UNDEBUG \
    -fno-pie -no-pie -I"$p1123_source/src" -I"$p1123_source/include" \
    "$p1123_output/oom.c" -Wl,--start-group "${p1123_libraries[@]}" -Wl,--end-group \
    -Wl,--wrap=malloc -Wl,--wrap=calloc -Wl,--wrap=realloc -o "$p1123_output/oom"
