/* CHECK-failure OOM is tested without claiming a successful LOOP owner. */
#include "newlang/checked.h"
#include "newlang/parser.h"
#include "semantic_internal.h"
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
void *__real_malloc(size_t);
void *__real_calloc(size_t, size_t);
void *__real_realloc(void *, size_t);
static bool injecting, hit;
static size_t allocation, failure;
static void *pc;
static char kind;
static bool reject(char k, void *caller) {
  if (!injecting)
    return false;
  if (allocation++ != failure)
    return false;
  hit = true;
  pc = caller;
  kind = k;
  return true;
}
void *__wrap_malloc(size_t n) {
  return reject('m', __builtin_return_address(0)) ? NULL : __real_malloc(n);
}
void *__wrap_calloc(size_t n, size_t size) {
  return reject('c', __builtin_return_address(0)) ? NULL
                                                  : __real_calloc(n, size);
}
void *__wrap_realloc(void *p, size_t n) {
  return reject('r', __builtin_return_address(0)) ? NULL : __real_realloc(p, n);
}
int main(int argc, char **argv) {
  assert(argc == 2);
  NLSource *source = NULL;
  NLParser *parser = NULL;
  NLSyntaxTree *tree = NULL;
  assert(nl_source_load(argv[1], &source) == NL_SOURCE_OK);
  assert(nl_parser_create(source, &parser) == NL_PARSE_OK);
  assert(nl_parser_parse_function_unit(parser, &tree, NULL) == NL_PARSE_OK);
  size_t reached = 0;
  for (size_t fault = SIZE_MAX;; fault = fault == SIZE_MAX ? 0 : fault + 1) {
    NLSemanticContext *c = NULL;
    assert(nl_semantic_create(&c) == NL_CHECK_OK);
    NLSemanticContext before = *c;
    allocation = 0;
    failure = fault;
    hit = false;
    const NLSyntaxTree *units[] = {tree};
    injecting = true;
    NLCheckStatus s = nl_semantic_register_function_unit(c, units, 1, NULL);
    injecting = false;
    assert(!memcmp(c, &before, sizeof(before)));
    if (fault == SIZE_MAX) {
      assert(s == NL_CHECK_ANALYSIS_PRECISION_LIMIT);
      reached = allocation;
      assert(reached);
    } else {
      printf("P1123 OOM ordinal=%zu kind=%c pc=%p status=%d\n", fault, kind, pc,
             s);
      assert(!fflush(stdout));
      assert(hit && allocation > fault && s == NL_CHECK_OUT_OF_MEMORY);
      assert(nl_semantic_register_function_unit(c, units, 1, NULL) ==
             NL_CHECK_ANALYSIS_PRECISION_LIMIT);
      assert(!memcmp(c, &before, sizeof(before)));
    }
    nl_semantic_destroy(c);
    if (fault != SIZE_MAX && fault + 1 == reached)
      break;
  }
  printf("P1123 reached registration OOM=%zu rollback/retry-to-precision PASS; "
         "no LOOP owner/native\n",
         reached);
  nl_syntax_tree_destroy(tree);
  nl_parser_destroy(parser);
  nl_source_destroy(source);
  return 0;
}
