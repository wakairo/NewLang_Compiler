"""Frozen exact-parent Gate0. Failures are recorded, not converted to PASS."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

compiler, probe, gcc, clang = map(str, sys.argv[1:])
data = Path(__file__).resolve().parent
raw = data / 'raw-v2'
raw.mkdir(exist_ok=False)
freeze = json.loads((data / 'freeze-v2.json').read_bytes())
for name, digest in freeze['files'].items():
    assert hashlib.sha256((data / name).read_bytes()).hexdigest() == digest, name
oracle = json.loads((data / 'oracle-v2.json').read_bytes())
rows = []


def run(args, label):
    args = list(map(str, args))
    r = subprocess.run(args, capture_output=True, timeout=120)
    prefix = raw / ('%03d-' % (len(rows) + 1) + label)
    prefix.with_suffix('.out').write_bytes(r.stdout)
    prefix.with_suffix('.err').write_bytes(r.stderr)
    rows.append({'label': label, 'command': args, 'returncode': r.returncode,
                 'stdout_sha256': hashlib.sha256(r.stdout).hexdigest(),
                 'stderr_sha256': hashlib.sha256(r.stderr).hexdigest()})
    (raw / 'observations.json').write_text(json.dumps(rows, indent=2) + '\n')
    print(label, r.returncode, r.stderr.decode(errors='replace').strip(), flush=True)
    return r


for name, case in oracle['cases'].items():
    source = data / 'sources' / (name + '.nl')
    checked = run([compiler, '--check', source], name + '-check')
    emitted = run([compiler, source], name + '-c17')
    expected = case['predicted_parent']
    if 'check' in expected:
        assert checked.returncode == expected['check'], (name, checked.stderr)
        assert emitted.returncode == expected['emit'], (name, emitted.stderr)
    else:
        assert checked.returncode in (2, 3) and emitted.returncode == checked.returncode
    assert not checked.stdout
    if expected.get('diagnostic'):
        failed = checked if checked.returncode else emitted
        assert expected['diagnostic'].encode() in failed.stderr
    if emitted.returncode:
        assert not emitted.stdout
    output = raw / (name + '-named.c')
    sentinel = b'P1123 preserve exact named bytes\x00\xff\n'
    output.write_bytes(sentinel)
    before = output.stat()
    named = run([compiler, '--emit-c17-to', output, source], name + '-named')
    assert named.returncode == emitted.returncode and not named.stdout
    if named.returncode:
        after = output.stat()
        assert output.read_bytes() == sentinel
        assert (after.st_ino, after.st_mtime_ns) == (before.st_ino, before.st_mtime_ns)
        assert not list(raw.glob('.' + output.name + '*.tmp*'))
    else:
        assert output.read_bytes() == emitted.stdout
    owned = run([probe, source, *(['--control'] if case.get('zero_continue_control') else [])], name + '-owned')
    assert owned.returncode == 0
    if case.get('zero_continue_control'):
        physical = case['physical']
        wanted = f"GENUINE_GET_CURRENT index={physical['field_index']} old={physical['old']} incoming={physical['incoming']}"
        assert wanted.encode() in owned.stdout
        assert b'A destroyed genuine B current remains valid' in owned.stdout
    else:
        # CLI0 alone would not license execution of an iterative source.
        continue
    assert checked.returncode == emitted.returncode == 0
    c17 = emitted.stdout.decode()
    pattern = r'(static uint8_t nl_fn_\d+\(uint8_t \*(nl_local_\d+), uint8_t (nl_local_\d+)\)\n\{\n)(.*?)(\n\})'

    def passive(m):
        body, stores = re.subn(r'(^\s*\*(nl_local_\d+) = [^;]+;)$',
                              lambda n: n[1] + f'\n    p1123_changed({n[2]});',
                              m[4], flags=re.M)
        assert stores == 1
        return m[1] + f'    p1123_helper({m[2]}, {m[3]});\n' + body + m[5]

    observed, functions = re.subn(pattern, passive, c17, flags=re.S)
    assert functions == 1
    p = case['physical']
    macros = dict(SELECTED=p['selected_bind'], INDEX=p['field_index'],
                  OLD=p['old'], NEXT=p['incoming'], F0=p['initial_selected'][0],
                  F1=p['initial_selected'][1], Q0=p['initial_other'][0], Q1=p['initial_other'][1])
    for variant, text in [('raw', c17), ('passive', observed)]:
        path = raw / (name + '-' + variant + '.c')
        path.write_text(text)
        for cc in [gcc, clang]:
            for optimization in ['-O0', '-O2']:
                label = name + '-' + Path(cc).name + '-' + variant + optimization
                executable = raw / label
                flags = ['-std=c17', '-Wall', '-Wextra', '-Wpedantic', '-Werror', optimization]
                if variant == 'passive':
                    flags += ['-DNEWLANG_LOOP_OBSERVER="' + str(data / 'native-control.h') + '"']
                    flags += ['-DP1123_' + key + '=' + str(value) for key, value in macros.items()]
                build = run([cc, *flags, path, '-o', executable], label + '-build')
                assert build.returncode == 0
                result = run([executable], label + '-native')
                assert result.returncode == 0 and not result.stderr
                if variant == 'passive':
                    assert b'zero-Continue actual original/old/current/sibling/other PASS' in result.stdout
                executable.unlink()
print('P1123 Gate0 completed; blocked iterative cases are NOT end-to-end PASS', flush=True)
