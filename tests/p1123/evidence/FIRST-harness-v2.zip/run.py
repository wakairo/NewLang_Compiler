from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).resolve().parent;f=json.loads((p/'freeze.json').read_bytes())
for name,digest in f['files'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
raw=p/'raw';raw.mkdir(exist_ok=False);rows=[]
def run(cmd,name):
    cmd=list(map(str,cmd));r=subprocess.run(cmd,capture_output=True,timeout=1200)
    (raw/(name+'.out')).write_bytes(r.stdout);(raw/(name+'.err')).write_bytes(r.stderr)
    rows.append(dict(name=name,command=cmd,status=r.returncode,stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest()))
    (raw/'observations.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(name,r.returncode,flush=True);return r
sources=Path('/tmp/p1123-c219-gate0/sources')
positive=[sources/(n+'.nl') for n in ['01-stutter-less','02-stutter-equality','11-prefix-current']]
positive += [Path('/tmp/p1123-c220-native-v1/sources')/(n+'.nl') for n in ['13-reversed-arms','14-first-break']]
for source in positive:
    r=run([p/'probe',source],source.stem+'-expanded-negative');assert r.returncode==0 and not r.stderr
    assert b'genuine public Copy GET/current0' in r.stdout and b'cardinality canonical cleanup PASS' in r.stdout
for source in positive[:3]:
    r=run([p/'oom',source],source.stem+'-all-reached-oom');assert r.returncode==0
    assert b'rollback/no-publication/current retry PASS' in r.stdout and b'exact bytes/inode/mtime/temp/retry PASS' in r.stdout
print('C220 corrected ownership harness and all reached registration/invocation/named OOM complete')
