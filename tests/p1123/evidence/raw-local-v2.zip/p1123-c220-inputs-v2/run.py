from pathlib import Path
import json,hashlib,subprocess
data=Path(__file__).resolve().parent
freeze=json.loads((data/'freeze.json').read_bytes())
for name,digest in freeze['files'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
raw=data/'raw';raw.mkdir(exist_ok=False);rows=[]
def run(cmd,name):
    r=subprocess.run(list(map(str,cmd)),capture_output=True,timeout=120)
    (raw/(name+'.out')).write_bytes(r.stdout)
    (raw/(name+'.err')).write_bytes(r.stderr)
    rows.append(dict(name=name,command=list(map(str,cmd)),status=r.returncode,
                     stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),
                     stderr_sha256=hashlib.sha256(r.stderr).hexdigest()))
    (raw/'observations.json').write_text(json.dumps(rows,indent=2)+'\n')
    print(name,r.returncode,flush=True)
    return r
for case in ['01-stutter-less','02-stutter-equality','11-prefix-current']:
    source=data/'sources'/(case+'.nl')
    r=run([data/'newlangc','--check',source],case+'-check')
    assert r.returncode==0 and not r.stdout and not r.stderr
    r=run([data/'probe',source],case+'-private')
    assert r.returncode==0 and not r.stderr and b'B survives PASS' in r.stdout
    r=run([data/'newlangc',source],case+'-c17')
    assert r.returncode==0 and not r.stderr
    assert b'for (;;) {' in r.stdout and b'continue;' in r.stdout
    (raw/(case+'.c')).write_bytes(r.stdout)
print('C220 CHECK/private/C17 all three PASS. Native not executed here.')
