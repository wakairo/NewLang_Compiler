from pathlib import Path
import hashlib,json,subprocess
p=Path(__file__).resolve().parent;f=json.loads((p/'freeze.json').read_bytes())
for name,digest in f['files'].items():assert hashlib.sha256(Path(name).read_bytes()).hexdigest()==digest,name
raw=p/'raw';raw.mkdir(exist_ok=False);rows=[]
for case in ['01-stutter-less','02-stutter-equality','11-prefix-current']:
    source=Path('/tmp/p1123-c219-gate0/sources')/(case+'.nl')
    cmd=[str(p/'oom'),str(source)]+(['--named-only'] if case=='01-stutter-less' else [])
    r=subprocess.run(cmd,capture_output=True,timeout=1200)
    (raw/(case+'.out')).write_bytes(r.stdout);(raw/(case+'.err')).write_bytes(r.stderr)
    rows.append(dict(name=case,command=cmd,status=r.returncode,stdout_sha256=hashlib.sha256(r.stdout).hexdigest(),stderr_sha256=hashlib.sha256(r.stderr).hexdigest()))
    (raw/'observations.json').write_text(json.dumps(rows,indent=2)+'\n');print(case,r.returncode,flush=True)
    assert r.returncode==0 and b'exact bytes/inode/mtime/temp/retry PASS' in r.stdout
print('C220 remaining named/API OOM complete; no repetition of source01 passed API enumeration')
