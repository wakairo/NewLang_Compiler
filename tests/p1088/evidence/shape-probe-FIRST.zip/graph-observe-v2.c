#define main inherited_loop_main
#include "/tmp/p1088/tests/unit/loop_test.c"
#undef main
static bool observe(void)
{
    Fixture f = {0};
    CHECK(setup(&f));
    TestChecked a = {0};
    CHECK(test_run(f.c,
        "loop(){let a0=x;let a1=y;let a2=x;let a3=y;let a4=x;let a5=y;let a6=x;break y;}",
        TEST_SOURCE, NL_CHECK_OK, NULL, &a));
    NLCheckedNodeId id = nl_checked_root(a.artifact);
    const NLCheckedFragment *body = nl_checked_loop_body(a.artifact, id);
    CHECK(body);
    bool valid = nl_checked_loop_break_provenance_valid(a.artifact, id);
    const NLControlExitView *e = nl_control_exit_view(body->exits, 0);
    printf("P1088 actual body_count=%zu source_break=%zu public_valid=%d\n", body->count, e->source_node, valid);
    for (NLCheckedNodeId n=1; n<=body->count; ++n) printf("node=%zu kind=%d\n", n, nl_checked_node_view(body,n)->kind);
    test_checked_destroy(&a);
    nl_semantic_destroy(f.c);
    CHECK(valid);
    return true;
}
int main(void) { return observe() ? 0 : 1; }
