# P1117 / C212 independent pre-execution inputs v1

Pin main 65055be55934416c911453463b5f26fa461e8d6a / tree
468bcea0ab46ad530c08bcdbb17e3e6ec05e4c13, Draft17.34.
Compass/Value Strategy1.1, Process4.1.2/4.2/4.3.1/4.3.2/7, canonical5.2/
13.5/17/19/27.3-27.4 and Backend Policy are the authority. Selected scalar
comparison/ordinary function/IF semantics KEEP, no source-design change (N/A).
Ledger is a historical index, no matching entry does not prove no history.

01/02 are new P sources, distinct equality vs ordering, names/values and
binding/tail flow. Unknown function formals are required at definition CHECK.
Two runtime outcomes are real guest calls/arguments, never a host seed/unroll.
03 is a known Bool/IF calibration. 04-06 are type/source negatives. 07 copies
only P1115's own independent input, byte-for-byte, as a blocked integration
control. No R source/oracle/fixture/raw/values, no M1118 conclusion, no stopped
P1036/PR1050 input. All prior evidence remains immutable.

Freeze full files/oracle/SHA on Issue1117 before compiler/probe execution.
Baseline uses the actual exact-main newlangc built in P1115 (binary SHA256
269021dcc2c408d621f1a302dfe75709b3e6a54b41ed9aa882f6808e0e1d8ab2),
whose source checkout is still exact-main and clean. This is not a changed
candidate. Compile new probe with strict C17 GCC13 using -I REPO/src and
-I REPO/include, and the libraries checked_c_node, semantic, checked, parser,
lexer, syntax, source, diagnostic in that order; add
-Wl,--wrap=nl_if_field_prepare. The wrapper passively observes the real IF
input after source comparison; it changes no arguments, return or state.

Run: python3 run.py COMPILER PROBE RAW baseline GCC CLANG
Only if safe bounded implementation is proved: repeat with mode candidate on
new exact-source HEAD. The runner preserves exact commands/status/raw hashes.
The passive native variant observes genuine generated usize-helper entry and
return, once per actual call, and asserts both distinct outputs. Raw C runs
separately. A successful API observer process may simply have logged CHECK
precision refusal; its exit0 alone is never a CHECK or authority PASS.

Any new instrumentation source/oracle or candidate is frozen prospectively,
not by editing this v1. Unreached native, OOM, sanitizer and cyclic obligations
must be reported NOT TESTED. Capability does not imply general soundness or
NewLang-vs-factored-C audit locality; Product GO/H1 remain held.

Prospective v2: no v1 file is modified. The first known-IF expected C17 success
was genuinely wrong (CHECK0, backend4); v1 runner stopped and raw was saved.
This v2 preserves that source verbatim and records its separate CHECK0/emit4
boundary, while adding known-Bool/no-IF ordinary CLI native calibration08.
All seven original source hashes are unchanged. Candidate source01/02 still
requires actual CHECK0/C170 and runtime true/false outcomes. No failing safety
assertion is removed; the new unsupported-profile expectation is explicit.
