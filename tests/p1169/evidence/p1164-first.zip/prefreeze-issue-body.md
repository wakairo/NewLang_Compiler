Track: P

### C236 pre-execution freeze v1 — 4 positive / 4 negative / 1 stutter control

Compiler/native execution has not started. Fixed main449 and af16 build-source entire tree are both `74a1bdc728398eb85bb690a9eaff34194f316b50`. Existing compiler SHA `ae3da6887b27c9a23b9aa0cc4eecaf27a50a1c3c2229d807ff2ecf49df53c993`, existing real-CHECK probe SHA `c1d1f0c572e5a70b37fc41640130538c80c17d4f7cbf5ca8f87820159be542f6`; no rebuild. Inputs archive `/workspace/p1164-c236-checkpoint/inputs-prefreeze-v1.zip` SHA **94a71700ab6661e7c09a093bcf061d406a02f22a6767e924d479378eee5d13cb**; freeze.json SHA **8f79e7d7e59abfe0226c123db4d74b7a2ea99d222dcf8ccb92d260131ce6af22**. Full source and oracle follow. No R1163 material used.

The old Copy is bound/copied/discarded within the Continue iteration, after the loan ends. Zero-case has an unexecuted write arm, not proof of changing backedge support. Same-bits writes still require fresh facts; no numeric fact identity is invented. Fixed CHECK rejection is a prediction, exact diagnostics will be preserved. Masked negatives do not prove their later safety gate. Unexpected acceptance/crash stops downstream execution. Only compiler check/emit/named and the existing probe on the accepted control will run; generated native/Production changes/CI0.

`01-zero.nl` SHA256 `9d3c9346b95626c02c8512d613168f760516008bd3d1b32b48ad79bf5fd1bb35`
```text
struct CounterNode { head:u8, tag:u8 }
fn main()->unit {
 let original=CounterNode{head:u8(45),tag:u8(173)};
 let result=loop(cursor=usize(9)){
  if(cursor < usize(9)){
   let old=loan_write(original@head){|writer|replace(writer,u8(121))};
   let old_copy=old;
   old_copy;
   let during=original@head;
   let beside=original@tag;
   during;
   beside;
   continue(cursor + usize(3));
  }else{break cursor;}
 };
 let final=original@head;
 let peer=original@tag;
 let copied=result;
 unit
}
```

`02-one.nl` SHA256 `a22de79dbe495dcc634809c8f00a319c26440e7f1606157d746503995632bfa6`
```text
struct BeaconNode { marker:u8, level:u8 }
fn main()->unit {
 let original=BeaconNode{marker:u8(67),level:u8(156)};
 let result=loop(cursor=usize(2)){
  if(cursor < usize(4)){
   let old=loan_write(original@level){|writer|replace(writer,u8(98))};
   let old_copy=old;
   old_copy;
   let during=original@level;
   let beside=original@marker;
   during;
   beside;
   continue(cursor + usize(5));
  }else{break cursor;}
 };
 let final=original@level;
 let peer=original@marker;
 let copied=result;
 unit
}
```

`03-multiple.nl` SHA256 `1cedd7fb7a5d87b5598c86b1e634d8c43eb14385b0c0c90e0c7b132e4b3a2b85`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   let old=loan_write(original@latch){|writer|replace(writer,u8(203))};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   continue(cursor + usize(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

`04-same-bits.nl` SHA256 `3d3d4c3a2a55877c023bbdc3252e550fa05da0cb4cb84e88f47a82a80affbeee`
```text
struct ModeNode { peer:u8, mode:u8 }
fn main()->unit {
 let original=ModeNode{peer:u8(182),mode:u8(54)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(3)){
   let old=loan_write(original@mode){|writer|replace(writer,u8(54))};
   let old_copy=old;
   old_copy;
   let during=original@mode;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@mode;
 let peer=original@peer;
 let copied=result;
 unit
}
```

`80-stutter-control.nl` SHA256 `c21827ac467cc9d22996c563005852b653d4fec10c0b450efbae1fac2ca8e6bb`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   continue(cursor + usize(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

`90-ending-reference.nl` SHA256 `1b560949b3c89d73bf038aaae2a62ffd10778c94ad1692d71df5b1d33f5601b7`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   let old=loan_write(original@latch){|writer|writer};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   continue(cursor + usize(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

`91-overflow.nl` SHA256 `63e5de4515428eadfa6d9035b2ae376be983fa9cc224fb97f06703acd112d0ef`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   let old=loan_write(original@latch){|writer|replace(writer,u8(203))};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   continue(cursor + usize(18446744073709551615));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

`92-incoming-type.nl` SHA256 `da572fc778e116e01390c7df213bcc567f3bb475d621f76a788758b4c3bd857f`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   let old=loan_write(original@latch){|writer|replace(writer,usize(203))};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   continue(cursor + usize(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

`93-read-mode.nl` SHA256 `7d28c48fe69330743d7200c379d2856bfc49d29a2f793d0a322e9f9eef40c3d0`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   let old=loan_read(original@latch){|writer|replace(writer,u8(203))};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   continue(cursor + usize(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

Full oracle (SHA256 `f06e129ecee87af4ea98c342388a49ae400d7d3661d724873439ee69fba339cc`):
```json
{
  "authority": "Compiler main449 / canonical Draft17.34; C236 diagnostic only",
  "independence": "P-owned values/source/expectations; no R1163 input or report used",
  "positive_prediction": {
    "canonical": "legal: one unchanged original root/children/incarnations; closed iteration loan; old Copy used locally",
    "fixed_compiler": "CHECK precision/invariant rejection predicted; exact diagnostic is observation, not oracle rewrite",
    "owned_backend_native": "NOT_REACHED after CHECK rejection; no native execution authorized",
    "fact_rule": "Every actual replace issues a fresh current-value fact even if new scalar bits equal old bits"
  },
  "cases": {
    "01-zero": {
      "category": "positive",
      "canonical_legal": true,
      "headers": [
        9
      ],
      "backedges": 0,
      "loop_result": 9,
      "old_values": [],
      "iteration_current_values": [],
      "final_child": 45,
      "sibling": 173,
      "target_index": 0,
      "preserved_root_child_incarnations": true,
      "fresh_current_transitions": 0,
      "current_fact_numeric_ids": "not predicted or minted; must derive from actual state transition"
    },
    "02-one": {
      "category": "positive",
      "canonical_legal": true,
      "headers": [
        2,
        7
      ],
      "backedges": 1,
      "loop_result": 7,
      "old_values": [
        156
      ],
      "iteration_current_values": [
        98
      ],
      "final_child": 98,
      "sibling": 67,
      "target_index": 1,
      "preserved_root_child_incarnations": true,
      "fresh_current_transitions": 1,
      "current_fact_numeric_ids": "not predicted or minted; must derive from actual state transition"
    },
    "03-multiple": {
      "category": "positive",
      "canonical_legal": true,
      "headers": [
        1,
        5,
        9,
        13
      ],
      "backedges": 3,
      "loop_result": 13,
      "old_values": [
        112,
        203,
        203
      ],
      "iteration_current_values": [
        203,
        203,
        203
      ],
      "final_child": 203,
      "sibling": 39,
      "target_index": 0,
      "preserved_root_child_incarnations": true,
      "fresh_current_transitions": 3,
      "current_fact_numeric_ids": "not predicted or minted; must derive from actual state transition"
    },
    "04-same-bits": {
      "category": "positive",
      "canonical_legal": true,
      "headers": [
        0,
        1,
        2,
        3
      ],
      "backedges": 3,
      "loop_result": 3,
      "old_values": [
        54,
        54,
        54
      ],
      "iteration_current_values": [
        54,
        54,
        54
      ],
      "final_child": 54,
      "sibling": 182,
      "target_index": 1,
      "preserved_root_child_incarnations": true,
      "fresh_current_transitions": 3,
      "current_fact_numeric_ids": "not predicted or minted; must derive from actual state transition"
    },
    "90-ending-reference": {
      "category": "negative",
      "canonical_legal": false,
      "required_property": "ref result escapes the iteration loan; dependency rejection required if path reached",
      "fixed_check": "nonzero",
      "earlier_precision_rejection": "record actual diagnostic; it does not demonstrate the masked negative gate",
      "stdout": "empty on rejection",
      "named_output": "same bytes/inode/mtime; no temporary residue on rejection"
    },
    "91-overflow": {
      "category": "negative",
      "canonical_legal": false,
      "required_property": "first reachable continue computes usize(1)+MAX and must reject, never wrap",
      "fixed_check": "nonzero",
      "earlier_precision_rejection": "record actual diagnostic; it does not demonstrate the masked negative gate",
      "stdout": "empty on rejection",
      "named_output": "same bytes/inode/mtime; no temporary residue on rejection"
    },
    "92-incoming-type": {
      "category": "negative",
      "canonical_legal": false,
      "required_property": "replace current u8 with usize: exact type mismatch",
      "fixed_check": "nonzero",
      "earlier_precision_rejection": "record actual diagnostic; it does not demonstrate the masked negative gate",
      "stdout": "empty on rejection",
      "named_output": "same bytes/inode/mtime; no temporary residue on rejection"
    },
    "93-read-mode": {
      "category": "negative",
      "canonical_legal": false,
      "required_property": "replace through loan_read cannot obtain write access",
      "fixed_check": "nonzero",
      "earlier_precision_rejection": "record actual diagnostic; it does not demonstrate the masked negative gate",
      "stdout": "empty on rejection",
      "named_output": "same bytes/inode/mtime; no temporary residue on rejection"
    },
    "80-stutter-control": {
      "category": "control",
      "canonical_legal": true,
      "fixed_check": 0,
      "fixed_emit": 0,
      "fixed_named": 0,
      "headers": [
        1,
        5,
        9,
        13
      ],
      "loop_result": 13,
      "final_child": 112,
      "sibling": 39,
      "fresh_current_transitions": 0,
      "public_loop_validate": 0,
      "genuine_main_owner_validate": 0,
      "native": "NOT_RUN by C236 scope"
    }
  },
  "runner": "check then stdout C17 then named C17 for each reject/control; existing real-CHECK probe only after control CHECK success; no generated native",
  "stop": "Unexpected CHECK acceptance or crash/no-clobber violation pauses affected execution; inspect read-only, preserve first result"
}
```

Full freeze manifest:
```json
{
  "created_utc": "2026-11-05T02:20:27.321741+00:00",
  "main": "449ccf0dc567c05f3fd6dc4430b265759e22d571",
  "tree": "74a1bdc728398eb85bb690a9eaff34194f316b50",
  "compiler_sha256": "ae3da6887b27c9a23b9aa0cc4eecaf27a50a1c3c2229d807ff2ecf49df53c993",
  "probe_sha256": "c1d1f0c572e5a70b37fc41640130538c80c17d4f7cbf5ca8f87820159be542f6",
  "files": {
    "baseline-provenance.json": "8526ffa0aa6fdbdcea5ef79f1acf9655eb4a65139b4b73480df5aca6b509747c",
    "existing-probe.c": "84042a1611956fa0e65b44d39c9ffccbba484fa3a5d2be6beaaf419c56a0afa5",
    "generate.py": "9d60aa8fda61f892c3c9b0bdec5f435a83ac9d6d643922fc9c628e23278eee9e",
    "observe.py": "9b4ddb9f03b47e4f882308d47bb717ecb2479ea3872eaa0949fce1f87119969a",
    "oracle.json": "f06e129ecee87af4ea98c342388a49ae400d7d3661d724873439ee69fba339cc",
    "sources/01-zero.nl": "9d3c9346b95626c02c8512d613168f760516008bd3d1b32b48ad79bf5fd1bb35",
    "sources/02-one.nl": "a22de79dbe495dcc634809c8f00a319c26440e7f1606157d746503995632bfa6",
    "sources/03-multiple.nl": "1cedd7fb7a5d87b5598c86b1e634d8c43eb14385b0c0c90e0c7b132e4b3a2b85",
    "sources/04-same-bits.nl": "3d3d4c3a2a55877c023bbdc3252e550fa05da0cb4cb84e88f47a82a80affbeee",
    "sources/80-stutter-control.nl": "c21827ac467cc9d22996c563005852b653d4fec10c0b450efbae1fac2ca8e6bb",
    "sources/90-ending-reference.nl": "1b560949b3c89d73bf038aaae2a62ffd10778c94ad1692d71df5b1d33f5601b7",
    "sources/91-overflow.nl": "63e5de4515428eadfa6d9035b2ae376be983fa9cc224fb97f06703acd112d0ef",
    "sources/92-incoming-type.nl": "da572fc778e116e01390c7df213bcc567f3bb475d621f76a788758b4c3bd857f",
    "sources/93-read-mode.nl": "7d28c48fe69330743d7200c379d2856bfc49d29a2f793d0a322e9f9eef40c3d0"
  }
}
```

Runner/source-generator/probe/provenance are retained verbatim in the archive before execution. This freezes P inputs only, not an implementation success claim. Audit locality remains UNMEASURED.
