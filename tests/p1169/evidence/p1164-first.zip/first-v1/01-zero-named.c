C236 existing named output must survive rejection
