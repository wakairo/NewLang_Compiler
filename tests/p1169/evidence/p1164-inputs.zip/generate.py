from pathlib import Path
import json

root = Path(__file__).resolve().parent
cases = [
    ("01-zero", "CounterNode", ["head", "tag"], [45, 173], 0, 121, 9, 9, 3),
    ("02-one", "BeaconNode", ["marker", "level"], [67, 156], 1, 98, 2, 4, 5),
    ("03-multiple", "LatchNode", ["latch", "echo"], [112, 39], 0, 203, 1, 10, 4),
    ("04-same-bits", "ModeNode", ["peer", "mode"], [182, 54], 1, 54, 0, 3, 1),
]


def source(case, mutation="change"):
    name, struct, fields, values, target, incoming, start, limit, step = case
    field, sibling = fields[target], fields[1 - target]
    loan = "loan_read" if mutation == "read-mode" else "loan_write"
    expression = "writer" if mutation == "ending-reference" else (
        f"replace(writer,usize({incoming}))" if mutation == "incoming-type"
        else f"replace(writer,u8({incoming}))")
    advance = 18446744073709551615 if mutation == "overflow" else step
    body = "" if mutation == "stutter" else f"""   let old={loan}(original@{field}){{|writer|{expression}}};
   let old_copy=old;
   old_copy;
   let during=original@{field};
   let beside=original@{sibling};
   during;
   beside;
"""
    return f"""struct {struct} {{ {fields[0]}:u8, {fields[1]}:u8 }}
fn main()->unit {{
 let original={struct}{{{fields[0]}:u8({values[0]}),{fields[1]}:u8({values[1]})}};
 let result=loop(cursor=usize({start})){{
  if(cursor < usize({limit})){{
{body}   continue(cursor + usize({advance}));
  }}else{{break cursor;}}
 }};
 let final=original@{field};
 let peer=original@{sibling};
 let copied=result;
 unit
}}
"""


oracle = {
    "authority": "Compiler main449 / canonical Draft17.34; C236 diagnostic only",
    "independence": "P-owned values/source/expectations; no R1163 input or report used",
    "positive_prediction": {
        "canonical": "legal: one unchanged original root/children/incarnations; closed iteration loan; old Copy used locally",
        "fixed_compiler": "CHECK precision/invariant rejection predicted; exact diagnostic is observation, not oracle rewrite",
        "owned_backend_native": "NOT_REACHED after CHECK rejection; no native execution authorized",
        "fact_rule": "Every actual replace issues a fresh current-value fact even if new scalar bits equal old bits",
    },
    "cases": {},
    "runner": "check then stdout C17 then named C17 for each reject/control; existing real-CHECK probe only after control CHECK success; no generated native",
    "stop": "Unexpected CHECK acceptance or crash/no-clobber violation pauses affected execution; inspect read-only, preserve first result",
}
for case in cases:
    name, struct, fields, values, target, incoming, start, limit, step = case
    cursor, child = start, values[target]
    headers, olds, currents = [cursor], [], []
    while cursor < limit:
        olds.append(child)
        child = incoming
        currents.append(child)
        cursor += step
        assert cursor <= 18446744073709551615
        headers.append(cursor)
    oracle["cases"][name] = {
        "category": "positive", "canonical_legal": True,
        "headers": headers, "backedges": len(olds), "loop_result": cursor,
        "old_values": olds, "iteration_current_values": currents,
        "final_child": child, "sibling": values[1-target],
        "target_index": target, "preserved_root_child_incarnations": True,
        "fresh_current_transitions": len(olds),
        "current_fact_numeric_ids": "not predicted or minted; must derive from actual state transition",
    }
    (root/"sources"/(name+".nl")).write_text(source(case))

bad = [
    ("90-ending-reference", "ending-reference", "ref result escapes the iteration loan; dependency rejection required if path reached"),
    ("91-overflow", "overflow", "first reachable continue computes usize(1)+MAX and must reject, never wrap"),
    ("92-incoming-type", "incoming-type", "replace current u8 with usize: exact type mismatch"),
    ("93-read-mode", "read-mode", "replace through loan_read cannot obtain write access"),
]
for name, mutation, reason in bad:
    (root/"sources"/(name+".nl")).write_text(source(cases[2],mutation))
    oracle["cases"][name] = {
        "category": "negative", "canonical_legal": False,
        "required_property": reason, "fixed_check": "nonzero",
        "earlier_precision_rejection": "record actual diagnostic; it does not demonstrate the masked negative gate",
        "stdout": "empty on rejection", "named_output": "same bytes/inode/mtime; no temporary residue on rejection",
    }
(root/"sources"/"80-stutter-control.nl").write_text(source(cases[2], "stutter"))
oracle["cases"]["80-stutter-control"] = {
    "category": "control", "canonical_legal": True,
    "fixed_check": 0, "fixed_emit": 0, "fixed_named": 0,
    "headers": [1, 5, 9, 13], "loop_result": 13,
    "final_child": 112, "sibling": 39, "fresh_current_transitions": 0,
    "public_loop_validate": 0, "genuine_main_owner_validate": 0,
    "native": "NOT_RUN by C236 scope",
}
(root/"oracle.json").write_text(json.dumps(oracle,indent=2)+"\n")
