from pathlib import Path
import hashlib,json,os,subprocess,sys,time

root=Path(__file__).resolve().parent
freeze=json.loads((root/"freeze.json").read_text())
for name,digest in freeze["files"].items():
    assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
compiler=Path("/tmp/p1164-tools/newlangc-base")
probe=Path("/tmp/p1164-tools/probe")
for path,key in [(compiler,"compiler_sha256"),(probe,"probe_sha256")]:
    assert hashlib.sha256(path.read_bytes()).hexdigest()==freeze[key],path
raw=Path("/tmp/p1164-raw/first-v1")
raw.mkdir(exist_ok=False)
rows=[]
oracle=json.loads((root/"oracle.json").read_text())


def invoke(name,mode,command):
    begin=time.time_ns()
    command=list(map(str,command))
    r=subprocess.run(command,capture_output=True,timeout=60)
    out=raw/(name+"-"+mode+".out")
    err=raw/(name+"-"+mode+".err")
    out.write_bytes(r.stdout);err.write_bytes(r.stderr)
    row={"case":name,"mode":mode,"command":command,"status":r.returncode,
         "start_ns":begin,"finish_ns":time.time_ns(),
         "stdout_bytes":len(r.stdout),"stderr_bytes":len(r.stderr),
         "stdout_sha256":hashlib.sha256(r.stdout).hexdigest(),
         "stderr_sha256":hashlib.sha256(r.stderr).hexdigest()}
    rows.append(row)
    (raw/"observations.json").write_text(json.dumps(rows,indent=2)+"\n")
    print(name,mode,r.returncode,r.stderr.decode().strip(),flush=True)
    if r.returncode and not (raw/"FIRST.json").exists():
        (raw/"FIRST.json").write_text(json.dumps(row,indent=2)+"\n")
    return r,row


for source in sorted((root/"sources").glob("*.nl")):
    name=source.stem
    category=oracle["cases"][name]["category"]
    r,row=invoke(name,"check",[compiler,"--check",source])
    if r.returncode<0 or (category=="control" and r.returncode!=0) or (category!="control" and r.returncode==0):
        (raw/"STOP.json").write_text(json.dumps({"why":"unexpected CHECK outcome; no downstream execution","observation":row},indent=2)+"\n")
        sys.exit(2)
    check_status=r.returncode
    if category=="control":
        r,row=invoke(name,"owned-current",[probe,source])
        if r.returncode!=0:
            (raw/"STOP.json").write_text(json.dumps(row,indent=2)+"\n");sys.exit(2)
    r,row=invoke(name,"emit",[compiler,source])
    if r.returncode!=check_status or (check_status and r.stdout):
        (raw/"STOP.json").write_text(json.dumps(row,indent=2)+"\n");sys.exit(2)
    target=raw/(name+"-named.c")
    sentinel=b"C236 existing named output must survive rejection\n"
    target.write_bytes(sentinel);before=target.stat()
    r,row=invoke(name,"named",[compiler,"--emit-c17-to",target,source])
    after=target.stat()
    row["same_bytes_inode_mtime"]=(target.read_bytes()==sentinel and before.st_ino==after.st_ino and before.st_mtime_ns==after.st_mtime_ns)
    row["temporary_residue"]=[p.name for p in raw.iterdir() if p.name.startswith(target.name+".")]
    (raw/"observations.json").write_text(json.dumps(rows,indent=2)+"\n")
    if r.returncode!=check_status or (check_status and (not row["same_bytes_inode_mtime"] or row["temporary_residue"])):
        (raw/"STOP.json").write_text(json.dumps(row,indent=2)+"\n");sys.exit(2)
print("C236 bounded cohort complete",len(rows),"observations; native/CI/Production edits 0",flush=True)
