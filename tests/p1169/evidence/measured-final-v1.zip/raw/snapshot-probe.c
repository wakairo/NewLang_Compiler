#include "newlang/parser.h"
#include "newlang/semantic.h"
#include "newlang/checked.h"
#include "semantic_internal.h"
#include "if_field_internal.h"
#include <assert.h>
#include <stdio.h>
int main(int argc, char **argv) {
    assert(argc==2);
    NLSource *s=NULL,*e=NULL; NLParser *p=NULL,*q=NULL;
    NLSyntaxTree *t=NULL,*u=NULL; NLSemanticContext *c=NULL;
    NLCheckedFragment *f=NULL;
    assert(nl_source_load(argv[1],&s)==NL_SOURCE_OK);
    assert(nl_parser_create(s,&p)==NL_PARSE_OK);
    assert(nl_parser_parse_function_unit(p,&t,NULL)==NL_PARSE_OK);
    assert(nl_semantic_create(&c)==NL_CHECK_OK);
    const NLSyntaxTree *units[]={t};
    assert(nl_semantic_register_function_unit(c,units,1,NULL)==NL_CHECK_OK);
    assert(nl_source_create("main()",6,"C238 owned snapshot census",&e)==NL_SOURCE_OK);
    assert(nl_parser_create(e,&q)==NL_PARSE_OK);
    assert(nl_parser_parse_expression_fragment(q,&u,NULL)==NL_PARSE_OK);
    assert(nl_semantic_check_expression(c,u,&f,NULL)==NL_CHECK_OK);
    const NLCheckedFragment *owner=nl_checked_call_body(f,nl_checked_root(f));
    assert(owner && !owner->copy_body);
    size_t extra=0,events=0;
    for(size_t id=1;id<=owner->count;++id) {
        const NLCheckedNodeView *v=nl_checked_node_view(owner,id);
        if(v->kind!=NL_CHECKED_LOOP)continue;
        const NLCheckedFragment *g=nl_checked_loop_body(owner,id);
        assert(g);
        for(const NLIfFieldProof *h=g->if_fields;h;h=h->next) {
            extra+=(h->entry!=NULL)+(h->post!=NULL)+(h->return_live!=NULL);
            for(size_t a=0;a<3;++a) {
                extra+=h->pending[a]!=NULL;
                for(const NLIfFieldTrace *x=h->first[a];x;x=x->next) {
                    ++events;extra+=(x->before!=NULL)+(x->after!=NULL);
                }
            }
        }
    }
    printf("C238 named-relation-and-canonical-contexts=19 existing-IF-extra=%zu events=%zu total=%zu\n",extra,events,19+extra);
    assert(extra==5 && events==3);
    nl_checked_destroy(f);nl_semantic_destroy(c);
    nl_syntax_tree_destroy(u);nl_parser_destroy(q);nl_source_destroy(e);
    nl_syntax_tree_destroy(t);nl_parser_destroy(p);nl_source_destroy(s);
    return 0;
}
