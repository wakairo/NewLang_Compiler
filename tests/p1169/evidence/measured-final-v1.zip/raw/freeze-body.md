Track: P

### C238 pre-execution source/oracle freeze v1

未変更main425（tree261a8e4）でbuildしたbaseline compiler SHA `63c3e9caee01cca663fd6a5f904d0aef0c986e49fa1b15e706b3bb9bff906908`。Production変更0、source実行前です。P1164原4+4+1はbyte不変で引き継ぎ、原oracleはpredecessor-oracle.jsonとして保全。新candidate向けoracleと区別します。追加P正例2（usize上限近くの一回・右field oldのalias chain）、負例8（phase shadow/equality guard/SUB/second writer/sibling writer/literal carry/zero step/carry type）、既存P1158対照1。計positive6/negative12/control2、認可内です。source/oracle/期待到達層/gate0 runnerの全文は別freeze・archiveに保全。新R入力未参照。

archive SHA **841e0c7017c5ebd38323eed05c60f210352274c5f41b12d0f962e411f4f3d51e**、freeze.json SHA **36cb869e3048e41fed5d9a7d649379dbcdb82306585ab43e3953c6dde0a2a705**、oracle SHA **088fb2cd256d9cca1edfe7844958eca8de43deedc837c8ed68a80f38c8ba0428**。baselineは正例のprecision拒否を予測、candidateは真正CHECK→public owned body→private current consumer→C17/native0を要求します。負例にはsource自体が合法でも今回未対応の形状を含み、失敗層を隠しません。原FIRSTを上書きしません。

`01-zero.nl` SHA `9d3c9346b95626c02c8512d613168f760516008bd3d1b32b48ad79bf5fd1bb35`
```text
struct CounterNode { head:u8, tag:u8 }
fn main()->unit {
 let original=CounterNode{head:u8(45),tag:u8(173)};
 let result=loop(cursor=usize(9)){
  if(cursor < usize(9)){
   let old=loan_write(original@head){|writer|replace(writer,u8(121))};
   let old_copy=old;
   old_copy;
   let during=original@head;
   let beside=original@tag;
   during;
   beside;
   continue(cursor + usize(3));
  }else{break cursor;}
 };
 let final=original@head;
 let peer=original@tag;
 let copied=result;
 unit
}
```

`02-one.nl` SHA `a22de79dbe495dcc634809c8f00a319c26440e7f1606157d746503995632bfa6`
```text
struct BeaconNode { marker:u8, level:u8 }
fn main()->unit {
 let original=BeaconNode{marker:u8(67),level:u8(156)};
 let result=loop(cursor=usize(2)){
  if(cursor < usize(4)){
   let old=loan_write(original@level){|writer|replace(writer,u8(98))};
   let old_copy=old;
   old_copy;
   let during=original@level;
   let beside=original@marker;
   during;
   beside;
   continue(cursor + usize(5));
  }else{break cursor;}
 };
 let final=original@level;
 let peer=original@marker;
 let copied=result;
 unit
}
```

`03-multiple.nl` SHA `1cedd7fb7a5d87b5598c86b1e634d8c43eb14385b0c0c90e0c7b132e4b3a2b85`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   let old=loan_write(original@latch){|writer|replace(writer,u8(203))};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   continue(cursor + usize(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

`04-same-bits.nl` SHA `3d3d4c3a2a55877c023bbdc3252e550fa05da0cb4cb84e88f47a82a80affbeee`
```text
struct ModeNode { peer:u8, mode:u8 }
fn main()->unit {
 let original=ModeNode{peer:u8(182),mode:u8(54)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(3)){
   let old=loan_write(original@mode){|writer|replace(writer,u8(54))};
   let old_copy=old;
   old_copy;
   let during=original@mode;
   let beside=original@peer;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@mode;
 let peer=original@peer;
 let copied=result;
 unit
}
```

`05-high-bound.nl` SHA `c31048223e6a8acd29a5a4559346768d64c9f0e47f9fd8e83ca2b736cb16040d`
```text
struct BoundaryNode { flag:u8, side:u8 }
fn main()->unit {
 let original=BoundaryNode{flag:u8(17),side:u8(214)};
 let result=loop(cursor=usize(18446744073709551613)){
  if(cursor < usize(18446744073709551614)){
   let old=loan_write(original@flag){|writer|replace(writer,u8(88))};
   let old_copy=old;
   old_copy;
   let during=original@flag;
   let beside=original@side;
   during;
   beside;
   continue(cursor + usize(1));
  }else{break cursor;}
 };
 let final=original@flag;
 let peer=original@side;
 let copied=result;
 unit
}
```

`06-alias-right.nl` SHA `a48f352265ba48ac927764ba61b15bdb05df0c471c8a1a184c15dd3463b881cb`
```text
struct TransitNode { marker:u8, level:u8 }
fn main()->unit {
 let original=TransitNode{marker:u8(236),level:u8(31)};
 let result=loop(cursor=usize(0)){
  if(cursor < usize(7)){
   let old=loan_write(original@level){|writer|replace(writer,u8(79))};
   let alias=old;
   let old_copy=alias;
   old_copy;
   let during=original@level;
   let beside=original@marker;
   during;
   beside;
   continue(cursor + usize(3));
  }else{break cursor;}
 };
 let final=original@level;
 let peer=original@marker;
 let copied=result;
 unit
}
```

`100-zero-step.nl` SHA `5a57326b3a2e970ca992cb9cdbf592535faa7bf082835620d36f678757e6f5e5`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   let old=loan_write(original@latch){|writer|replace(writer,u8(203))};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   continue(cursor + usize(0));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

`101-wrong-carry-type.nl` SHA `9e38d9f85913ce47132cf7257311e5570f1ce6b700fb78910765dbe2af0809f5`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   let old=loan_write(original@latch){|writer|replace(writer,u8(203))};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   continue(u8(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

`80-stutter-control.nl` SHA `c21827ac467cc9d22996c563005852b653d4fec10c0b450efbae1fac2ca8e6bb`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   continue(cursor + usize(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

`81-existing-return-control.nl` SHA `974ebaf3eec771c0dcca0832b59d26fc06596d88720d6cf18932cceeab6c946b`
```text
struct LatchPair { latch:u8, stamp:u8 }
fn main()->unit {
 let original=LatchPair{latch:u8(83),stamp:u8(151)};
 let result=usize(3);
 let copied=result;
 let decision=copied < usize(9);
 let old=if(decision){
  return unit;
 }else{
  loan_write(original@latch){|writer|replace(writer,u8(204))}
 };
 let updated=original@latch;
 let sibling=original@stamp;
 let old_copy=old;
 unit
}
```

`90-ending-reference.nl` SHA `1b560949b3c89d73bf038aaae2a62ffd10778c94ad1692d71df5b1d33f5601b7`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   let old=loan_write(original@latch){|writer|writer};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   continue(cursor + usize(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

`91-overflow.nl` SHA `63e5de4515428eadfa6d9035b2ae376be983fa9cc224fb97f06703acd112d0ef`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   let old=loan_write(original@latch){|writer|replace(writer,u8(203))};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   continue(cursor + usize(18446744073709551615));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

`92-incoming-type.nl` SHA `da572fc778e116e01390c7df213bcc567f3bb475d621f76a788758b4c3bd857f`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   let old=loan_write(original@latch){|writer|replace(writer,usize(203))};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   continue(cursor + usize(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

`93-read-mode.nl` SHA `7d28c48fe69330743d7200c379d2856bfc49d29a2f793d0a322e9f9eef40c3d0`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   let old=loan_read(original@latch){|writer|replace(writer,u8(203))};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   continue(cursor + usize(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

`94-phase-shadow.nl` SHA `65385a1d042978e039fe94e0d6c39bee52c91f047fba61033c3507065ab83e8c`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   let old=loan_write(original@latch){|writer|replace(writer,u8(203))};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   let cursor=usize(0);
   continue(cursor + usize(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

`95-wrong-arm.nl` SHA `d87f87f0eee3c8d867a36c3178bf81a94b77aa0a8d5c14b7cefe88580f4b386c`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor == usize(10)){
   let old=loan_write(original@latch){|writer|replace(writer,u8(203))};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   continue(cursor + usize(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

`96-subtract.nl` SHA `e28b76bbee8cc29024142176cf5964fbb75d21f7017ba29dbf6933362ec7bb93`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   let old=loan_write(original@latch){|writer|replace(writer,u8(203))};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   continue(cursor - usize(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

`97-second-writer.nl` SHA `686daf6e8dda6983f814cc94b02606e37f065ff322176131c0d40b43379c5ccf`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   let old=loan_write(original@latch){|writer|replace(writer,u8(203))};
   let other=loan_write(original@latch){|again|replace(again,u8(7))};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   continue(cursor + usize(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

`98-sibling-writer.nl` SHA `52f546bce0c5fb3c100e4b2233162bc580382e0524fe42d87a2ca4c65342f626`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   let old=loan_write(original@latch){|writer|replace(writer,u8(203))};
   let other=loan_write(original@echo){|again|replace(again,u8(7))};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   continue(cursor + usize(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

`99-literal-carry.nl` SHA `b210ba47be387152ae7602d300f32e9b6196024b1f4540f877b5395ee9269160`
```text
struct LatchNode { latch:u8, echo:u8 }
fn main()->unit {
 let original=LatchNode{latch:u8(112),echo:u8(39)};
 let result=loop(cursor=usize(1)){
  if(cursor < usize(10)){
   let old=loan_write(original@latch){|writer|replace(writer,u8(203))};
   let old_copy=old;
   old_copy;
   let during=original@latch;
   let beside=original@echo;
   during;
   beside;
   continue(usize(4));
  }else{break cursor;}
 };
 let final=original@latch;
 let peer=original@echo;
 let copied=result;
 unit
}
```

oracle:
```json
{
  "authority": "C238 main425; new candidate success expectations; C236 oracle retained separately unchanged",
  "independence": "P-owned values/source/expectations; no R1163 input or report used",
  "positive_prediction": {
    "canonical": "legal selected family",
    "candidate": "CHECK0 -> genuine owned -> private current consumer0 -> C17 -> native",
    "baseline": "expected precision3; actual FIRST retained separately",
    "fact_rule": "each actual Change refreshes child and ancestor root facts, even with equal scalar bits; sibling fact/incarnations unchanged"
  },
  "cases": {
    "01-zero": {
      "category": "positive",
      "canonical_legal": true,
      "headers": [
        9
      ],
      "backedges": 0,
      "loop_result": 9,
      "old_values": [],
      "iteration_current_values": [],
      "final_child": 45,
      "sibling": 173,
      "target_index": 0,
      "preserved_root_child_incarnations": true,
      "fresh_current_transitions": 0,
      "current_fact_numeric_ids": "not predicted or minted; must derive from actual state transition",
      "candidate_check": 0
    },
    "02-one": {
      "category": "positive",
      "canonical_legal": true,
      "headers": [
        2,
        7
      ],
      "backedges": 1,
      "loop_result": 7,
      "old_values": [
        156
      ],
      "iteration_current_values": [
        98
      ],
      "final_child": 98,
      "sibling": 67,
      "target_index": 1,
      "preserved_root_child_incarnations": true,
      "fresh_current_transitions": 1,
      "current_fact_numeric_ids": "not predicted or minted; must derive from actual state transition",
      "candidate_check": 0
    },
    "03-multiple": {
      "category": "positive",
      "canonical_legal": true,
      "headers": [
        1,
        5,
        9,
        13
      ],
      "backedges": 3,
      "loop_result": 13,
      "old_values": [
        112,
        203,
        203
      ],
      "iteration_current_values": [
        203,
        203,
        203
      ],
      "final_child": 203,
      "sibling": 39,
      "target_index": 0,
      "preserved_root_child_incarnations": true,
      "fresh_current_transitions": 3,
      "current_fact_numeric_ids": "not predicted or minted; must derive from actual state transition",
      "candidate_check": 0
    },
    "04-same-bits": {
      "category": "positive",
      "canonical_legal": true,
      "headers": [
        0,
        1,
        2,
        3
      ],
      "backedges": 3,
      "loop_result": 3,
      "old_values": [
        54,
        54,
        54
      ],
      "iteration_current_values": [
        54,
        54,
        54
      ],
      "final_child": 54,
      "sibling": 182,
      "target_index": 1,
      "preserved_root_child_incarnations": true,
      "fresh_current_transitions": 3,
      "current_fact_numeric_ids": "not predicted or minted; must derive from actual state transition",
      "candidate_check": 0
    },
    "90-ending-reference": {
      "category": "negative",
      "canonical_legal": false,
      "required_property": "ref result escapes the iteration loan; dependency rejection required if path reached",
      "fixed_check": "nonzero",
      "earlier_precision_rejection": "record actual diagnostic; it does not demonstrate the masked negative gate",
      "stdout": "empty on rejection",
      "named_output": "same bytes/inode/mtime; no temporary residue on rejection"
    },
    "91-overflow": {
      "category": "negative",
      "canonical_legal": false,
      "required_property": "first reachable continue computes usize(1)+MAX and must reject, never wrap",
      "fixed_check": "nonzero",
      "earlier_precision_rejection": "record actual diagnostic; it does not demonstrate the masked negative gate",
      "stdout": "empty on rejection",
      "named_output": "same bytes/inode/mtime; no temporary residue on rejection"
    },
    "92-incoming-type": {
      "category": "negative",
      "canonical_legal": false,
      "required_property": "replace current u8 with usize: exact type mismatch",
      "fixed_check": "nonzero",
      "earlier_precision_rejection": "record actual diagnostic; it does not demonstrate the masked negative gate",
      "stdout": "empty on rejection",
      "named_output": "same bytes/inode/mtime; no temporary residue on rejection"
    },
    "93-read-mode": {
      "category": "negative",
      "canonical_legal": false,
      "required_property": "replace through loan_read cannot obtain write access",
      "fixed_check": "nonzero",
      "earlier_precision_rejection": "record actual diagnostic; it does not demonstrate the masked negative gate",
      "stdout": "empty on rejection",
      "named_output": "same bytes/inode/mtime; no temporary residue on rejection"
    },
    "80-stutter-control": {
      "category": "control",
      "canonical_legal": true,
      "fixed_check": 0,
      "fixed_emit": 0,
      "fixed_named": 0,
      "headers": [
        1,
        5,
        9,
        13
      ],
      "loop_result": 13,
      "final_child": 112,
      "sibling": 39,
      "fresh_current_transitions": 0,
      "public_loop_validate": 0,
      "genuine_main_owner_validate": 0,
      "native": "NOT_RUN by C236 scope"
    },
    "05-high-bound": {
      "category": "positive",
      "canonical_legal": true,
      "headers": [
        18446744073709551613,
        18446744073709551614
      ],
      "backedges": 1,
      "loop_result": 18446744073709551614,
      "old_values": [
        17
      ],
      "iteration_current_values": [
        88
      ],
      "final_child": 88,
      "sibling": 214,
      "target_index": 0,
      "fresh_current_transitions": 1,
      "candidate_check": 0
    },
    "06-alias-right": {
      "category": "positive",
      "canonical_legal": true,
      "headers": [
        0,
        3,
        6,
        9
      ],
      "backedges": 3,
      "loop_result": 9,
      "old_values": [
        31,
        79,
        79
      ],
      "iteration_current_values": [
        79,
        79,
        79
      ],
      "final_child": 79,
      "sibling": 236,
      "target_index": 1,
      "fresh_current_transitions": 3,
      "candidate_check": 0
    },
    "94-phase-shadow": {
      "category": "negative",
      "canonical_legal": "some are legal but outside the promised finite ADD family",
      "required_property": "reject unsupported or invalid 94-phase-shadow",
      "candidate_check": "nonzero",
      "stdout": "empty on reject",
      "named": "unchanged bytes/inode/mtime; no residue"
    },
    "95-wrong-arm": {
      "category": "negative",
      "canonical_legal": "some are legal but outside the promised finite ADD family",
      "required_property": "reject unsupported or invalid 95-wrong-arm",
      "candidate_check": "nonzero",
      "stdout": "empty on reject",
      "named": "unchanged bytes/inode/mtime; no residue"
    },
    "96-subtract": {
      "category": "negative",
      "canonical_legal": "some are legal but outside the promised finite ADD family",
      "required_property": "reject unsupported or invalid 96-subtract",
      "candidate_check": "nonzero",
      "stdout": "empty on reject",
      "named": "unchanged bytes/inode/mtime; no residue"
    },
    "97-second-writer": {
      "category": "negative",
      "canonical_legal": "some are legal but outside the promised finite ADD family",
      "required_property": "reject unsupported or invalid 97-second-writer",
      "candidate_check": "nonzero",
      "stdout": "empty on reject",
      "named": "unchanged bytes/inode/mtime; no residue"
    },
    "98-sibling-writer": {
      "category": "negative",
      "canonical_legal": "some are legal but outside the promised finite ADD family",
      "required_property": "reject unsupported or invalid 98-sibling-writer",
      "candidate_check": "nonzero",
      "stdout": "empty on reject",
      "named": "unchanged bytes/inode/mtime; no residue"
    },
    "99-literal-carry": {
      "category": "negative",
      "canonical_legal": "some are legal but outside the promised finite ADD family",
      "required_property": "reject unsupported or invalid 99-literal-carry",
      "candidate_check": "nonzero",
      "stdout": "empty on reject",
      "named": "unchanged bytes/inode/mtime; no residue"
    },
    "100-zero-step": {
      "category": "negative",
      "canonical_legal": "some are legal but outside the promised finite ADD family",
      "required_property": "reject unsupported or invalid 100-zero-step",
      "candidate_check": "nonzero",
      "stdout": "empty on reject",
      "named": "unchanged bytes/inode/mtime; no residue"
    },
    "101-wrong-carry-type": {
      "category": "negative",
      "canonical_legal": "some are legal but outside the promised finite ADD family",
      "required_property": "reject unsupported or invalid 101-wrong-carry-type",
      "candidate_check": "nonzero",
      "stdout": "empty on reject",
      "named": "unchanged bytes/inode/mtime; no residue"
    },
    "81-existing-return-control": {
      "category": "control",
      "candidate_check": 0,
      "c17": "byte-identical baseline; existing P1158 contract",
      "native": "covered by old regression"
    }
  },
  "runner": "bounded source gate0 then targeted current/native/OOM/sanitizer and final GCC suite; no R inputs",
  "stop": "Unexpected CHECK acceptance or crash/no-clobber violation pauses affected execution; inspect read-only, preserve first result"
}
```

manifest:
```json
{
  "fixed_main": "425e7f6c8c54643765e861b8235620348a3c91a3",
  "tree": "261a8e404a1cf1982e13d3b94e3223d5da0e0499",
  "created_utc": "2026-11-05T02:49:56.064411+00:00",
  "baseline_sha256": "63c3e9caee01cca663fd6a5f904d0aef0c986e49fa1b15e706b3bb9bff906908",
  "files": {
    "gate0.py": "ea71a984b6e26180978743d8a7035b7a7d95db70d0522aac64b5fe9bd84539fd",
    "oracle.json": "088fb2cd256d9cca1edfe7844958eca8de43deedc837c8ed68a80f38c8ba0428",
    "predecessor-oracle.json": "f06e129ecee87af4ea98c342388a49ae400d7d3661d724873439ee69fba339cc",
    "prepare.py": "6eb4bafee66d4d35fe3cacff05b05538d6eecccf9a16bd6b73ff625374f240a6",
    "sources/01-zero.nl": "9d3c9346b95626c02c8512d613168f760516008bd3d1b32b48ad79bf5fd1bb35",
    "sources/02-one.nl": "a22de79dbe495dcc634809c8f00a319c26440e7f1606157d746503995632bfa6",
    "sources/03-multiple.nl": "1cedd7fb7a5d87b5598c86b1e634d8c43eb14385b0c0c90e0c7b132e4b3a2b85",
    "sources/04-same-bits.nl": "3d3d4c3a2a55877c023bbdc3252e550fa05da0cb4cb84e88f47a82a80affbeee",
    "sources/05-high-bound.nl": "c31048223e6a8acd29a5a4559346768d64c9f0e47f9fd8e83ca2b736cb16040d",
    "sources/06-alias-right.nl": "a48f352265ba48ac927764ba61b15bdb05df0c471c8a1a184c15dd3463b881cb",
    "sources/100-zero-step.nl": "5a57326b3a2e970ca992cb9cdbf592535faa7bf082835620d36f678757e6f5e5",
    "sources/101-wrong-carry-type.nl": "9e38d9f85913ce47132cf7257311e5570f1ce6b700fb78910765dbe2af0809f5",
    "sources/80-stutter-control.nl": "c21827ac467cc9d22996c563005852b653d4fec10c0b450efbae1fac2ca8e6bb",
    "sources/81-existing-return-control.nl": "974ebaf3eec771c0dcca0832b59d26fc06596d88720d6cf18932cceeab6c946b",
    "sources/90-ending-reference.nl": "1b560949b3c89d73bf038aaae2a62ffd10778c94ad1692d71df5b1d33f5601b7",
    "sources/91-overflow.nl": "63e5de4515428eadfa6d9035b2ae376be983fa9cc224fb97f06703acd112d0ef",
    "sources/92-incoming-type.nl": "da572fc778e116e01390c7df213bcc567f3bb475d621f76a788758b4c3bd857f",
    "sources/93-read-mode.nl": "7d28c48fe69330743d7200c379d2856bfc49d29a2f793d0a322e9f9eef40c3d0",
    "sources/94-phase-shadow.nl": "65385a1d042978e039fe94e0d6c39bee52c91f047fba61033c3507065ab83e8c",
    "sources/95-wrong-arm.nl": "d87f87f0eee3c8d867a36c3178bf81a94b77aa0a8d5c14b7cefe88580f4b386c",
    "sources/96-subtract.nl": "e28b76bbee8cc29024142176cf5964fbb75d21f7017ba29dbf6933362ec7bb93",
    "sources/97-second-writer.nl": "686daf6e8dda6983f814cc94b02606e37f065ff322176131c0d40b43379c5ccf",
    "sources/98-sibling-writer.nl": "52f546bce0c5fb3c100e4b2233162bc580382e0524fe42d87a2ca4c65342f626",
    "sources/99-literal-carry.nl": "b210ba47be387152ae7602d300f32e9b6196024b1f4540f877b5395ee9269160"
  }
}
```
