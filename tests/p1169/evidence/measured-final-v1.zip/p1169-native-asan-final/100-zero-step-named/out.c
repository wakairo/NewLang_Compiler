C238 named-output sentinel
