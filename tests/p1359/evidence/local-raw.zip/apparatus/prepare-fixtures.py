from pathlib import Path
import json

repo = Path('/workspace/p1359-c653/repo')
root = repo / 'tests/p1359'
root.mkdir(exist_ok=True)
base = Path('/workspace/p1358-c646/sources/B-two-calls.nl').read_text()
base = base.replace('    kept;\n    second_copy;\n',
                    '    let first_after = kept;\n    let second_after = second_copy;\n'
                    '    first_after;\n    second_after;\n')
(root/'A-two-inputs.nl').write_text(base)
other = base.replace('stable:u8, item:u8', 'item:u8, stable:u8')
other = other.replace('stable:u8(211), item:u8(17)', 'item:u8(23), stable:u8(173)')
other = other.replace('Packet { stable:value, item:u8(59) }', 'Packet { item:u8(61), stable:value }')
other = other.replace('usize(3)', 'usize(2)').replace('u8(197)', 'u8(233)')
other = other.replace('u8(43)', 'u8(91)').replace('u8(181)', 'u8(157)')
other = other.replace('spin_value', 'roll_input').replace('carry_value', 'wrap_input')
(root/'B-reversed-field.nl').write_text(other)
wrong = base.replace('let other = u8(181);', 'let other = usize(181);')
(root/'N-wrong-argument.nl').write_text(wrong)
ended = base.replace('    let argument = original@stable;',
                     '    let escaped = loan_write(original@item) { |slot| slot };\n'
                     '    escaped;\n    let argument = original@stable;')
(root/'N-ended-loan.nl').write_text(ended)
third = base.replace('    let first_after = kept;',
                     '    let third = carry_value(u8(99));\n    third;\n'
                     '    let first_after = kept;')
(root/'N-third-call.nl').write_text(third)
oracle = {
    'release':'C653', 'baseline':'acf775ea4bdeb39387730e302422f650d31ab5bd',
    'StageA':'actual CHECK0; exact root->main->two wrapper->each one inner; both current/Copy seals, distinct actual/formal/original/result; first free Copy survives in second entry and in post-second source bindings; affected negatives reject and restore',
    'A':{'inputs':[43,181], 'index':1, 'inner_initial':17, 'inner_current':197,
         'inner_sibling':211, 'backedges':3, 'wrapper_old':59,
         'wrapper_current':[43,181], 'wrapper_sibling':[43,181],
         'main_Copy_sequence':[43,43,181,181,43,181]},
    'B':{'inputs':[91,157], 'index':0, 'inner_initial':23, 'inner_current':233,
         'inner_sibling':173, 'backedges':2, 'wrapper_old':61,
         'wrapper_current':[91,157], 'wrapper_sibling':[91,157],
         'main_Copy_sequence':[91,91,157,157,91,157]},
    'negative':{'N-wrong-argument':'registration P3-TYPE-MISMATCH, rollback',
                'N-ended-loan':'registration P8-EXIT-DEPENDENCY, rollback',
                'N-third-call':'actual precision, nil entry, rollback'},
    'OOM':'fresh census; selected points for all four originals/readonly captures, two current attachment events, five Copy/custody seals and last allocation; each point must actually fire with OOM/nil/unchanged ownership and retry; every reached outer Copy allocation <=256 and inner <=64, for both invocations',
    'StageB':'after genuine StageA only: unedited raw/passive GCC/Clang O0/O2 for both sources 16 guests, plus passive ASan+LSan/UBSan4 =20; each live wrapper/inner original separate, temporal stack address reuse between invocations allowed; main Copy values after second invocation must be input1 then input2',
    'budgets':{'functional_candidates':4,'total_fixed':6,'host_configs':3,'local_guest':24},
    'P1358_FIRST_source_oracle':'unchanged; new source aliases expose actual post-second use; old B bytes preserved separately',
    'private_consumer_input':'only genuine immutable synchronous source CHECK output, no new raw signature/world tamper contract (C651/C649)',
}
(root/'oracle.json').write_text(json.dumps(oracle, indent=2)+'\n')
print('source fixtures and provisional oracle prepared; not executed')
