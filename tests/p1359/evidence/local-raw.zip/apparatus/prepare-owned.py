from pathlib import Path

repo = Path('/workspace/p1359-c653/repo')
source = (repo/'tests/p1355/owned.c').read_text().replace('P1355','P1359')
source = source.replace('input_at[2], input_end[2]', 'input_at[4], input_end[4]')
source = source.replace('seals[3], seal_count, init_at[2]', 'seals[5], seal_count, init_at[4]')
source = source.replace('copy_seals[3]', 'copy_seals[5]')
source = source.replace('seal_count < 3', 'seal_count < 5').replace('init_count < 2', 'init_count < 4')
source = source.replace('copy_seal_count < 3', 'copy_seal_count < 5')
source = source.replace('size_t slot = 2;', 'size_t slot = 4;').replace('input_count < 2', 'input_count < 4').replace('if (slot < 2)', 'if (slot < 4)')
source = source.replace('static P1359Frame frame(PInput *p, size_t index)', 'static P1359Frame frame(PInput *p, size_t index, size_t slot)')
source = source.replace('f.main_body->body_count == 1', 'f.main_body->body_count == 2 && slot < 2')
source = source.replace('f.wrapper_call = f.main_body->body_calls[0];', 'f.wrapper_call = f.main_body->body_calls[slot];')
start = source.index('static void rejected(')
end = source.index('static void attacks(',start)
source = source[:start]+'''static void rejected(PInput *p, size_t index, const char *label)
{
    NLCheckedFragment *main = (NLCheckedFragment *)nl_checked_call_body(p->entry, p->entry->root);
    /* Preserve original handles independently of intentionally changed views. */
    for (size_t slot = 0; slot < 2; ++slot) {
        NLCheckedFragment *wrapper = (NLCheckedFragment *)nl_h_custody_observe_body(main, main->body_calls[slot]);
        if (!wrapper || !wrapper->copy_body) continue;
        NLCheckedFragment *inner = (NLCheckedFragment *)nl_h_custody_observe_body(wrapper, wrapper->copy_body->current_call);
        if (!inner || !inner->copy_body) continue;
        NLLinearBreakView out, before;
        memset(&out, 0xa5, sizeof(out)); before=out;
        NLCheckStatus a=nl_linear_break_owner_validate(inner),
            b=nl_linear_break_validate(inner, inner->copy_body->current_loop, &out),
            c=nl_checked_copy_body_validate(wrapper, wrapper->copy_body->current_call, NULL),
            d=nl_checked_copy_body_validate(main, wrapper->copy_body->call, NULL);
        printf("negative %s slot%zu owner%d current%d innerCopy%d outerCopy%d\\n",label,slot,a,b,c,d);
        assert(a!=NL_CHECK_OK && b!=NL_CHECK_OK && c!=NL_CHECK_OK && d!=NL_CHECK_OK && !memcmp(&out,&before,sizeof(out)));
    }
    (void)index;
}
static void pair(PInput *p, size_t index)
{
    P1359Frame a=frame(p,index,0), b=frame(p,index,1);
    const NLCopyBodyProof *x=a.wrapper->copy_body,*y=b.wrapper->copy_body;
    assert(a.wrapper!=b.wrapper && a.inner!=b.inner && a.original!=b.original && a.current.root!=b.current.root);
    assert(x->view.function==y->view.function && x->readonly_parameter!=y->readonly_parameter &&
        a.inner->copy_body->readonly_parameter!=b.inner->copy_body->readonly_parameter &&
        a.outer_copy.result.value!=b.outer_copy.result.value);
    assert(nl_copy_plain(y->entry,a.outer_copy.result.value,a.outer_copy.result.type));
    const NLCheckedNodeView *second=nl_checked_node_view(b.main_body,b.wrapper_call);
    size_t after_first=0, after_second=0;
    for(size_t id=1;id<=a.main_body->count;++id) {
        const NLCheckedNodeView*n=nl_checked_node_view(a.main_body,id);
        if(n->kind!=NL_CHECKED_BINDING || n->span.start_byte<=second->span.end_byte) continue;
        NLCheckedNodeId origin=copy_origin(a.main_body,n->initializer);
        after_first+=origin==a.wrapper_call; after_second+=origin==b.wrapper_call;
    }
    assert(after_first && after_second);
    puts("distinct wrapper/inner/formal/result pairs; first free Copy retained at second entry and post-second bindings PASS");
}
''' + source[end:]
source = source.replace('P1359Frame f = frame(p, index);', 'P1359Frame f = frame(p, index, 0);\n    P1359Frame second = frame(p, index, 1);\n    pair(p, index);')
source = source.replace('P1359Frame foreign = frame(&other, index);','P1359Frame foreign = frame(&other, index, 0);')
source = source.replace('rejected(&f, label);', 'rejected(p, index, label);')
source = source.replace('(void)frame(p, index);','pair(p, index);')
marker='    CHANGE(NLCheckedNodeId, "main wrapper slot",'
pos=source.index(marker)
source=source[:pos]+'''    CHANGE(NLCheckedNodeId, "wrapper call order", f.main_body->body_calls[0], f.main_body->body_calls[1]);
    CHANGE(NLCheckedFragment *, "same-origin second wrapper in first slot", f.main_body->bodies[0], second.wrapper);
    CHANGE(NLValueId, "first result replaced by second result", f.main_body->nodes[f.wrapper_call-1].results[0].value, second.outer_copy.result.value);
    CHANGE(NLSymbolId, "second formal replaced by first", second.wrapper->copy_body->readonly_parameter, f.wrapper->copy_body->readonly_parameter);
''' + source[pos:]
# Calls to historical getters must keep canonical IDs even if the public call
# slot itself is modified. The rejected helper below is replaced with handles.
start=source.index('static void rejected(');end=source.index('static void pair(',start)
source=source[:start]+'''static P1359Frame challenged[2];
static void rejected(PInput *p, size_t index, const char *label)
{
    for(size_t slot=0;slot<2;++slot) {
        P1359Frame *f=&challenged[slot];
        NLLinearBreakView out,before; memset(&out,0xa5,sizeof(out));before=out;
        NLCheckStatus a=nl_linear_break_owner_validate(f->inner),
            b=nl_linear_break_validate(f->inner,f->loop,&out),
            c=nl_checked_copy_body_validate(f->wrapper,f->inner_call,NULL),
            d=nl_checked_copy_body_validate(f->main_body,f->wrapper_call,NULL);
        printf("negative %s slot%zu owner%d current%d innerCopy%d outerCopy%d\\n",label,slot,a,b,c,d);
        assert(a!=NL_CHECK_OK && b!=NL_CHECK_OK && c!=NL_CHECK_OK && d!=NL_CHECK_OK && !memcmp(&out,&before,sizeof(out)));
    }
    (void)p;(void)index;
}
''' + source[end:]
source=source.replace('    pair(p, index);\n    PInput other', '    pair(p, index);\n    challenged[0]=f; challenged[1]=second;\n    PInput other',1)
# New OOM census has both readonly wrappers, both inner calls and main.
start=source.index('    printf("CHECK census');end=source.index('    for (size_t i = 0; i < sizeof(targets)',start)
source=source[:start]+'''    printf("CHECK census%zu init-count%zu copy-seals%zu custody%zu current-attach%zu input-count%zu status%d\\n",
        total,init_count,copy_seal_count,seal_count,retain_count,input_count,status);
    assert(status==NL_CHECK_OK && init_count==4 && retain_count==2 && copy_seal_count==5 && seal_count==5 && input_count==4);
    pair(&p,index); p_dispose(&p);
    size_t targets[40]={1,2,total/2,total};size_t target_count=4;
    for(size_t k=0;k<4;++k) {
        targets[target_count++]=init_at[k]; targets[target_count++]=input_at[k]; targets[target_count++]=input_end[k];
        printf("readonly capture%zu [%zu,%zu], original init%zu\\n",k,input_at[k],input_end[k],init_at[k]);
    }
    for(size_t k=0;k<5;++k) {targets[target_count++]=copy_seals[k];targets[target_count++]=seals[k];}
    for(size_t k=0;k<2;++k) {targets[target_count++]=retain_at[k];printf("current attach%zu marker%zu\\n",k,retain_at[k]);}
    assert(target_count<=40);
''' + source[end:]
source=source.replace('i < sizeof(targets) / sizeof(targets[0])','i < target_count')
source=source.replace('(void)frame(&trial, index);','pair(&trial,index);')
source=source.replace('P1359Frame f = frame(&p, index);\n    for (size_t which = 0; which < 2; ++which) {',
'''P1359Frame frames[2]={frame(&p,index,0),frame(&p,index,1)};
    for(size_t slot=0;slot<2;++slot) {
    P1359Frame f=frames[slot];
    for (size_t which = 0; which < 2; ++which) {''')
source=source.replace('total_calls <= (which ? 8u : 128u)', 'total_calls <= (which ? 64u : 256u)')
source=source.replace('printf("validator%zu census status%d allocations%zu fired%d\\n", which,', 'printf("slot%zu validator%zu census status%d allocations%zu fired%d\\n", slot, which,')
source=source.replace('printf("validator%zu actual allocations%zu\\n", which, total_calls);', 'printf("slot%zu validator%zu actual allocations%zu\\n",slot,which,total_calls);')
source=source.replace('(void)frame(&p, index);', 'pair(&p,index);')
source=source.replace('    p_dispose(&p);\n    puts("nested call retained/sealed full rollback', '    }\n    p_dispose(&p);\n    puts("nested call retained/sealed full rollback')
source=source.replace('"p1347", "scope"', '"p1359", "scope"').replace('"P1343 actual main"','"P1359 actual main"')
(repo/'tests/p1359/owned.c').write_text(source)
print('owned/current/Copy negative + OOM apparatus prepared, not executed')
