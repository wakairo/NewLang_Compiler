Track: P — C649 STATIC FINAL / input-contract distinction

固定HEAD `072ac5e9aa10a671081e55b46164e66ef4f398db` / tree `7186728df24fd99162874ae74c0dd98e38e5fc41` だけを静的に照合しました。FのIssue/FIRST/審査資料は開いていません。compile/native/new harness/Production/push/new CIは0、全元証拠・候補は不変です。

1. **通常CLIの所有期間。** `main`→`compile_v0_to` はsourceを読み、contextをcreate/registerして、synthetic main()をCHECKします（main.c:4253/4283/4291/4336）。CHECK内部はcandidate cloneを検証・sealした後で `nl_sem_commit` し、その後にentryを返します（semantic_check.c:10345–10354）。commitは古いcontext配列を解放しますが、これは成功CHECKの返却前です。registered signature parametersはclone時にdeep copyされ、BODY planはretainされます（semantic.c:183–218/234）。返却後、対象のH-free wrapper経路はsyntaxのH/T分類、型getter、stack-local V0Program、v0_validate_callへ進みます。ここに登録・binding等のmutating API、context/world commit/交換、signature解放、ユーザーcallbackは見当たりません。helperはprogram/scratchを更新し、contextへ再commitしません。cleanupでentryをdestroyした後にcontext/signatureをdestroyします（main.c:4470–4480）。したがって調べた通常CLI経路では、この間のcurrent signature allocationは生存したままです。生成されたNewLang関数がcompiler hostへcallbackする機構でもありません。

2. **private consumerの契約と入口。** v0_validate_call/v1_call_parameter_kindはmain.c内staticで、CMakeはmain.cをCLI executableへ組み込み、checked_c_node公開libraryは別sourceです（CMakeLists:103–106）。通常CLIはsource path/entry selectorを受け取り、外部のchecked-artifact pointerやserialize済みworldを受け取りません。v1_call_parameter_kindのコメントも「actual owned synchronous body」「immutable registry」を前提にしています（main.c:2030）。public semantic.h:432–437はartifactがcontext meaningsをborrowし、lookup/access中はownerの生存を要求します。checked.h:238は成功artifactをimmutableとします。公開semantic APIで別途contextを更新できることと、その更新済みartifactをこのdriver-private関数へ投入できることは別です。context破棄後のlookupやprivate header経由のparameter allocation解放は、この通常CLIのinput contractにはありません。

   ただしstatic/constだけで全不正graphを安全にするわけではありません。テストはsupport.hでmain.cをincludeでき、同translation unitからprivate consumerを呼べます。将来これを外部/可変artifact用のAPIへ抽出するなら、現在のimmutable/fresh-registry前提を引き継ぐだけでは不十分です。

3. **順序の疑問と既存試験の正確な範囲。** Cの指摘どおり、readonly wrapper自身はlinear_breaksを持たないためmain.c:2255の前置owner検証を通らず、predicate_callとv1_call_parameter_kindがmain.c:2345のfull Copy validatorより先に来ます。predicate_callのnl_pure_u8_call→nl_pure_u8_contents_atもparameters[0]を読む可能性があります（c17_predicate_internal.h:48–69、pure_u8_internal.h:483–507）。NULL table/index/countのguardと、任意foreign allocationのextent認証は同じではありません。従って「CHECK後に真正内部worldをrawに改変したものをprivate consumerへ渡す」という条件での先行参照疑問は、public validatorの順序保証だけから否定できません。新probeを実行して到達/UAFを実証したとは主張しません。

   P1355 owned.c:222–317のNULL/short-foreign signature試験が呼ぶのは、**inner owner validator、inner current validator、inner Copy validator、outer wrapper Copy validatorの4つ**です。private v0_validate_call/predicate_call/v1_call_parameter_kindはtamper中に呼んでいません。support.hはmain.cをincludeしていますが、includeされていること自体はその経路の試験ではありません。positive frameではowner/current/Copy成功後にreadonly helperも確認しています。native.pyは真正な通常CLI inputを実行し、failure.py/p1332_cli_oomはallocation/write/flush failureを注入しますが、CHECK後signature pointerの差替え・解放を注入していません。既存p1332_consumerはprivate admissionのtamper/OOMを測りますが、direct zeroarg current calleeを対象にcurrent_loop/result等を変更し、readonly forwarding wrapperのshort signatureケースではありません。

4. **分類と次の選択。** 調べた通常CLIの生存期間・immutable fresh registryという既存trust boundaryの下では、この参照を安全にする所有期間が確認できます。ordinary source到達の不正CHECK0/UAFや、公開APIからの当該private-input経路は見つかっていません。したがって現時点の分類は **限定private入力をraw改変する場合の追加hardening候補／契約・試験範囲の不足** であり、実証された通常CLI wrong-code/UAFと同一視しません。一般soundnessや任意の壊れたhost graphの安全性PASSではありません。

   Cがprivate consumerにもこの改変入力へのfail-closedを必須とするなら、既存Copy/current validatorをwrapperのpredicate/parameter読みより前へ置く狭いhardeningが候補です。同じissued relationを使い、新issuer/worldは不要という静的見込みです。ただし前置validatorのOOM/resourceを正しく伝え、duplicate validationの費用、private-consumer向けshort-pointer/extent負例、no-clobber/retryを新認可内で実測する必要があります。C649では実装・compile・新試験をしていません。採用・hardening必須化の裁定はCへ返します。

P1355の以前の「NULL/short signature拒否」という記述は、上記4 validatorの測定範囲です。**private C17 consumerへの同tamper入力を測定済みという意味には拡張しません。** Required6/EARLY2の緑で、この未測定経路の契約確認を代替しません。

静的確認範囲: main.cのparameter/predicate/admission/CLI/cleanup、c17_predicate_internal.h、pure_u8_internal.h、semantic.cのclone/commit/destroy、semantic_check.cのCHECK返却、公開checked/semantic/checked_c_node headers、CMake target、P1355 owned/native/failure、P1280 supportとP1332 consumer/CLI injector。F/R資料は未読。

**VALUE-ALIGNMENT-RISK（技術結果と別）:** trusted fresh-artifact前提への依存を明示することと、全host-memory tamperを守ることは別です。認証済み関係を共通の前置境界へ集めれば監査範囲を整理する余地はありますが、追加検証allocation/OOMと維持費を伴います。ordinary-safe libraryの全writer/error/teardownやC比UB監査局所性は未実証。Product GO PAUSED / H1 HOLD。
